# S2 - Skills desde el catálogo (fuente GitHub + ciclo SDLC)

## Objetivo

Descargar la fuente del catálogo desde GitHub, seleccionar los 5 Skills base por dominio y simular el ciclo Discovery, Spec, Architecture, Implementation y DoD sobre HU-01 y HU-05, sin empezar de cero: contrato desde `docs/ENDPOINTS.md` y pruebas desde `docs/TESTING.md`.

## Materiales

- `reqflow-workspace/` con tus 3 repos propios; los comandos se ejecutan desde ahí.
- `workshop-auth-backend/.github/skills/feature-intake-spec-checklist` (S1).
- Los 5 Skills base de ReqFlow ya instalados en los repositorios remotos.
- `workshop-auth-backend/HU-01.md` (generada en S1) y `workshop-login-frontend/HU-05.md` (generada igual desde el `HALLAZGOS.md` del frontend). Solo si tu `HALLAZGOS.md` no tiene esos hallazgos "Pendiente", usa las versiones de referencia: `s1_skills/HU-01.md` y `s2_templates/HU-05.md`.

## Catálogo de Skills

Los cinco Skills del catálogo, junto al de S1, viven en `.github/skills/` para que Copilot los descubra. Descarga la fuente desde GitHub, consulta `SKILLS-MANIFEST.json` y selecciona los Skills según su dominio. Sincroniza los Skills ya instalados antes de comenzar el ciclo SDLC.

| Dominio | Skills a seleccionar |
| --- | --- |
| quality | `discovery-analysis`, `issue-implementation` |
| specification | `spec-writing` |
| architecture | `architecture-decision` |
| review | `reqflow-definition-of-done` |

No se copian artefactos externos sin validar su alcance o licencia. El catalogo central es la fuente de trabajo del laboratorio.

El SDD de S2 es un insumo practico para el resto del dia. No sustituye un proceso completo de SDD fuera del alcance de este laboratorio.

## Pasos

Sigue `STEP-BY-STEP.md` en orden:

| Paso | Qué hace |
| --- | --- |
| 01 | Verifica prerrequisitos: 3 repos + Skill de S1 |
| 02 | Descarga la fuente del catálogo desde GitHub |
| 03 | Lista los dominios y selecciona los Skills en `SKILLS-MANIFEST.json` |
| 04 | Sincroniza (`pull`) los Skills instalados por el bot |
| 05 | Discovery con `discovery-analysis` |
| 06 | Spec con `spec-writing` |
| 07 | Architecture con `architecture-decision` |
| 08 | Implementation con `issue-implementation` |
| 09 | Review con `reqflow-definition-of-done` y decisión |
| 10 | Versiona: commit y tag `lab02-s2` |

## Evidencia mínima

- `.github/skills/` con los 5 Skills del catálogo junto al de S1 en cada repo.
- Contrato API, cambios de HU-01/HU-05, matriz de pruebas y `SDLC-EVIDENCE.md` por repo cambiado.
- Commit y tag `lab02-s2`; enlace al issue del Project ReqFlow correspondiente.

## Criterio de aceptación

Cada repo remoto contiene los 5 Skills instalados; `workshop-auth-backend` trae los cambios de HU-01 y `workshop-login-frontend` los de HU-05, cada uno con su `SDLC-EVIDENCE.md` y revisión con decisión explícita (approved, changes_requested o blocked).
