// One formula shared by the API and UI. Unsupported checks never count as failures.
export function evaluationScores(run){
 const ready=['passed','failed'].includes(run?.status),scenarios=run?.result?.scenarios?.filter(s=>s.status!=='unsupported')||[];
 const flowPercent=ready&&scenarios.length?Math.round(100*scenarios.filter(s=>s.status==='passed').length/scenarios.length):null;
 const roles=run?.result?.quality?.roles||[];
 const qualityPercent=ready&&roles.length===6&&roles.every(r=>Number.isFinite(r.score))?Math.round(roles.reduce((sum,r)=>sum+r.score,0)/6):null;
 return {flowPercent,qualityPercent,totalPercent:flowPercent===null||qualityPercent===null?null:Math.round(.4*flowPercent+.6*qualityPercent)};
}
