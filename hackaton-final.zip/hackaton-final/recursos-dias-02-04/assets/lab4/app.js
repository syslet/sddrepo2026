import {createStorage} from '../lab3/storage.js';
import {stages,agenda,ROLES,ROLE_IDS,LABS,emptySnapshot,FLOW_VERSION,templateUrl,forkUrl,pullRequestUrl} from './scenario.js';
const $=id=>document.getElementById(id);
const LOGIN=/^[a-z\d](?:[a-z\d-]{0,37}[a-z\d])?$/i;
// assignment: equipo asignado por el administrador (GET /api/lab4-team). undefined = aún sin respuesta, null = sin equipo.
let identity,storage,snapshot,index=0,overview=true,activeStep='',dashboard,routeSerial=0,assignment,assignmentError=false,roleAssignments={},savingRole=false;

/* ---------- Arranque ---------- */
const bootPhases=['account','session'];
const bootLabels={account:'Comprobando el acceso a tu cuenta…',session:'Recuperando tu avance, rol y equipo…'};
function phase(name){
 const current=bootPhases.indexOf(name);$('boot-message').textContent=bootLabels[name];
 document.querySelectorAll('[data-boot-step]').forEach((node,i)=>{node.dataset.state=i<current?'done':i===current?'current':'pending';node.firstElementChild.className=i===current?'loading loading-spinner loading-sm':'boot-step-icon';node.querySelector('small').textContent=i<current?'Listo':i===current?'Preparando…':'Pasos, rol y equipo';});
}
const slowTimer=setTimeout(()=>{$('boot-slow').hidden=false;},8000);
$('boot-retry').onclick=()=>location.reload();
function bootError(error){
 clearTimeout(slowTimer);$('lab-boot').setAttribute('aria-busy','false');$('boot-slow').hidden=true;
 $('boot-title').textContent=error.login?'Inicia sesión para continuar':'No se pudo abrir el laboratorio';
 $('boot-message').textContent=error.name==='TimeoutError'?'La conexión tardó demasiado. Puedes volver a intentarlo.':error.message;
 $('boot-error-text').hidden=Boolean(error.login);$('boot-login').hidden=!error.login;$('boot-error').hidden=false;
 document.querySelectorAll('[data-boot-step]').forEach(node=>{if(node.dataset.state==='current'){node.dataset.state='error';node.firstElementChild.className='boot-step-icon';node.querySelector('small').textContent='No completado';}});
}
function normalize(saved){
 const base=emptySnapshot();
 if(!saved||typeof saved!=='object'||saved.flowVersion!==FLOW_VERSION)return base;
 const fit=list=>stages.map((_,i)=>Array.isArray(list)&&list[i]===true);
 const evidence=Object.fromEntries(Object.entries(saved.evidence&&typeof saved.evidence==='object'&&!Array.isArray(saved.evidence)?saved.evidence:{}).filter(([key,value])=>typeof value==='string'&&!key.endsWith('.captain')));
 return {...saved,flowVersion:FLOW_VERSION,cwd:base.cwd,completed:fit(saved.completed),approved:fit(saved.approved),files:{},history:[],branch:typeof saved.branch==='string'?saved.branch:'main',staged:saved.staged===true,committed:saved.committed===true,tagged:saved.tagged===true,evidence};
}
function save(changes){snapshot={...snapshot,...changes};storage.save(snapshot);}
function track(type,details={}){storage?.track(type,{stepId:activeStep,...details});}
function visit(i){activeStep=stages[i].id;track('step_view',{label:stages[i].title,target:activeStep});}

/* ---------- Datos del participante ---------- */
// El líder sale solo de la asignación del servidor, nunca de la evidencia guardada.
function teamValue(session,key){if(key==='captain')return assignment?.leader||'';if(key==='role')return Object.entries(roleAssignments).find(([,login])=>login.toLowerCase()===identity.user.login.toLowerCase())?.[0]||'';return snapshot.evidence[`${session}.${key}`]||'';}
function fill(text,session){
 const captain=teamValue(session,'captain'),role=teamValue(session,'role');
 return text.replaceAll('{capitan}',captain||'<líder>').replaceAll('{rol}',role||'<rol>').replaceAll('{usuario}',identity.user.login).replaceAll('{origen}',assignment?.isLeader?captain:identity.user.login).replaceAll('{head}',`${assignment?.isLeader?'':identity.user.login+':'}agents/${role||'<rol>'}`);
}

/* ---------- Utilidades de interfaz ---------- */
function el(tag,props,...kids){
 const node=document.createElement(tag);
 if(props)for(const [key,value] of Object.entries(props)){if(value===null||value===undefined||value===false)continue;if(key==='class')node.className=value;else if(key==='text')node.textContent=value;else node.setAttribute(key,value===true?'':String(value));}
 for(const kid of kids.flat()){if(kid===null||kid===undefined||kid===false)continue;node.append(kid.nodeType?kid:document.createTextNode(String(kid)));}
 return node;
}
function color(node,text){for(const token of text.split(/("[^"]*"|'[^']*'|<[^>\s]+>|(?:^|(?<=\s))--?[\w-]+)/g)){if(!token)continue;node.append(el('span',{class:/^['"]/.test(token)?'literal':/^</.test(token)?'l4-placeholder':/^--?/.test(token)?'flag':null,text:token}));}}
async function copyText(text){
 try{await navigator.clipboard.writeText(text);return;}catch{}
 const input=document.createElement('textarea'),focused=document.activeElement;input.value=text;input.style.cssText='position:fixed;top:0;left:0;opacity:0';
 // A modal only allows focus inside itself.
 const parent=$('help').open?$('help'):document.body;parent.append(input);input.focus();input.select();
 try{if(!document.execCommand('copy'))throw Error('copy_failed');}finally{input.remove();focused?.focus({preventScroll:true});}
}
function icon(kind){
 const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');
 for(const [name,value] of Object.entries({viewBox:'0 0 24 24',width:'16',height:'16',fill:'none',stroke:'currentColor','stroke-width':'1.7','aria-hidden':'true',focusable:'false'}))svg.setAttribute(name,value);
 svg.innerHTML=kind==='copy'?'<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V4a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h4"/>':kind==='check'?'<path d="M5 12.5l4.5 4.5L19 7.5"/>':'<path d="M7 17 17 7M9 7h8v8"/>';
 return svg;
}
function showHelp(title,why,{command,parts=[],output=[],issues=[],actions=[],partsTitle='Qué significa cada parte',expectedTitle='Qué observar',copy}={}){
 track('help_open',{label:title.slice(0,160)});
 $('help-title').textContent=title;$('help-content').replaceChildren(el('p',{text:why}));
 const section=(heading,items)=>{if(!items.length)return;$('help-content').append(el('h3',{text:heading}),el('ul',null,items.map(text=>el('li',{text}))));};
 section('Cómo realizar este paso',actions);
 if(command)$('help-content').append(el('pre',{tabindex:'0',text:command}));
 section(partsTitle,parts);section(expectedTitle,output);section('Qué revisar si algo no coincide',issues);
 activeCopy=copy||'';$('prompt-actions').hidden=!copy;$('prompt-copy-status').textContent='';$('copy-prompt').textContent='Copiar';
 $('help').showModal();
}
let activeCopy='';
$('copy-prompt').onclick=async()=>{try{await copyText(activeCopy);track('command_copy',{target:activeCopy,label:'Copiado desde la ayuda'});$('copy-prompt').textContent='Copiado';$('prompt-copy-status').textContent='Texto copiado.';}catch{track('copy_failed',{target:activeCopy,label:'Copia fallida'});$('prompt-copy-status').textContent='Selecciona el texto para copiarlo manualmente.';}};
$('help').addEventListener('click',event=>{if(event.target!==$('help'))return;const r=$('help').getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)$('help').close();});

/* ---------- Guía ---------- */
function renderNav(){
 const groups=agenda.map(group=>{
  const members=stages.map((stage,i)=>({stage,i})).filter(({stage})=>stage.session===group.id);
  const done=members.filter(({i})=>snapshot.completed[i]).length;
  const count=el('span',{class:'session-count','aria-label':`${done} de ${members.length} pasos marcados`,text:`${done}/${members.length}`});
  return el('li',{class:'session-group'},el('h2',null,el('span',{text:group.title}),count),el('ol',null,members.map(({stage,i},n)=>{
   const button=el('button',{type:'button','data-state':snapshot.completed[i]?'done':'pending','aria-current':!overview&&i===index?'step':null},el('span',{class:'s2-step-num',text:String(n+1).padStart(2,'0')}),el('span',{text:stage.title}),el('small',{text:snapshot.completed[i]?'Marcado':'Pendiente'}));
   button.onclick=()=>openStage(i);return el('li',null,button);
  })));
 });
 $('steps').replaceChildren(...groups);
 const marked=snapshot.completed.filter(Boolean).length;
 $('progress-count').replaceChildren(String(marked)+' ',el('span',{text:`de ${stages.length} pasos marcados`}));
 $('day-progress').max=stages.length;$('day-progress').value=marked;
 $('getting-started').setAttribute('aria-current',overview?'page':'false');
 renderLeaderSetup();renderTeamBar(overview?null:stages[index]);
}
function teamState(){return assignment?(assignment.isLeader?'leader':'member'):assignment===null?'pending':assignmentError?'error':'loading';}
const POSITION={leader:'Eres el líder',member:'Eres integrante',pending:'Sin asignación',error:'Sin datos',loading:'Cargando…'};
function setPosition(node){const state=teamState();node.dataset.position=state;node.textContent=POSITION[state];}
function teamName(){return assignment?.name||(assignment===null?'Pendiente de asignación':assignmentError?'No disponible':'Cargando…');}
function leaderNode(){
 if(!assignment)return document.createTextNode(assignment===null?'Pendiente de asignación':assignmentError?'No disponible':'Cargando…');
 const link=el('a',{class:'l4-handle',href:'https://github.com/'+assignment.leader,target:'_blank',rel:'noopener',title:'@'+assignment.leader},assignment.leaderName&&el('span',{class:'l4-handle-name',text:assignment.leaderName}),el('span',{class:'l4-handle-login',text:'@'+assignment.leader}),el('span',{class:'s2-sr',text:' (perfil de GitHub, se abre en otra pestaña)'}));
 return assignment.isLeader?el('span',null,link,el('span',{class:'l4-you',text:' · tú'})):link;
}
function external(label,href,primary){return el('a',{class:primary?'btn primary':'btn',href,target:'_blank',rel:'noopener'},label,icon('external'),el('span',{class:'s2-sr',text:' (se abre en otra pestaña)'}));}
function renderRoleSelect(){
 const select=$('role-select'),role=teamValue('s1','role');
 select.value=ROLE_IDS.includes(role)?role:'';
 select.disabled=savingRole||!assignment;
 select.options[0].textContent=assignment?'Elige tu rol':'Requiere equipo asignado';
 for(const option of select.options){
  const owner=roleAssignments[option.value];
  option.disabled=!option.value||Boolean(owner&&owner.toLowerCase()!==identity.user.login.toLowerCase());
  if(option.value)option.textContent=`${option.value} · ${owner?'@'+owner:'disponible'}`;
 }
}
function renderTeamBar(stage){
 const status=$('team-bar-status');status.hidden=!stage;$('leader-status').hidden=Boolean(stage);
 if(!stage)return;
 const leader=teamValue(stage.session,'captain'),role=teamValue(stage.session,'role'),repo=LABS[stage.session].id;
 if(leader)status.replaceChildren(`${stage.session.toUpperCase()} · repo del equipo: `,el('a',{href:`https://github.com/${leader}/${repo}`,target:'_blank',rel:'noopener'},el('code',{text:`${leader}/${repo}`})),' · ',role?el('span',null,'tu rol: ',el('code',{text:role})):el('strong',{text:`elige tu rol en «Antes de empezar» para completar los comandos.`}));
 else status.textContent=assignmentError&&assignment===undefined?'No se pudo consultar tu equipo. Pulsa Actualizar.':'Pendiente de asignación: el administrador aún no te asignó a un equipo. Los comandos muestran <líder> hasta entonces.';
}
function renderLinks(stage){
 const captain=teamValue(stage.session,'captain'),state=teamState();
 const links=(stage.links||[]).filter(link=>!link.audience||link.audience===state);
 const role=teamValue(stage.session,'role');
 if(stage.id.endsWith('-11')&&assignment&&role)links.unshift({href:pullRequestUrl(stage.session,assignment.leader,identity.user.login,role,assignment.isLeader),label:'Abrir mi PR hacia el líder',primary:true});
 $('stage-links').hidden=!links.length;
 $('stage-links').replaceChildren(...links.map(link=>{
  if(link.href.includes('{capitan}')&&!captain)return el('span',{class:'btn l4-link-disabled','aria-disabled':'true',title:'Disponible cuando el administrador te asigne a un equipo'},link.label);
  const href=link.href.startsWith('https://github.com/new?')?templateUrl(stage.session,identity.user.login):fill(link.href,stage.session);
  return external(link.label,href,link.primary);
 }));
}
function leaderOnlyNote(stage){
 const repo=LABS[stage.session].id;
 return assignment
  ?{kind:'note',label:'Este paso lo hace tu líder',text:`@${assignment.leader} crea ${assignment.leader}/${repo} desde la plantilla.\nCuando exista, crea un fork de ese repo en tu cuenta.`,why:'El repo del líder es el repo del equipo. Los integrantes trabajan en forks y envían sus PR al main del líder. Un repo independiente desde la plantilla no sirve para este flujo.'}
  :{kind:'note',label:'Pendiente de asignación',text:'El administrador aún no te asignó a un equipo.\nCuando lo haga, verás aquí si este paso te corresponde.',why:'Solo el líder asignado crea el repositorio del equipo. Nadie se designa líder desde esta página.'};
}
function renderCommands(stage){
 const items=stage.leaderOnly&&!assignment?.isLeader?[leaderOnlyNote(stage)]:stage.commands.filter(command=>!command.audience||command.audience===teamState());
 const prompts=items.some(command=>command.kind==='file');
 $('guide-heading').textContent=!items.length?'Sigue los pasos de arriba':prompts?'Comandos y archivos de la guía':'Comandos de la guía';
 $('commands').replaceChildren(...items.map((command,i)=>{
  const text=fill(command.text,stage.session),li=el('li',{'data-kind':command.kind});
  const body=el('div',{class:'l4-cmd'});
  const label=el('div',{class:'l4-cmd-label',text:command.label});
  const code=el('code',{class:command.kind==='command'?null:'guide-prompt'});
  if(command.kind==='command')color(code,text);else code.textContent=text;
  body.append(label,el('pre',{class:command.kind==='command'?'l4-command-code':'l4-file',tabindex:'0'},code));
  const actions=el('div',{class:'s2-command-actions'});
  if(command.kind!=='note'){
   const copy=el('button',{class:'btn command-copy-action',type:'button',title:'Copiar','aria-label':`Copiar: ${command.label}`},icon('copy'));
   copy.onclick=async()=>{try{await copyText(text);track('command_copy',{target:text,label:command.label});copy.replaceChildren(icon('check'));$('command-feedback').textContent=text.includes('<')?'Copiado. Sustituye los valores entre < > antes de ejecutarlo.':'Copiado.';setTimeout(()=>copy.replaceChildren(icon('copy')),1500);}catch{track('copy_failed',{target:text,label:command.label});$('command-feedback').textContent='No se pudo copiar. Selecciona el texto para copiarlo manualmente.';}};
   actions.append(copy);
  }
  const help=el('button',{class:'btn command-explain-action',type:'button',title:'Explicación','aria-label':`Explicar: ${command.label}`,'aria-haspopup':'dialog',text:'?'});
  help.onclick=()=>showHelp(command.label,fill(command.why,stage.session),{command:text,parts:(command.parts||[]).map(p=>fill(p,stage.session)),output:(command.output||[]).map(p=>fill(p,stage.session)),issues:(command.issues||[]).map(p=>fill(p,stage.session)),expectedTitle:command.kind==='file'?'Resultado esperado':'Qué observar al ejecutar',copy:command.kind==='note'?'':text});
  actions.append(help);li.append(body,actions);return li;
 }));
 $('command-feedback').textContent=items.some(command=>command.kind==='command')?'Ejecuta los comandos en tu terminal, desde la carpeta indicada. Esta web no ejecuta nada.':'';
}
function renderStage(){
 const stage=stages[index],siblings=stages.filter(item=>item.session===stage.session),position=siblings.indexOf(stage);
 $('position').textContent=`${LABS[stage.session].title} · Paso ${position+1} de ${siblings.length}`;
 $('title').textContent=fill(stage.title,stage.session);$('description').textContent=fill(stage.description,stage.session);$('who').textContent=stage.who;
 renderLinks(stage);renderCommands(stage);
 $('check-list').replaceChildren(...stage.check.map(text=>el('li',{text:fill(text,stage.session)})));
 const done=snapshot.completed[index],last=index===stages.length-1;
 $('prev').disabled=index===0;$('undo').hidden=!done;
 $('next').textContent=done?(last?'Laboratorio marcado':'Siguiente paso'):last?'Marcar como hecho':'Marcar como hecho y seguir';
 $('next').disabled=done&&last;
 if(!$('feedback').dataset.keep)$('feedback').textContent=done?'Marcaste este paso como hecho. Es tu avance declarado; no verifica tu repositorio.':'Cuando termines, márcalo. Marcar registra tu avance declarado; no verifica tu repositorio.';
 delete $('feedback').dataset.keep;
}
function render(){
 $('team-panel').hidden=!overview;
 $('work-layout').classList.toggle('show-overview',overview);
 $('overview').hidden=!overview;$('stage').hidden=overview;
 renderNav();if(!overview)renderStage();
}
function openStage(i,{focus=true,keepHash=false}={}){
 overview=false;index=i;visit(i);render();
 if(!keepHash)history.replaceState(null,'','#'+stages[i].id);
 if(focus){$('stage').focus({preventScroll:true});scrollTo({top:0});}
}
function openOverview(){overview=true;history.replaceState(null,'','#guia');render();$('overview').focus({preventScroll:true});scrollTo({top:0});}
$('getting-started').onclick=openOverview;
$('begin-lab').onclick=()=>{const first=stages.findIndex((stage,i)=>stage.session==='s1'&&!snapshot.completed[i]);openStage(first<0?0:first);};
$('explain').onclick=()=>{const stage=stages[index],x=stage.explanation;showHelp(fill(stage.title,stage.session),fill(x.why,stage.session),{actions:x.actions.map(t=>fill(t,stage.session)),output:x.output.map(t=>fill(t,stage.session)),issues:x.issues.map(t=>fill(t,stage.session)),expectedTitle:'Cómo comprobar el paso'});};
$('prev').onclick=()=>{if(index>0)openStage(index-1);};
$('next').onclick=()=>{
 const done=snapshot.completed[index];
 if(!done){const completed=snapshot.completed.slice();completed[index]=true;save({completed});}
 if(index<stages.length-1){track('step_next',{label:done?'Siguiente paso':'Paso marcado y siguiente'});$('feedback').textContent=done?'':'Paso anterior marcado como hecho.';$('feedback').dataset.keep=done?'':'1';openStage(index+1);}
 else{$('feedback').textContent='Marcaste el último paso. Revisa que tu PR esté abierto o integrado en el repo del líder.';$('feedback').dataset.keep='1';render();}
};
$('undo').onclick=()=>{const completed=snapshot.completed.slice();completed[index]=false;save({completed});$('feedback').textContent='Paso desmarcado.';$('feedback').dataset.keep='1';render();};

/* ---------- Barra de equipo ---------- */
{
 const select=$('role-select');
 select.append(...ROLES.map(role=>el('option',{value:role.id,text:`${role.id} · agents/${role.id}.py`})));
 select.addEventListener('change',async()=>{
  const role=select.value;
  savingRole=true;select.disabled=true;$('role-save-status').textContent='Guardando tu rol para CrewAI y Guardrails…';
  try{
   const response=await fetch('/api/lab4-role',{method:'PUT',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({role}),signal:AbortSignal.timeout(10000)});
   const data=await response.json();
   if(!response.ok)throw Error(data.message||'No se pudo guardar tu rol. Reintenta.');
   roleAssignments=data.roles;
   $('role-save-status').textContent='';
  }catch(error){await loadAssignment();$('role-save-status').textContent=error.message;}
  finally{savingRole=false;render();}
 });
}

function renderLeaderSetup(){
 const state=teamState();
 $('team-panel').dataset.state=state;
 $('assigned-team').textContent=assignment?.table?`${teamName()} · ${assignment.table}`:teamName();$('assigned-leader').replaceChildren(leaderNode());setPosition($('assigned-position'));
 renderRoleSelect();
 $('leader-status').textContent=assignmentError
  ?(assignment?'No se pudo actualizar tu asignación; se muestra la última conocida.':'No se pudo consultar tu asignación. Pulsa Actualizar.')
  :{leader:'Creas los repos públicos crewai y guardrails en tu cuenta desde las plantillas, compartes sus enlaces y también eliges un único rol para CrewAI y Guardrails.',member:`Tu líder crea los repos públicos. Crea tus forks de ${assignment?.leader}/crewai y ${assignment?.leader}/guardrails, clónalos y elige un único rol para CrewAI y Guardrails.`,pending:'El administrador aún no te asignó a un equipo. Tu equipo, su líder y tu participación aparecerán aquí automáticamente.',loading:''}[state];
 for(const session of agenda){
  const lab=LABS[session.id],name=assignment?`${assignment.leader}/${lab.id}`:null;
  const start=$(lab.id+'-repo-start');
  start.textContent=assignment?.isLeader?'Crear mi repo desde la plantilla':assignment?`Integrante: crear mi fork de ${lab.id}`:'Pendiente de asignación';
  if(assignment){start.href=assignment.isLeader?templateUrl(session.id,identity.user.login):forkUrl(session.id,assignment.leader);start.removeAttribute('aria-disabled');}
  else{start.removeAttribute('href');start.setAttribute('aria-disabled','true');}
  $(lab.id+'-team-repo').replaceChildren(name
   ?el('a',{href:'https://github.com/'+name,target:'_blank',rel:'noopener'},el('code',{text:name}))
   :el('code',{class:'l4-pending-code',text:`<líder>/${lab.id}`}));
  const role=teamValue(session.id,'role');
  $(lab.id+'-repo-guide').replaceChildren(...(assignment?[
   el('p',{text:assignment.isLeader?`Pulsa Create repository para crear ${identity.user.login}/${lab.id}.`:`Pulsa Create fork. Tu copia de ${name} se llamará ${identity.user.login}/${lab.id}.`}),
   el('p',{text:role?`Rama: agents/${role}. Haz push y abre «${assignment.isLeader?'Abrir mi PR a main':'Abrir mi PR hacia el líder'}».`:'Elige tu rol arriba para obtener el enlace de tu PR.'})
  ]:[]));
  $(lab.id+'-team-actions').replaceChildren(...(name?[
   assignment.isLeader&&external('Crear mi repo desde la plantilla',templateUrl(session.id,identity.user.login),true),
   external(assignment.isLeader?'Abrir mi repo':'Abrir mi fork',`https://github.com/${identity.user.login}/${lab.id}`),
   role&&external(assignment.isLeader?'Abrir mi PR a main':'Abrir mi PR hacia el líder',pullRequestUrl(session.id,assignment.leader,identity.user.login,role,assignment.isLeader),!assignment.isLeader),
   !assignment.isLeader&&external('Abrir repo del líder',`https://github.com/${name}`),
   external('Pull requests',`https://github.com/${name}/pulls`)
  ].filter(Boolean):[]));
 }
}
function readAssignment(data){
 const team=data?.team;
 if(team===null)return null;
 if(!team||typeof team.name!=='string'||!team.name.trim()||!LOGIN.test(team.leader||'')||typeof team.isLeader!=='boolean')throw Error('invalid_assignment');
 return {id:team.id,name:team.name.trim(),leader:team.leader,leaderName:typeof team.leaderName==='string'?team.leaderName:null,table:typeof team.table==='string'?team.table:null,isLeader:team.isLeader};
}
async function loadAssignment(){
 $('assignment-retry').disabled=true;
 try{
  const response=await fetch('/api/lab4-team',{credentials:'same-origin',cache:'no-store',signal:AbortSignal.timeout(10000)});
  if(!response.ok)throw Error('assignment_unavailable');
  const data=await response.json(),next=readAssignment(data),roles=data.roles||{},changed=JSON.stringify(next)!==JSON.stringify(assignment)||JSON.stringify(roles)!==JSON.stringify(roleAssignments)||assignmentError;
  roleAssignments=roles;
  assignment=next;assignmentError=false;
  if(!changed)return;
 }catch{assignmentError=true;}
 finally{$('assignment-retry').disabled=false;}
 if(snapshot)render();
}
$('assignment-retry').onclick=loadAssignment;

/* ---------- Roles en la portada ---------- */
$('roles-table').append(el('div',{class:'l4-roles-scroll',role:'region','aria-label':'Roles y archivos',tabindex:'0'},el('table',{class:'table l4-roles-table'},
 el('thead',null,el('tr',null,el('th',{scope:'col',text:'Rol'}),el('th',{scope:'col',text:'Archivo'}),el('th',{scope:'col',text:'Responsabilidad'}))),
 el('tbody',null,ROLES.map(role=>el('tr',null,el('th',{scope:'row',text:role.id}),el('td',null,el('code',{text:`agents/${role.id}.py`})),el('td',{text:role.duty})))))));

/* ---------- Vistas: guía y equipos (solo admins) ---------- */
function setNav(view){
 $('guide-link').setAttribute('aria-current',view==='guide'?'page':'false');
 if(!$('teams-link').hidden)$('teams-link').setAttribute('aria-current',view==='teams'?'page':'false');
}
async function route(){
 const serial=++routeSerial,hash=location.hash.slice(1);
 if(hash==='equipos'&&identity?.isAdmin){
  $('work-layout').hidden=true;$('teams-view').hidden=false;setNav('teams');
  if(!dashboard){
   $('teams-view').replaceChildren(el('p',{class:'l4-teams-loading',role:'status',text:'Cargando el tablero de equipos…'}));
   try{const module=await import('./dashboard.js');if(serial!==routeSerial)return;dashboard=module.mountDashboard($('teams-view'),{track:(type,details)=>storage.track(type,{stepId:'',...details})});}
   catch{$('teams-view').replaceChildren(el('p',{class:'l4-teams-loading',role:'alert',text:'No se pudo cargar el tablero. Recarga la página.'}));return;}
  }
  activeStep='';storage.track('page_view',{label:'Tablero de equipos del Lab 4',target:'/dia-04/#equipos'});
  dashboard.start();$('teams-view').focus({preventScroll:true});
  return;
 }
 dashboard?.stop();$('teams-view').hidden=true;$('work-layout').hidden=false;setNav('guide');
 await loadAssignment();
 const target=stages.findIndex(stage=>stage.id===hash);
 if(target>=0){if(overview||target!==index)openStage(target,{focus:false,keepHash:true});}
 else if(hash==='guia'||hash==='equipos'){overview=true;if(hash==='equipos')history.replaceState(null,'','#guia');render();}
}
window.addEventListener('hashchange',route);
$('labs-list').querySelector('a[href="/dia-04/#guia"]').addEventListener('click',event=>{event.preventDefault();if(location.hash==='#equipos')location.hash='#guia';openOverview();});

/* ---------- Inicio ---------- */
try{
 phase('account');
 const response=await fetch('/auth/session',{credentials:'same-origin',cache:'no-store',signal:AbortSignal.timeout(15000)});
 identity=await response.json().catch(()=>null);
 if(!response.ok||!identity)throw Error('No se pudo comprobar tu cuenta. Reintenta en unos segundos.');
 if(!identity.user)throw Object.assign(Error('Inicia sesión con GitHub para guardar tu avance del Lab 4.'),{login:true});
 if(identity.labs?.['dia-04']?.available===false)throw Error('El Lab 4 todavía no está disponible para tu cuenta.');
 $('github-account').textContent=identity.localPreview?'Demo local':'@'+identity.user.login;$('github-account').title=identity.localPreview?'Demo local':'Sesión de GitHub: @'+identity.user.login;$('github-account').hidden=false;
 $('tracking-link').hidden=$('teams-link').hidden=identity.isAdmin!==true;
 phase('session');
 const status=el('p',{id:'save-status',class:'command-feedback',role:'status'});$('feedback').after(status);
 storage=createStorage({key:'bcp.lab4.team-guide.v5.user.'+identity.user.id,endpoint:'/api/lab4-session',feedback:message=>{status.textContent=message;}});
 const saved=await storage.load();
 snapshot=normalize(saved);
 await loadAssignment();
 setInterval(()=>{if(document.visibilityState==='visible')void loadAssignment();},45000);
 setInterval(()=>storage.flush(),10000);window.addEventListener('online',()=>storage.flush());
 document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')storage.flush();});
 clearTimeout(slowTimer);$('lab-boot').hidden=true;$('lab-boot').setAttribute('aria-busy','false');$('work-layout').hidden=false;
 const next=snapshot.completed.findIndex(value=>!value);index=next<0?stages.length-1:next;
 track('page_view',{label:'Laboratorio Día 4',target:'/dia-04/'});
 render();await route();
}catch(error){bootError(error);}
