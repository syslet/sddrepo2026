// Shared team overview. APIs decide which team the current viewer can evaluate.
import {ROLES} from './scenario.js';
import {mountEvaluations} from './evaluations.js';
const SLOTS=8,POLL_MS=45000,ENDPOINT='/api/admin/lab4-teams';
const LOGIN=/^[a-z\d](?:[a-z\d-]{0,37}[a-z\d])?$/i;
const PROJECTS={crewai:{label:'CrewAI · S1',session:'s1'},guardrails:{label:'Guardrails · S2',session:'s2'}};
const STATES={
 base:{glyph:'○',short:'Base',label:'Igual a la plantilla'},
 changed:{glyph:'●',short:'Cambio',label:'Cambio publicado sin PR válido'},
 pr:{glyph:'◐',short:'PR abierto',label:'Cambio propuesto en un PR abierto'},
 merged:{glyph:'✓',short:'Integrado',label:'Cambio integrado mediante PR'},
 missing:{glyph:'✕',short:'Falta',label:'Ausente tras una lectura completa'},
 unknown:{glyph:'?',short:'Sin dato',label:'Sin lectura confiable'},
 empty:{glyph:'·',short:'Sin equipo',label:'Slot sin líder registrado'}
};
const REPO={connected:'Conectado',access_pending:'Acceso pendiente',unknown:'Sin lectura'};
const CHECKS={SUCCESS:'Correctos',FAILURE:'Fallidos',ERROR:'Con error',PENDING:'En curso',EXPECTED:'Esperados'};
const PR_STATE={open:'abierto',merged:'integrado',closed:'cerrado'};
const pad=n=>String(n).padStart(2,'0');
const teamName=i=>'Equipo '+pad(i+1);

function el(tag,props,...kids){
 const node=document.createElement(tag);
 if(props)for(const [key,value] of Object.entries(props)){if(value===null||value===undefined||value===false)continue;if(key==='class')node.className=value;else if(key==='text')node.textContent=value;else node.setAttribute(key,value===true?'':String(value));}
 for(const kid of kids.flat()){if(kid===null||kid===undefined||kid===false)continue;node.append(kid.nodeType?kid:document.createTextNode(String(kid)));}
 return node;
}
const glyph=state=>el('span',{class:'vt-glyph','aria-hidden':'true',text:STATES[state].glyph});
const external=(href,text,extra={})=>el('a',{href,target:'_blank',rel:'noopener',...extra},text,el('span',{class:'vt-sr',text:' (se abre en otra pestaña)'}));
const relative=new Intl.RelativeTimeFormat('es',{numeric:'auto'});
function ago(iso){
 const time=Date.parse(iso||'');if(!Number.isFinite(time))return null;
 const seconds=Math.round((time-Date.now())/1000),abs=Math.abs(seconds);
 const text=abs<60?relative.format(seconds,'second'):abs<3600?relative.format(Math.round(seconds/60),'minute'):abs<86400?relative.format(Math.round(seconds/3600),'hour'):relative.format(Math.round(seconds/86400),'day');
 return `${text} (${new Date(time).toLocaleTimeString('es',{hour:'2-digit',minute:'2-digit'})})`;
}
class ApiError extends Error{}
function apiMessage(status,data){
 if(data?.message)return data.message;
 if(status===401)return 'Tu sesión expiró. Recarga la página e inicia sesión otra vez.';
 if(status===403)return 'Este tablero es solo para admins del taller.';
 if(status===400&&data?.error==='invalid_captains')return 'Ingresa hasta ocho usuarios de GitHub distintos, uno por línea.';
 if(status===503)return 'El servicio de seguimiento no está disponible. Reintenta en unos minutos.';
 return 'No se pudo consultar el tablero. Se conserva la última lectura.';
}

export function mountDashboard(container,{track=()=>{},audience='admin',endpoint=ENDPOINT,evaluationEndpoint}={}){
 const student=audience==='student';
 const ui={lab:'crewai',view:'visual',team:0,role:0,cache:{},busy:false,timer:null,active:false,serial:0,fetchedAt:{},error:null,quiet:false};
 container.replaceChildren(el('div',{id:'visual-teams'},el('div',{class:'vt-shell'},
  el('header',{class:'vt-head'},
   el('div',null,
    el('nav',{class:'vt-crumbs','aria-label':'Ruta'},el('ol',null,el('li',null,el('a',{href:'/',text:'Laboratorios'})),el('li',null,el('a',{href:'/seguimiento/',text:'Seguimiento'})),el('li',{'aria-current':'page',text:'Equipos del Lab 4'}))),
    el('h1',{id:'vt-title',text:'Tablero de equipos'}),
    el('p',{class:'vt-sub',id:'vt-sub'})),
   el('span',{class:'badge vt-admin'},'Solo admins')),
  el('div',{class:'vt-toolbar'},
   el('label',{class:'vt-field',for:'vt-project'},'Repositorio',el('select',{class:'select',id:'vt-project'},Object.entries(PROJECTS).map(([value,p])=>el('option',{value,text:p.label})))),
   el('div',{class:'vt-seg',role:'group','aria-label':'Forma de ver los equipos'},
    el('button',{class:'btn',type:'button','data-view':'visual','aria-pressed':'true','aria-controls':'vt-visual',text:'Vista visual'}),
    el('button',{class:'btn',type:'button','data-view':'table','aria-pressed':'false','aria-controls':'vt-table',text:'Tabla'})),
   el('div',{class:'vt-tools'},
    el('button',{class:'btn',type:'button',id:'vt-refresh',text:'Actualizar desde GitHub'}),
    el('button',{class:'btn',type:'button',id:'vt-eval-all',text:'Evaluar todos'}),
    el('button',{class:'btn',type:'button',id:'vt-eval-refresh',text:'Actualizar pruebas'}),
    el('button',{class:'btn',type:'button',id:'vt-register-toggle','aria-expanded':'false','aria-controls':'vt-register',text:'Registrar líderes'}))),
  el('p',{class:'vt-updated',id:'vt-updated',role:'status'}),
  el('div',{class:'vt-alert',id:'vt-error',role:'alert',hidden:true},el('p',{id:'vt-error-text'}),el('button',{class:'btn',type:'button',id:'vt-retry',text:'Reintentar'})),
  el('div',{class:'vt-config',id:'vt-config',hidden:true},el('strong',{text:'Consulta de GitHub pausada.'}),el('span',{id:'vt-config-text'})),
  el('section',{class:'vt-register',id:'vt-register',hidden:true,'aria-labelledby':'vt-register-label'},
   el('label',{id:'vt-register-label',for:'vt-captains',text:'Usuarios de GitHub de los líderes, uno por línea (máximo 8)'}),
   el('p',{class:'vt-hint',text:'El orden define Equipo 01 a 08 y se usa en CrewAI y Guardrails. Registrar líderes no asigna roles: cada persona elige su rol en la guía y el servidor lo reserva para su equipo. Cambiar un líder borra las lecturas y asignaciones anteriores de ese equipo.'}),
   el('textarea',{class:'textarea',id:'vt-captains',rows:'8',spellcheck:'false',autocomplete:'off','aria-describedby':'vt-register-status'}),
   el('div',{class:'vt-actions'},el('button',{class:'btn btn-primary',type:'button',id:'vt-register-save',text:'Guardar líderes'}),el('button',{class:'btn',type:'button',id:'vt-register-cancel',text:'Cancelar'})),
   el('p',{class:'vt-status',id:'vt-register-status',role:'status'}),
   el('hr'),
   el('label',{for:'vt-member-team',text:'Integrantes del equipo'}),
   el('select',{class:'select',id:'vt-member-team'},Array.from({length:SLOTS},(_,i)=>el('option',{value:String(i+1),text:teamName(i)}))),
   el('p',{class:'vt-hint',text:'Selecciona el equipo y registra a los otros cinco usuarios. Su equipo, líder y participación aparecerán automáticamente al iniciar sesión. El líder ya está incluido.'}),
   el('label',{for:'vt-members',text:'Usuarios de los integrantes, uno por línea'}),
   el('textarea',{class:'textarea',id:'vt-members',rows:'5',spellcheck:'false'}),
   el('button',{class:'btn',id:'vt-members-save',type:'button',text:'Guardar integrantes'}),
   el('p',{id:'vt-members-status',class:'vt-status',role:'status'})),
  el('dl',{class:'vt-metrics',id:'vt-metrics','aria-label':'Resumen del repositorio seleccionado'}),
  el('section',{class:'vt-strip','aria-labelledby':'vt-strip-title'},
   el('div',{class:'vt-strip-head'},el('h2',{id:'vt-strip-title',text:'Cada rol en los 8 equipos'}),el('p',{text:'Una marca por equipo, de 01 a 08.'})),
   el('ul',{class:'vt-strip-grid',id:'vt-strip'})),
  el('div',{class:'vt-legend'},
   el('ul',{class:'vt-keys','aria-label':'Leyenda de estados'},['base','changed','pr','merged','missing','unknown'].map(state=>el('li',{class:'vt-key'},el('span',{class:'vt-swatch vt-st','data-state':state,'aria-hidden':'true',text:STATES[state].glyph}),`${STATES[state].short}: ${STATES[state].label.toLowerCase()}`)),
    el('li',{class:'vt-key'},el('span',{class:'vt-swatch vt-swatch-stale','aria-hidden':'true'}),'Rayado y ↻: lectura desactualizada')),
   el('p',null,el('strong',{text:'Que exista el archivo no es avance:'}),' los seis vienen en la plantilla, que también pasa CI sin trabajo. Solo PR abierto o integrado son evidencia publicada.')),
  el('p',{id:'vt-eval-status',class:'vt-status is-error',role:'alert',hidden:true}),
  el('div',{class:'vt-main'},
   el('div',{class:'vt-views'},
    el('section',{id:'vt-visual','aria-label':'Vista visual de los equipos'},el('ol',{class:'vt-grid',id:'vt-grid'})),
    el('section',{id:'vt-table','aria-label':'Tabla de los equipos',hidden:true},el('div',{class:'vt-scroll',role:'region','aria-label':'Estado de los seis roles por equipo',tabindex:'0'},el('table',{class:'table vt-table'},el('caption',{id:'vt-caption'}),el('thead',null,el('tr',{id:'vt-thead'})),el('tbody',{id:'vt-tbody'}))))),
   el('aside',{class:'vt-detail',id:'vt-detail','aria-labelledby':'vt-detail-title'},el('div',{class:'vt-detail-inner',id:'vt-detail-inner'}))),
  el('p',{class:'vt-foot',text:'Solo se ve lo publicado en GitHub: ramas, PR e integraciones. No hay acceso a ediciones locales ni a ejecuciones de main.py en las computadoras del equipo. output/ y evidence/ están ignorados en las plantillas.'}),
  el('p',{class:'vt-sr',id:'vt-live','aria-live':'polite'}))));
 const root=container.querySelector('#visual-teams');
 const $=selector=>root.querySelector(selector),$$=selector=>[...root.querySelectorAll(selector)];
 root.dataset.audience=audience;
 if(student){$('#vt-title').textContent='Tablero de equipos';$('.vt-admin').textContent='Vista de estudiante';$('#vt-eval-all').hidden=true;$('#vt-register-toggle').hidden=true;$('.vt-crumbs ol').children[1].remove();}
 const evaluations=mountEvaluations(root,{endpoint:evaluationEndpoint,audience});

 /* ---------- Datos ---------- */
 const data=()=>ui.cache[ui.lab]||null;
 const slot=i=>data()?.teams?.find(team=>team.id===i+1)||null;
 const connected=team=>team?.repo?.status==='connected';
 const stale=team=>Boolean(team?.repo?.stale);
 const roleOf=(team,ri)=>team?.roles?.find(role=>role.id===ROLES[ri].id)||null;
 function stateOf(team,ri){if(!team)return 'empty';const s=roleOf(team,ri)?.status;return STATES[s]&&s!=='empty'?s:'unknown';}
 const indices=()=>[...Array(SLOTS).keys()];
 const states=i=>ROLES.map((_,ri)=>stateOf(slot(i),ri));
 const repoKey=team=>!team?'empty':stale(team)?'stale':team.repo?.status||'unknown';
 const repoBadge=team=>!team?'Sin líder':stale(team)?'↻ Desactualizado':REPO[team.repo?.status]||'Sin lectura';
 const repoName=(team,i)=>team?.repo?.fullName||(team?`${team.captain}/${ui.lab}`:`Equipo ${pad(i+1)} sin líder`);
 const tally=list=>{const t={base:0,changed:0,pr:0,merged:0,missing:0,unknown:0,empty:0};list.forEach(s=>{t[s]++;});return t;};

 async function request(method,body){
  const init={method,credentials:'same-origin',cache:'no-store',signal:AbortSignal.timeout(method==='GET'?15000:60000)};
  if(body){init.headers={'Content-Type':'application/json'};init.body=JSON.stringify(body);}
  let response;
  try{response=await fetch(`${endpoint}?lab=${encodeURIComponent(ui.lab)}`,init);}
  catch(error){throw new ApiError(error.name==='TimeoutError'?'El servidor tardó demasiado en responder. Se conserva la última lectura.':'No hay conexión con el portal. Se conserva la última lectura.');}
  const payload=await response.json().catch(()=>null);
  if(!response.ok)throw new ApiError(apiMessage(response.status,payload));
  if(!payload||!Array.isArray(payload.teams))throw new ApiError('La respuesta del tablero no tiene el formato esperado.');
  return payload;
 }
 async function load(method='GET',body=null){
  const lab=ui.lab,serial=++ui.serial;ui.busy=true;syncBusy();
  try{
   let payload=await request(method,body);
   if(method==='POST'&&!student)for(let batch=1;batch<4&&payload.refreshPending;batch++)payload=await request(method,body);
   if(lab!==payload.lab&&payload.lab)throw new ApiError('La respuesta corresponde a otro repositorio.');
   ui.cache[lab]=payload;if(student&&payload.ownTeamId){if(ui.ownTeamId!==payload.ownTeamId)ui.team=payload.ownTeamId-1;ui.ownTeamId=payload.ownTeamId};ui.fetchedAt[lab]=Date.now();
   if(serial===ui.serial){ui.error=null;renderAll();}
   return true;
  }catch(error){
   if(serial===ui.serial){ui.error=error instanceof ApiError?error.message:'No se pudo consultar el tablero. Se conserva la última lectura.';renderStatus();}
   if(body)throw error;return false;
  }finally{if(serial===ui.serial){ui.busy=false;syncBusy();}}
 }
 function syncBusy(){$('#vt-refresh').disabled=ui.busy;$('#vt-register-save').disabled=ui.busy;$('#vt-refresh').textContent=ui.busy?'Consultando…':'Actualizar desde GitHub';root.setAttribute('aria-busy',String(ui.busy));}
 function schedule(){
  clearInterval(ui.timer);ui.timer=null;
  if(!ui.active)return;
  ui.timer=setInterval(()=>{if(ui.active&&!ui.busy&&document.visibilityState==='visible')load('GET');},POLL_MS);
 }
 function onVisibility(){if(!ui.active)return;if(document.visibilityState==='visible'&&!ui.busy&&Date.now()-(ui.fetchedAt[ui.lab]||0)>=POLL_MS)load('GET');}

 /* ---------- Cabecera, estado y avisos ---------- */
 function renderStatus(){
  const d=data();
  $('#vt-sub').textContent=student?`8 equipos · compara avances y resultados · puedes evaluar tu equipo ${ui.ownTeamId?String(ui.ownTeamId).padStart(2,'0'):''}`:`8 equipos de 6 personas · repo público <líder>/${ui.lab} · seis roles en agents/<rol>.py`;
  const parts=[];
  if(d){const oldest=ago(d.updatedAt);parts.push(oldest?`Lectura de GitHub más antigua: ${oldest}`:'Todavía no hay lecturas de GitHub');}
  if(ui.fetchedAt[ui.lab])parts.push(`consultado ${ago(new Date(ui.fetchedAt[ui.lab]).toISOString())}`);
  parts.push(d?.configured?'lectura pública por turnos cada 45 s':'sincronización pausada');
  $('#vt-updated').textContent=d||ui.error?parts.join(' · '):'Cargando el tablero…';
  $('#vt-error').hidden=!ui.error;$('#vt-error-text').textContent=ui.error||'';
  $('#vt-config').hidden=!d||d.configured;$('#vt-config-text').textContent=' '+(d?.message||'La sincronización está pausada en este entorno.')+'';
  $('#vt-caption').textContent=d?.configured?`${PROJECTS[ui.lab].label} · rama principal y PR · ${d.message||''}`:`${PROJECTS[ui.lab].label} · sin lectura de GitHub`;
 }

 /* ---------- Métricas ---------- */
 function renderMetrics(){
  const idx=indices(),registered=idx.filter(i=>slot(i)),read=registered.filter(i=>connected(slot(i)));
  const old=registered.filter(i=>stale(slot(i))).length,pending=registered.length-read.length;
  const all=tally(read.flatMap(states));
  const withMissing=read.filter(i=>states(i).includes('missing'));
  const review=new Set([...withMissing,...registered.filter(i=>!connected(slot(i))||stale(slot(i)))]).size;
  const metric=(label,value,small,note)=>el('div',{class:'vt-metric'},el('dt',{text:label}),el('dd',null,el('span',{class:'vt-m-value'},String(value),el('small',{text:small})),el('span',{class:'vt-m-note',text:note})));
  $('#vt-metrics').replaceChildren(
   metric('Repos conectados',read.length,` / ${registered.length}`,registered.length?([pending&&`? ${pending} sin lectura`,old&&`↻ ${old} desactualizados`].filter(Boolean).join(' · ')||'Todos con lectura'):'Sin líderes registrados'),
   metric('Roles con PR',all.pr+all.merged,` / ${read.length*6}`,`✓ ${all.merged} integrados · ◐ ${all.pr} abiertos`),
   metric('Cambio sin PR',all.changed,all.changed===1?' rol':' roles','Actividad publicada, sin revisión'),
   metric('Para revisar',review,review===1?' equipo':' equipos',[withMissing.length&&`✕ ${withMissing.length} con faltantes`,pending&&`? ${pending}`,old&&`↻ ${old}`].filter(Boolean).join(' · ')||'Nada pendiente'));
 }
 function renderStrip(){
  $('#vt-strip').replaceChildren(...ROLES.map((role,ri)=>{
   const col=indices().map(i=>stateOf(slot(i),ri)),t=tally(col);
   const parts=[`✓ ${t.merged}`,`◐ ${t.pr}`,`● ${t.changed}`];if(t.missing)parts.push(`✕ ${t.missing}`);
   return el('li',{class:'vt-rs'},
    el('span',{class:'vt-rs-name','aria-hidden':'true',text:role.id}),
    el('span',{class:'vt-dots','aria-hidden':'true'},col.map((s,i)=>el('span',{class:'vt-dot','data-state':s,title:`${teamName(i)}: ${STATES[s].short}`}))),
    el('span',{class:'vt-rs-count','aria-hidden':'true',text:parts.join(' · ')}),
    el('span',{class:'vt-sr',text:`${role.id}: ${t.merged} integrados, ${t.pr} en PR abierto, ${t.changed} con cambio sin PR, ${t.base} base, ${t.missing} faltan, ${t.unknown+t.empty} sin dato.`}));
  }));
 }

 /* ---------- Vista visual ---------- */
 function tileNote(team,i){
  if(!team)return el('p',{class:'vt-tile-note'},el('strong',{text:'Sin líder.'}),' Registra al líder para buscar su repo.');
  if(stale(team))return el('p',{class:'vt-tile-note'},el('strong',{text:'↻ Última lectura correcta'}),' '+(ago(team.repo.updatedAt)||'sin fecha')+'. '+(team.repo.message||''));
  if(team.repo?.status==='access_pending')return el('p',{class:'vt-tile-note'},el('strong',{text:'Sin lectura.'}),' '+(team.repo.message||'El líder debe crear este repositorio con visibilidad pública.'));
  if(team.repo?.status!=='connected')return el('p',{class:'vt-tile-note'},el('strong',{text:'Sin lectura.'}),' '+(team.repo?.message||`No se pudo leer ${repoName(team,i)}.`));
  if(team.repo.message)return el('p',{class:'vt-tile-note',text:team.repo.message});
  return null;
 }
 function counts(team,i){
  if(!connected(team))return null;
  const t=tally(states(i));
  const item=(state,n,word)=>el('li',{class:'vt-st','data-state':state},glyph(state),el('b',{text:n}),word);
  const assigned=team.roles.filter(role=>role.assignee).length;
  return el('ul',{class:'vt-counts','aria-label':'Resumen del '+teamName(i)},item('merged',t.merged,'integrados'),item('pr',t.pr,'en PR'),item('changed',t.changed,'sin PR válido'),t.missing?item('missing',t.missing,'faltan'):null,el('li',null,el('b',{text:`${assigned}/6`}),'con rol elegido'));
 }
 function renderGrid(){
  $('#vt-grid').replaceChildren(...indices().map(i=>{
   const team=slot(i),st=states(i),key=repoKey(team);
   return el('li',{class:'vt-tile','data-repo':key,'data-team':i},
    el('div',{class:'vt-tile-head'},
     el('button',{class:'vt-team',type:'button','data-team-pick':i,'aria-pressed':'false'},
      el('span',{class:'vt-no','aria-hidden':'true',text:pad(i+1)}),
      el('span',{class:'vt-team-text'},el('span',{class:'vt-team-name',text:teamName(i)+(student&&ui.ownTeamId===i+1?' · Tu equipo':'')}),el('span',{class:'vt-team-cap',text:team?'@'+team.captain:'Sin líder'}))),
     el('span',{class:'badge vt-repo','data-repo':key,text:repoBadge(team)})),
    el('div',{class:'vt-map',role:'group','aria-label':'Seis roles del '+teamName(i)},
     ROLES.map((role,ri)=>{const assignee=roleOf(team,ri)?.assignee;return el('button',{class:'vt-node vt-st',type:'button','data-state':st[ri],'data-role':role.id,'data-pick':'','data-team':i,'data-ri':ri,'aria-pressed':'false','aria-label':`${role.id}: ${STATES[st[ri]].short}${assignee?', @'+assignee:''}, ${teamName(i)}`,title:assignee?'@'+assignee:null},
      el('span',{class:'vt-node-role',text:role.id}),
      el('span',{class:'vt-node-state'},glyph(st[ri]),STATES[st[ri]].short));})),
    counts(team,i),tileNote(team,i),el('div',{'data-evaluation-team':i+1}));
  }));
 }

 /* ---------- Tabla ---------- */
 function renderTable(){
  $('#vt-thead').replaceChildren(el('th',{scope:'col',text:'Equipo / líder'}),...ROLES.map(role=>el('th',{scope:'col',text:role.id})),el('th',{scope:'col',text:'Repo'}),el('th',{scope:'col',text:'Prueba del flujo'}),el('th',{scope:'col',text:'Última lectura'}));
  $('#vt-tbody').replaceChildren(...indices().map(i=>{
   const team=slot(i),st=states(i);
   return el('tr',{'data-repo':repoKey(team)},
    el('th',{scope:'row'},teamName(i),el('span',{class:'vt-mono',text:team?'@'+team.captain:'Sin líder'})),
    st.map((s,ri)=>{const assignee=roleOf(team,ri)?.assignee;return el('td',null,el('button',{class:'vt-cell vt-st',type:'button','data-state':s,'data-pick':'','data-team':i,'data-ri':ri,'aria-pressed':'false','aria-label':`${ROLES[ri].id}: ${STATES[s].short}${assignee?', @'+assignee:''}, ${teamName(i)}`},el('span',{class:'vt-cell-top'},glyph(s),STATES[s].short),assignee?el('span',{class:'vt-cell-who',text:'@'+assignee}):null));}),
    el('td',{class:'vt-num'},team?.repo?.url&&connected(team)?external(team.repo.url,repoBadge(team)):repoBadge(team)),
    el('td',{class:'vt-eval-table-cell'},el('div',{'data-evaluation-team':i+1})),
    el('td',{class:'vt-num',text:ago(team?.repo?.updatedAt)||'—'}));
  }));
 }

 /* ---------- Detalle ---------- */
 function meaning(team,i,ri,s){
  const file=`agents/${ROLES[ri].id}.py`;
  const note=stale(team)?' Dato de una lectura anterior: puede haber cambiado.':'';
  if(s==='empty')return 'Este slot no tiene líder registrado. Registra los líderes para empezar a buscar sus repos.';
  if(s==='unknown'){
   if(team.repo?.status==='access_pending')return (team.repo.message||'El repositorio público aún no está disponible.')+' «Sin dato» no equivale a un archivo faltante; un 404 puede ocultar un repo público.';
   if(team.repo?.status!=='connected')return (team.repo?.message||'No se pudo leer el repositorio.')+' Se conserva la última lectura correcta si existía.';
   return `No se pudo clasificar ${file} con la última lectura, por ejemplo porque la lista de PR quedó incompleta. No cuenta como faltante.`+note;
  }
  return {
   base:`${file} sigue igual a la versión de la plantilla. Que exista y que el CI pase no indica trabajo en este rol.`,
   changed:`El contenido de ${file} en la rama principal difiere de la plantilla, sin un PR válido del responsable. Es actividad publicada, todavía sin entrega validada.`,
   pr:`Hay un PR abierto que modifica ${file}. Es un cambio propuesto, pendiente de revisión e integración.`,
   merged:`Un PR que modifica ${file} se integró en la rama principal. Es evidencia publicada y revisable; no prueba que el agente funcione bien.`,
   missing:`Una lectura completa del árbol confirmó que ${file} no está en la rama principal. No se deduce de un error de conexión.`
  }[s]+note;
 }
 function facts(team,ri,s){
  const role=roleOf(team,ri),pr=role?.pr;
  const prValue=pr?el('span',null,pr.url?external(pr.url,`#${pr.number}`):`#${pr.number}`,` · ${PR_STATE[pr.state]||pr.state||'—'}`,pr.author?` · @${pr.author}`:''):role?.prs?.length?el('span',null,role.prs.map(p=>p.url?external(p.url,`#${p.number}`):`#${p.number}`)):s==='unknown'||s==='empty'?'Sin datos':'Ninguno asociado';
  return [
   ['Estado',STATES[s].label],
   ['Responsable del rol',role?.assignee?'@'+role.assignee:team?'Aún no eligieron este rol':'—'],
   ['Pull request',prValue],
   ['Validación de entrega',pr?'Autor, archivo y destino coinciden':role?.prNotice||'Sin PR válido del responsable'],
   ['Checks del PR',pr?.checks?CHECKS[pr.checks]||pr.checks:'Sin datos'],
   ['Blob en la rama principal',role?.sha?el('code',{text:role.sha.slice(0,10)}):'—'],
   ['Última lectura',team?.repo?.updatedAt?(ago(team.repo.updatedAt)+(stale(team)?' · desactualizada':'')):'Nunca']
  ];
 }
 function renderDetail(){
  const i=ui.team,ri=ui.role,team=slot(i),st=states(i),s=st[ri],role=ROLES[ri],file=`agents/${role.id}.py`;
  const focusKey=document.activeElement&&root.contains(document.activeElement)?document.activeElement.getAttribute('data-focus-key'):null;
  const fileHref=connected(team)&&team.repo.url&&s!=='missing'?`${team.repo.url}/blob/${encodeURIComponent(team.repo.branch||'HEAD')}/${file}`:null;
  const t=tally(st);
  const repoLine=!team?[el('b',{text:'Sin líder'}),' · registra al líder del equipo']:connected(team)?[el('b',{text:repoBadge(team)}),` · ${t.merged} integrados · ${t.pr} en PR · ${t.changed} sin PR`]:[el('b',{text:repoBadge(team)}),' · '+(team.repo?.message||'sin lectura')];
  $('#vt-detail-inner').replaceChildren(
   el('section',{class:'vt-detail-role','aria-label':'Rol seleccionado'},
    el('div',null,el('p',{class:'vt-eyebrow',text:`Rol seleccionado · ${PROJECTS[ui.lab].label}`}),
     el('div',{class:'vt-title-row'},el('h2',{id:'vt-detail-title',text:`${teamName(i)} · ${role.id}`}),el('span',{class:'vt-pill vt-st','data-state':s},glyph(s),STATES[s].short))),
    el('p',{class:'vt-path',id:'vt-detail-path'},fileHref?external(fileHref,`${repoName(team,i)}/${file}`):`${repoName(team,i)}/${file}`),
    el('p',{class:'vt-meaning',text:meaning(team,i,ri,s)}),
    el('dl',{class:'vt-facts'},facts(team,ri,s).map(([k,v])=>el('div',{class:'vt-fact'},el('dt',{text:k}),el('dd',null,v))))),
   el('section',{class:'vt-detail-team','aria-labelledby':'vt-team-title'},
    el('div',null,el('p',{class:'vt-eyebrow',text:'Equipo'}),el('h3',{id:'vt-team-title'},`${teamName(i)} · `,team?.repo?.url&&connected(team)?external(team.repo.url,team.repo.fullName||'@'+team.captain):team?'@'+team.captain:'sin líder')),
    el('p',{class:'vt-repo-line'},repoLine),
    el('ul',{class:'vt-roster','aria-label':'Roles del '+teamName(i)},ROLES.map((r,k)=>{const who=roleOf(team,k)?.assignee;return el('li',null,el('button',{class:'vt-st',type:'button','data-state':st[k],'data-pick':'','data-team':i,'data-ri':k,'data-focus-key':'roster-'+k,'aria-pressed':String(k===ri),'aria-label':`${r.id}: ${STATES[st[k]].short}, ${who?'@'+who:'sin responsable'}`},
     el('span',{class:'vt-r-top'},glyph(st[k]),r.id),el('span',{class:'vt-r-sub',text:who?'@'+who:STATES[st[k]].short})));})),
    el('p',{class:'vt-people',text:'Cada participante elige su rol en la guía. Solo cuenta un PR del responsable, listo para revisión y con su archivo de agente.'})));
  if(focusKey)root.querySelector(`#vt-detail [data-focus-key="${focusKey}"]`)?.focus();
 }

 /* ---------- Selección y vistas ---------- */
 function syncSelection(){
  $$('#vt-grid [data-pick],#vt-tbody [data-pick]').forEach(b=>b.setAttribute('aria-pressed',String(+b.dataset.team===ui.team&&+b.dataset.ri===ui.role)));
  $$('#vt-grid [data-team-pick]').forEach(b=>b.setAttribute('aria-pressed',String(+b.dataset.teamPick===ui.team)));
  $$('#vt-grid .vt-tile').forEach(t=>t.classList.toggle('is-selected',+t.dataset.team===ui.team));
  renderDetail();
 }
 const announce=text=>{$('#vt-live').textContent=text;};
 function select(i,ri){
  ui.team=i;ui.role=ri;syncSelection();announce(`${teamName(i)} · ${ROLES[ri].id}: ${STATES[states(i)[ri]].label}`);
  if(matchMedia('(max-width: 860px)').matches){
   const detail=$('#vt-detail');detail.setAttribute('tabindex','-1');detail.focus({preventScroll:true});
   detail.scrollIntoView({block:'start',behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});
  }
 }
 function setView(view){
  ui.view=view;$('#vt-visual').hidden=view!=='visual';$('#vt-table').hidden=view!=='table';
  $$('[data-view]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.view===view)));
  announce(view==='visual'?'Vista visual activa':'Vista de tabla activa');
 }
 function renderAll(){renderStatus();renderMetrics();renderStrip();renderGrid();renderTable();syncSelection();evaluations.update(ui.lab,data()?.teams||[]);}

 root.addEventListener('click',event=>{
  const pick=event.target.closest('[data-pick]');if(pick){select(+pick.dataset.team,+pick.dataset.ri);return;}
  const team=event.target.closest('[data-team-pick]');if(team){select(+team.dataset.teamPick,ui.role);return;}
  const view=event.target.closest('[data-view]');if(view)setView(view.dataset.view);
 });
 $('#vt-project').addEventListener('change',event=>{
  ui.lab=event.target.value;renderAll();announce('Repositorio '+PROJECTS[ui.lab].label);
  track('page_view',{label:'Tablero de equipos · '+PROJECTS[ui.lab].label,target:'/dia-04/#equipos?lab='+ui.lab});
  load('GET');
 });
 $('#vt-refresh').addEventListener('click',()=>load('POST'));
 $('#vt-retry').addEventListener('click',()=>load('GET'));

 /* ---------- Registro de líderes ---------- */
 const status=$('#vt-register-status');
 const setStatus=(text,error)=>{status.textContent=text;status.classList.toggle('is-error',Boolean(error));};
 function openRegister(open){
  $('#vt-register').hidden=!open;$('#vt-register-toggle').setAttribute('aria-expanded',String(open));
  if(open){fillMembers();$('#vt-captains').value=(data()?.teams||[]).slice().sort((a,b)=>a.id-b.id).map(team=>team.captain).join('\n');setStatus('');$('#vt-captains').focus();}
 }
 function fillMembers(){
  const team=(data()?.teams||[]).find(team=>team.id===Number($('#vt-member-team').value));
  $('#vt-members').value=(team?.members||[]).join('\n');$('#vt-members-status').textContent='';
 }
 $('#vt-member-team').addEventListener('change',fillMembers);
 $('#vt-members-save').addEventListener('click',async()=>{
  const members=$('#vt-members').value.split(/\r?\n/).map(s=>s.trim().replace(/^@/,'')).filter(Boolean);
  const status=$('#vt-members-status');
  if(members.length>5||members.some(name=>!LOGIN.test(name))||new Set(members.map(s=>s.toLowerCase())).size!==members.length){status.textContent='Ingresa hasta cinco usuarios válidos distintos.';return;}
  $('#vt-members-save').disabled=true;status.textContent='Guardando integrantes…';
  try{await load('PUT',{teamId:Number($('#vt-member-team').value),members});for(const lab of Object.keys(ui.cache))if(lab!==ui.lab)delete ui.cache[lab];status.textContent='Integrantes guardados. El equipo y su líder aparecen automáticamente en sus cuentas.';}
  catch(error){status.textContent=error.message;}
  finally{$('#vt-members-save').disabled=false;}
 });
 $('#vt-register-toggle').addEventListener('click',()=>openRegister($('#vt-register').hidden));
 $('#vt-register-cancel').addEventListener('click',()=>{openRegister(false);$('#vt-register-toggle').focus();});
 $('#vt-register-save').addEventListener('click',async()=>{
  const names=$('#vt-captains').value.split(/\r?\n/).map(x=>x.trim().replace(/^@/,'')).filter(Boolean);
  if(names.length>SLOTS)return setStatus(`Hay ${names.length} usuarios. Escribe como máximo ${SLOTS}, uno por línea.`,true);
  const bad=names.find(x=>!LOGIN.test(x));if(bad)return setStatus(`«${bad}» no es un usuario de GitHub válido.`,true);
  if(new Set(names.map(x=>x.toLowerCase())).size!==names.length)return setStatus('Hay usuarios repetidos. Cada equipo necesita un líder distinto.',true);
  if(!names.length&&!confirm('¿Quitar todos los líderes registrados? Se borrarán sus lecturas guardadas.'))return;
  setStatus('Guardando…');
  try{await load('PUT',{captains:names});for(const lab of Object.keys(ui.cache))if(lab!==ui.lab)delete ui.cache[lab];fillMembers();setStatus(`${names.length} ${names.length===1?'líder':'líderes'} guardado${names.length===1?'':'s'}. ${data()?.configured?'Usa «Actualizar desde GitHub» para leer sus repos ahora.':'La sincronización está pausada en este entorno.'}`);}
  catch(error){setStatus(error.message||'No se pudieron guardar los líderes.',true);}
 });

 renderAll();setView('visual');
 document.addEventListener('visibilitychange',onVisibility);
 return {
  start(){ui.active=true;if(!ui.busy&&Date.now()-(ui.fetchedAt[ui.lab]||0)>=5000)load('GET');schedule();evaluations.start();},
  stop(){ui.active=false;schedule();evaluations.stop();}
 };
}
