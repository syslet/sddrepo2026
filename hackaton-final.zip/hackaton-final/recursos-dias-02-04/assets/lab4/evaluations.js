import {evaluationScores} from './evaluation-scores.js';
const ENDPOINT='/api/admin/lab4-evaluations';
const LABELS={queued:'En ejecución',passed:'Flujo correcto',failed:'Revisar flujo',error:'No se pudo evaluar',unsupported:'No aplica',untested:'Sin evaluar',stale:'Resultado anterior'};
const PHASES=[['preparing','Entorno'],['downloading','Código'],['loading','Carga'],['testing','Pruebas'],['complete','Resultado']];
const CHECKS={
 each_role_builds_its_own_task:['Tareas de los seis roles','Cada agente construye su propia tarea y recibe el requisito.'],
 pipeline_saves_all_roles_and_resumes:['Recorrido y reanudación','Se ejecutan los seis roles, se guardan sus salidas y al retomar no se repiten los aprobados.'],
 human_rejection_stops_downstream:['Rechazo humano','Rechazar una etapa detiene el flujo y evita ejecutar los agentes siguientes.'],
 retry_injects_feedback_before_continuing:['Reintento con feedback','El agente vuelve a ejecutarse con las observaciones antes de continuar.'],
 model_error_does_not_approve_or_advance:['Error durante la ejecución','Si falla la llamada al modelo, el flujo no avanza ni registra una aprobación.'],
 rejection_stops_at_max_rounds:['Límite de rondas','El flujo se detiene al alcanzar el límite sin registrar una aprobación falsa.'],
 six_separate_nodes_and_review_context:['Seis agentes y ciclo de revisión','Chapter recibe los informes y sus observaciones llegan a la siguiente ronda.'],
 resume_keeps_testing_and_security_pending:['Reanudación del equipo','Se conserva el trabajo aprobado y se continúa por los roles pendientes.'],
 output_gate_requires_both_review_reports:['Informes de Testing y Security','La revisión final exige los dos informes.'],
 architect_rejects_missing_plan:['Salida incompleta de Architect','El flujo rechaza una respuesta sin el plan requerido.'],
 cli_persists_all_six_reports:['Artefactos del equipo','La ejecución guarda los seis informes y el estado de aprobación.'],
 hitl_un_nodo_por_invoke:['Pausa entre agentes','Cada avance ejecuta un solo nodo y vuelve a detenerse para revisión.'],
 review_loop:['Rechazo de Chapter','Las observaciones devuelven el trabajo a desarrollo antes de aprobar.'],
 feedback_llega_al_dev:['Observaciones a desarrollo','El siguiente intento recibe el feedback concreto de Chapter.'],
 analisis_sale_del_repo_real:['Contexto del repositorio','Architect recibe el repositorio y el código que corresponden a la ejecución.'],
 salta_por_project_type:['Selección del tipo de proyecto','Se omiten los roles que no aplican al proyecto elegido.'],
 load_context:['Contexto del equipo','El flujo carga instrucciones, constitución y políticas.'],
 siembra_sin_ejecutar:['Inicio en espera','Preparar la ejecución no dispara agentes antes de la aprobación.'],
 step_un_nodo:['Avance por etapa','Cada acción ejecuta un solo agente en el orden esperado.'],
 retry_node:['Reintento de un nodo','Reintentar reemplaza su salida sin adelantar el siguiente nodo.'],
 resume_restaura_review_loop:['Reanudación con observaciones','Retomar conserva la ronda y el feedback pendiente.'],
 guardrail_entrada:['Control de entrada','Se bloquean entradas vacías o con datos sensibles de prueba.'],
 guardrail_salida:['Control de salida','Se rechazan salidas incompletas, sin veredicto o con secretos de prueba.'],
 contexto_del_producto:['Contexto del producto','Se incorporan las reglas y especificaciones del producto.'],
 gate_g2:['Reglas de aprobación final','El resultado respeta los criterios y el umbral de aprobación.']
};
function node(tag,props={},children=[]){
 const element=document.createElement(tag);
 for(const [key,value] of Object.entries(props)){if(value===null||value===undefined||value===false)continue;if(key==='text')element.textContent=value;else if(key==='class')element.className=value;else element.setAttribute(key,String(value));}
 for(const child of children)element.append(child);
 return element;
}
export function evaluationSummary(run,currentCommit){
 if(!run)return {state:'untested',label:LABELS.untested,note:'Comprueba el recorrido de tus agentes.',passed:0,total:0,unsupported:0};
 const scenarios=run.result?.scenarios||[],supported=scenarios.filter(s=>s.status!=='unsupported'),passed=supported.filter(s=>s.status==='passed').length,unsupported=scenarios.length-supported.length;
 const state=currentCommit&&currentCommit!==run.commit&&run.status!=='queued'?'stale':run.status;
 const note=state==='stale'?'El código cambió. Vuelve a evaluar.':state==='queued'?'Esperando el informe del ejecutor.':state==='error'?'No hay un resultado válido sobre el flujo.':supported.length?`${passed} de ${supported.length} pruebas aprobadas${unsupported?` · ${unsupported} no aplica`:''}`:'No se ejecutaron pruebas.';
 return {state,label:LABELS[state],note,passed,total:supported.length,unsupported};
}
function scenarioView(s){
 const key=s.id.split('.').at(-1).replace(/^test_/,''),known=CHECKS[key];
 const detail=node('details',{class:'vt-eval-scenario','data-outcome':s.status});
 const status=s.status==='passed'?'Aprobada':s.status==='failed'?'Falló':'No aplica';
 detail.append(node('summary',{},[node('span',{class:'vt-eval-symbol','aria-hidden':'true',text:s.status==='passed'?'✓':s.status==='failed'?'×':'–'}),node('span',{text:known?.[0]||s.name}),node('span',{class:'vt-eval-outcome',text:status})]));
 if(known)detail.append(node('p',{class:'vt-eval-expect',text:known[1]}));
 if(s.status!=='passed'){
  const observation=s.detail.split('\n').filter(Boolean).at(-1)||s.detail;
  detail.append(node('p',{class:'vt-eval-observed',text:observation}));
 }
 if(s.status==='failed'&&s.detail.includes('\n')){
  const technical=node('details',{class:'vt-eval-technical'});technical.append(node('summary',{text:'Detalle técnico'}),node('pre',{class:'vt-eval-log',text:s.detail}));detail.append(technical);
 }
 return detail;
}
function scoresView(run){
 const scores=evaluationScores(run),panel=node('div',{class:'vt-eval-scores'});
 for(const [key,label] of [['flowPercent','Flujo aprobado'],['qualityPercent','Instrucciones'],['totalPercent','Total del equipo']]){
  const value=scores[key];panel.append(node('div',{},[node('span',{text:label}),node('strong',{text:value===null?'Pendiente':`${value}%`})]));
 }
 return panel;
}
function qualityView(run){
 const quality=run.result?.quality;if(!quality)return null;
 const panel=node('section',{class:'vt-quality','aria-label':'Calidad de las instrucciones por agente'});
 panel.append(node('h3',{text:'Instrucciones por agente'}),node('p',{class:'vt-eval-note',text:'Cobertura de una rúbrica estática. Revisa instrucciones del código evaluado; no mide respuestas reales del modelo. Cada criterio muestra evidencia y qué mejorar.'}));
 for(const role of quality.roles){
  const detail=node('details',{class:'vt-quality-role'});
  detail.append(node('summary',{},[node('span',{text:role.role}),node('strong',{text:Number.isFinite(role.score)?`${role.score}%`:'Revisión manual'})]));
  if(role.issue)detail.append(node('p',{text:role.issue}));
  for(const criterion of role.criteria){
   const item=node('div',{class:'vt-quality-criterion'});
   item.append(node('p',{text:`${criterion.passed?'✓':'○'} ${criterion.name} · ${criterion.passed?criterion.weight:0}/${criterion.weight}`}));
   if(!criterion.passed)item.append(node('p',{text:criterion.feedback}));
   for(const evidence of criterion.evidence){item.append(node('a',{href:`https://github.com/${run.repository}/blob/${run.commit}/agents/${role.role}.py#L${evidence.line}`,target:'_blank',rel:'noopener',text:`Línea ${evidence.line} ↗`}),node('blockquote',{text:evidence.text}));}
   detail.append(item);
  }
  panel.append(detail);
 }
 return panel;
}
function checkName(item){return CHECKS[item.id.split('.').at(-1).replace(/^test_/,'')]?.[0]||item.name;}
export function evaluationProgress(run){
 const progress=run?.result?.progress;
 if(!progress)return {phase:'queued',current:null,completed:0,total:0,plan:[],label:'En cola · esperando al ejecutor'};
 const label={preparing:'Preparando el entorno aislado',downloading:'Descargando el commit del equipo',loading:'Cargando agentes y flujo',testing:progress.current?`Validando · ${checkName(progress.current)}`:'Preparando la siguiente comprobación',complete:'Evaluación terminada'}[progress.phase];
 return {...progress,label};
}
function liveProgress(run){
 const progress=evaluationProgress(run),index=PHASES.findIndex(([id])=>id===progress.phase),panel=node('div',{class:'vt-eval-live'});
 panel.append(node('ol',{class:'vt-eval-phases','aria-label':'Etapas de la evaluación'},PHASES.map(([id,label],i)=>node('li',{'data-phase-state':index<0?'pending':i<index?'done':i===index?'active':'pending'},[node('span',{class:'vt-eval-phase-dot','aria-hidden':'true',text:i<index?'✓':String(i+1)}),node('span',{text:label})]))));
 panel.append(node('p',{class:'vt-eval-now',role:'status','aria-live':'polite'},[node('span',{class:'vt-eval-spinner','aria-hidden':'true'}),node('span',{text:progress.label})]));
 if(progress.total){
  const outcomes=run.result?.scenarios||[],failures=outcomes.filter(s=>s.status==='failed').length;
  panel.append(node('p',{class:'vt-eval-count',text:`${progress.completed} de ${progress.total} comprobaciones terminadas${failures?` · ${failures} con fallo`:''}`}));
  const meter=node('progress',{class:'vt-eval-progress',value:progress.completed,max:progress.total,'aria-label':'Comprobaciones terminadas'});panel.append(meter);
 }
 return panel;
}
export function mountEvaluations(root,{endpoint=ENDPOINT,audience='admin'}={}){
 let ownTeamId=null;
 let lab='crewai',teams=[],records=[],configured=false,loaded=false,active=false,timer=null,loading=false,error='',generation=0,lastPoll=0;
 const launching=new Set(),signatures=new WeakMap(),openRuns=new Set();
 const all=root.querySelector('#vt-eval-all'),refresh=root.querySelector('#vt-eval-refresh'),status=root.querySelector('#vt-eval-status');
 async function api(method,body,currentLab){
  const response=await fetch(`${endpoint}?lab=${currentLab}`,{method,credentials:'same-origin',cache:'no-store',signal:AbortSignal.timeout(45000),...(body?{headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}:{})});
  const data=await response.json().catch(()=>null);
  if(!response.ok)throw Error(data?.message||'No se pudieron consultar las pruebas. Reintenta.');
  return data;
 }
 function runDetails(run){
  const content=node('div',{class:'vt-eval-content'});
  content.append(node('p',{class:'vt-eval-meta',text:`Commit ${run.commit.slice(0,8)} · ${new Date(run.createdAt).toLocaleString('es')}`}));
  if(run.status==='error')content.append(node('p',{text:'Un error del ejecutor no demuestra que los agentes estén mal. Revisa la salida y vuelve a intentarlo.'}));
  const quality=qualityView(run);if(quality)content.append(quality);
  const done=run.result?.scenarios||[];
  if(done.length)content.append(node('div',{class:'vt-eval-scenarios'},done.map(scenarioView)));
  if(run.status==='queued'){
   const progress=evaluationProgress(run),ids=new Set(done.map(s=>s.id));
   const pending=progress.plan.filter(item=>!ids.has(item.id));
   if(pending.length)content.append(node('ol',{class:'vt-eval-pending','aria-label':'Comprobaciones pendientes'},pending.map(item=>node('li',{'data-current':String(item.id===progress.current?.id)},[node('span',{class:item.id===progress.current?.id?'vt-eval-spinner':'vt-eval-wait-dot','aria-hidden':'true'}),node('span',{text:checkName(item)}),node('small',{text:item.id===progress.current?.id?'Validando':'Pendiente'})]))));
  }
  const links=node('div',{class:'vt-eval-links'},[node('a',{href:`https://github.com/${run.repository}/tree/${run.commit}`,target:'_blank',rel:'noopener',text:'Código evaluado ↗'})]);
  if(run.result?.runUrl)links.append(node('a',{href:run.result.runUrl,target:'_blank',rel:'noopener',text:'Ejecución ↗'}));
  content.append(links);
  if(run.result?.log){const logs=node('details',{class:'vt-eval-technical'});logs.append(node('summary',{text:'Salida completa'}),node('pre',{class:'vt-eval-log',text:run.result.log}));content.append(logs);}
  return content;
 }
 function render(){
  if(refresh)refresh.disabled=loading;
  if(all)all.disabled=!configured||!teams.length||launching.size>0;
  if(status){status.textContent=error;status.hidden=!error;}
  for(const mount of root.querySelectorAll('[data-evaluation-team]')){
   const id=Number(mount.dataset.evaluationTeam),team=teams.find(t=>t.id===id);
   if(!team){mount.replaceChildren();continue;}
   const history=records.filter(r=>r.teamId===id),latest=history[0],summary=evaluationSummary(latest,team.repo?.commit),busy=launching.has(id)||latest?.status==='queued';
   const signature=JSON.stringify([lab,team.repo?.commit,history,configured,loaded,busy,ownTeamId]);
   if(signatures.get(mount)===signature)continue;signatures.set(mount,signature);
   const tile=mount.closest('.vt-tile');
   if(tile){for(const button of tile.querySelectorAll('.vt-node[data-role]')){button.querySelector('.vt-node-quality')?.remove();const role=latest?.result?.quality?.roles?.find(r=>r.role===button.dataset.role);if(role&&['passed','failed'].includes(latest.status))button.append(node('span',{class:'vt-node-quality',text:Number.isFinite(role.score)?`${role.score}% instrucciones`:'Revisión manual'}));}}
   const oldOpen=openRuns;
   const block=node('section',{class:'vt-eval','data-outcome':busy?'queued':summary.state,'aria-label':`Prueba del flujo del Equipo ${id}`});
   block.append(node('div',{class:'vt-eval-heading'},[node('span',{class:'vt-eval-label',text:'Prueba del flujo'}),node('span',{class:'badge vt-eval-badge',text:busy?(latest?.result?.progress?LABELS.queued:'En cola'):summary.label,role:'status'})]));
   const note=!loaded?'Consultando resultados…':!configured&&!latest?'Disponible cuando se active el ejecutor.':summary.note;
   if(busy)block.append(liveProgress(latest));else block.append(node('p',{class:'vt-eval-note',text:note}));
   if(summary.total&&!busy)block.append(node('div',{class:'vt-eval-bar','aria-hidden':'true'},Array.from({length:summary.total},(_,i)=>node('span',{'data-passed':i<summary.passed?'true':'false'}))));
   if(latest&&!busy&&['passed','failed'].includes(latest.status)){block.append(scoresView(latest));block.append(node('p',{class:'vt-eval-note',text:'Total = 40% flujo + 60% instrucciones. Corresponde al repositorio y commit evaluados.'}));}
   const actions=node('div',{class:'vt-eval-actions'}),launch=node('button',{class:'btn',type:'button',text:busy?'En ejecución…':latest?'Volver a evaluar':'Evaluar flujo',disabled:!configured||busy||(audience==='student'&&id!==ownTeamId),'data-evaluate-team':id,'aria-label':`${latest?'Volver a evaluar':'Evaluar flujo'} del Equipo ${String(id).padStart(2,'0')}`});
   if(audience!=='student'||id===ownTeamId)actions.append(launch);else actions.append(node('span',{class:'vt-eval-note',text:'Solo este equipo y el admin pueden ejecutar su evaluación.'}));block.append(actions);
   if(latest){
    const details=node('details',{class:'vt-eval-results','data-evaluation-run':latest.id,...(oldOpen.has(latest.id)||busy?{open:''}:{})});
    details.append(node('summary',{text:busy?'Resultados en vivo':'Ver resultado'}),runDetails(latest));block.append(details);
    if(history.length>1){const archive=node('details',{class:'vt-eval-history'});archive.append(node('summary',{text:`Historial · ${history.length-1} anteriores`}));for(const run of history.slice(1)){const item=node('details');item.append(node('summary',{text:`${LABELS[run.status]} · ${run.commit.slice(0,8)}`}),runDetails(run));archive.append(item);}block.append(archive);}
   }
   const help=node('details',{class:'vt-eval-help'});help.append(node('summary',{text:'Qué incluye esta prueba'}),node('p',{text:'Ejecuta el código publicado del equipo con respuestas del modelo y decisiones humanas controladas. Comprueba recorrido, aprobaciones, reintentos, reanudación y errores. En Guardrails también comprueba el ciclo de Chapter y el límite de rondas. También revisa las instrucciones con una rúbrica estática y muestra evidencia por agente. No mide respuestas reales de la IA ni su conexión a Copilot. Los criterios no detectados requieren mejora o revisión manual del instructor.'}));block.append(help);
   mount.replaceChildren(block);
  }
 }
 async function load(){
  if(loading)return;
  const currentLab=lab,version=generation;loading=true;lastPoll=Date.now();render();
  try{const payload=await api('GET',null,currentLab);if(version!==generation)return;records=payload.evaluations;ownTeamId=payload.ownTeamId??null;configured=payload.configured;loaded=true;error='';}
  catch(e){if(version===generation)error=e.message;}
  finally{loading=false;render();if(version!==generation&&active)load();}
 }
 async function launchTeams(ids){
  const currentLab=lab,version=generation;ids.forEach(id=>launching.add(id));error='';render();const errors=[];
  for(const teamId of ids){
   try{const payload=await api('POST',{teamId},currentLab);if(version===generation)records=[payload.evaluation,...records.filter(r=>r.id!==payload.evaluation.id)];}
   catch(e){errors.push(`Equipo ${teamId}: ${e.message}`);}
   finally{launching.delete(teamId);if(version===generation)render();}
  }
  if(version===generation){error=errors.join(' ');render();}
 }
 root.addEventListener('toggle',event=>{const run=event.target.dataset.evaluationRun;if(run){if(event.target.open)openRuns.add(run);else if(event.target.isConnected)openRuns.delete(run);}},true);
 root.addEventListener('click',event=>{const launch=event.target.closest('[data-evaluate-team]');if(launch&&root.contains(launch)&&!launch.disabled)launchTeams([Number(launch.dataset.evaluateTeam)]);});
 refresh?.addEventListener('click',load);
 all?.addEventListener('click',()=>launchTeams(teams.filter(t=>!records.some(r=>r.teamId===t.id&&r.status==='queued')).map(t=>t.id)));
 return {
  update(nextLab,nextTeams){const changed=lab!==nextLab;lab=nextLab;teams=nextTeams;if(changed){generation++;records=[];configured=false;loaded=false;error='';if(active)load();}render();},
  start(){active=true;load();clearInterval(timer);timer=setInterval(()=>{if(document.visibilityState==='visible'&&Date.now()-lastPoll>=(records.some(r=>r.status==='queued')?2000:15000))load();},2000);},
  stop(){active=false;clearInterval(timer);}
 };
}
