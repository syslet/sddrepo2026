// Lab 4 · trabajo en equipo sobre las plantillas CrewAI y Guardrails.
// El catálogo de pasos del servidor se genera a partir de `stages`.
export const ROLES = [
  {id:'architect',name:'Architect',fn:'Diseño',duty:'Define la solución y el contrato de API.'},
  {id:'backend',name:'Backend',fn:'Construcción',duty:'Implementa el backend.'},
  {id:'frontend',name:'Frontend',fn:'Construcción',duty:'Implementa el frontend.'},
  {id:'testing',name:'Testing',fn:'Verificación',duty:'Diseña las pruebas y sus comandos de ejecución.'},
  {id:'security',name:'Security',fn:'Verificación',duty:'Revisa riesgos y propone correcciones verificables.'},
  {id:'chapter',name:'Chapter',fn:'Cierre',duty:'Revisa todas las entregas y emite el veredicto final.'}
];
export const ROLE_IDS = ROLES.map(role => role.id);
export const TEMPLATE_OWNER = 'NTTData-Academy';
export const LABS = {
  s1:{id:'crewai',session:'s1',title:'S1 · CrewAI',product:'CrewAI',description:'Laboratorio colaborativo para diseñar, desarrollar y validar software con seis agentes de CrewAI y supervisión humana.'},
  s2:{id:'guardrails',session:'s2',title:'S2 · Guardrails',product:'Guardrails',description:'Laboratorio colaborativo para refactorizar software con seis nodos de LangGraph, guardrails, evaluaciones y supervisión humana.'}
};
export const agenda = [
  {id:'s1',title:'S1 · CrewAI'},
  {id:'s2',title:'S2 · Guardrails'}
];
export function templateUrl(session, owner) {
  const lab = LABS[session];
  return 'https://github.com/new?' + new URLSearchParams({...owner && {owner},name:lab.id,description:lab.description,visibility:'public',template_owner:TEMPLATE_OWNER,template_name:lab.id});
}
export const templateRepoUrl = session => `https://github.com/${TEMPLATE_OWNER}/${LABS[session].id}`;
export const forkUrl = (session,leader='{capitan}') => `https://github.com/${leader}/${LABS[session].id}/fork`;
export function pullRequestUrl(session,leader,login,role,isLeader=false) {
 const unit=session==='s1'?'agente':'nodo';
 const query=new URLSearchParams({expand:'1',quick_pull:'1',title:`Ajusta el ${unit} ${role}`,body:`Rol: ${role}\nArchivo: agents/${role}.py\nDestino: ${leader}/${LABS[session].id}, rama main\n\nCambios realizados: [completa con tus cambios]\nEvidencia real: [adjunta los comandos ejecutados y sus salidas]\nRevisor: [indica a quién pides revisión]`});
 return `https://github.com/${leader}/${LABS[session].id}/compare/main...${isLeader?'':login+':'}agents/${role}?${query}`;
}


const TEAM_JSON = `{
  "roles": {
    "architect": "usuario-architect",
    "backend": "usuario-backend",
    "frontend": "usuario-frontend",
    "testing": "usuario-testing",
    "security": "usuario-security",
    "chapter": "usuario-chapter"
  }
}`;
const teamJsonLink = repo => `https://github.com/{capitan}/${repo}/new/main?` + new URLSearchParams({filename:'team.json',value:TEAM_JSON+'\n'});

// Tokens: {capitan} sale de la asignación del administrador (/api/lab4-team) y {rol} del rol que elige cada participante.
// links[].audience y commands[].audience: 'leader' o 'member' muestra el enlace solo a esa participación; leaderOnly oculta los comandos a los integrantes.
function teamSteps(session) {
  const lab = LABS[session], repo = lab.id, crew = session === 's1';
  const unit = crew ? 'agente' : 'nodo';
  const step = (n, data) => ({id:`d4-${session}-team-${String(n).padStart(2,'0')}`,session,...data});
  const venvBash = {kind:'command',label:'Crear el entorno en Bash',text:'python -m venv .venv\nif [ -f .venv/Scripts/activate ]; then\n  source .venv/Scripts/activate\nelse\n  source .venv/bin/activate\nfi\npython -m pip install -r requirements.txt\n[ -f .env ] || cp .env.example .env',why:'Crea el entorno virtual con Python 3.12, lo activa, instala las dependencias y copia la plantilla de variables solo si aún no tienes .env.',output:['El prompt muestra (.venv).','pip termina sin errores.','Existe .env en la raíz del repo.'],issues:['El comando python debe usar Python 3.12. En macOS o Linux puedes usar python3.12 para crear el entorno si ese es el nombre instalado.']};
  return [
    step(1,{
      title:'Revisa tu equipo y prepara el entorno',
      who:'Las seis personas',
      description:crew
        ? 'Revisa tu equipo, tu líder asignado y tu participación. Comprueba tu entorno en Bash. Cada equipo tiene seis personas y seis agentes de CrewAI: un archivo por persona.'
        : 'Revisa tu equipo, tu líder asignado y tu participación. Comprueba tu entorno en Bash. Cada equipo tiene seis personas y seis nodos de LangGraph: un archivo por persona.',
      commands:[
        {kind:'command',label:'Comprobar herramientas en Bash',text:'python --version\ngit --version\ngh --version',why:'Confirma que tienes Python 3.12, Git y GitHub CLI.',output:['Python 3.12.x','git version 2.x','gh version 2.x']},
        {kind:'command',label:'Sesión de GitHub CLI',text:'gh auth status',why:'GitHub CLI crea, clona y abre los PR del equipo. Debe estar autenticado con tu cuenta personal.',output:['Logged in to github.com account <tu-usuario>.'],issues:['Si no hay sesión, ejecuta gh auth login, elige GitHub.com y autentica en el navegador.']}
      ],
      explanation:{
        why:`El trabajo se reparte por archivos: cada persona edita un solo ${unit} en agents/<rol>.py y lo entrega con su propio PR en el repo del líder.`,
        actions:['El administrador asigna tu equipo y tu líder. El panel «Tu equipo» indica si eres líder o integrante. Solo el líder crea los repos y también toma uno de los seis roles.',`Repartan los seis roles exactos: ${ROLE_IDS.join(', ')}. Chapter es el revisor final; no existe el rol LT.`,'Cada persona necesita Python 3.11 a 3.13 (usa 3.12), Git, GitHub CLI y acceso a GitHub Copilot.','Tu equipo y tu líder aparecen solos al iniciar sesión. Elige un único rol para CrewAI y Guardrails en «Antes de empezar» y espera la confirmación; si ves «Pendiente de asignación», avisa al instructor.'],
        output:['Los tres comandos responden con su versión.','gh auth status indica tu cuenta.'],
        issues:['Si falta una persona, coordina el reparto con el instructor antes de empezar. El taller está preparado para seis personas por equipo.']
      },
      check:['Python 3.12, Git y GitHub CLI responden.','El equipo conoce al líder y el rol de cada persona.']
    }),
    step(2,{
      title:`Líder: crear ${repo} desde la plantilla`,
      who:'Solo el líder',
      leaderOnly:true,
      description:`El líder crea el repo ${repo} en su cuenta personal a partir de ${TEMPLATE_OWNER}/${repo}. Si eres integrante, espera a que el líder cree el repositorio y crea un fork de ese repo; no crees otro desde la plantilla.`,
      links:[{href:templateUrl(session),label:`Crear ${repo} en mi cuenta`,primary:true,audience:'leader'},{href:templateRepoUrl(session),label:`Ver plantilla ${TEMPLATE_OWNER}/${repo}`}],
      commands:[
        {kind:'command',label:'Líder: crear el repositorio con GitHub CLI',text:`gh repo create ${repo} --template ${TEMPLATE_OWNER}/${repo} --public`,why:`Crea {capitan}/${repo} como copia pública de la plantilla en tu cuenta. Equivale al botón de creación.`,parts:[`${repo}: el nombre debe ser exactamente ${repo} para que el seguimiento lo encuentre.`,`--template: copia ${TEMPLATE_OWNER}/${repo} sin historial compartido.`,'--public: cualquiera puede verlo; solo tú y tus colaboradores pueden publicar cambios.'],output:[`https://github.com/{capitan}/${repo}`],issues:[`Si ya existe un repo ${repo} en tu cuenta, avisa al instructor antes de usar otro nombre.`]}
      ],
      explanation:{
        why:'El repo del líder es el repo del equipo. Los integrantes publican sus ramas en forks; todos los PR y las revisiones llegan al repo del líder.',
        actions:[`Abre «Crear ${repo} en mi cuenta». El enlace abre directamente la creación desde la plantilla, con tu usuario como propietario, nombre ${repo}, descripción y visibilidad pública.`,'Revisa los valores y confirma con Create repository.',`No abras PR hacia ${TEMPLATE_OWNER}/${repo}: la plantilla central no recibe cambios del taller.`],
        output:[`Existe https://github.com/{capitan}/${repo}, público.`,`Bajo el nombre se lee «generated from ${TEMPLATE_OWNER}/${repo}».`],
        issues:['Si el formulario muestra otro propietario, cambia el selector Owner a tu cuenta personal.']
      },
      check:[`El repo {capitan}/${repo} existe y es público.`]
    }),
    step(3,{
      title:'Elegir tu rol y crear tu fork',
      who:'Líder e integrantes',
      description:'Elige tu rol en «Antes de empezar». Si eres integrante, abre el enlace y pulsa Create fork. El repo ya tiene su nombre.',
      links:[{href:`https://github.com/{capitan}/${repo}/edit/main/TEAM.md`,label:'Líder: editar TEAM.md',audience:'leader'},{href:teamJsonLink(repo),label:'Líder: crear team.json',audience:'leader'},{href:forkUrl(session),label:`Integrante: crear mi fork de ${repo}`,audience:'member',primary:true}],
      commands:[
        {kind:'file',audience:'leader',label:'team.json en la raíz del repo',text:TEAM_JSON,why:'Copia opcional del reparto de roles. El tablero usa el rol que cada persona guarda en «Antes de empezar». Usa los mismos usuarios en TEAM.md y team.json.',output:['Los seis roles tienen responsables.']}
      ],
      explanation:{
        why:'El líder usa su repo. Cada integrante crea su fork con el enlace de esta sesión.',
        actions:['Elige tu rol en «Antes de empezar» y espera la confirmación de guardado.','Líder: crea el repo del equipo con el enlace del paso anterior.','Integrante: abre «Crear mi fork» y pulsa Create fork. El nombre ya está definido.','Comprueba que tu fork aparezca en tu cuenta.'],
        output:['El líder tiene el repo generado desde la plantilla.','Cada integrante tiene un fork cuyo origen es el repo del líder.'],
        issues:['Si ya existe un repo con ese nombre en tu cuenta, verifica que sea un fork del líder. Un repo independiente creado desde la plantilla no sirve para este flujo.','Si aún no tienes equipo asignado o el líder no creó el repo, coordina con el instructor antes de crear el fork.']
      },
      check:['El repo del líder es público.','Cada integrante tiene un fork del líder; el líder usa su repo original.','Las seis personas eligieron roles diferentes en «Antes de empezar».']
    }),
    step(4,{
      title:crew ? 'Clonar el Crew y el proyecto de trabajo' : 'Clonar tu repo y preparar Python',
      who:'Cada persona',
      description:crew
        ? 'Clona tu repo crewai y el proyecto de producto. Puedes elegir cualquier repo de producto; el ejemplo usa workshop-auth-backend. El backend queda en ~/Documents/bcp-ai-labs/reqflow-workspace/workshop-auth-backend.'
        : `El clon queda en tu computadora, en ~/Documents/bcp-ai-labs/${repo}, al lado de reqflow-workspace. El líder clona su repo original y cada integrante su fork. origin debe apuntar a tu cuenta.`,
      links:[{href:forkUrl(session),label:`Crear mi fork de ${repo}`,audience:'member'}],
      commands:[
        {kind:'command',label:'Clonar el repo de mi cuenta',text:`mkdir -p ~/Documents/bcp-ai-labs\ncd ~/Documents/bcp-ai-labs\ngh repo clone {origen}/${repo}\ncd ${repo}\npwd`,why:`Usa Bash, también en Windows con Git Bash. Crea la carpeta base y deja el clon en ~/Documents/bcp-ai-labs/${repo}. Si tus laboratorios están en otra carpeta, usa esa ruta. El líder clona su repo original y el integrante su fork.`,output:[`Cloning into '${repo}'...`,`pwd termina en /Documents/bcp-ai-labs/${repo}.`],issues:[`Si ya existe el clon, entra en ~/Documents/bcp-ai-labs/${repo} y revisa git remote -v antes de continuar. No vuelvas a clonarlo encima.`]},
        {kind:'note',label:'Dónde queda cada repositorio',text:`~/Documents/bcp-ai-labs/${repo}/ → agentes, .venv y .env\n~/Documents/bcp-ai-labs/reqflow-workspace/ → repos del producto de los días anteriores`,why:`${repo} tiene su propio repositorio Git. Conserva el clon fuera de reqflow-workspace y de workshop-requirements-api. GitHub aloja el repo remoto; los comandos del laboratorio corren en tu computadora.`},
        {kind:'command',audience:'member',label:'Conectar mi fork con el repo del líder',text:`git remote get-url upstream >/dev/null 2>&1 || git remote add upstream https://github.com/{capitan}/${repo}.git\ngit remote -v`,why:'origin es tu fork para hacer push. upstream es el repo del líder, destino de los PR. Si upstream ya existe, comprueba su URL con git remote -v en lugar de añadirlo otra vez.',output:[`origin apunta a {usuario}/${repo}.`,`upstream apunta a {capitan}/${repo}.`]},
        venvBash,
        ...(crew ? [{kind:'command',label:'Clonar el proyecto de producto · backend por defecto',text:'PRODUCT_OWNER="{usuario}"\nPRODUCT_REPO="workshop-auth-backend"\nmkdir -p ~/Documents/bcp-ai-labs/reqflow-workspace\ncd ~/Documents/bcp-ai-labs/reqflow-workspace\nif [ ! -e "$PRODUCT_REPO" ]; then\n  gh repo clone "$PRODUCT_OWNER/$PRODUCT_REPO" "$PRODUCT_REPO"\nfi\ngit -C "$PRODUCT_REPO" remote -v\ncd ~/Documents/bcp-ai-labs/crewai',why:'Cambia PRODUCT_OWNER por el dueño del producto y PRODUCT_REPO si quieres trabajar con otro repositorio. El ejemplo clona tu workshop-auth-backend en reqflow-workspace. Si ya lo tienes desde los días anteriores, conserva esa copia y comprueba su remoto. Al terminar vuelves a crewai para ejecutar los agentes.',output:['Existe ~/Documents/bcp-ai-labs/reqflow-workspace/workshop-auth-backend con el código del backend.','El remoto del producto coincide con PRODUCT_OWNER/PRODUCT_REPO.'],issues:['S1 genera la solución en crewai/output/. El clon del producto queda disponible para revisar e integrar los archivos generados; main.py no lo lee ni lo modifica automáticamente.']}] : [])
      ],
      explanation:{
        why:'Cada persona trabaja con su propia copia local, .venv y .env. Los integrantes publican ramas en su fork; el líder publica en su repo original.',
        actions:[`Clona el repositorio de tu cuenta en ~/Documents/bcp-ai-labs/${repo}. Si usas otra carpeta base, conserva ${repo} al lado de reqflow-workspace.`,`Ejecuta los siguientes comandos desde la raíz de ${repo}, donde están main.py y requirements.txt.`,'Si eres integrante, añade upstream para identificar el repositorio del líder.','Comprueba git remote -v: origin debe ser tu cuenta, nunca NTTData-Academy.','Crea y activa el entorno virtual con el comando de Bash.',...(crew ? ['Clona o verifica el producto con el último comando. Puedes cambiar PRODUCT_OWNER y PRODUCT_REPO; workshop-auth-backend es el ejemplo por defecto.'] : [])],
        output:['origin apunta al repo de tu cuenta.','(.venv) aparece en el prompt.'],
        issues:['Si ya tienes otra carpeta con el mismo nombre, clona en otra ubicación.','Si clonaste directamente el repo del líder siendo integrante, vuelve a este paso y clona tu fork antes de continuar.']
      },
      check:['Clonaste tu repo y activaste el entorno virtual.','Como integrante, origin es tu fork y upstream es el repo del líder.',...(crew ? ['El producto está clonado y su remoto es correcto. Por defecto, es workshop-auth-backend.'] : [])]
    }),
    step(5,{
      title:'Iniciar sesión en Copilot CLI y configurar .env',
      who:'Cada integrante',
      description:crew
        ? 'Los agentes usan tu sesión de Copilot CLI. Después configura en .env el backlog que leerá el Crew.'
        : 'Los nodos usan tu sesión de Copilot CLI. Después configura en .env el repo de producto que se va a refactorizar.',
      links:[{href:'https://github.com/features/copilot/cli',label:'Instalar Copilot CLI'}],
      commands:[
        {kind:'command',label:'Iniciar sesión en Copilot CLI',text:'copilot\n/login',why:'Abre Copilot CLI; dentro, /login autentica tu cuenta en el navegador. El runtime de Python reutiliza esa sesión.',output:['Copilot CLI confirma la sesión con tu usuario.'],issues:['Si copilot no existe, instálalo desde la página de Copilot CLI y abre una terminal nueva.','Tu cuenta necesita una licencia de Copilot activa.']},
        {kind:'command',label:'Descargar el runtime (opcional, antes del taller)',text:'python -m copilot download-runtime',why:'Descarga por adelantado el runtime que usa el paquete de Python para hablar con Copilot.',output:['La descarga termina sin errores.']},
        ...(crew ? [
          {kind:'file',label:'Variables de .env para S1',text:'COPILOT_USE_LOGGED_IN_USER=true\nPROJECTS_MCP_URL=http://localhost:8081\nPROJECTS_MCP_API_KEY=<clave-del-taller>\nGITHUB_OWNER=<owner-del-producto>\nGITHUB_REPO=workshop-requirements-api',why:'COPILOT_USE_LOGGED_IN_USER usa la sesión de /login. GITHUB_OWNER y GITHUB_REPO identifican el repo del requerimiento. El Crew consulta GitHub Projects por MCP y lee el título, la descripción y los criterios de aceptación del issue seleccionado.',output:['.env tiene los cinco valores. No lo subas a Git.'],issues:['Si usas el MCP local, levántalo en otra terminal Bash desde support/mcp-local con bash start-mcp.sh. Requiere la imagen localhost/mcp-github-project-manager:latest del instructor; si no la tienes, pide el endpoint del taller.']},
          {kind:'note',label:'Requerimiento y proyecto de trabajo',text:'Requerimiento: issue de <owner-del-producto>/workshop-requirements-api agregado al GitHub Project.\nProyecto de trabajo por defecto: reqflow-workspace/workshop-auth-backend. Puedes elegir otro repo al clonar.\nSelección: python main.py muestra el proyecto y su backlog; tú eliges la funcionalidad.\nSalida del Crew: crewai/output/.',why:'El issue describe el trabajo que se realizará sobre el producto clonado. En S1, GITHUB_OWNER y GITHUB_REPO apuntan al repositorio del issue, aunque el código del producto esté en workshop-auth-backend u otro repo. Seleccionas el item al ejecutar main.py. Revisa la salida de crewai/output/ antes de integrarla en el producto.'}
        ] : [
          {kind:'command',label:'Autenticar GitHub CLI',text:'gh auth login',why:'El flujo clona el producto, publica una rama y abre el PR con gh.',output:['Logged in as <tu-usuario>.']},
          {kind:'file',label:'Variables de .env para S2 · backend por defecto',text:'COPILOT_USE_LOGGED_IN_USER=true\nGITHUB_OWNER=<owner-del-producto>\nGITHUB_REPO=workshop-auth-backend\nGITHUB_ISSUE=<número-del-issue>\nGIT_BASE_BRANCH=main\nGIT_HEAD_BRANCH=feature/equipo-XX/workshop-refactor',why:'Por defecto se refactoriza workshop-auth-backend. Puedes elegir cualquier otro repo de producto cambiando GITHUB_OWNER y GITHUB_REPO. Necesitas permiso para crear ramas y PR en ese repo.',output:['.env tiene los valores del producto. No lo subas a Git.'],issues:['El repo de los agentes ({capitan}/guardrails) no es el repo de producto: GITHUB_OWNER y GITHUB_REPO apuntan al código que se revisa.']},
          {kind:'note',label:'Dónde se clona el producto en S2',text:'Repo por defecto: <owner-del-producto>/workshop-auth-backend\nClon automático al ejecutar python main.py: guardrails/.tmp/workshop-auth-backend/\nOtro producto: cambia GITHUB_OWNER y GITHUB_REPO en .env; el clon queda en guardrails/.tmp/<GITHUB_REPO>/.',why:'Guardrails clona el producto al iniciar el flujo y trabaja sobre esa copia. Si ya existe, intenta actualizarla. La copia de reqflow-workspace de los días anteriores queda separada del clon que usa S2.'}
        ])
      ],
      explanation:{
        why:'El modelo predeterminado es gpt-6-luna con esfuerzo high. Cada llamada consume uso de tu plan de Copilot.',
        actions:['Instala Copilot CLI y ejecuta copilot y luego /login.','Completa .env con los valores del taller. .env está en .gitignore: cada persona tiene el suyo.',crew ? 'Pide al instructor la URL y la clave del MCP Projects, o usa el MCP local.' : 'Elige el issue del producto que cierra el PR.'],
        output:['Copilot CLI tiene sesión iniciada.','.env completo en la raíz del repo.'],
        issues:['No escribas tokens en archivos versionados ni en los PR.']
      },
      check:['Copilot CLI tiene sesión y .env está completo.']
    }),
    step(6,{
      title:`Crear tu rama y editar tu ${unit}`,
      who:'Cada integrante',
      description:crew
        ? 'Cada persona edita solo agents/{rol}.py: rol, objetivo, contexto y la tarea de su agente.'
        : 'Cada persona edita solo agents/{rol}.py: el prompt y los entregables de su nodo.',
      commands:[
        {kind:'command',label:'Rama de tu rol',text:'git switch main\ngit pull\ngit switch -c agents/{rol}',why:'Parte de la última versión de main y crea una rama solo para tu archivo.',output:["Switched to a new branch 'agents/{rol}'"]},
        {kind:'command',label:'Abrir tu archivo',text:'code agents/{rol}.py',why:'Abre tu archivo en VS Code. Usa otro editor si lo prefieres.',output:['Se abre agents/{rol}.py.']}
      ],
      explanation:{
        why:crew
          ? 'Cada archivo de agents/ define un Agent de CrewAI y su build_task. El orden es architect → backend → frontend → testing → security → chapter.'
          : 'Cada archivo de agents/ implementa un nodo. graph/nodes.py lo conecta con el modelo y graph/graph.py define el orden y el ciclo de revisión del Chapter.',
        actions:crew
          ? ['Ajusta role, goal y backstory para tu responsabilidad.','Ajusta las instrucciones y el formato de salida de build_task.','Coordina con Architect cualquier cambio de contrato de API.','No cambies KEY ni SPEC_FILE: el pipeline los usa para guardar artefactos.']
          : ['Ajusta el prompt de tu nodo y los entregables que exige.','Mantén el formato «### ruta/archivo» + bloque de código: el flujo extrae los cambios con él.','Architect reúne diagnóstico y plan; Chapter revisa y puede devolver observaciones hasta MAX_REVIEW_ROUNDS.','No cambies harness/, guardrails/ ni evals/ sin acordarlo con el equipo.'],
        output:['git status muestra solo agents/{rol}.py modificado.'],
        issues:['Si tocas otros archivos, el PR mezcla trabajo de varias personas. Revierte con git restore <archivo>.']
      },
      check:['Tu rama agents/{rol} tiene cambios solo en agents/{rol}.py.']
    }),
    step(7,{
      title:'Verificar sin servicios externos',
      who:'Cada integrante',
      description:crew
        ? 'verify.py recorre los seis roles con respuestas simuladas. No llama a Copilot ni a MCP.'
        : 'verify.py recorre el grafo real con respuestas simuladas del modelo. No llama a Copilot, MCP ni GitHub.',
      commands:[
        {kind:'command',label:'Checks offline',text:'python tools/verify.py',why:crew ? 'Comprueba los seis roles, los artefactos, el contexto y la reanudación sin credenciales.' : 'Comprueba pausas humanas, los seis roles, feedback, límite de rondas, reanudación y guardrails sin credenciales.',output:crew ? ['All pipeline checks passed. No model or external service was called.'] : ['Todos los tests terminan en OK.'],issues:['Lee el primer test que falla: indica qué contrato de tu archivo cambió.','El mismo comando corre en GitHub Actions en cada push y PR.']}
      ],
      explanation:{
        why:'Es la comprobación rápida antes de gastar llamadas al modelo. Que pase no demuestra que tu agente sea bueno: solo que respeta el contrato del pipeline.',
        actions:['Ejecuta verify.py con el entorno virtual activo.','Corrige y repite hasta que pase.'],
        output:['El comando termina con código 0.'],
        issues:['ModuleNotFoundError: activa .venv y reinstala requirements.txt.']
      },
      check:['python tools/verify.py pasa en tu rama.']
    }),
    step(8,{
      title:crew ? 'Ejecutar el Crew con main.py' : 'Ejecutar el flujo con main.py',
      who:'Cada integrante · integración final desde main',
      description:crew
        ? 'Desde la raíz del clon crewai, ejecuta el pipeline y elige el issue de workshop-requirements-api en el backlog del GitHub Project. Cada paso es un mini-Crew de un agente con aprobación humana. La solución queda en crewai/output/.'
        : 'Ejecuta el flujo real: main.py clona el producto configurado en .env. Por defecto usa workshop-auth-backend y lo guarda en guardrails/.tmp/workshop-auth-backend/. Confirma el tipo de proyecto y revisa cada nodo antes de publicar el PR.',
      commands:[
        {kind:'command',label:'Ejecutar',text:'python main.py',why:'Ejecuta el pipeline con Copilot. Consume uso de tu plan.',output:crew ? ['[MCP Proyectos] Autenticando...','Lista de proyectos y funcionalidades del backlog.'] : ['Confirmación del tipo de proyecto y salida del primer nodo.'],issues:crew ? ['Si falla la conexión MCP, revisa PROJECTS_MCP_URL y que el servicio esté levantado.'] : ['Si falla el clon, revisa gh auth status y los permisos sobre el repo de producto.']}
      ],
      explanation:{
        why:'Puedes probar tu cambio desde tu rama. La ejecución integrada la hace una persona desde main cuando los seis PR estén integrados, con el equipo participando en las aprobaciones.',
        actions:crew
          ? ['Selecciona el GitHub Project del equipo. Si solo hay uno, main.py lo selecciona automáticamente.','Elige en el backlog el item asociado al issue del requerimiento. Confirma su título y criterios de aceptación antes de aprobar al primer agente.','Lee la salida de cada agente antes de responder.','Revisa output/specs/, output/backend-quarkus/, output/frontend-angular/ y output/db/ dentro del clon crewai. S1 no clona ni modifica automáticamente workshop-requirements-api.','El checkpoint permite retomar los pasos ya aprobados.']
          : ['Confirma el tipo de proyecto.','Los cambios de backend, frontend y tests se extraen en el clon local del producto.','Si el Chapter devuelve observaciones, el ciclo repite desde backend hasta MAX_REVIEW_ROUNDS.'],
        output:crew ? ['output/specs/ contiene los informes de cada rol.'] : ['output/ contiene los informes y evidence/ la URL del PR.'],
        issues:['No compartas checkpoints entre ejecuciones de distintas computadoras.']
      },
      check:['main.py llegó a la aprobación de tu rol.']
    }),
    step(9,{
      title:crew ? 'Revisar aprobaciones humanas y evidencia' : 'Revisar aprobaciones, evaluaciones y evidencia',
      who:'Cada integrante',
      description:crew
        ? 'En cada pausa decides s, r o n. Revisa los artefactos que deja tu agente antes de aprobar.'
        : 'En cada pausa decides s, r o n. Revisa la salida, la evidencia y, si corresponde, las evaluaciones.',
      commands:[
        {kind:'note',label:'Opciones de la aprobación humana',text:'s  aprobar y continuar\nr  reintentar con feedback\nn  rechazar y detener el flujo',why:'La aprobación humana se conserva entre etapas. Con r puedes escribir instrucciones adicionales para el agente.'},
        ...(crew ? [
          {kind:'command',label:'Artefactos de la ejecución',text:'ls output/specs',why:'Lista los informes: user_story, backend_spec, frontend_spec, testing_report, security_report y chapter_review.',output:['user_story.md  backend_spec.md  frontend_spec.md  testing_report.md  security_report.md  chapter_review.md']},
        ] : [
          {kind:'command',label:'Evaluación básica (consume llamadas al modelo)',text:'python evals/eval_basic.py',why:'Ejecuta el pipeline real y guarda los resultados en evidence/eval_results.json.',output:['evidence/eval_results.json'],issues:['evals/contract_evals.py requiere además los servicios del producto levantados.']},
          {kind:'command',label:'Evidencia de la ejecución',text:'ls output evidence',why:'architecture_report, backend_refactor, frontend_refactor, testing_report, security_report y chapter_report; las rondas extra usan _r<N>. evidence/ guarda compliance, evals y la URL del PR.'},
        ])
      ],
      explanation:{
        why:crew
          ? 'Los agentes generan texto y archivos. El informe de pruebas propone tests; no demuestra que pasaron.'
          : 'Los guardrails de salida detectan estructura y patrones; no reemplazan la validación humana. Llegar al límite de rondas no equivale a una aprobación.',
        actions:['Lee el informe de tu rol y compáralo con lo que pediste en tu archivo.','Si las pruebas propuestas se ejecutan, adjunta la salida real al PR.',crew ? 'output/ está en .gitignore: copia al PR solo los extractos relevantes.' : 'output/ y evidence/ están en .gitignore: copia al PR solo los extractos relevantes.'],
        output:['Sabes qué cambiarías de tu agente y qué evidencia adjuntarás.'],
        issues:['No pegues secretos, tokens ni datos personales en el PR.']
      },
      check:['Revisaste la salida de tu rol y elegiste la evidencia para el PR.']
    }),
    step(10,{
      title:'Commit y push de tu rama',
      who:'Cada integrante',
      description:'Publica solo tu archivo en tu rama agents/<rol>. Los integrantes hacen push a su fork; el líder hace push a su repo original.',
      commands:[
        {kind:'command',label:'Revisar el cambio',text:'git status\ngit diff agents/{rol}.py',why:'Confirma que solo cambió tu archivo antes de crear el commit.'},
        {kind:'command',label:'Commit y push',text:`git add agents/{rol}.py\ngit commit -m "Ajusta el ${unit} {rol}"\ngit push -u origin agents/{rol}`,why:'Crea el commit con tu archivo y publica la rama en origin. Para integrantes, origin es su fork; para el líder, su repo original.',output:[`To https://github.com/{origen}/${repo}.git`,' * [new branch]      agents/{rol} -> agents/{rol}'],issues:['Si git pide identidad, configura git config --global user.name y user.email.','Nunca agregues .env ni output/.']}
      ],
      explanation:{
        why:'Un commit por rol hace legible la revisión y permite al tablero asociar el PR con tu archivo.',
        actions:['Revisa el diff.','Haz commit solo de agents/{rol}.py.','Publica la rama.'],
        output:['La rama agents/{rol} aparece en GitHub.'],
        issues:[`Si el push intenta ir a ${TEMPLATE_OWNER}, revisa git remote -v: origin debe ser el repo de tu cuenta.`,'Si eres integrante y el push apunta al líder, revisa el paso de clonado: origin debe ser tu fork. No necesitas una invitación para publicar en tu propio fork.']
      },
      check:['La rama agents/{rol} está publicada en tu fork si eres integrante, o en tu repo original si eres líder.']
    }),
    step(11,{
      title:'Abrir el PR y pedir revisión',
      who:'Cada integrante · revisa un compañero',
      description:'Abre el PR hacia main del repo del líder. Otra persona del equipo lo revisa antes de integrarlo.',
      links:[{href:`https://github.com/{capitan}/${repo}/pulls`,label:'Ver PR del equipo'}],
      commands:[
        {kind:'command',audience:'leader',label:'Crear el PR en el repo del líder',text:`gh pr create --repo {capitan}/${repo} --base main --head {head} --title "Ajusta el ${unit} {rol}" --body "Cambios en agents/{rol}.py. Evidencia: <extractos y salidas reales>"`,why:'Abre el PR desde tu rama publicada hacia main del repo del líder. --repo evita que gh proponga la plantilla central. Abrir el PR no integra los cambios; otra persona lo revisa y alguien con permisos hace el merge según las reglas del repo.',parts:[`--repo {capitan}/${repo}: el PR va al repo del equipo, nunca a ${TEMPLATE_OWNER}/${repo}.`,'--head: tu usuario y rama si eres integrante, o solo la rama si eres líder.','--body: resume el cambio y adjunta la evidencia revisada.','Ejecuta gh auth status: el autor debe ser la misma cuenta con la que elegiste tu rol. No uses --draft.'],output:[`https://github.com/{capitan}/${repo}/pull/<n>`]},
        {kind:'command',audience:'leader',label:'Confirmar que enviaste tu PR',text:`gh pr view <n> --repo {capitan}/${repo} --json url,state,isDraft,author,baseRefName,files`,why:'Sustituye <n> por el número del PR que acabas de abrir. Comprueba que author.login sea tu cuenta, baseRefName sea main, isDraft sea false y files incluya agents/{rol}.py. Guarda la URL de la entrega.',output:['state es OPEN o MERGED; la URL pertenece al repositorio del líder.'],issues:['Un PR cerrado sin integrar, en borrador, de otra persona o enviado a la plantilla central no valida tu entrega.']},
        {kind:'command',label:'Compañero: revisar el PR',text:`gh pr checkout <n> --repo {capitan}/${repo}\npython tools/verify.py\ngh pr review <n> --repo {capitan}/${repo} --approve`,why:'El revisor prueba la rama y aprueba, o usa --request-changes -b "motivo" para pedir cambios.'},
        {kind:'command',audience:'leader',label:'Líder: integrar tras la aprobación',text:`gh pr merge <n> --repo {capitan}/${repo} --squash --delete-branch`,why:'Integra el cambio en main cuando hay aprobación y el check Verify está en verde.'}
      ],
      explanation:{
        why:'El PR es la evidencia publicada del trabajo de cada rol. El tablero verifica el autor contra tu rol elegido, el archivo agents/{rol}.py y la rama de destino del repo del líder. Distingue PR abierto e integrado; entregar no equivale a aprobar la calidad del agente.',
        actions:['Abre el PR desde tu propia cuenta, con la evidencia en la descripción y sin marcarlo como borrador.','Usa «Abrir mi PR hacia el líder»: base repository es el repo del líder, base main; head repository es tu fork y compare agents/{rol}. Para el líder, ambas ramas pertenecen a su repo. Revisa los cambios y confirma Create pull request.','Ejecuta «Confirmar que enviaste tu PR» y conserva la URL. El instructor ve el enlace, autor y estado en Equipos; puede usar Actualizar desde GitHub, sujeto al límite de consultas.','Pide revisión a otro compañero. Chapter puede revisar los otros cinco PR; otro integrante revisa el de Chapter.','Atiende los comentarios con nuevos commits en la misma rama.','El líder integra con revisión y Verify en verde. GitHub puede pedirle aprobar la ejecución de Actions de un PR procedente de un fork; debe revisar el cambio antes de autorizarla.'],
        output:['El PR aparece en la pestaña Pull requests del repo del líder.'],
        issues:['Un check verde valida el contrato del pipeline, no que el agente esté terminado.']
      },
      check:['Tu PR tiene URL, autor correcto, destino main y modifica tu archivo.','Otra persona revisó tu PR; el tablero permite al instructor consultar la entrega.']
    })
  ];
}
export const stages = [...teamSteps('s1'), ...teamSteps('s2')];
export const sessions = agenda.map(group => ({...group, ...LABS[group.id], stages:stages.filter(stage => stage.session === group.id)}));
export const FLOW_VERSION = 5;
export function emptySnapshot() {
  return {flowVersion:FLOW_VERSION,cwd:'/curso/lab4',completed:stages.map(() => false),approved:stages.map(() => false),files:{},history:[],branch:'main',staged:false,committed:false,tagged:false,evidence:{}};
}
