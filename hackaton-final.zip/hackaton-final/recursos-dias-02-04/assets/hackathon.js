(() => {
  const menu = document.querySelector('.hackathon-menu');
  const compactMenu = matchMedia('(max-width: 1000px)');
  const syncMenu = () => { menu.open = !compactMenu.matches; };
  syncMenu();
  compactMenu.addEventListener('change', syncMenu);
  const markdown = JSON.parse(document.getElementById('markdown-source').textContent);
  const copy = document.querySelector('[data-copy-markdown]');
  const tabs = [...document.querySelectorAll('[data-view]')];
  const panel = document.getElementById('markdown-panel');
  const reading = document.getElementById('document-reading');
  const status = document.getElementById('document-status');
  const expand = document.querySelector('[data-expand-markdown]');
  let feedbackTimer;

  reading.querySelectorAll('pre').forEach((pre, index) => {
    const code = pre.querySelector('code') || pre;
    const block = document.createElement('div');
    block.className = 'document-code';
    const toolbar = document.createElement('div');
    toolbar.className = 'document-code-toolbar';
    const title = document.createElement('span');
    title.textContent = code.className.match(/language-([\w-]+)/)?.[1] || 'Código';
    const button = document.createElement('button');
    button.className = 'btn';
    button.type = 'button';
    button.textContent = 'Copiar';
    button.setAttribute('aria-label', `Copiar bloque de código ${index + 1}`);
    const feedback = document.createElement('p');
    feedback.className = 'document-code-status';
    feedback.setAttribute('role', 'status');
    pre.tabIndex = 0;
    pre.setAttribute('aria-label', `Bloque de código ${index + 1}`);
    pre.before(block);
    toolbar.append(title, button);
    block.append(toolbar, pre, feedback);
    let reset;
    button.addEventListener('click', async () => {
      clearTimeout(reset);
      feedback.textContent = '';
      try {
        await navigator.clipboard.writeText(code.textContent);
        button.textContent = 'Copiado';
        feedback.textContent = 'Código copiado al portapapeles.';
      } catch {
        pre.focus();
        const range = document.createRange();
        range.selectNodeContents(code);
        const selection = window.getSelection();
        selection.removeAllRanges();
        selection.addRange(range);
        feedback.textContent = 'Código seleccionado. Cópialo con Ctrl+C o ⌘C.';
      }
      reset = setTimeout(() => { button.textContent = 'Copiar'; feedback.textContent = ''; }, 2500);
    });
  });

  function showMarkdown(show) {
    panel.hidden = !show;
    reading.hidden = show;
    tabs.forEach(tab => {
      const selected = (tab.dataset.view === 'markdown') === show;
      tab.setAttribute('aria-selected', String(selected));
      tab.tabIndex = selected ? 0 : -1;
    });
  }
  tabs.forEach((tab, index) => {
    tab.addEventListener('click', () => showMarkdown(tab.dataset.view === 'markdown'));
    tab.addEventListener('keydown', event => {
      if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
      event.preventDefault();
      const next = event.key === 'Home' ? tabs[0] : event.key === 'End' ? tabs.at(-1) : tabs[1 - index];
      showMarkdown(next.dataset.view === 'markdown');
      next.focus();
    });
  });
  expand.addEventListener('click', () => {
    const expanded = expand.getAttribute('aria-expanded') !== 'true';
    expand.setAttribute('aria-expanded', String(expanded));
    expand.setAttribute('aria-label', expanded ? 'Contraer Markdown' : 'Expandir Markdown');
    expand.title = expanded ? 'Contraer Markdown' : 'Expandir Markdown';
    panel.classList.toggle('is-expanded', expanded);
  });
  copy.addEventListener('click', async () => {
    copy.disabled = true;
    clearTimeout(feedbackTimer);
    status.textContent = '';
    status.classList.remove('is-error');
    try {
      await navigator.clipboard.writeText(markdown);
      copy.querySelector('span').textContent = 'Copiado';
      status.textContent = 'Markdown copiado';
      feedbackTimer = setTimeout(() => {
  const menu = document.querySelector('.hackathon-menu');
  const compactMenu = matchMedia('(max-width: 1000px)');
  const syncMenu = () => { menu.open = !compactMenu.matches; };
  syncMenu();
  compactMenu.addEventListener('change', syncMenu);
        copy.querySelector('span').textContent = 'Copiar para IA';
        status.textContent = '';
      }, 2500);
    } catch {
      copy.querySelector('span').textContent = 'Copiar para IA';
      showMarkdown(true);
      const code = document.getElementById('markdown-code');
      code.focus();
      const range = document.createRange();
      range.selectNodeContents(code);
      const selection = window.getSelection();
      selection.removeAllRanges();
      selection.addRange(range);
      status.classList.add('is-error');
      status.textContent = 'Copia el Markdown seleccionado con Ctrl+C o ⌘C.';
    } finally {
      copy.disabled = false;
    }
  });
})();

(() => {
  if (!location.pathname.startsWith('/dia-05/')) return;
  const canvas = document.createElement('canvas');
  canvas.className = 'hackathon-flow';
  canvas.setAttribute('aria-hidden', 'true');
  document.body.prepend(canvas);
  const context = canvas.getContext('2d');
  if (!context) { canvas.remove(); return; }
  const motion = matchMedia('(prefers-reduced-motion: reduce)');
  const contrast = matchMedia('(forced-colors: active)');
  let width, height, frame = 0, elapsed = 8, previous = 0, lastPaint = 0;

  function draw() {
    const dark = document.documentElement.dataset.theme === 'dark';
    context.clearRect(0, 0, width, height);
    context.lineWidth = 1.3;
    context.setLineDash([60, 140]);
    for (let index = 0; index < 14; index++) {
      const offset = index / 14;
      context.lineDashOffset = -elapsed * (30 + index * 3);
      const color = index % 5 === 2 ? '255,127,0' : dark ? '24,162,251' : '0,113,187';
      context.strokeStyle = `rgba(${color},${.2 + .1 * Math.sin(elapsed * .5 + index)})`;
      context.beginPath();
      context.moveTo(-20, height * (.15 + offset * .5));
      context.bezierCurveTo(width * .12, height * (.5 + offset * .3), width * .25, height * (.9 + offset * .05), width * (.6 + offset * .4), height * (.86 + offset * .12));
      context.stroke();
      context.beginPath();
      context.moveTo(width + 20, height * (.05 + offset * .4));
      context.bezierCurveTo(width * (.9 - offset * .05), height * .4, width * .92, height * .75, width * (.75 - offset * .2), height + 20);
      context.stroke();
    }
    context.setLineDash([]);
    context.globalCompositeOperation = 'destination-out';
    const veil = context.createRadialGradient(width * .5, height * .4, 0, width * .5, height * .4, Math.max(width, height) * .6);
    veil.addColorStop(0, 'rgba(0,0,0,.94)');
    veil.addColorStop(.55, 'rgba(0,0,0,.55)');
    veil.addColorStop(1, 'rgba(0,0,0,0)');
    context.fillStyle = veil;
    context.fillRect(0, 0, width, height);
    context.globalCompositeOperation = 'source-over';
  }
  function tick(now) {
    elapsed += Math.min(now - previous, 50) / 1000;
    previous = now;
    if (now - lastPaint >= 32) { draw(); lastPaint = now; }
    frame = requestAnimationFrame(tick);
  }
  function sync() {
    cancelAnimationFrame(frame);
    frame = 0;
    if (document.hidden || contrast.matches) return;
    draw();
    if (!motion.matches) { previous = performance.now(); frame = requestAnimationFrame(tick); }
  }
  function resize() {
    width = innerWidth;
    height = innerHeight;
    const ratio = Math.min(devicePixelRatio || 1, 2);
    canvas.width = Math.round(width * ratio);
    canvas.height = Math.round(height * ratio);
    context.setTransform(ratio, 0, 0, ratio, 0, 0);
    draw();
  }
  addEventListener('resize', resize);
  document.addEventListener('visibilitychange', sync);
  motion.addEventListener('change', sync);
  contrast.addEventListener('change', sync);
  new MutationObserver(draw).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
  addEventListener('pagehide', () => { cancelAnimationFrame(frame); frame = 0; });
  addEventListener('pageshow', sync);
  resize();
  sync();
})();
