// Generated from the original Lab 3 guide and modules. Do not edit.
export const guideData={
  "agenda": [
    {
      "id": "s1",
      "title": "S1 · OpenSpec / Spec Kit + Constitution (conceptos) → contrato inicial"
    },
    {
      "id": "s2",
      "title": "S2 · Specify → Plan → Tasks → Validate (diseño, plan y gates)"
    },
    {
      "id": "s3",
      "title": "S3 · Fundamentos de agente: model + tools + context + loop"
    },
    {
      "id": "s4",
      "title": "S4 · Patrones: routing, evaluator, HITL → PR final"
    }
  ],
  "stages": [
    {
      "issueFallback": null,
      "id": "d3-s1-paso-01",
      "session": "s1",
      "title": "Preparar OpenSpec en workshop-auth-backend",
      "description": "Instala la CLI, inicializa seleccionando GitHub Copilot, conserva el schema estándar spec-driven y configura el contexto/reglas del laboratorio.",
      "role": "Guía original · s04-openspec-sdd/STEP_0_OPENSPEC.md",
      "source": "s04-openspec-sdd/STEP_0_OPENSPEC.md",
      "why": "Prepara OpenSpec para trabajar sobre el backend con GitHub Copilot y el schema spec-driven.",
      "explanation": {
        "why": "Prepara OpenSpec para trabajar sobre el backend con GitHub Copilot y el schema spec-driven.",
        "where": "En la raíz de tu workshop-auth-backend local, donde está pom.xml.",
        "actions": [
          "Comprueba Node.js e instala la CLI.",
          "Inicializa el backend con GitHub Copilot seleccionado.",
          "Revisa la configuración generada y agrega el contexto del producto sin borrar propiedades existentes."
        ],
        "output": "El repositorio debe tener la estructura OpenSpec, la integración en .github/ y una configuración que conserve el flujo proposal → specs → design → tasks → apply.",
        "issues": []
      },
      "commands": [
        {
          "text": "node --version",
          "kind": "command",
          "executable": false,
          "source": "s04-openspec-sdd/STEP_0_OPENSPEC.md",
          "sourceBlock": 0,
          "label": "Comprobar la versión de Node.js",
          "why": "Muestra qué versión de Node.js encuentra tu terminal. OpenSpec necesita Node.js para ejecutar su CLI.",
          "where": "En Git Bash de tu equipo, antes de instalar OpenSpec.",
          "parts": [
            "node es el ejecutable de Node.js que resuelve el PATH de tu terminal.",
            "--version imprime su versión y termina. No instala ni modifica archivos del proyecto."
          ],
          "output": "Debe aparecer una versión con formato vMAJOR.MINOR.PATCH. La guía requiere Node.js 20.19.0 o superior. Si aparece command not found, la terminal no encuentra Node.js.",
          "issues": [
            "Si acabas de instalar Node.js, abre una terminal nueva y repite la consulta. Una versión inferior al requisito debe actualizarse antes de instalar OpenSpec."
          ]
        },
        {
          "text": "npm install -g @fission-ai/openspec@latest",
          "kind": "command",
          "executable": false,
          "source": "s04-openspec-sdd/STEP_0_OPENSPEC.md",
          "sourceBlock": 1,
          "label": "Instalar la CLI de OpenSpec",
          "why": "Descarga e instala OpenSpec para que el comando openspec esté disponible en tu equipo. Esta instrucción prepara la herramienta; la configuración del backend se crea después con openspec init.",
          "where": "En Git Bash de tu equipo, con Node.js y npm instalados y acceso al registro de npm.",
          "parts": [
            "npm es el gestor de paquetes que acompaña a Node.js.",
            "install descarga el paquete y sus dependencias.",
            "-g instala el paquete en la ubicación global de npm para tu entorno, en lugar de añadirlo a node_modules del backend.",
            "@fission-ai/openspec es el nombre completo del paquete; @fission-ai identifica su organización en npm.",
            "@latest selecciona la versión que el publicador marque como latest en ese momento; no fija una versión concreta."
          ],
          "output": "npm mostrará su resumen de instalación. La cantidad de paquetes y los avisos pueden variar. Comprueba el resultado ejecutando openspec --version en la misma terminal.",
          "issues": [
            "Un error de red o de permisos de npm impide completar la instalación. Conserva el mensaje y corrige esa causa antes de inicializar el repositorio.",
            "Si openspec no se encuentra después de instalar, revisa que la ubicación global de ejecutables de npm esté en PATH y abre una terminal nueva."
          ]
        },
        {
          "text": "openspec --version",
          "kind": "command",
          "executable": false,
          "source": "s04-openspec-sdd/STEP_0_OPENSPEC.md",
          "sourceBlock": 1,
          "label": "Comprobar la instalación de OpenSpec",
          "why": "Consulta la versión de la CLI instalada para confirmar que tu terminal puede encontrar y ejecutar OpenSpec.",
          "where": "En Git Bash de tu equipo. La terminal web no ejecuta este comando.",
          "parts": [
            "openspec invoca la CLI instalada con npm.",
            "--version pide únicamente su versión; no inicializa el backend ni crea artefactos."
          ],
          "output": "Debe aparecer la versión instalada de OpenSpec. Anótala junto a tu evidencia del laboratorio. Si aparece command not found, todavía falta resolver la instalación o el PATH."
        },
        {
          "text": "openspec init",
          "kind": "command",
          "executable": true,
          "source": "s04-openspec-sdd/STEP_0_OPENSPEC.md",
          "sourceBlock": 2,
          "label": "Inicializar OpenSpec en el backend",
          "why": "Prepara la estructura de OpenSpec y los workflows de GitHub Copilot dentro de workshop-auth-backend.",
          "where": "En tu backend local. El botón ▶ de esta web reproduce la inicialización de referencia con GitHub Copilot seleccionado.",
          "parts": [
            "openspec ejecuta la CLI de gestión de cambios.",
            "init prepara este repositorio para usar OpenSpec. En la ejecución local selecciona GitHub Copilot cuando la CLI lo pregunte.",
            "Conserva el schema spec-driven. Incorpora el contexto del producto sin borrar la configuración que genere la herramienta."
          ],
          "output": "Comprueba que aparezcan openspec/config.yaml, la estructura de openspec/ y los archivos de integración en .github/. Revisa el diff y confirma schema: spec-driven. La terminal web muestra la captura de esa inicialización.",
          "issues": [
            "Si el proyecto ya está inicializado, revisa su configuración antes de repetir el setup. La referencia web corresponde a la primera inicialización y no sobrescribe una segunda configuración."
          ]
        },
        {
          "text": "openspec list",
          "kind": "command",
          "executable": true,
          "source": "s04-openspec-sdd/STEP_0_OPENSPEC.md",
          "sourceBlock": 9,
          "label": "Consultar los cambios de OpenSpec",
          "why": "Lista los cambios activos que OpenSpec reconoce en este repositorio. Sirve para identificar el nombre del cambio que usarás en status y validate.",
          "where": "En tu backend inicializado. En esta web, ▶ muestra la referencia del proyecto recién inicializado, todavía sin cambios activos.",
          "parts": [
            "openspec usa la configuración del repositorio actual.",
            "list consulta sus cambios activos; no genera proposal, specs, design ni tasks."
          ],
          "output": "Justo después de init puede indicar No active changes found; eso es válido. En tu repositorio, después de crear la propuesta, debe aparecer el cambio correspondiente al Issue. Copia su nombre exacto para los siguientes comandos.",
          "issues": [
            "Una lista vacía no demuestra que ya exista una propuesta. Revisa la carpeta openspec/changes/ si esperabas ver un cambio."
          ]
        }
      ],
      "gate": true
    },
    {
      "issueFallback": {
        "command": "python create_backend_issue.py --hu HU-01.md --repo TU_OWNER/workshop-auth-backend --web",
        "instructions": "El Lab 1 deja `HALLAZGOS.md` con Id `H-xx` y evidencia. El **Lab 2, S3 paso 4**, pide crear un issue por cada HU, en su repositorio. Para este recorrido se reutiliza el de `HU-01.md` en `workshop-auth-backend`.\n\nLa estructura requerida es:\n\n- **Título:** el título de la HU.\n- **Origen:** el Id real del hallazgo y evidencia `archivo:línea`.\n- **Criterios de aceptación:** checklist de la HU.\n- **PR de S2:** enlace si existe.\n\nSi no lo creaste, descarga [create_backend_issue.py](../tools/create_backend_issue.py) y guárdalo en la raíz de tu `workshop-auth-backend`, junto a `HU-01.md`. En Git Bash, desde esa carpeta:\n\n```bash\npython create_backend_issue.py --hu HU-01.md --repo TU_OWNER/workshop-auth-backend --web\n```\n\nReemplaza `TU_OWNER` por tu usuario u organización. Necesitas Python, GitHub CLI y una sesión activa de `gh auth login`. El comando se ejecuta en tu equipo; la terminal de esta web no crea issues remotos.\n\nEl script prepara `ISSUE-DRAFT.md` desde tu HU, convierte los criterios en checklist y comprueba duplicados por título y por Id del hallazgo, incluidos issues cerrados. Si hay coincidencias, muestra sus enlaces. Si no las hay, abre el formulario de GitHub con título y cuerpo preparados para que lo revises antes de crearlo. No inventa una HU ni evidencia y conserva cualquier borrador existente.\n\nSi tienes un PR de S2, añade `--pr https://github.com/TU_OWNER/workshop-auth-backend/pull/NUMERO` al comando, sustituyendo la URL por la real.\n\nDespués de crearlo, reutiliza el Project **ReqFlow**, agrega el issue, déjalo en **Todo** y completa **Hallazgo origen** con el Id `H-xx` real. Conserva su número para crear la rama vinculada. El fallback por CLI no sustituye la práctica de MCP del Lab 2.",
        "download": "/dia-03/tools/create_backend_issue.py",
        "explanation": {
          "label": "Preparar el Issue desde la HU del backend",
          "why": "Usa el script descargado para preparar el cuerpo del Issue, comprobar duplicados y abrir el formulario de GitHub con el contenido revisable.",
          "where": "En Git Bash de tu equipo, dentro de workshop-auth-backend, con el script y HU-01.md en esa carpeta.",
          "parts": [
            "python ejecuta create_backend_issue.py; descarga antes ese archivo desde el modal.",
            "--hu HU-01.md indica la historia que contiene el título, Origen y Criterios de aceptación.",
            "--repo TU_OWNER/workshop-auth-backend selecciona el repositorio remoto. Reemplaza TU_OWNER por tu usuario u organización.",
            "--web habilita la búsqueda de duplicados y abre el formulario de GitHub para revisar el Issue. Sin esa opción se prepara solamente ISSUE-DRAFT.md.",
            "--pr URL es opcional y permite incluir el enlace real del PR de S2 en el cuerpo."
          ],
          "output": "Revisa ISSUE-DRAFT.md. Si existe un Issue con el mismo título o Id de hallazgo, el script mostrará sus enlaces. Si no encuentra coincidencias, abrirá GitHub; revisa el título y cuerpo antes de pulsar Submit new issue.",
          "issues": [
            "El Id H-xx y la evidencia archivo:línea deben estar completados con valores reales en Origen.",
            "Si ya existe un borrador con otro contenido, el script lo conserva y pide revisarlo o renombrarlo."
          ]
        }
      },
      "id": "d3-s1-paso-02",
      "session": "s1",
      "title": "Elegir un Issue real del Project ReqFlow (estado Todo)",
      "description": "Selecciona el issue que guiará el cambio en workshop-auth-backend. Verifica que exista y esté priorizado en el Project.",
      "role": "Guía original · s04-openspec-sdd/STEP_1_SPEC.md",
      "source": "s04-openspec-sdd/STEP_1_SPEC.md",
      "why": "Selecciona el trabajo aprobado que gobernará el recorrido, con su origen y trazabilidad en ReqFlow.",
      "explanation": {
        "why": "Selecciona el trabajo aprobado que gobernará el recorrido, con su origen y trazabilidad en ReqFlow.",
        "where": "En Copilot con PM/PO para consultar el Project y en tu backend local para preparar la rama.",
        "actions": [
          "Consulta el ReqFlow del owner correcto y sus items.",
          "Elige un Issue de workshop-auth-backend en Todo que corresponda a un hallazgo confirmado.",
          "Reutiliza o crea su rama vinculada y confirma que esté activa."
        ],
        "output": "Conserva el número y enlace del Issue, su H-xx y el nombre de la rama. Todos los artefactos posteriores deben referirse a ese mismo cambio.",
        "issues": [
          "Si falta el Issue, la opción No tengo un issue prepara su creación desde HU-01.md."
        ]
      },
      "commands": [
        {
          "text": "Usando exclusivamente el GitHub MCP oficial, consulta el GitHub Project \"ReqFlow\"\ndel owner <OWNER> y lista sus items: repositorio, título, estado y campo\n\"Hallazgo origen\".\n\nNo crees ni modifiques nada todavía.\nNo uses terminal ni GitHub CLI.",
          "kind": "prompt",
          "executable": false,
          "source": "s03-reqflow-setup/STEP_3_PROJECT.md",
          "sourceBlock": 0,
          "agent": "PM/PO",
          "label": "Consultar los items de ReqFlow",
          "why": "Recupera el Project ReqFlow del Día 2 y sus items para elegir un Issue existente del backend.",
          "parts": [
            "Selecciona PM/PO y reemplaza <OWNER> por el usuario u organización que contiene ReqFlow.",
            "Pide repositorio, título, estado y Hallazgo origen para distinguir los items de los tres componentes.",
            "La restricción de solo lectura evita crear otro Project o modificar items durante esta consulta."
          ],
          "output": "Copilot debe identificar ReqFlow y listar sus items con evidencia obtenida por MCP. Elige uno de workshop-auth-backend en Todo y conserva su número y su hallazgo de origen.",
          "issues": [
            "Si no tienes un Issue del backend, usa la opción No tengo un issue del paso."
          ],
          "where": "En GitHub Copilot Chat de VS Code. Selecciona PM/PO."
        },
        {
          "text": "Usando exclusivamente github-official, lista los GitHub Projects de <OWNER> y confirma el número o identificador del Project ReqFlow.",
          "kind": "prompt",
          "executable": false,
          "source": "s03-reqflow-setup/STEP_3_PROJECT.md",
          "sourceBlock": 1,
          "agent": "PM/PO",
          "label": "Identificar el Project correcto",
          "why": "Confirma la identidad del Project para que las operaciones siguientes apunten al ReqFlow correcto.",
          "parts": [
            "Sustituye <OWNER> por el propietario real del Project.",
            "Pide el número o identificador de ReqFlow mediante github-official.",
            "Compara el Project devuelto con el que usaste el Día 2."
          ],
          "output": "La respuesta debe identificar el Project ReqFlow y la tool MCP usada para consultarlo. Un Project con el mismo nombre bajo otro owner requiere revisar la selección.",
          "issues": [],
          "where": "En GitHub Copilot Chat de VS Code. Selecciona PM/PO."
        },
        {
          "text": "cd workshop-auth-backend",
          "kind": "command",
          "executable": false,
          "source": "s04-openspec-sdd/STEP_1_SPEC.md",
          "sourceBlock": 0,
          "label": "Entrar en el repositorio del backend",
          "why": "Cambia el directorio de trabajo de la terminal al backend para que las operaciones siguientes se hagan en el repositorio correcto.",
          "where": "En Git Bash de tu equipo, partiendo de reqflow-workspace/. La terminal web ya empieza dentro de workshop-auth-backend.",
          "parts": [
            "cd cambia el directorio actual de la shell.",
            "workshop-auth-backend es una ruta relativa: debe ser una carpeta dentro del directorio en el que estás."
          ],
          "output": "Cuando funciona, cd no imprime una salida propia. El prompt puede cambiar. Usa pwd si necesitas confirmar que estás dentro de workshop-auth-backend.",
          "issues": [
            "Si ya estás dentro del backend, omite este comando. Repetirlo buscaría otra carpeta workshop-auth-backend dentro de él."
          ]
        },
        {
          "text": "gh issue develop <ISSUE_NUMBER> --checkout --base main --name <BRANCH_DEL_ISSUE>",
          "kind": "command",
          "executable": false,
          "source": "s04-openspec-sdd/STEP_1_SPEC.md",
          "sourceBlock": 0,
          "label": "Crear la rama vinculada al Issue",
          "why": "Pide a GitHub una rama de desarrollo vinculada al Issue elegido y deja esa rama activa en tu copia local del backend.",
          "where": "En el clon local de workshop-auth-backend, con gh autenticado y permisos para crear ramas en ese repositorio.",
          "parts": [
            "gh es GitHub CLI; issue develop trabaja con la rama de desarrollo de un Issue.",
            "<ISSUE_NUMBER> se sustituye por el número real del Issue del backend, sin los signos < >.",
            "--checkout trae la rama y cambia tu copia local a ella.",
            "--base main usa main como punto de partida de la rama nueva.",
            "--name <BRANCH_DEL_ISSUE> define su nombre; reemplaza el marcador por el nombre que usarás durante todo el cambio."
          ],
          "output": "Comprueba git branch --show-current: debe devolver la rama elegida. En GitHub, revisa que la sección Development del Issue muestre el vínculo con esa rama.",
          "issues": [
            "Este comando modifica GitHub y tu rama local. Confirma el repositorio y el Issue antes de ejecutarlo.",
            "Si el Issue ya tiene una rama, reutilízala como indica la guía en vez de crear otra."
          ]
        },
        {
          "text": "git branch --show-current",
          "kind": "command",
          "executable": false,
          "source": "s04-openspec-sdd/STEP_1_SPEC.md",
          "sourceBlock": 3,
          "label": "Comprobar la rama activa",
          "why": "Muestra el nombre de la rama local actual para confirmar dónde se guardarán tus cambios.",
          "where": "En la raíz de tu workshop-auth-backend local, donde está pom.xml.",
          "parts": [
            "git branch consulta las ramas del repositorio local.",
            "--show-current limita la salida al nombre de la rama activa; no crea ni cambia ramas."
          ],
          "output": "Debe imprimir exactamente el nombre de la rama vinculada al Issue. Si imprime main, todavía no estás en la rama de trabajo. Una salida vacía puede indicar que HEAD no está asociado a una rama."
        }
      ],
      "gate": true
    },
    {
      "issueFallback": null,
      "id": "d3-s1-paso-03",
      "session": "s1",
      "title": "Crear proposal + specs/ desde el Issue",
      "description": "Genera el contrato de cambio (qué se cambia, criterios, no-funcionales) antes de implementar. Pasa por GATE HUMANO antes de continuar a S2.",
      "role": "Guía original · s04-openspec-sdd/STEP_1_SPEC.md",
      "source": "s04-openspec-sdd/STEP_1_SPEC.md",
      "why": "Define por qué importa el cambio y qué comportamiento se espera antes de decidir cómo implementarlo.",
      "explanation": {
        "why": "Define por qué importa el cambio y qué comportamiento se espera antes de decidir cómo implementarlo.",
        "where": "En Copilot con PM/PO, limitado al backend.",
        "actions": [
          "Consulta el Issue y el contrato documentado.",
          "Crea proposal y specs con alcance, fuera de alcance y escenarios observables.",
          "Revisa y aprueba los artefactos antes de pasar al diseño."
        ],
        "output": "El cambio debe referenciar el Issue y especificar qué se preserva o cambia. Todavía no deben añadirse design, tasks ni código funcional en esta etapa.",
        "issues": []
      },
      "commands": [
        {
          "text": "Trabaja únicamente en workshop-auth-backend.\nNo leas ni modifiques los otros repositorios del workspace.\n\nTrabaja sobre la rama actual.\nNo crees ni cambies de rama.\n\nUsa github-official para consultar el GitHub Issue #<ISSUE_NUMBER>\ny úsalo como fuente del trabajo comprometido y del alcance.\n\nTrabaja con OpenSpec y el schema estándar spec-driven configurado en este repositorio.\n\nUsa github-official para consultar el Issue y úsalo como fuente del trabajo comprometido y del alcance.\nUsa docs/ENDPOINTS.md (contrato documentado el Dia 1) como baseline del comportamiento que debe preservarse: los escenarios de las specs deben ser coherentes con ese contrato, o explicar por que el Issue lo cambia.\n\nCrea una propuesta OpenSpec para este cambio y materializa:\n- proposal.md;\n- las specs necesarias bajo openspec/changes/<change>/specs/.\n\nLa propuesta debe:\n- referenciar el Issue;\n- explicar por qué importa el cambio;\n- separar alcance y fuera de alcance;\n- identificar comportamiento que debe preservarse;\n- definir requisitos verificables y escenarios observables.\n\nNo diseñes todavía la implementación técnica.\nNo crees tasks.md todavía.\nNo modifiques código funcional.",
          "kind": "prompt",
          "executable": false,
          "source": "s04-openspec-sdd/STEP_1_SPEC.md",
          "sourceBlock": 7,
          "agent": "PM/PO",
          "label": "Crear proposal y specs desde el Issue",
          "why": "Convierte el Issue aprobado en una propuesta de cambio y escenarios verificables antes de diseñar o implementar.",
          "parts": [
            "Selecciona PM/PO; reemplaza <ISSUE_NUMBER> por el Issue real del backend.",
            "Limita las lecturas y los cambios a workshop-auth-backend y conserva la rama actual.",
            "El Issue define el alcance; docs/ENDPOINTS.md aporta el contrato que debes preservar o cambiar explícitamente.",
            "Pide proposal.md y specs/; deja design, tasks e implementación para las etapas siguientes."
          ],
          "output": "Revisa el vínculo al Issue, el alcance, el fuera de alcance y los escenarios de las specs. Deben existir proposal.md y specs/ del cambio, con requisitos observables y sin código funcional modificado.",
          "issues": [
            "Un escenario sin evidencia del contrato debe revisarse antes de aprobar la propuesta."
          ],
          "where": "En GitHub Copilot Chat de VS Code. Selecciona PM/PO."
        },
        {
          "text": "openspec list",
          "kind": "command",
          "executable": true,
          "source": "s04-openspec-sdd/STEP_1_SPEC.md",
          "sourceBlock": 8,
          "label": "Consultar los cambios de OpenSpec",
          "why": "Lista los cambios activos que OpenSpec reconoce en este repositorio. Sirve para identificar el nombre del cambio que usarás en status y validate.",
          "where": "En tu backend inicializado. En esta web, ▶ muestra la referencia del proyecto recién inicializado, todavía sin cambios activos.",
          "parts": [
            "openspec usa la configuración del repositorio actual.",
            "list consulta sus cambios activos; no genera proposal, specs, design ni tasks."
          ],
          "output": "Justo después de init puede indicar No active changes found; eso es válido. En tu repositorio, después de crear la propuesta, debe aparecer el cambio correspondiente al Issue. Copia su nombre exacto para los siguientes comandos.",
          "issues": [
            "Una lista vacía no demuestra que ya exista una propuesta. Revisa la carpeta openspec/changes/ si esperabas ver un cambio."
          ]
        },
        {
          "text": "openspec status --change <CHANGE_NAME>",
          "kind": "command",
          "executable": false,
          "source": "s04-openspec-sdd/STEP_1_SPEC.md",
          "sourceBlock": 11,
          "label": "Revisar el estado de los artefactos",
          "why": "Consulta qué artefactos del cambio están disponibles y cuáles siguen pendientes según el workflow de OpenSpec.",
          "where": "En la raíz de tu workshop-auth-backend local, donde está pom.xml.",
          "parts": [
            "status consulta el estado del workflow; no genera los documentos que falten.",
            "--change selecciona el cambio que quieres revisar.",
            "<CHANGE_NAME> es el nombre real de la carpeta bajo openspec/changes/. Obtén ese nombre con openspec list y reemplaza el marcador antes de ejecutar."
          ],
          "output": "Revisa proposal, specs, design y tasks según la etapa en la que estés. En S1 todavía no se pide implementar. En S2 comprueba que el diseño y las tareas aprobadas estén disponibles antes de pasar a S4.",
          "issues": [
            "Si el cambio no se encuentra, compara el nombre con openspec list y confirma el directorio de trabajo."
          ]
        },
        {
          "text": "openspec validate <CHANGE_NAME>",
          "kind": "command",
          "executable": false,
          "source": "s04-openspec-sdd/STEP_1_SPEC.md",
          "sourceBlock": 11,
          "label": "Validar los artefactos del cambio",
          "why": "Comprueba las reglas de estructura y contenido que OpenSpec aplica a las especificaciones del cambio seleccionado.",
          "where": "En la raíz de tu workshop-auth-backend local, donde está pom.xml.",
          "parts": [
            "validate ejecuta las validaciones de OpenSpec.",
            "<CHANGE_NAME> selecciona el cambio que se validará.",
            "<CHANGE_NAME> es el nombre real de la carpeta bajo openspec/changes/. Obtén ese nombre con openspec list y reemplaza el marcador antes de ejecutar."
          ],
          "output": "Busca el resultado de validación del cambio. Si hay errores, identifica el archivo y la regla mencionados, corrige el artefacto y vuelve a validar. Registra el comando y su resultado junto a la evidencia de la etapa.",
          "issues": [
            "La validación de OpenSpec comprueba sus artefactos. Las pruebas Java, los criterios del Issue y la revisión humana se comprueban por separado."
          ]
        }
      ],
      "gate": true
    },
    {
      "issueFallback": null,
      "id": "d3-s2-paso-01",
      "session": "s2",
      "title": "Crear design.md (Plan)",
      "description": "Decisiones técnicas, impacto, estrategia incremental y riesgos.",
      "role": "Guía original · s04-openspec-sdd/STEP_2_ARCHITECTURE.md",
      "source": "s04-openspec-sdd/STEP_2_ARCHITECTURE.md",
      "why": "Convierte las specs aprobadas en decisiones técnicas que permitan un cambio acotado.",
      "explanation": {
        "why": "Convierte las specs aprobadas en decisiones técnicas que permitan un cambio acotado.",
        "where": "En Copilot con Architect, en la misma rama.",
        "actions": [
          "Lee proposal y specs antes de diseñar.",
          "Documenta componentes, contratos, alternativas, riesgos y estrategia incremental.",
          "Identifica qué pruebas deben proteger el comportamiento antes del cambio."
        ],
        "output": "design.md debe explicar las decisiones necesarias para ese Issue y permitir revisar sus riesgos sin ampliar el alcance.",
        "issues": []
      },
      "commands": [
        {
          "text": "Trabaja únicamente en workshop-auth-backend.\nNo leas ni modifiques los otros repositorios del workspace.\nTodos los comandos, lecturas, cambios y operaciones Git/GitHub de este paso deben referirse únicamente a workshop-auth-backend.\n\nTrabaja sobre la rama actual <BRANCH_DEL_ISSUE>. No crees ni cambies a otra rama.\n\nTrabaja sobre el cambio OpenSpec <CHANGE_NAME> ya aprobado.\nLee proposal.md y specs/ antes de proponer cualquier diseño.\n\nCrea o completa:\nopenspec/changes/<CHANGE_NAME>/design.md\n\nEl design debe incluir:\n- contexto técnico relevante;\n- goals / non-goals;\n- contratos protegidos;\n- componentes afectados;\n- decisiones técnicas y alternativas consideradas;\n- estrategia incremental;\n- pruebas de caracterización necesarias antes de modificar comportamiento crítico;\n- riesgos / trade-offs;\n- rollback cuando aplique.\n\nNo implementes código funcional.\nNo rediseñes toda la aplicación.",
          "kind": "prompt",
          "executable": false,
          "source": "s04-openspec-sdd/STEP_2_ARCHITECTURE.md",
          "sourceBlock": 2,
          "agent": "Architect",
          "label": "Diseñar el cambio con Architect",
          "why": "Pide el diseño técnico del cambio a partir de la propuesta y las specs aprobadas.",
          "parts": [
            "Selecciona Architect y sustituye <BRANCH_DEL_ISSUE> y <CHANGE_NAME> por los valores reales.",
            "Haz que lea proposal y specs antes de proponer decisiones.",
            "Pide contexto, límites, contratos, componentes, alternativas, estrategia incremental, pruebas y riesgos.",
            "Mantén esta etapa en design.md; la implementación funcional viene después del gate de caracterización."
          ],
          "output": "design.md debe explicar cómo cumplir las specs, qué comportamiento se protege, qué pruebas lo demostrarán y por qué se eligió esa estrategia. Revisa que no amplíe el Issue.",
          "issues": [],
          "where": "En GitHub Copilot Chat de VS Code. Selecciona Architect."
        }
      ],
      "gate": true
    },
    {
      "issueFallback": null,
      "id": "d3-s2-paso-02",
      "session": "s2",
      "title": "Crear tasks.md (Tasks)",
      "description": "Checklist de implementación vinculada al Issue. Mantén GitHub como tracking de trabajo comprometido. GATE HUMANO antes de validar.",
      "role": "Guía original · s04-openspec-sdd/STEP_2_ARCHITECTURE.md",
      "source": "s04-openspec-sdd/STEP_2_ARCHITECTURE.md",
      "why": "Ordena el trabajo aprobado en tareas pequeñas y demostrables.",
      "explanation": {
        "why": "Ordena el trabajo aprobado en tareas pequeñas y demostrables.",
        "where": "En Copilot con Architect.",
        "actions": [
          "Deriva las tareas del Issue, proposal, specs y design.",
          "Sitúa la caracterización antes del cambio funcional.",
          "Revisa que cada tarea tenga una forma de comprobarse."
        ],
        "output": "tasks.md debe ser coherente con los artefactos y conservar pendientes las tareas que todavía no se ejecutaron.",
        "issues": []
      },
      "commands": [
        {
          "text": "Trabaja únicamente en workshop-auth-backend.\nNo leas ni modifiques los otros repositorios del workspace.\nTodos los comandos, lecturas, cambios y operaciones Git/GitHub de este paso deben referirse únicamente a workshop-auth-backend.\n\nContinúa sobre la rama actual <BRANCH_DEL_ISSUE>. No crees ni cambies de rama.\n\nUsa proposal.md, specs/ y design.md ya aprobados del cambio OpenSpec <CHANGE_NAME>.\n\nGenera o completa:\nopenspec/changes/<CHANGE_NAME>/tasks.md\n\nLas tareas deben:\n- estar dentro del alcance del GitHub Issue;\n- ser pequeñas y verificables;\n- comenzar por las pruebas de caracterización necesarias antes del cambio funcional;\n- incluir la implementación incremental;\n- incluir pruebas/validaciones relevantes;\n- evitar trabajo secundario no aprobado.\n\nEl GitHub Issue sigue siendo la unidad de trabajo del producto. tasks.md es el checklist de implementación de este cambio OpenSpec.\n\nNo implementes todavía el cambio funcional.",
          "kind": "prompt",
          "executable": false,
          "source": "s04-openspec-sdd/STEP_2_ARCHITECTURE.md",
          "sourceBlock": 3,
          "agent": "Architect",
          "label": "Preparar el checklist de tareas",
          "why": "Descompone el diseño aprobado en tareas pequeñas que permitan ejecutar y revisar el cambio.",
          "parts": [
            "Selecciona Architect y usa la misma rama y el mismo cambio.",
            "Deriva cada tarea de proposal, specs y design.",
            "Ordena primero la caracterización del comportamiento existente y después la implementación y las validaciones.",
            "GitHub Issue conserva el trabajo comprometido; tasks.md registra el checklist técnico de ese cambio."
          ],
          "output": "tasks.md debe contener tareas verificables, dentro del alcance y con la caracterización antes de tocar el comportamiento crítico. Los checks se marcarán después de ejecutar y demostrar cada tarea.",
          "issues": [],
          "where": "En GitHub Copilot Chat de VS Code. Selecciona Architect."
        }
      ],
      "gate": true
    },
    {
      "issueFallback": null,
      "id": "d3-s2-paso-03",
      "session": "s2",
      "title": "Validar (Validate) antes de tocar código",
      "description": "Ejecuta openspec validate y revisiones humanas de los artefactos (Specify/Plan/Tasks). Recién después sigue el baseline de characterization tests en S4.",
      "role": "Guía original · s04-openspec-sdd/STEP_2_ARCHITECTURE.md",
      "source": "s04-openspec-sdd/STEP_2_ARCHITECTURE.md",
      "why": "Comprueba los artefactos y su coherencia antes de tocar el comportamiento del backend.",
      "explanation": {
        "why": "Comprueba los artefactos y su coherencia antes de tocar el comportamiento del backend.",
        "where": "En la raíz de tu workshop-auth-backend local, donde está pom.xml.",
        "actions": [
          "Identifica el nombre real del cambio.",
          "Consulta status y ejecuta validate.",
          "Revisa proposal, specs, design y tasks con el participante."
        ],
        "output": "Conserva la validación y los gates humanos de los artefactos. Las pruebas del baseline se realizan después, en S4.",
        "issues": []
      },
      "commands": [
        {
          "text": "openspec list",
          "kind": "command",
          "executable": true,
          "source": "s04-openspec-sdd/STEP_2_ARCHITECTURE.md",
          "sourceBlock": 4,
          "label": "Consultar los cambios de OpenSpec",
          "why": "Lista los cambios activos que OpenSpec reconoce en este repositorio. Sirve para identificar el nombre del cambio que usarás en status y validate.",
          "where": "En tu backend inicializado. En esta web, ▶ muestra la referencia del proyecto recién inicializado, todavía sin cambios activos.",
          "parts": [
            "openspec usa la configuración del repositorio actual.",
            "list consulta sus cambios activos; no genera proposal, specs, design ni tasks."
          ],
          "output": "Justo después de init puede indicar No active changes found; eso es válido. En tu repositorio, después de crear la propuesta, debe aparecer el cambio correspondiente al Issue. Copia su nombre exacto para los siguientes comandos.",
          "issues": [
            "Una lista vacía no demuestra que ya exista una propuesta. Revisa la carpeta openspec/changes/ si esperabas ver un cambio."
          ]
        },
        {
          "text": "openspec status --change <CHANGE_NAME>",
          "kind": "command",
          "executable": false,
          "source": "s04-openspec-sdd/STEP_2_ARCHITECTURE.md",
          "sourceBlock": 6,
          "label": "Revisar el estado de los artefactos",
          "why": "Consulta qué artefactos del cambio están disponibles y cuáles siguen pendientes según el workflow de OpenSpec.",
          "where": "En la raíz de tu workshop-auth-backend local, donde está pom.xml.",
          "parts": [
            "status consulta el estado del workflow; no genera los documentos que falten.",
            "--change selecciona el cambio que quieres revisar.",
            "<CHANGE_NAME> es el nombre real de la carpeta bajo openspec/changes/. Obtén ese nombre con openspec list y reemplaza el marcador antes de ejecutar."
          ],
          "output": "Revisa proposal, specs, design y tasks según la etapa en la que estés. En S1 todavía no se pide implementar. En S2 comprueba que el diseño y las tareas aprobadas estén disponibles antes de pasar a S4.",
          "issues": [
            "Si el cambio no se encuentra, compara el nombre con openspec list y confirma el directorio de trabajo."
          ]
        },
        {
          "text": "openspec validate <CHANGE_NAME>",
          "kind": "command",
          "executable": false,
          "source": "s04-openspec-sdd/STEP_2_ARCHITECTURE.md",
          "sourceBlock": 6,
          "label": "Validar los artefactos del cambio",
          "why": "Comprueba las reglas de estructura y contenido que OpenSpec aplica a las especificaciones del cambio seleccionado.",
          "where": "En la raíz de tu workshop-auth-backend local, donde está pom.xml.",
          "parts": [
            "validate ejecuta las validaciones de OpenSpec.",
            "<CHANGE_NAME> selecciona el cambio que se validará.",
            "<CHANGE_NAME> es el nombre real de la carpeta bajo openspec/changes/. Obtén ese nombre con openspec list y reemplaza el marcador antes de ejecutar."
          ],
          "output": "Busca el resultado de validación del cambio. Si hay errores, identifica el archivo y la regla mencionados, corrige el artefacto y vuelve a validar. Registra el comando y su resultado junto a la evidencia de la etapa.",
          "issues": [
            "La validación de OpenSpec comprueba sus artefactos. Las pruebas Java, los criterios del Issue y la revisión humana se comprueban por separado."
          ]
        }
      ],
      "gate": true
    },
    {
      "issueFallback": null,
      "id": "d3-s3-paso-01",
      "session": "s3",
      "title": "Copiar los Custom Agents al workspace",
      "description": "Copia los templates desde bcp-ai-lab-day-03/templates/agents/ hacia reqflow-workspace/.github/agents/ (en S4 paso 0 también a workshop-auth-backend).",
      "role": "Guía original · s01-custom-agents/README.md",
      "source": "s01-custom-agents/README.md",
      "why": "Hace disponibles los roles persistentes del taller en el workspace de VS Code.",
      "explanation": {
        "why": "Hace disponibles los roles persistentes del taller en el workspace de VS Code.",
        "where": "En reqflow-workspace/.",
        "actions": [
          "Localiza los templates de Agents dentro del laboratorio, situado al lado del workspace.",
          "Copia pm-po.agent.md, discovery.agent.md, architect.agent.md y developer.agent.md a .github/agents/ del workspace.",
          "Refresca VS Code y comprueba que puedes seleccionar los perfiles."
        ],
        "output": "Debe existir reqflow-workspace/.github/agents/ con los cuatro perfiles. La preparación del módulo SDD también pide copiarlos al repositorio del backend cuando corresponda.",
        "issues": []
      },
      "commands": [],
      "gate": true
    },
    {
      "issueFallback": null,
      "id": "d3-s3-paso-02",
      "session": "s3",
      "title": "Probar los límites de un agente aislado",
      "description": "Selecciona un solo Custom Agent (Discovery, PM/PO, Architect o Developer) sin usar tools y verifica que explique su responsabilidad y a qué rol debe pasar lo que no le corresponde.",
      "role": "Guía original · s01-custom-agents/README.md",
      "source": "s01-custom-agents/README.md",
      "why": "Prueba las responsabilidades de cada agente de forma aislada antes de usar sus tools.",
      "explanation": {
        "why": "Prueba las responsabilidades de cada agente de forma aislada antes de usar sus tools.",
        "where": "En Copilot Chat, seleccionando un solo Custom Agent por prueba.",
        "actions": [
          "Abre el prompt correspondiente al rol elegido.",
          "Ejecútalo sin lecturas de archivos ni tools, como indica el texto.",
          "Revisa el límite que explica el agente y el rol al que deriva lo que no le corresponde."
        ],
        "output": "Debes poder justificar qué decide cada rol y comprobar que respeta el límite solicitado en la prueba.",
        "issues": []
      },
      "commands": [
        {
          "text": "Esta es únicamente una prueba de los límites de tu rol.\nNo leas archivos, no busques en el workspace y no uses MCP ni ninguna otra tool.\n\nSupón que durante un análisis encuentras un problema importante en ReqFlow.\n¿Puedes corregirlo directamente?\nExplica qué deberías hacer según tu responsabilidad antes de que alguien modifique código.",
          "kind": "prompt",
          "executable": false,
          "source": "s01-custom-agents/README.md",
          "sourceBlock": 6,
          "agent": "Discovery",
          "label": "Probar los límites de Discovery",
          "why": "Comprueba que Discovery reconoce su límite antes de darle acceso al producto.",
          "parts": [
            "Selecciona únicamente Discovery.",
            "La prueba pide razonar sobre el rol sin leer archivos ni usar tools.",
            "La pregunta distingue encontrar un problema de tener autorización para corregirlo."
          ],
          "output": "Discovery debe explicar cómo reunir evidencia y pasar el hallazgo a revisión antes de implementar. Comprueba también que no haya invocaciones de tools.",
          "issues": [],
          "where": "En GitHub Copilot Chat de VS Code. Selecciona Discovery."
        },
        {
          "text": "Esta es únicamente una prueba de los límites de tu rol.\nNo leas archivos y no uses ninguna tool.\n\nSupón que se detectó deuda en la capa de persistencia de ReqFlow.\n¿Debes decidir y ejecutar tú mismo el refactor técnico?\nExplica qué te corresponde hacer y a qué rol debería pasar la decisión técnica.",
          "kind": "prompt",
          "executable": false,
          "source": "s01-custom-agents/README.md",
          "sourceBlock": 7,
          "agent": "PM/PO",
          "label": "Probar los límites de PM/PO",
          "why": "Comprueba que PM/PO separa la decisión de producto del diseño y la implementación técnica.",
          "parts": [
            "Selecciona únicamente PM/PO.",
            "No adjuntes archivos ni habilites una ejecución de tools para esta prueba.",
            "Observa cómo trata una petición de refactor en persistencia que requiere criterio técnico."
          ],
          "output": "PM/PO debe explicar el alcance, la prioridad y la aceptación que le corresponden, y derivar el diseño técnico al rol adecuado. Comprueba que no implemente el refactor.",
          "issues": [],
          "where": "En GitHub Copilot Chat de VS Code. Selecciona PM/PO."
        },
        {
          "text": "Esta es únicamente una prueba de los límites de tu rol.\nNo leas archivos y no uses ninguna tool.\n\nSupón que recibes un hallazgo técnico ya confirmado.\n¿Debes implementar directamente el cambio en código?\nExplica cuál es tu responsabilidad y cuándo debe intervenir Developer.",
          "kind": "prompt",
          "executable": false,
          "source": "s01-custom-agents/README.md",
          "sourceBlock": 8,
          "agent": "Architect",
          "label": "Probar los límites de Architect",
          "why": "Comprueba que Architect define decisiones técnicas sin asumir la implementación del cambio.",
          "parts": [
            "Selecciona únicamente Architect.",
            "Mantén la prueba sin lecturas de archivos ni invocaciones de tools.",
            "Pregunta qué hace con un hallazgo confirmado y cuándo debe pasar el trabajo a Developer."
          ],
          "output": "La respuesta debe describir el diseño, sus límites y el traspaso a Developer después de aprobarlo. No debe ejecutar una corrección.",
          "issues": [],
          "where": "En GitHub Copilot Chat de VS Code. Selecciona Architect."
        },
        {
          "text": "Esta es únicamente una prueba de los límites de tu rol.\nNo leas archivos y no uses ninguna tool.\n\nTe piden mejorar todo ReqFlow sin issue, spec ni alcance aprobado.\n¿Debes empezar a modificar código?\nExplica qué información necesitas antes de implementar.",
          "kind": "prompt",
          "executable": false,
          "source": "s01-custom-agents/README.md",
          "sourceBlock": 9,
          "agent": "Developer",
          "label": "Probar los límites de Developer",
          "why": "Comprueba que Developer pide trabajo aprobado antes de modificar el producto.",
          "parts": [
            "Selecciona únicamente Developer.",
            "Usa la petición amplia de mejorar todo ReqFlow tal como aparece en la prueba.",
            "Verifica que identifique la falta de Issue, spec y alcance aprobado sin usar tools."
          ],
          "output": "Developer debe pedir el contexto y las decisiones que faltan antes de implementar. Una respuesta que empieza a cambiar archivos no cumple el límite de esta prueba.",
          "issues": [],
          "where": "En GitHub Copilot Chat de VS Code. Selecciona Developer."
        }
      ],
      "gate": true
    },
    {
      "issueFallback": null,
      "id": "d3-s3-paso-03",
      "session": "s3",
      "title": "Verificar MCP oficial + Projects habilitado",
      "description": "Confirma que github-official expone tools de Projects y que puedes leer Projects vía MCP.",
      "role": "Guía original · s03-reqflow-setup/STEP_2_MCP.md",
      "source": "s03-reqflow-setup/STEP_2_MCP.md",
      "why": "Comprueba que VS Code puede consultar el backend y Projects a través del MCP oficial.",
      "explanation": {
        "why": "Comprueba que VS Code puede consultar el backend y Projects a través del MCP oficial.",
        "where": "En VS Code con Agent estándar y github-official.",
        "actions": [
          "Revisa .vscode/mcp.json y el toolset projects.",
          "Comprueba la conexión y las tools disponibles en Configure Tools.",
          "Ejecuta las consultas de lectura y conserva la tool y el resultado."
        ],
        "output": "La evidencia debe mostrar una lectura real de Projects y del repositorio mediante MCP. Si hay un problema de permisos, resuélvelo antes de operar el Project.",
        "issues": []
      },
      "commands": [
        {
          "text": "Usando exclusivamente github-official, lista los GitHub Projects accesibles para mi usuario.\n\nNo uses terminal, GitHub CLI, web ni otras herramientas.\nIndica qué tool MCP utilizaste.",
          "kind": "prompt",
          "executable": false,
          "source": "s03-reqflow-setup/STEP_2_MCP.md",
          "sourceBlock": 2,
          "agent": "Agent estándar",
          "label": "Comprobar Projects mediante MCP",
          "why": "Verifica que el MCP oficial puede consultar Projects con tu identidad y permisos actuales.",
          "parts": [
            "Usa el modo Agent estándar de Copilot, no un Custom Agent.",
            "La consulta debe usar exclusivamente github-official y mostrar qué tool se invocó.",
            "La lista se obtiene de GitHub; no se deduce desde archivos locales ni desde gh."
          ],
          "output": "Comprueba la invocación de una tool de Projects y el resultado real. Puede devolver una lista vacía; eso es distinto de un error de autorización o de una tool ausente.",
          "issues": [
            "Si no hay acceso a Projects, conserva el error y revisa configuración y permisos antes de continuar."
          ],
          "where": "En GitHub Copilot Chat de VS Code. Selecciona Agent estándar."
        },
        {
          "text": "Usando exclusivamente github-official, consulta información de <OWNER>/workshop-auth-backend y dime qué tool MCP utilizaste.\nNo uses terminal ni GitHub CLI para obtener la información de GitHub.",
          "kind": "prompt",
          "executable": false,
          "source": "s03-reqflow-setup/STEP_2_MCP.md",
          "sourceBlock": 4,
          "agent": "Agent estándar",
          "label": "Consultar el backend mediante MCP",
          "why": "Verifica una lectura del repositorio del backend mediante GitHub MCP.",
          "parts": [
            "Usa Agent estándar y sustituye <OWNER> por tu usuario u organización.",
            "El repositorio consultado debe ser tu workshop-auth-backend.",
            "Pide que la respuesta identifique la tool de github-official y evita la sustitución por terminal o GitHub CLI."
          ],
          "output": "La respuesta debe corresponder a tu repositorio y estar respaldada por una llamada MCP visible. Si falla el acceso, conserva el resultado como evidencia del problema.",
          "issues": [],
          "where": "En GitHub Copilot Chat de VS Code. Selecciona Agent estándar."
        }
      ],
      "gate": true
    },
    {
      "issueFallback": null,
      "id": "d3-s3-paso-04",
      "session": "s3",
      "title": "Completar backlog (sin inventar trabajo)",
      "description": "Discovery revalida HALLAZGOS.md y convierte hallazgos revisados en issues reales y verificables en el repo correcto.",
      "role": "Guía original · s03-reqflow-setup/STEP_4_DISCOVERY_BACKLOG.md",
      "source": "s03-reqflow-setup/STEP_4_DISCOVERY_BACKLOG.md",
      "why": "Completa el backlog con hallazgos revisados y trazables, aprovechando los issues de los días anteriores.",
      "explanation": {
        "why": "Completa el backlog con hallazgos revisados y trazables, aprovechando los issues de los días anteriores.",
        "where": "Discovery analiza; PM/PO crea o incorpora trabajo aprobado.",
        "actions": [
          "Revalida HALLAZGOS.md contra código, contratos y pruebas actuales.",
          "Clasifica humanamente los hallazgos.",
          "Reutiliza issues existentes; crea los que falten en el repositorio correcto y agrégalos a ReqFlow."
        ],
        "output": "Cada Issue debe tener evidencia, aceptación verificable e Id H-xx. El Project debe conservar esa trazabilidad y evitar duplicados.",
        "issues": []
      },
      "commands": [
        {
          "text": "Analiza workshop-auth-backend sin modificar archivos.\n\nParte de lo que ya existe: workshop-auth-backend/HALLAZGOS.md (Dia 1) y\nlos issues del Project ReqFlow (Dia 2). Re-verifica cada hallazgo \"Pendiente\"\ncontra el codigo actual e indica si ya tiene issue (campo Hallazgo origen).\nDespues comprende estructura, contratos (docs/ENDPOINTS.md) y pruebas\nexistentes (docs/TESTING.md).\nDespués presenta como máximo 5 hallazgos candidatos.\n\nPara cada hallazgo incluye:\n- evidencia concreta;\n- por qué importa;\n- prioridad propuesta;\n- contrato funcional que podría verse afectado;\n- cómo lo validarías antes de cambiarlo.\n\nNo inventes problemas si no encuentras evidencia.\nNo implementes soluciones.",
          "kind": "prompt",
          "executable": false,
          "source": "s03-reqflow-setup/STEP_4_DISCOVERY_BACKLOG.md",
          "sourceBlock": 2,
          "agent": "Discovery",
          "label": "Revalidar los hallazgos del backend",
          "why": "Revalida los hallazgos del backend contra su estado actual para construir backlog con evidencia.",
          "parts": [
            "Selecciona Discovery y limita el análisis a workshop-auth-backend.",
            "Haz que lea HALLAZGOS.md, el backlog existente, docs/ENDPOINTS.md y docs/TESTING.md.",
            "Cada candidato debe indicar evidencia, impacto, prioridad, contrato afectado y una forma de validarlo.",
            "La instrucción prohíbe implementar y limita los candidatos a un máximo de cinco."
          ],
          "output": "Revisa si cada hallazgo sigue vigente, qué archivo lo demuestra y si ya tiene Issue. Clasifica los candidatos como CONFIRMADO, NECESITA MÁS EVIDENCIA o DESCARTADO antes de convertirlos en trabajo.",
          "issues": [],
          "where": "En GitHub Copilot Chat de VS Code. Selecciona Discovery."
        },
        {
          "text": "Usando exclusivamente github-official, convierte estos hallazgos CONFIRMADOS en issues.\n\nReglas:\n- cada issue debe vivir en el repositorio al que pertenece la evidencia;\n- no dupliques: si el hallazgo ya tiene issue en ReqFlow, reutilízalo;\n- incluye el Id H-xx del hallazgo de origen y completa el campo Hallazgo origen;\n- no inventes nuevos hallazgos;\n- incluye problema, evidencia, impacto y criterio verificable;\n- antes de crear, muéstrame el repositorio destino y el título propuesto.",
          "kind": "prompt",
          "executable": false,
          "source": "s03-reqflow-setup/STEP_4_DISCOVERY_BACKLOG.md",
          "sourceBlock": 6,
          "agent": "PM/PO",
          "label": "Crear issues desde hallazgos confirmados",
          "why": "Convierte únicamente hallazgos aprobados en issues trazables en su repositorio correcto.",
          "parts": [
            "Selecciona PM/PO y aporta los hallazgos que ya clasificaste como CONFIRMADO.",
            "Comprueba el Id H-xx, la evidencia y el criterio verificable de cada hallazgo.",
            "Exige reutilizar un Issue existente si ya cubre ese hallazgo.",
            "Revisa el repositorio y el título propuestos antes de autorizar la creación mediante MCP."
          ],
          "output": "Cada Issue creado debe tener problema, evidencia, impacto, aceptación verificable e Id del hallazgo. Su repositorio debe coincidir con el componente de la evidencia.",
          "issues": [
            "La respuesta de Discovery por sí sola no autoriza la creación de un Issue."
          ],
          "where": "En GitHub Copilot Chat de VS Code. Selecciona PM/PO."
        },
        {
          "text": "Usando exclusivamente las tools de Projects de github-official, agrega al Project ReqFlow los issues que acabamos de aprobar.\nNo cambies su repositorio de origen.",
          "kind": "prompt",
          "executable": false,
          "source": "s03-reqflow-setup/STEP_4_DISCOVERY_BACKLOG.md",
          "sourceBlock": 7,
          "agent": "PM/PO",
          "label": "Agregar los issues aprobados a ReqFlow",
          "why": "Añade al Project ReqFlow los issues que ya aprobaste para coordinarlos desde el producto.",
          "parts": [
            "Selecciona PM/PO y conserva los enlaces de los issues aprobados.",
            "Usa las tools de Projects de github-official.",
            "Agregar un item al Project no cambia el repositorio donde vive el Issue."
          ],
          "output": "Comprueba los enlaces de los items dentro de ReqFlow y su repositorio original. Completa Hallazgo origen con el Id real y deja el Issue elegido para el recorrido en Todo.",
          "issues": [],
          "where": "En GitHub Copilot Chat de VS Code. Selecciona PM/PO."
        }
      ],
      "gate": true
    },
    {
      "issueFallback": null,
      "id": "d3-s3-paso-05",
      "session": "s3",
      "title": "De single-agent a routing",
      "description": "Mapea cada rol a un tipo de trabajo: producto/alcance → PM/PO, hallazgo → Discovery, diseño → Architect, implementación → Developer. Prepara el routing explícito de S4.",
      "role": "Guía original · s01-custom-agents/README.md",
      "source": "s01-custom-agents/README.md",
      "why": "Define a qué rol se entrega cada tipo de trabajo y qué necesita recibir para empezar.",
      "explanation": {
        "why": "Define a qué rol se entrega cada tipo de trabajo y qué necesita recibir para empezar.",
        "where": "En Copilot, eligiendo explícitamente el Agent adecuado.",
        "actions": [
          "Producto y alcance se dirigen a PM/PO.",
          "Hallazgos se dirigen a Discovery; diseño, a Architect.",
          "Implementación se dirige a Developer después de las aprobaciones."
        ],
        "output": "Debes explicar el motivo de cada traspaso y sus entradas. El laboratorio usa selección explícita de roles; no pide construir un router autónomo.",
        "issues": []
      },
      "commands": [],
      "gate": true
    },
    {
      "issueFallback": null,
      "id": "d3-s4-paso-01",
      "session": "s4",
      "title": "Confirmar el routing del Issue",
      "description": "Verifica que proposal/specs/design/tasks ya pasaron por PM/PO y Architect antes de que Developer implemente.",
      "role": "Guía original · s04-openspec-sdd/STEP_3_CHARACTERIZATION.md",
      "source": "s04-openspec-sdd/STEP_3_CHARACTERIZATION.md",
      "why": "Confirma que el trabajo llega a Developer con el alcance y el plan aprobados.",
      "explanation": {
        "why": "Confirma que el trabajo llega a Developer con el alcance y el plan aprobados.",
        "where": "En el Issue, el cambio OpenSpec y la rama del backend.",
        "actions": [
          "Revisa el vínculo entre Issue, proposal, specs, design y tasks.",
          "Confirma la revisión de PM/PO y Architect.",
          "Valida el cambio antes de comenzar las tareas de caracterización."
        ],
        "output": "Debe existir una cadena de decisiones revisable y un plan aprobado para el mismo Issue. La validación de OpenSpec se acompaña de la revisión humana.",
        "issues": []
      },
      "commands": [
        {
          "text": "openspec validate <CHANGE_NAME>",
          "kind": "command",
          "executable": false,
          "source": "s04-openspec-sdd/STEP_3_CHARACTERIZATION.md",
          "sourceBlock": 2,
          "label": "Validar los artefactos del cambio",
          "why": "Comprueba las reglas de estructura y contenido que OpenSpec aplica a las especificaciones del cambio seleccionado.",
          "where": "En la raíz de tu workshop-auth-backend local, donde está pom.xml.",
          "parts": [
            "validate ejecuta las validaciones de OpenSpec.",
            "<CHANGE_NAME> selecciona el cambio que se validará.",
            "<CHANGE_NAME> es el nombre real de la carpeta bajo openspec/changes/. Obtén ese nombre con openspec list y reemplaza el marcador antes de ejecutar."
          ],
          "output": "Busca el resultado de validación del cambio. Si hay errores, identifica el archivo y la regla mencionados, corrige el artefacto y vuelve a validar. Registra el comando y su resultado junto a la evidencia de la etapa.",
          "issues": [
            "La validación de OpenSpec comprueba sus artefactos. Las pruebas Java, los criterios del Issue y la revisión humana se comprueban por separado."
          ]
        }
      ],
      "gate": true
    },
    {
      "issueFallback": null,
      "id": "d3-s4-paso-02",
      "session": "s4",
      "title": "Proteger baseline (characterization)",
      "description": "Asegura que el comportamiento actual quede cubierto antes de implementar.",
      "role": "Guía original · s04-openspec-sdd/STEP_3_CHARACTERIZATION.md",
      "source": "s04-openspec-sdd/STEP_3_CHARACTERIZATION.md",
      "why": "Obtiene una línea base de comportamiento que permita detectar regresiones durante la implementación.",
      "explanation": {
        "why": "Obtiene una línea base de comportamiento que permita detectar regresiones durante la implementación.",
        "where": "En Copilot con Developer y Maven en el backend.",
        "actions": [
          "Revisa las pruebas ya documentadas.",
          "Añade solo la caracterización que falte para el alcance aprobado.",
          "Ejecuta las pruebas, registra sus resultados y actualiza únicamente las tareas verificadas."
        ],
        "output": "Conserva el comando, el resultado y el comportamiento protegido por cada prueba. El diff de esta etapa debe limitarse a las pruebas necesarias y tasks.md.",
        "issues": []
      },
      "commands": [
        {
          "text": "Trabaja únicamente en workshop-auth-backend.\nNo leas ni modifiques los otros repositorios del workspace.\nTodos los comandos, lecturas, cambios y operaciones Git/GitHub de este paso deben referirse únicamente a workshop-auth-backend.\n\nTrabaja sobre la rama actual vinculada al GitHub Issue. No crees ni cambies de rama.\n\nLee el GitHub Issue y el cambio OpenSpec <CHANGE_NAME> completo:\n- proposal.md;\n- specs/;\n- design.md;\n- tasks.md.\n\nTodavía no implementes el cambio funcional.\n\nEjecuta únicamente las tareas de tasks.md relacionadas con caracterización y protección del comportamiento existente.\n\nAntes de crear pruebas nuevas, revisa docs/TESTING.md (Dia 1): reutiliza las\nque ya protegen el comportamiento y agrega solo las que falten.\n\nCrea las pruebas de caracterización necesarias y ejecútalas.\n\nReglas:\n- no corrijas todavía el problema objeto del Issue;\n- no cambies contratos HTTP;\n- no amplíes cobertura fuera del scope;\n- explica qué requisito o comportamiento protege cada prueba;\n- registra el comando ejecutado y su resultado;\n- actualiza en tasks.md únicamente las tareas de caracterización realmente completadas;\n- si una prueba demuestra que proposal, specs, design o tasks eran incorrectos, detente y solicita revisión.",
          "kind": "prompt",
          "executable": false,
          "source": "s04-openspec-sdd/STEP_3_CHARACTERIZATION.md",
          "sourceBlock": 4,
          "agent": "Developer",
          "label": "Caracterizar el comportamiento existente",
          "why": "Protege el comportamiento existente del backend antes de implementar el cambio funcional.",
          "parts": [
            "Selecciona Developer y usa el Issue, la rama y el cambio OpenSpec aprobados.",
            "Revisa docs/TESTING.md antes de añadir pruebas; reutiliza las que ya cubren el contrato.",
            "Ejecuta solo las tareas de caracterización y conserva el código funcional.",
            "Registra comandos, resultados, requisitos protegidos y tareas realmente completadas."
          ],
          "output": "Debe quedar evidencia reproducible de las pruebas del baseline. Revisa que el diff se limite a las pruebas necesarias y a los checks correspondientes de tasks.md, sin corregir todavía el Issue.",
          "issues": [
            "Si las pruebas contradicen los artefactos aprobados, detén el cambio y pide revisión."
          ],
          "where": "En GitHub Copilot Chat de VS Code. Selecciona Developer."
        },
        {
          "text": "mvn test",
          "kind": "command",
          "executable": false,
          "source": "s04-openspec-sdd/STEP_3_CHARACTERIZATION.md",
          "sourceBlock": 5,
          "label": "Ejecutar las pruebas del backend",
          "why": "Usa Maven y el pom.xml del workshop para compilar el código y ejecutar las pruebas Java del proyecto.",
          "where": "En la raíz de tu workshop-auth-backend local, donde está pom.xml.",
          "parts": [
            "mvn invoca Maven y lee el pom.xml del directorio actual.",
            "test ejecuta el ciclo hasta la fase de pruebas, incluida la compilación del código y de las clases de test.",
            "La configuración del proyecto determina qué pruebas JUnit se ejecutan. En esta etapa revisa primero las ya documentadas en docs/TESTING.md."
          ],
          "output": "Revisa el resumen de pruebas: Tests run, Failures y Errors, además del resultado final de Maven. Registra las cifras reales y el comportamiento protegido. La cantidad de pruebas depende del estado de tu repositorio; esta web no ejecuta Maven.",
          "issues": [
            "Un fallo al descargar dependencias o encontrar el JDK es un problema de entorno que debe resolverse antes de evaluar el comportamiento.",
            "Si una prueba falla sobre el baseline, investiga la causa antes de cambiar código funcional. Conserva esa evidencia; no desactives la prueba para obtener un resultado verde."
          ]
        }
      ],
      "gate": true
    },
    {
      "issueFallback": null,
      "id": "d3-s4-paso-03",
      "session": "s4",
      "title": "Aplicar e implementar incrementalmente",
      "description": "Usa OpenSpec apply, implementa, ejecuta tests y evidencia.",
      "role": "Guía original · s04-openspec-sdd/STEP_4_IMPLEMENT.md",
      "source": "s04-openspec-sdd/STEP_4_IMPLEMENT.md",
      "why": "Implementa el Issue aprobado con OpenSpec apply y evidencia incremental.",
      "explanation": {
        "why": "Implementa el Issue aprobado con OpenSpec apply y evidencia incremental.",
        "where": "En Copilot con Developer, sobre la misma rama.",
        "actions": [
          "Lee los artefactos aprobados y el baseline.",
          "Ejecuta las tareas funcionales pendientes en cambios pequeños.",
          "Prueba los cambios y actualiza el checklist cuando exista evidencia."
        ],
        "output": "El diff debe permanecer dentro del Issue, las pruebas relevantes deben tener resultados registrados y cada check debe corresponder a trabajo demostrado.",
        "issues": []
      },
      "commands": [
        {
          "text": "Trabaja únicamente en workshop-auth-backend.\nNo leas ni modifiques los otros repositorios del workspace.\nTodos los comandos, lecturas, cambios y operaciones Git/GitHub de este paso deben referirse únicamente a workshop-auth-backend.\n\nTrabaja sobre la rama actual vinculada al GitHub Issue. No crees ni cambies de rama.\n\nImplementa el GitHub Issue seleccionado utilizando el cambio OpenSpec <CHANGE_NAME> como definición y plan aprobados.\n\nFuentes de verdad:\n1. GitHub Issue aprobado;\n2. openspec/changes/<CHANGE_NAME>/proposal.md;\n3. openspec/changes/<CHANGE_NAME>/specs/;\n4. openspec/changes/<CHANGE_NAME>/design.md;\n5. openspec/changes/<CHANGE_NAME>/tasks.md;\n6. pruebas de caracterización existentes y su baseline.\n\nUsa el workflow OpenSpec apply disponible para GitHub Copilot.\n\nReglas:\n- implementa siguiendo las tareas pendientes de tasks.md;\n- marca una tarea como completada solo cuando exista evidencia de que terminó;\n- no amplíes el scope fuera del Issue y OpenSpec;\n- no cambies contratos fuera del alcance;\n- no resuelvas hallazgos secundarios;\n- no desactives tests ni controles;\n- realiza cambios pequeños;\n- ejecuta las pruebas relevantes después de cada cambio significativo;\n- registra comandos y resultados;\n- detente si implementación, spec, design y tasks entran en conflicto.",
          "kind": "prompt",
          "executable": false,
          "source": "s04-openspec-sdd/STEP_4_IMPLEMENT.md",
          "sourceBlock": 1,
          "agent": "Developer",
          "label": "Implementar las tareas aprobadas",
          "why": "Ejecuta el cambio aprobado usando OpenSpec apply y el checklist de tareas, con la caracterización como red de seguridad.",
          "parts": [
            "Selecciona Developer y conserva la rama vinculada al Issue.",
            "Usa Issue, proposal, specs, design, tasks y las pruebas del baseline como fuentes.",
            "Implementa las tareas pendientes en cambios pequeños y ejecuta las pruebas relevantes.",
            "Marca una tarea solo cuando exista evidencia; si los artefactos se contradicen, detén la ejecución."
          ],
          "output": "Revisa el diff, los resultados de pruebas y cada check de tasks.md. El comportamiento debe satisfacer las specs del Issue y conservar los contratos fuera del alcance.",
          "issues": [],
          "where": "En GitHub Copilot Chat de VS Code. Selecciona Developer."
        }
      ],
      "gate": true
    },
    {
      "issueFallback": null,
      "id": "d3-s4-paso-04",
      "session": "s4",
      "title": "Evaluator + DoD + PR",
      "description": "Ejecuta Definition of Done, abre PR con Closes #N y revisa checks. GATE HUMANO de cierre antes de integrar a main.",
      "role": "Guía original · s04-openspec-sdd/STEP_5_PR_CI.md",
      "source": "s04-openspec-sdd/STEP_5_PR_CI.md",
      "why": "Prepara una revisión independiente y decide el cierre usando evidencia del cambio.",
      "explanation": {
        "why": "Prepara una revisión independiente y decide el cierre usando evidencia del cambio.",
        "where": "En Copilot con Developer, GitHub y revisión del participante.",
        "actions": [
          "Valida los artefactos y revisa el diff y las tareas.",
          "Prepara el PR de la rama del Issue hacia main con Closes #N y evidencia real.",
          "Evalúa DoD, revisa los checks y toma la decisión humana antes de integrar."
        ],
        "output": "El PR debe permitir reconstruir Issue → artefactos → pruebas → implementación. Cierra solo los criterios demostrados y registra los que tengan falta de evidencia o bloqueos.",
        "issues": []
      },
      "commands": [
        {
          "text": "openspec validate <CHANGE_NAME>",
          "kind": "command",
          "executable": false,
          "source": "s04-openspec-sdd/STEP_5_PR_CI.md",
          "sourceBlock": 0,
          "label": "Validar los artefactos del cambio",
          "why": "Comprueba las reglas de estructura y contenido que OpenSpec aplica a las especificaciones del cambio seleccionado.",
          "where": "En la raíz de tu workshop-auth-backend local, donde está pom.xml.",
          "parts": [
            "validate ejecuta las validaciones de OpenSpec.",
            "<CHANGE_NAME> selecciona el cambio que se validará.",
            "<CHANGE_NAME> es el nombre real de la carpeta bajo openspec/changes/. Obtén ese nombre con openspec list y reemplaza el marcador antes de ejecutar."
          ],
          "output": "Busca el resultado de validación del cambio. Si hay errores, identifica el archivo y la regla mencionados, corrige el artefacto y vuelve a validar. Registra el comando y su resultado junto a la evidencia de la etapa.",
          "issues": [
            "La validación de OpenSpec comprueba sus artefactos. Las pruebas Java, los criterios del Issue y la revisión humana se comprueban por separado."
          ]
        },
        {
          "text": "Trabaja únicamente en workshop-auth-backend.\nNo leas ni modifiques los otros repositorios del workspace.\nTodos los comandos, lecturas, cambios y operaciones Git/GitHub de este paso deben referirse únicamente a workshop-auth-backend.\n\nPrepara el Pull Request final del GitHub Issue desde la rama actual <BRANCH_DEL_ISSUE> hacia main.\n\nUsa únicamente evidencia existente en:\n- el GitHub Issue;\n- openspec/changes/<CHANGE_NAME>/proposal.md;\n- openspec/changes/<CHANGE_NAME>/specs/;\n- openspec/changes/<CHANGE_NAME>/design.md;\n- openspec/changes/<CHANGE_NAME>/tasks.md;\n- diff acumulado;\n- pruebas ejecutadas.\n\nAntes de preparar el PR:\n- verifica que estás trabajando con <BRANCH_DEL_ISSUE>;\n- revisa que tasks.md refleje el trabajo realmente completado;\n- revisa el diff acumulado;\n- confirma que las pruebas relevantes tienen evidencia.\n\nPrepara:\n- título;\n- descripción;\n- Issue relacionado;\n- cambio OpenSpec relacionado;\n- estado de tasks.md;\n- comportamiento protegido;\n- cambios realizados;\n- pruebas ejecutadas y resultados;\n- trade-offs;\n- riesgos residuales;\n- rollback;\n- trabajo fuera de alcance.\n\nNo crees ramas adicionales.\nNo modifiques el código en esta etapa.",
          "kind": "prompt",
          "executable": false,
          "source": "s04-openspec-sdd/STEP_5_PR_CI.md",
          "sourceBlock": 2,
          "agent": "Developer",
          "label": "Preparar el contenido del PR",
          "why": "Prepara un Pull Request que un revisor pueda evaluar con la evidencia del cambio.",
          "parts": [
            "Selecciona Developer; usa la rama del Issue como origen y main como destino.",
            "Haz que lea el Issue, los artefactos, el diff acumulado y los resultados de pruebas existentes.",
            "Pide título, descripción, trazabilidad, pruebas, riesgos, rollback y trabajo fuera de alcance.",
            "Esta instrucción prepara el contenido del PR y no pide modificar código."
          ],
          "output": "La propuesta de PR debe referenciar el Issue y el cambio OpenSpec, describir las pruebas realmente ejecutadas y permitir revisar tasks.md. Verifica base main y compare la rama del Issue antes de crear el PR.",
          "issues": [
            "No aceptes un resultado de CI o una prueba que la evidencia disponible no demuestre."
          ],
          "where": "En GitHub Copilot Chat de VS Code. Selecciona Developer."
        },
        {
          "text": "Trabaja únicamente en workshop-auth-backend.\nNo leas ni modifiques los otros repositorios del workspace.\nTodos los comandos, lecturas y operaciones Git/GitHub de esta evaluación deben referirse únicamente a workshop-auth-backend.\n\nUsa el Skill reqflow-definition-of-done para evaluar el cambio actual.\n\nEvalúa únicamente con evidencia existente en:\n- el GitHub Issue;\n- el Pull Request final;\n- openspec/changes/<CHANGE_NAME>/proposal.md;\n- openspec/changes/<CHANGE_NAME>/specs/;\n- openspec/changes/<CHANGE_NAME>/design.md;\n- openspec/changes/<CHANGE_NAME>/tasks.md;\n- pruebas ejecutadas;\n- checks disponibles en GitHub.\n\nPara cada criterio clasifica el resultado como:\n- CUMPLIDO;\n- PENDIENTE DE OTRO GATE;\n- NO APLICA AL ALCANCE;\n- FALTA EVIDENCIA;\n- BLOQUEADO.\n\nNo declares un criterio como cumplido si no existe evidencia verificable.\nNo modifiques código ni archivos.\nDevuélveme una tabla con:\ncriterio | estado | evidencia | observación",
          "kind": "prompt",
          "executable": false,
          "source": "s04-openspec-sdd/STEP_5_PR_CI.md",
          "sourceBlock": 6,
          "agent": "Developer",
          "label": "Evaluar la Definition of Done",
          "why": "Evalúa la Definition of Done con evidencia existente para decidir si el cambio puede cerrarse.",
          "parts": [
            "Selecciona Developer y usa el Skill reqflow-definition-of-done.",
            "Limita la evaluación al backend y a su Issue, PR, artefactos, pruebas y checks disponibles.",
            "Clasifica cada criterio con los estados definidos en el prompt.",
            "Conserva la evaluación como lectura: este prompt no pide modificar archivos."
          ],
          "output": "Revisa una tabla con criterio, estado, evidencia y observación. FALTA EVIDENCIA y BLOQUEADO impiden dar por cumplido ese criterio; NO APLICA debe justificarse por el alcance. La decisión de cierre la toma el participante.",
          "issues": [],
          "where": "En GitHub Copilot Chat de VS Code. Selecciona Developer."
        }
      ],
      "gate": true
    }
  ],
  "files": {
    "bcp-ai-lab-day-03/s04-openspec-sdd/STEP_0_OPENSPEC.md": "# Paso 0 - Preparar OpenSpec para ReqFlow\n\n## Objetivo\n\nInstalar e inicializar OpenSpec en `workshop-auth-backend`, conservar el schema estándar `spec-driven` y dejar sus workflows disponibles para GitHub Copilot antes de iniciar el SDD guiado.\n\n## 0.1 Prerrequisito\n\nOpenSpec es una CLI basada en Node.js. Verifica:\n\n```powershell\nnode --version\n```\n\nSe requiere Node.js 20.19.0 o superior.\n\n## 0.2 Instalar OpenSpec CLI\n\n```powershell\nnpm install -g @fission-ai/openspec@latest\nopenspec --version\n```\n\n## 0.3 Inicializar el repositorio\n\nDesde la raíz de `workshop-auth-backend`:\n\n```powershell\nopenspec init\n```\n\nEn el selector interactivo, elige **GitHub Copilot** como herramienta de IA utilizada por el laboratorio.\n\nOpenSpec crea su estructura de trabajo y los workflows/skills correspondientes a la herramienta seleccionada. Reinicia o refresca el host si OpenSpec lo solicita.\n\n> No reemplaces a ciegas `openspec/config.yaml`: `openspec init` puede guardar allí configuración generada para la herramienta seleccionada. Conserva esa configuración y agrega únicamente el contexto/reglas del laboratorio que necesites.\n\n## 0.4 Confirmar el schema estándar\n\nEl recorrido principal del Día 3 utiliza:\n\n```text\nspec-driven\n```\n\nSu flujo esperado es:\n\n```text\nproposal -> specs -> design -> tasks -> apply\n```\n\nNo instales ni actives `reqflow-github` durante el recorrido principal. Ese schema se conserva en `templates/openspec/schemas/reqflow-github/` únicamente como ejemplo opcional de personalización para el cierre del día.\n\n## 0.5 Configurar contexto ReqFlow\n\nUsa `templates/openspec/config.yaml.example` como referencia para incorporar el contexto y reglas del laboratorio al `openspec/config.yaml` generado, **sin borrar propiedades que haya creado `openspec init`**.\n\nLa configuración debe mantener `schema: spec-driven` y recordar, entre otras cosas, que:\n\n- el cambio parte de un GitHub Issue confirmado;\n- deben preservarse contratos HTTP fuera del alcance aprobado;\n- no se resuelve deuda adicional;\n- los artefactos se escriben en español;\n- `tasks.md` debe ser coherente con Issue, proposal, specs y design.\n\n## 0.6 Verificar el flujo completo\n\nEl participante debe poder explicar que OpenSpec materializará, para un cambio:\n\n```text\nproposal.md\nspecs/\ndesign.md\ntasks.md\n```\n\ny que posteriormente `apply` utilizará esos artefactos para ejecutar el cambio.\n\nEn paralelo:\n\n```text\nGitHub Issue = trabajo comprometido y trazabilidad del producto\ntasks.md      = checklist de implementación dentro del cambio OpenSpec\n```\n\n## 0.7 Publicar la configuración antes de usar cloud agent\n\nLa configuración de OpenSpec y los workflows instalados deben estar versionados y disponibles en el repositorio que utilizará GitHub Copilot cloud agent.\n\nAntes del Paso 1 confirma que `main` contiene, como mínimo:\n\n```text\n.github/agents/\n.github/skills/\nopenspec/config.yaml\n```\n\nademás de los archivos de integración generados por `openspec init` para GitHub Copilot.\n\nEn `s01` y `s02` copiaste agents y skills a la raíz de `reqflow-workspace/`. Cópialos ahora al repo, junto a los Skills del Día 2 que ya están ahí:\n\n```powershell\n# Desde reqflow-workspace/\nCopy-Item -Recurse -Force .github\\agents workshop-auth-backend\\.github\\\nCopy-Item -Recurse -Force .github\\skills\\* workshop-auth-backend\\.github\\skills\\\n```\n\n> Revisa el diff de `openspec init` y conserva únicamente archivos cuyo propósito comprendas.\n\n## 0.8 Comprobación\n\nEjecuta:\n\n```powershell\nopenspec list\n```\n\nEn este punto puede no existir todavía ningún cambio activo. Lo importante es que la CLI reconozca el proyecto y su configuración.\n\n## Criterio de salida\n\nPuede demostrarse que:\n\n- OpenSpec está instalado;\n- `workshop-auth-backend` está inicializado;\n- GitHub Copilot fue seleccionado como herramienta;\n- el recorrido principal usa el schema estándar `spec-driven`;\n- el flujo incluye `proposal`, `specs`, `design`, `tasks` y `apply`;\n- GitHub Issues continúan formando parte del proceso.\n",
    "bcp-ai-lab-day-03/s04-openspec-sdd/STEP_1_SPEC.md": "# Paso 1 - Crear proposal y specs desde el GitHub Issue\n\n## Objetivo\n\nTransformar un GitHub Issue confirmado en artefactos OpenSpec que definan por qué se hace el cambio y qué comportamiento debe preservarse o modificarse.\n\n## Precondición\n\nAntes de comenzar este paso debe existir un GitHub Issue de `workshop-auth-backend` seleccionado para el recorrido guiado.\n\nEse Issue se crea durante el Discovery y backlog del módulo anterior, en [S03 - Paso 4: Discovery y backlog multi-repo](../s03-reqflow-setup/STEP_4_DISCOVERY_BACKLOG.md):\n\n- **4.5** Crear issues a partir de hallazgos CONFIRMADOS;\n- **4.6** agregar los issues al Project ReqFlow;\n- **4.7** elegir un issue de `workshop-auth-backend` para el recorrido guiado de S4.\n\nEl Issue seleccionado debe corresponder a un hallazgo **CONFIRMADO** y será la fuente de alcance y trazabilidad para todo el flujo SDD de este módulo.\n\n## 1.1 Preparar la rama del Issue\n\nUsa el Issue seleccionado en S3 para crear una rama de desarrollo **vinculada al Issue y dejarla activa localmente**.\n\nDesde `reqflow-workspace`:\n\n```powershell\ncd workshop-auth-backend\n\ngh issue develop <ISSUE_NUMBER> --checkout --base main --name <BRANCH_DEL_ISSUE>\n```\n\nPor ejemplo:\n\n```powershell\ngh issue develop 9 --checkout --base main --name feature/issue-9-auth-legacy-base64\n```\n\nEste comando realiza en una sola operación el flujo que necesitamos:\n\n```text\nGitHub Issue\n -> crea rama vinculada al Issue\n -> publica/configura la rama de desarrollo\n -> checkout local\n```\n\nVerifica únicamente que quedaste sobre la rama esperada:\n\n```powershell\ngit branch --show-current\n```\n\nEl resultado debe ser exactamente `<BRANCH_DEL_ISSUE>`.\n\n> Si ya creaste la rama desde la sección **Development** del Issue en GitHub, no crees otra. En ese caso basta con sincronizarla y cambiar a ella:\n>\n> ```powershell\n> git fetch origin\n> git switch <BRANCH_DEL_ISSUE>\n> ```\n\nEsa rama será la rama del Issue utilizada durante todo el recorrido principal de S4.\n\nPara S4 mantén VS Code abierto desde `reqflow-workspace` para conservar el MCP configurado a nivel workspace. Aunque el workspace contiene varios repositorios, todos los prompts y operaciones de este laboratorio deben limitarse explícitamente a `workshop-auth-backend`.\n\n## 1.2 Qué debe producir OpenSpec\n\nPara este paso esperamos:\n\n```text\nopenspec/changes/<change-name>/\n├─ .openspec.yaml\n├─ proposal.md\n└─ specs/\n   └─ <capability>/\n      └─ spec.md\n```\n\nTodavía no queremos design, tasks ni implementación.\n\n## 1.3 Prompt recomendado\n\nEn GitHub Copilot Chat de VS Code, abre el selector **Agent** y elige:\n\n```text\nPM/PO\n```\n\nPrompt sugerido:\n\n```text\nTrabaja únicamente en workshop-auth-backend.\nNo leas ni modifiques los otros repositorios del workspace.\n\nTrabaja sobre la rama actual.\nNo crees ni cambies de rama.\n\nUsa github-official para consultar el GitHub Issue #<ISSUE_NUMBER>\ny úsalo como fuente del trabajo comprometido y del alcance.\n\nTrabaja con OpenSpec y el schema estándar spec-driven configurado en este repositorio.\n\nUsa github-official para consultar el Issue y úsalo como fuente del trabajo comprometido y del alcance.\nUsa docs/ENDPOINTS.md (contrato documentado el Dia 1) como baseline del comportamiento que debe preservarse: los escenarios de las specs deben ser coherentes con ese contrato, o explicar por que el Issue lo cambia.\n\nCrea una propuesta OpenSpec para este cambio y materializa:\n- proposal.md;\n- las specs necesarias bajo openspec/changes/<change>/specs/.\n\nLa propuesta debe:\n- referenciar el Issue;\n- explicar por qué importa el cambio;\n- separar alcance y fuera de alcance;\n- identificar comportamiento que debe preservarse;\n- definir requisitos verificables y escenarios observables.\n\nNo diseñes todavía la implementación técnica.\nNo crees tasks.md todavía.\nNo modifiques código funcional.\n```\n\n## 1.4 Validar la estructura\n\nVerifica que:\n\n- exista `proposal.md`;\n- exista al menos una spec cuando el cambio modifica comportamiento observable;\n- todavía no exista `design.md` ni `tasks.md`;\n- el proposal referencia el GitHub Issue correcto;\n- no haya código funcional modificado.\n\nEjecuta los comandos OpenSpec con `workshop-auth-backend` como directorio de trabajo.\n\nPrimero identifica el nombre exacto del cambio:\n\n```powershell\nopenspec list\n```\n\nTambién puedes verlo como el nombre de la carpeta bajo `openspec/changes/` del repositorio `workshop-auth-backend`.\n\nPor ejemplo:\n\n```text\nopenspec/changes/issue-<N>-<slug-del-hallazgo>/\n```\n\nEntonces:\n\n```text\nCHANGE_NAME = issue-<N>-<slug-del-hallazgo>\n```\n\nCon ese nombre, ejecuta o solicita evidencia de:\n\n```powershell\nopenspec status --change <CHANGE_NAME>\nopenspec validate <CHANGE_NAME>\n```\n\nEjemplo:\n\n```powershell\nopenspec status --change <CHANGE_NAME>\nopenspec validate <CHANGE_NAME>\n```\n\n## 1.5 Gate humano\n\nRevisa proposal y specs:\n\n- ¿es el problema correcto?;\n- ¿el alcance coincide con el Issue?;\n- ¿queda explícito lo que no cambia?;\n- ¿los requisitos son verificables?;\n- ¿los escenarios protegen contratos reales?;\n- ¿no se agregó deuda secundaria?\n\n## 1.6 Integrar la etapa\n\nSi proposal y specs son correctos, registra esta etapa con un commit sobre la misma rama vinculada al Issue.\n\nAntes de commitear, revisa el diff y confirma que solo contiene los artefactos esperados de esta etapa dentro de `workshop-auth-backend`.\n\nPuedes usar GitHub Copilot en VS Code para generar el mensaje del commit a partir de los cambios staged.\n\nEjemplo conceptual:\n\n```text\ndocs(openspec): define issue 10 proposal and specs\n\n- referencia GitHub Issue #10\n- agrega proposal y specs del cambio\n- valida el change de OpenSpec\n- no modifica código funcional\n```\n\nNo abras todavía un PR hacia `main`. La rama del Issue seguirá acumulando las siguientes etapas del flujo SDD.\n\n## Criterio de salida\n\nLa rama integradora contiene un cambio OpenSpec válido con `proposal.md` y `specs/`, vinculado al GitHub Issue y sin implementación funcional.\n\n## Si no tienes un issue del backend\n\nEl Lab 1 deja `HALLAZGOS.md` con Id `H-xx` y evidencia. El **Lab 2, S3 paso 4**, pide crear un issue por cada HU, en su repositorio. Para este recorrido se reutiliza el de `HU-01.md` en `workshop-auth-backend`.\n\nLa estructura requerida es:\n\n- **Título:** el título de la HU.\n- **Origen:** el Id real del hallazgo y evidencia `archivo:línea`.\n- **Criterios de aceptación:** checklist de la HU.\n- **PR de S2:** enlace si existe.\n\nSi no lo creaste, descarga [create_backend_issue.py](../tools/create_backend_issue.py) y guárdalo en la raíz de tu `workshop-auth-backend`, junto a `HU-01.md`. En Git Bash, desde esa carpeta:\n\n```bash\npython create_backend_issue.py --hu HU-01.md --repo TU_OWNER/workshop-auth-backend --web\n```\n\nReemplaza `TU_OWNER` por tu usuario u organización. Necesitas Python, GitHub CLI y una sesión activa de `gh auth login`. El comando se ejecuta en tu equipo; la terminal de esta web no crea issues remotos.\n\nEl script prepara `ISSUE-DRAFT.md` desde tu HU, convierte los criterios en checklist y comprueba duplicados por título y por Id del hallazgo, incluidos issues cerrados. Si hay coincidencias, muestra sus enlaces. Si no las hay, abre el formulario de GitHub con título y cuerpo preparados para que lo revises antes de crearlo. No inventa una HU ni evidencia y conserva cualquier borrador existente.\n\nSi tienes un PR de S2, añade `--pr https://github.com/TU_OWNER/workshop-auth-backend/pull/NUMERO` al comando, sustituyendo la URL por la real.\n\nDespués de crearlo, reutiliza el Project **ReqFlow**, agrega el issue, déjalo en **Todo** y completa **Hallazgo origen** con el Id `H-xx` real. Conserva su número para crear la rama vinculada. El fallback por CLI no sustituye la práctica de MCP del Lab 2.\n",
    "bcp-ai-lab-day-03/s03-reqflow-setup/STEP_3_PROJECT.md": "# Paso 3 - Crear el GitHub Project de ReqFlow (desde cero)\n\n## Objetivo\n\nCrear desde cero un GitHub Project `ReqFlow` bajo el owner del participante para coordinar trabajo ubicado en tres repositorios distintos.\n\n## 3.1 Reutilizar el Project del Día 2\n\nEl Project `ReqFlow` ya existe: lo creaste el Día 2 (S3) con los issues de HU-01 y HU-05. **No crees otro.** Selecciona el Agent `PM/PO`:\n\n```text\nUsando exclusivamente el GitHub MCP oficial, consulta el GitHub Project \"ReqFlow\"\ndel owner <OWNER> y lista sus items: repositorio, título, estado y campo\n\"Hallazgo origen\".\n\nNo crees ni modifiques nada todavía.\nNo uses terminal ni GitHub CLI.\n```\n\nSolo si no existe (no hiciste el Día 2 o partes de `checkpoint/day2`), pide su creación con la misma restricción de usar solo `github-official`, revisa la propuesta antes de autorizar la escritura y crea el campo `Hallazgo origen`. Si falla por scopes o permisos, conserva el error como evidencia y corrige la autorización antes de continuar.\n\n## 3.2 Verificar el Project\n\nDespués de crearlo:\n\n```text\nUsando exclusivamente github-official, lista los GitHub Projects de <OWNER> y confirma el número o identificador del Project ReqFlow.\n```\n\n## 3.3 No existe \"un repo principal\" para el Project\n\nEl Project pertenece al producto/owner y puede coordinar items de varios repositorios.\n\nNo intentes mover el código de los tres componentes a un solo repositorio para simplificar el laboratorio.\n\n## 3.4 Preparar la trazabilidad\n\nTodavía no crees una lista masiva de issues.\n\nEl siguiente paso será:\n\n```text\nDiscovery de los 3 repos\n -> hallazgos candidatos\n -> revisión humana\n -> selección de algunos\n -> issues en el repo correcto\n -> agregar esos issues a ReqFlow\n```\n\n## Nota sobre Projects\n\nEl GitHub MCP oficial implementa actualmente operaciones consolidadas de Projects. La tool de escritura puede incluir operaciones como crear Project, agregar items y actualizar items.\n\nNo memorices nombres internos de campos o IDs si la tool puede resolverlos. Observa siempre el esquema que VS Code muestra en el momento de la ejecución.\n\n## Criterio de salida\n\nExiste un GitHub Project `ReqFlow`, creado o consultado mediante GitHub MCP oficial, y todavía no se ha confundido el Project de producto con ninguno de los tres repositorios de implementación.\n",
    "bcp-ai-lab-day-03/s04-openspec-sdd/STEP_2_ARCHITECTURE.md": "# Paso 2 - Crear design y tasks con OpenSpec\n\n## Objetivo\n\nConvertir proposal y specs aprobados en un diseño técnico incremental y luego descomponer ese diseño en `tasks.md` usando el flujo estándar de OpenSpec.\n\n## 2.1 Partir de la rama integradora actualizada\n\nConfirma que estás trabajando sobre `<BRANCH_DEL_ISSUE>` de `workshop-auth-backend` y que el commit del Paso 1 ya contiene:\n\n```text\nopenspec/changes/<CHANGE_NAME>/proposal.md\nopenspec/changes/<CHANGE_NAME>/specs/\n```\n\nContinúa trabajando sobre esa misma rama. En GitHub Copilot Chat, abre el selector **Agent** y elige:\n\n```text\nArchitect\n```\n\n## 2.2 Crear el design\n\nPrompt recomendado:\n\n```text\nTrabaja únicamente en workshop-auth-backend.\nNo leas ni modifiques los otros repositorios del workspace.\nTodos los comandos, lecturas, cambios y operaciones Git/GitHub de este paso deben referirse únicamente a workshop-auth-backend.\n\nTrabaja sobre la rama actual <BRANCH_DEL_ISSUE>. No crees ni cambies a otra rama.\n\nTrabaja sobre el cambio OpenSpec <CHANGE_NAME> ya aprobado.\nLee proposal.md y specs/ antes de proponer cualquier diseño.\n\nCrea o completa:\nopenspec/changes/<CHANGE_NAME>/design.md\n\nEl design debe incluir:\n- contexto técnico relevante;\n- goals / non-goals;\n- contratos protegidos;\n- componentes afectados;\n- decisiones técnicas y alternativas consideradas;\n- estrategia incremental;\n- pruebas de caracterización necesarias antes de modificar comportamiento crítico;\n- riesgos / trade-offs;\n- rollback cuando aplique.\n\nNo implementes código funcional.\nNo rediseñes toda la aplicación.\n```\n\n## 2.3 Gate humano del design\n\nRevisa:\n\n- ¿cumple las specs sin ampliar alcance?;\n- ¿protege contratos existentes?;\n- ¿explica decisiones y trade-offs?;\n- ¿identifica qué comportamiento debe caracterizarse antes de cambiar?;\n- ¿evita una reescritura innecesaria?\n\nSi una pregunta cambiaría lo que se construirá, resuélvela antes de avanzar.\n\n## 2.4 Crear `tasks.md`\n\nUna vez aprobado el design, completa el artefacto `tasks.md` del mismo cambio OpenSpec.\n\nPrompt recomendado:\n\n```text\nTrabaja únicamente en workshop-auth-backend.\nNo leas ni modifiques los otros repositorios del workspace.\nTodos los comandos, lecturas, cambios y operaciones Git/GitHub de este paso deben referirse únicamente a workshop-auth-backend.\n\nContinúa sobre la rama actual <BRANCH_DEL_ISSUE>. No crees ni cambies de rama.\n\nUsa proposal.md, specs/ y design.md ya aprobados del cambio OpenSpec <CHANGE_NAME>.\n\nGenera o completa:\nopenspec/changes/<CHANGE_NAME>/tasks.md\n\nLas tareas deben:\n- estar dentro del alcance del GitHub Issue;\n- ser pequeñas y verificables;\n- comenzar por las pruebas de caracterización necesarias antes del cambio funcional;\n- incluir la implementación incremental;\n- incluir pruebas/validaciones relevantes;\n- evitar trabajo secundario no aprobado.\n\nEl GitHub Issue sigue siendo la unidad de trabajo del producto. tasks.md es el checklist de implementación de este cambio OpenSpec.\n\nNo implementes todavía el cambio funcional.\n```\n\n## 2.5 Validar OpenSpec\n\nEjecuta los comandos OpenSpec con `workshop-auth-backend` como directorio de trabajo.\n\nSi no recuerdas el nombre del cambio, puedes obtenerlo con:\n\n```powershell\nopenspec list\n```\n\nTambién corresponde al nombre de la carpeta bajo:\n\n```text\nopenspec/changes/\n```\n\nCon el nombre identificado, ejecuta:\n\n```powershell\nopenspec status --change <CHANGE_NAME>\nopenspec validate <CHANGE_NAME>\n```\n\nComprueba que el cambio contiene:\n\n```text\nproposal.md\nspecs/\ndesign.md\ntasks.md\n```\n\ny que está listo para `apply` según el schema `spec-driven`.\n\n## 2.6 Gate humano de tasks\n\nRevisa:\n\n- ¿cada tarea deriva del Issue, specs y design?;\n- ¿la caracterización ocurre antes de modificar comportamiento crítico?;\n- ¿las tareas son verificables?;\n- ¿no aparecen refactors o mejoras fuera de alcance?;\n- ¿el checklist permite saber qué falta durante `apply`?\n\n## 2.7 Integrar la etapa\n\nUna vez aprobados `design.md` y `tasks.md`, registra los cambios directamente en `<BRANCH_DEL_ISSUE>` de `workshop-auth-backend`.\n\nRevisa el diff y crea un commit descriptivo que deje claro que esta etapa incorpora el diseño y el plan de implementación del cambio OpenSpec. Puedes usar GitHub Copilot para proponer el mensaje del commit.\n\nPor ejemplo:\n\n```text\ndocs(openspec): add design and implementation tasks\n```\n\nNo abras todavía un PR hacia `main`.\n\n## Criterio de salida\n\n`<BRANCH_DEL_ISSUE>` contiene un cambio OpenSpec válido con proposal, specs, design y tasks aprobados y registrados en la propia rama del Issue. El GitHub Issue y `tasks.md` son coherentes aunque cumplan funciones de tracking distintas.\n",
    "bcp-ai-lab-day-03/s01-custom-agents/README.md": "# Módulo práctico - Custom Agents sobre ReqFlow\n\n> Este módulo aporta principalmente a **S3 - Fundamentos: model + tools + context + loop** y prepara **S4 - routing, evaluator, HITL**. No sustituye el nombre oficial de esas sesiones.\n\n## Objetivo\n\nTransformar el modo Agent genérico de VS Code en roles especializados con responsabilidades y límites explícitos.\n\nAntes de enrutar trabajo entre varios roles, observa primero qué hace que **un solo agente** sea distinto de un prompt aislado:\n\n```text\nmodel\n+ instructions persistentes\n+ context\n+ tools permitidas\n+ loop de ejecución\n= agent\n```\n\n## Agents del caso\n\n```text\nPM/PO\nDiscovery\nArchitect\nDeveloper\n```\n\nEstos perfiles se reutilizarán después para mostrar routing explícito.\n\n## Preparación del entorno\n\nVienes del Día 2: `reqflow-workspace/.vscode/mcp.json` ya existe. **Consérvalo y ajústalo**: mantén `github-official`, agrega `projects` a `X-MCP-Toolsets` y quita `github-local` (MCP local, puerto 8081) y `github-official-readonly`, que hoy no se usan.\n\nPuedes partir de:\n\n```text\ntemplates/mcp/mcp.json.example\n```\n\nEl servidor debe llamarse:\n\n```text\ngithub-official\n```\n\nEn el Día 3 utilizaremos además el toolset `projects`.\n\nDespués de dejar limpio el archivo, verifica en VS Code que `github-official` pueda iniciarse y aparezca en estado **Started**.\n\n> En la primera prueba de límites no es necesario invocar MCP. El objetivo inicial es aislar instructions + context y observar el comportamiento de un single-agent.\n\n## Preparación de los Agents\n\nCopia los templates desde:\n\n```text\nbcp-ai-lab-day-03/templates/agents/\n```\n\n(el lab está al lado del workspace) hacia `reqflow-workspace/.github/agents/` (en `s04` paso 0 se copian también a `workshop-requirements-api`).\n\nResultado esperado:\n\n```text\n.github/\n└─ agents/\n   ├─ pm-po.agent.md\n   ├─ discovery.agent.md\n   ├─ architect.agent.md\n   └─ developer.agent.md\n```\n\n## Parte 1 - Responsabilidades\n\n### PM/PO\n\nTrabaja sobre necesidad, criterios de aceptación, prioridades y trazabilidad.\n\nNo debe refactorizar código, decidir arquitectura ni inventar hallazgos técnicos.\n\n### Discovery\n\nComprende el sistema antes de modificarlo y produce hallazgos con evidencia.\n\nNo debe arreglar automáticamente lo que encuentra.\n\n### Architect\n\nConvierte una necesidad o hallazgo aprobado en límites técnicos claros.\n\nNo debe implementar el cambio funcional.\n\n### Developer\n\nImplementa únicamente trabajo aprobado y respeta specs, decisiones, contratos y Definition of Done.\n\nNo debe ampliar alcance por su cuenta.\n\n## Parte 2 - Probar un agente y sus límites\n\nEstas pruebas se realizan en GitHub Copilot Chat dentro de VS Code. Selecciona un solo Custom Agent y observa cómo sus instrucciones persistentes condicionan la respuesta.\n\nSelecciona `Discovery`:\n\n```text\nEsta es únicamente una prueba de los límites de tu rol.\nNo leas archivos, no busques en el workspace y no uses MCP ni ninguna otra tool.\n\nSupón que durante un análisis encuentras un problema importante en ReqFlow.\n¿Puedes corregirlo directamente?\nExplica qué deberías hacer según tu responsabilidad antes de que alguien modifique código.\n```\n\nSelecciona `PM/PO`:\n\n```text\nEsta es únicamente una prueba de los límites de tu rol.\nNo leas archivos y no uses ninguna tool.\n\nSupón que se detectó deuda en la capa de persistencia de ReqFlow.\n¿Debes decidir y ejecutar tú mismo el refactor técnico?\nExplica qué te corresponde hacer y a qué rol debería pasar la decisión técnica.\n```\n\nSelecciona `Architect`:\n\n```text\nEsta es únicamente una prueba de los límites de tu rol.\nNo leas archivos y no uses ninguna tool.\n\nSupón que recibes un hallazgo técnico ya confirmado.\n¿Debes implementar directamente el cambio en código?\nExplica cuál es tu responsabilidad y cuándo debe intervenir Developer.\n```\n\nSelecciona `Developer`:\n\n```text\nEsta es únicamente una prueba de los límites de tu rol.\nNo leas archivos y no uses ninguna tool.\n\nTe piden mejorar todo ReqFlow sin issue, spec ni alcance aprobado.\n¿Debes empezar a modificar código?\nExplica qué información necesitas antes de implementar.\n```\n\n## De single-agent a routing\n\nUna vez comprendido cada perfil de forma aislada, S4 reutiliza los mismos roles como destinos de routing:\n\n```text\nproducto/alcance -> PM/PO\nhallazgo         -> Discovery\ndiseño           -> Architect\nimplementación   -> Developer\n```\n\nEl taller no requiere un router autónomo: seleccionar deliberadamente el Agent correcto ya permite observar el patrón y discutir sus reglas.\n\n## Criterio de salida\n\nEl participante puede explicar:\n\n```text\nAgent != prompt largo\nAgent = model + instrucciones + contexto + tools + loop\n```\n\ny puede justificar por qué una tarea debe enrutarse a un rol y no a otro.\n",
    "bcp-ai-lab-day-03/s03-reqflow-setup/STEP_2_MCP.md": "# Paso 2 - Configurar GitHub MCP oficial\n\n## Objetivo\n\nConectar el workspace de ReqFlow al GitHub MCP oficial con capacidades de repositorios, issues, pull requests y Projects.\n\n## 2.1 Configuración\n\n### Inconsistencia típica desde el Día 2\n\nSi vienes del Día 2, tu `./reqflow-workspace/.vscode/mcp.json` puede contener servidores MCP locales (`github-local`) o una configuración sin el toolset `projects`.\nEn el Día 3 debes usar **solo** el servidor `github-official` y habilitar `projects`.\n\n### Configuración requerida\n\nCrea o actualiza `./reqflow-workspace/.vscode/mcp.json`:\n\n```json\n{\n  \"servers\": {\n    \"github-official\": {\n      \"type\": \"http\",\n      \"url\": \"https://api.githubcopilot.com/mcp/\",\n      \"headers\": {\n        \"X-MCP-Toolsets\": \"context,repos,issues,pull_requests,projects,users\"\n      }\n    }\n  }\n}\n```\n\nNo incrustes tokens en el archivo.\n\n## 2.2 Conectar\n\nEn VS Code:\n\n1. abre Copilot Chat;\n2. utiliza modo Agent;\n3. comprueba que `github-official` esté conectado;\n4. abre **Configure Tools**;\n5. localiza las tools del GitHub MCP oficial.\n\n## 2.3 Verificar Projects\n\nAntes de intentar crear el Project de ReqFlow, comprueba que el toolset `projects` quedó realmente disponible.\n\n### Verificación visual\n\nEn **Configure Tools**:\n\n1. expande `github-official`;\n2. busca tools relacionadas con GitHub Projects;\n3. confirma que existen operaciones de lectura y escritura de Projects.\n\nSegún la versión de VS Code, los nombres pueden mostrarse de forma amigable o con el nombre técnico de la tool. La implementación oficial actual consolida estas capacidades en tools como:\n\n```text\nprojects_list\nprojects_write\n```\n\n### Prueba real de lectura\n\nUsa el **modo Agent estándar de VS Code** y ejecuta:\n\n```text\nUsando exclusivamente github-official, lista los GitHub Projects accesibles para mi usuario.\n\nNo uses terminal, GitHub CLI, web ni otras herramientas.\nIndica qué tool MCP utilizaste.\n```\n\nResultado esperado:\n\n```text\nVS Code Agent mode\n  -> github-official\n  -> Projects\n  -> GitHub\n```\n\nNo es necesario que exista todavía un Project llamado `ReqFlow`. En este punto solo estamos verificando que la capacidad de Projects está expuesta y puede consultarse mediante MCP.\n\nSi no aparecen tools de Projects o la lectura falla por autorización, no continúes todavía con la creación del Project. Conserva el error como evidencia y revisa configuración/permisos antes de seguir.\n\n## 2.4 Prueba de lectura de repositorio\n\nPara esta prueba usa el **modo Agent estándar de VS Code**. No selecciones todavía ninguno de los Custom Agents (`PM/PO`, `Discovery`, `Architect` o `Developer`).\n\nAquí solo queremos validar que VS Code puede invocar correctamente el servidor `github-official` para consultar un repositorio real. Los roles especializados se utilizarán en los pasos posteriores, cuando ya exista una tarea propia de cada responsabilidad.\n\nUsa repositorio explícito:\n\n```text\nUsando exclusivamente github-official, consulta información de <OWNER>/workshop-auth-backend y dime qué tool MCP utilizaste.\nNo uses terminal ni GitHub CLI para obtener la información de GitHub.\n```\n\nResultado esperado:\n\n```text\nVS Code Agent mode\n  -> github-official\n  -> GitHub\n```\n\nLa respuesta debe provenir de una tool del MCP oficial y debe indicar cuál fue utilizada.\n\n## 2.5 Principio de seguridad\n\nRecuerda el Día 2:\n\n```text\nAgent limita comportamiento\nMCP limita tools expuestas\nOAuth/scopes limitan identidad\nGitHub permissions limitan recursos\nPolicies/rulesets gobiernan integración\n```\n\nLa presencia de una tool con capacidad de escritura sobre Projects no garantiza que la identidad tenga permisos efectivos para crear o modificar Projects.\n\n## Criterio de salida\n\n- `github-official` aparece conectado;\n- las capacidades de Projects están visibles y una lectura real funciona mediante MCP;\n- una operación de lectura de repositorio se ejecuta mediante GitHub MCP usando el modo Agent estándar;\n- no se utilizaron herramientas alternativas para ocultar un fallo de MCP.\n",
    "bcp-ai-lab-day-03/s03-reqflow-setup/STEP_4_DISCOVERY_BACKLOG.md": "# Paso 4 - Discovery y backlog multi-repo\n\n## Objetivo\n\nUtilizar el Agent `Discovery` para comprender los tres componentes y convertir únicamente hallazgos revisados en backlog trazable.\n\n## 4.1 Regla de oro\n\nDiscovery no corrige código.\n\n```text\nobservar -> explicar -> evidenciar -> priorizar\n```\n\nNo:\n\n```text\nobservar -> arreglar automáticamente\n```\n\n## 4.2 Analizar cada repositorio por separado\n\nEjecuta una conversación de Discovery por componente para evitar mezclar evidencias.\n\nEjemplo para el backend Java:\n\n```text\nAnaliza workshop-auth-backend sin modificar archivos.\n\nParte de lo que ya existe: workshop-auth-backend/HALLAZGOS.md (Dia 1) y\nlos issues del Project ReqFlow (Dia 2). Re-verifica cada hallazgo \"Pendiente\"\ncontra el codigo actual e indica si ya tiene issue (campo Hallazgo origen).\nDespues comprende estructura, contratos (docs/ENDPOINTS.md) y pruebas\nexistentes (docs/TESTING.md).\nDespués presenta como máximo 5 hallazgos candidatos.\n\nPara cada hallazgo incluye:\n- evidencia concreta;\n- por qué importa;\n- prioridad propuesta;\n- contrato funcional que podría verse afectado;\n- cómo lo validarías antes de cambiarlo.\n\nNo inventes problemas si no encuentras evidencia.\nNo implementes soluciones.\n```\n\nRepite el patrón para:\n\n```text\nworkshop-requirements-api\nworkshop-login-frontend\n```\n\n## 4.3 Revisión humana\n\nAntes de crear issues, revisa cada hallazgo.\n\nClasifica:\n\n```text\nCONFIRMADO\nNECESITA MÁS EVIDENCIA\nDESCARTADO\n```\n\nUn hallazgo generado por IA no se convierte en backlog por existir en una respuesta.\n\n## 4.4 Seleccionar backlog inicial\n\nPara mantener la sesión manejable, selecciona pocos hallazgos confirmados.\n\nSugerencia:\n\n```text\n1 a 3 por repositorio\n```\n\nNo se busca resolver toda la deuda del caso.\n\nLos issues de HU-01 (backend) y HU-05 (frontend) del Día 2 ya cubren parte del backlog. Reutiliza los issues existentes; el recorrido guiado de S4 se realiza en `workshop-auth-backend`.\n\n## 4.5 Crear issues en el repositorio correcto\n\nSelecciona `PM/PO` y proporciona únicamente los hallazgos aprobados.\n\nEjemplo:\n\n```text\nUsando exclusivamente github-official, convierte estos hallazgos CONFIRMADOS en issues.\n\nReglas:\n- cada issue debe vivir en el repositorio al que pertenece la evidencia;\n- no dupliques: si el hallazgo ya tiene issue en ReqFlow, reutilízalo;\n- incluye el Id H-xx del hallazgo de origen y completa el campo Hallazgo origen;\n- no inventes nuevos hallazgos;\n- incluye problema, evidencia, impacto y criterio verificable;\n- antes de crear, muéstrame el repositorio destino y el título propuesto.\n```\n\n## 4.6 Agregar los issues al Project ReqFlow\n\nDespués de crear los issues aprobados:\n\n```text\nUsando exclusivamente las tools de Projects de github-official, agrega al Project ReqFlow los issues que acabamos de aprobar.\nNo cambies su repositorio de origen.\n```\n\nResultado conceptual:\n\n```text\nReqFlow Project\n  + Frontend issue -> workshop-login-frontend\n  + Backend issue  -> workshop-auth-backend\n  + API issue      -> workshop-requirements-api\n```\n\n## 4.7 Elegir el issue guiado\n\nDe los issues de `workshop-auth-backend`, selecciona uno para demostrar el ciclo SDD completo.\n\nCriterios recomendados:\n\n- hallazgo confirmado;\n- alcance pequeño o mediano;\n- contrato identificable;\n- comportamiento susceptible de proteger con pruebas;\n- no requiere resolver previamente media aplicación.\n\nNo fijamos un issue específico en la guía porque el discovery forma parte de la evaluación.\n\n## 4.8 Relación con `tasks.md` de OpenSpec\n\nEl GitHub Issue creado en este laboratorio no reemplaza a `tasks.md`.\n\nEn S4 ambos coexistirán deliberadamente:\n\n```text\nGitHub Issue\n= trabajo comprometido, responsable, prioridad y trazabilidad del producto\n\nOpenSpec tasks.md\n= checklist de implementación del cambio seleccionado\n```\n\nEs normal que exista cierto solapamiento. El objetivo del Día 3 es que el participante conozca el flujo completo estándar de OpenSpec y, al mismo tiempo, conserve GitHub como plataforma operativa del producto.\n\n## Criterio de salida\n\n- existe evidencia de Discovery en los tres repos;\n- los hallazgos fueron revisados humanamente;\n- hay issues distribuidos entre los repositorios;\n- esos issues aparecen coordinados en ReqFlow Project;\n- hay exactamente un issue del backend seleccionado para S4;\n- el participante puede explicar que ese Issue convivirá en S4 con `tasks.md` de OpenSpec.\n",
    "bcp-ai-lab-day-03/s04-openspec-sdd/STEP_3_CHARACTERIZATION.md": "# Paso 3 - Proteger el comportamiento antes de implementar\n\n## Objetivo\n\nEjecutar primero las tareas de caracterización definidas en `tasks.md` para crear evidencia del comportamiento que debe preservarse antes de modificar una pieza crítica.\n\n## 3.1 Partir de la rama integradora actualizada\n\nConfirma que estás trabajando sobre `<BRANCH_DEL_ISSUE>` de `workshop-auth-backend` y que el cambio OpenSpec ubicado en:\n\n```text\nopenspec/changes/<CHANGE_NAME>/\n```\n\ncontiene:\n\n```text\nproposal.md\nspecs/\ndesign.md\ntasks.md\n```\n\nValida además que el cambio sigue siendo válido, ejecutando OpenSpec con `workshop-auth-backend` como directorio de trabajo:\n\n```powershell\nopenspec validate <CHANGE_NAME>\n```\n\nContinúa trabajando sobre la misma rama del Issue. No crees ni cambies a otra rama para esta etapa.\n\nEn GitHub Copilot Chat, abre el selector **Agent** y elige:\n\n```text\nDeveloper\n```\n\n## 3.2 Prompt recomendado\n\n```text\nTrabaja únicamente en workshop-auth-backend.\nNo leas ni modifiques los otros repositorios del workspace.\nTodos los comandos, lecturas, cambios y operaciones Git/GitHub de este paso deben referirse únicamente a workshop-auth-backend.\n\nTrabaja sobre la rama actual vinculada al GitHub Issue. No crees ni cambies de rama.\n\nLee el GitHub Issue y el cambio OpenSpec <CHANGE_NAME> completo:\n- proposal.md;\n- specs/;\n- design.md;\n- tasks.md.\n\nTodavía no implementes el cambio funcional.\n\nEjecuta únicamente las tareas de tasks.md relacionadas con caracterización y protección del comportamiento existente.\n\nAntes de crear pruebas nuevas, revisa docs/TESTING.md (Dia 1): reutiliza las\nque ya protegen el comportamiento y agrega solo las que falten.\n\nCrea las pruebas de caracterización necesarias y ejecútalas.\n\nReglas:\n- no corrijas todavía el problema objeto del Issue;\n- no cambies contratos HTTP;\n- no amplíes cobertura fuera del scope;\n- explica qué requisito o comportamiento protege cada prueba;\n- registra el comando ejecutado y su resultado;\n- actualiza en tasks.md únicamente las tareas de caracterización realmente completadas;\n- si una prueba demuestra que proposal, specs, design o tasks eran incorrectos, detente y solicita revisión.\n```\n\n> En esta etapa el Developer puede modificar únicamente las pruebas necesarias y `tasks.md` dentro de `workshop-auth-backend`. Puede ejecutar la suite para obtener una línea base reproducible, pero todavía no debe modificar código funcional.\n\nDesde la raíz de `workshop-auth-backend`, ejecuta las pruebas del proyecto Java con Maven:\n\n```powershell\nmvn test\n```\n\nUn error de entorno o de invocación del comando no equivale a un fallo del comportamiento caracterizado. Corrige primero el entorno y vuelve a ejecutar la misma batería de pruebas antes de sacar conclusiones sobre el código.\n\n## 3.3 Relación con OpenSpec\n\nEn una aplicación brownfield, OpenSpec define el cambio, pero antes de aplicar tareas funcionales necesitamos proteger el comportamiento existente que podría verse afectado. Por eso este laboratorio introduce un gate de characterization tests antes del cambio funcional.\n\n```text\nspec\n= comportamiento requerido\n\ndesign\n= estrategia técnica\n\ntasks.md\n= plan/checklist aprobado\n\ncharacterization test\n= evidencia ejecutable del comportamiento existente que debemos proteger\n```\n\nLas pruebas de caracterización forman parte de la ejecución del plan, pero se separan como gate brownfield antes del cambio funcional.\n\n## 3.4 Evidencia esperada\n\nLa sesión debe dejar evidencia de:\n\n```text\ncomando ejecutado\nresultado\nnúmero de tests relevantes\nspec/requisito relacionado\ntarea de tasks.md relacionada\ncomportamiento protegido\n```\n\n## 3.5 Integrar la etapa\n\nUna vez que las pruebas de caracterización pasan y `tasks.md` refleja únicamente las tareas realmente completadas, revisa el diff antes de registrar los cambios.\n\nConfirma que:\n\n- solo se modificaron pruebas necesarias para caracterizar el baseline y `tasks.md` dentro de `workshop-auth-backend`;\n- no se modificó código funcional;\n- las pruebas ejecutadas pasan sobre el comportamiento actual;\n- las tareas futuras que todavía no corresponden al baseline permanecen pendientes.\n\nRegistra la etapa directamente en `<BRANCH_DEL_ISSUE>` con un commit descriptivo. Puedes usar GitHub Copilot para proponer el mensaje del commit.\n\nPor ejemplo:\n\n```text\ntest: characterize current <comportamiento-protegido> behavior\n```\n\nEl commit debe incluir las pruebas de caracterización y la actualización correspondiente de `tasks.md`.\n\nNo abras todavía un PR hacia `main`.\n\n## Criterio de salida\n\n`<BRANCH_DEL_ISSUE>` contiene proposal, specs, design y tasks aprobados, con las tareas de caracterización realmente verificadas marcadas como completadas y una red de seguridad reproducible antes del cambio funcional.\n",
    "bcp-ai-lab-day-03/s04-openspec-sdd/STEP_4_IMPLEMENT.md": "# Paso 4 - Implementar con OpenSpec apply + GitHub Issue\n\n## Objetivo\n\nImplementar únicamente el GitHub Issue aprobado usando el cambio OpenSpec completo y `tasks.md` como checklist de ejecución.\n\n## 4.1 Partir de la rama integradora actualizada\n\nConfirma que estás trabajando sobre `<BRANCH_DEL_ISSUE>` de `workshop-auth-backend` y que allí existen:\n\n- OpenSpec proposal aprobado;\n- OpenSpec specs aprobadas;\n- OpenSpec design aprobado;\n- OpenSpec tasks aprobado;\n- tareas de caracterización completadas;\n- baseline conocido.\n\nContinúa trabajando sobre la misma rama del Issue. No crees ni cambies a otra rama para esta etapa.\n\nEn GitHub Copilot Chat, abre el selector **Agent** y elige:\n\n```text\nDeveloper\n```\n\n## 4.2 Prompt recomendado\n\n```text\nTrabaja únicamente en workshop-auth-backend.\nNo leas ni modifiques los otros repositorios del workspace.\nTodos los comandos, lecturas, cambios y operaciones Git/GitHub de este paso deben referirse únicamente a workshop-auth-backend.\n\nTrabaja sobre la rama actual vinculada al GitHub Issue. No crees ni cambies de rama.\n\nImplementa el GitHub Issue seleccionado utilizando el cambio OpenSpec <CHANGE_NAME> como definición y plan aprobados.\n\nFuentes de verdad:\n1. GitHub Issue aprobado;\n2. openspec/changes/<CHANGE_NAME>/proposal.md;\n3. openspec/changes/<CHANGE_NAME>/specs/;\n4. openspec/changes/<CHANGE_NAME>/design.md;\n5. openspec/changes/<CHANGE_NAME>/tasks.md;\n6. pruebas de caracterización existentes y su baseline.\n\nUsa el workflow OpenSpec apply disponible para GitHub Copilot.\n\nReglas:\n- implementa siguiendo las tareas pendientes de tasks.md;\n- marca una tarea como completada solo cuando exista evidencia de que terminó;\n- no amplíes el scope fuera del Issue y OpenSpec;\n- no cambies contratos fuera del alcance;\n- no resuelvas hallazgos secundarios;\n- no desactives tests ni controles;\n- realiza cambios pequeños;\n- ejecuta las pruebas relevantes después de cada cambio significativo;\n- registra comandos y resultados;\n- detente si implementación, spec, design y tasks entran en conflicto.\n```\n\n## 4.3 Qué significa `apply`\n\nEn el recorrido principal usamos el schema estándar `spec-driven`:\n\n```text\nproposal -> specs -> design -> tasks -> apply\n```\n\nDurante `apply`, OpenSpec guía la implementación a partir de los artefactos aprobados y del estado de `tasks.md`.\n\nGitHub conserva, en paralelo:\n\n```text\nIssue   = unidad de trabajo y trazabilidad del producto\nProject = prioridad y coordinación\nPR      = revisión e integración\n```\n\n## 4.4 Validación\n\nEl agente debe ejecutar, con `workshop-auth-backend` como directorio de trabajo y según corresponda al repositorio real:\n\n- tests de caracterización;\n- tests del cambio;\n- build/lint disponibles;\n- pruebas HTTP relevantes;\n- `openspec validate <CHANGE_NAME>` si los artefactos OpenSpec fueron modificados.\n\nAntes de cerrar la etapa revisa `tasks.md`: cualquier checkbox marcado debe corresponder a trabajo realmente ejecutado y validado.\n\n## 4.5 Integrar la etapa\n\nAntes de registrar los cambios, revisa:\n\n- el diff de implementación dentro de `workshop-auth-backend`;\n- `tasks.md` y el estado real de cada checkbox;\n- las pruebas ejecutadas y sus resultados;\n- que cada tarea marcada como completada tenga evidencia;\n- que no existan cambios fuera del alcance aprobado.\n\nRegistra los cambios directamente en `<BRANCH_DEL_ISSUE>` con un commit descriptivo. Puedes usar GitHub Copilot para proponer el mensaje del commit.\n\nPor ejemplo:\n\n```text\nfeat: implement approved <CHANGE_NAME> change\n```\n\nEl commit debe incluir la implementación validada y la actualización correspondiente de `tasks.md`.\n\nNo abras todavía el PR final hacia `main`; ese paso corresponde al Step 5.\n\n## Criterio de salida\n\n`<BRANCH_DEL_ISSUE>` contiene la implementación aprobada del GitHub Issue, satisface las specs OpenSpec relevantes, refleja correctamente el progreso en `tasks.md` y mantiene pruebas reproducibles en verde según el baseline esperado.\n",
    "bcp-ai-lab-day-03/s04-openspec-sdd/STEP_5_PR_CI.md": "# Paso 5 - Preparar Pull Request final y revisar quality gates\n\n## Objetivo\n\nCerrar el ciclo guiado con evidencia suficiente para una revisión independiente y con un Pull Request final desde la rama del Issue hacia `main`.\n\n## 5.1 Confirmar la rama del Issue\n\nConfirma que estás trabajando sobre `<BRANCH_DEL_ISSUE>` de `workshop-auth-backend` y que allí existen:\n\n- `proposal.md` aprobado;\n- `specs/` aprobadas;\n- `design.md` aprobado;\n- `tasks.md` actualizado;\n- pruebas de caracterización;\n- implementación del Issue;\n- evidencia de pruebas relevantes.\n\nValida además el cambio OpenSpec con `workshop-auth-backend` como directorio de trabajo:\n\n```powershell\nopenspec validate <CHANGE_NAME>\n```\n\nRevisa `tasks.md`: no debe haber tareas marcadas como completas sin evidencia. Si quedan tareas pendientes, determina si bloquean el cierre o si el alcance debe volver a revisión.\n\n## 5.2 Preparar el contenido del PR\n\nSi trabajas desde el workspace multi-repo, limita explícitamente el contexto al repositorio objetivo:\n\n```text\nTrabaja únicamente en workshop-auth-backend.\nNo leas ni modifiques los otros repositorios del workspace.\n```\n\nEn GitHub Copilot Chat, abre el selector **Agent**, elige `Developer` y usa un prompt como el siguiente:\n\n```text\nTrabaja únicamente en workshop-auth-backend.\nNo leas ni modifiques los otros repositorios del workspace.\nTodos los comandos, lecturas, cambios y operaciones Git/GitHub de este paso deben referirse únicamente a workshop-auth-backend.\n\nPrepara el Pull Request final del GitHub Issue desde la rama actual <BRANCH_DEL_ISSUE> hacia main.\n\nUsa únicamente evidencia existente en:\n- el GitHub Issue;\n- openspec/changes/<CHANGE_NAME>/proposal.md;\n- openspec/changes/<CHANGE_NAME>/specs/;\n- openspec/changes/<CHANGE_NAME>/design.md;\n- openspec/changes/<CHANGE_NAME>/tasks.md;\n- diff acumulado;\n- pruebas ejecutadas.\n\nAntes de preparar el PR:\n- verifica que estás trabajando con <BRANCH_DEL_ISSUE>;\n- revisa que tasks.md refleje el trabajo realmente completado;\n- revisa el diff acumulado;\n- confirma que las pruebas relevantes tienen evidencia.\n\nPrepara:\n- título;\n- descripción;\n- Issue relacionado;\n- cambio OpenSpec relacionado;\n- estado de tasks.md;\n- comportamiento protegido;\n- cambios realizados;\n- pruebas ejecutadas y resultados;\n- trade-offs;\n- riesgos residuales;\n- rollback;\n- trabajo fuera de alcance.\n\nNo crees ramas adicionales.\nNo modifiques el código en esta etapa.\n```\n\nEl objetivo de este paso es preparar un PR auditable a partir de evidencia existente, no volver a implementar el cambio.\n\n## 5.3 Crear el PR final\n\nEl Pull Request final propone integrar todo el trabajo del Issue desde `<BRANCH_DEL_ISSUE>` hacia `main`.\n\nEn GitHub, la dirección debe ser:\n\n```text\nbase: main\ncompare: <BRANCH_DEL_ISSUE>\n```\n\nDonde:\n\n```text\nbase    = rama destino\ncompare = rama que contiene los cambios\n```\n\nAntes de crear el PR revisa:\n\n- commits incluidos;\n- archivos modificados;\n- diff acumulado;\n- que no haya cambios fuera del Issue;\n- que `tasks.md` refleje el estado real;\n- que las pruebas relevantes tengan evidencia.\n\nUsa como título y descripción el contenido preparado en el paso anterior.\n\nSi el agente dispone de acceso a GitHub mediante MCP, puede realizar la operación sobre el PR de `workshop-auth-backend`. Si la creación se hace manualmente en GitHub.com, conserva exactamente la misma dirección de ramas y revisa el diff antes de confirmar.\n\n## 5.4 Revisar trazabilidad\n\nLa cadena esperada es:\n\n```text\nDiscovery\n-> GitHub Issue\n-> GitHub Project\n-> rama del Issue\n-> OpenSpec proposal/specs/design/tasks\n-> characterization tests\n-> OpenSpec apply\n-> implementación\n-> PR final rama del Issue -> main\n```\n\nComprueba que el PR final permite reconstruir esa historia sin depender de información implícita.\n\n## 5.5 Revisar checks automatizados\n\nGitHub puede ejecutar automáticamente workflows y controles ya configurados en el repositorio.\n\nEn S4 no creamos ni modificamos el pipeline de CI. Revisa cada check existente como quality gate independiente.\n\nSi alguno falla:\n\n- no lo deshabilites para obtener verde;\n- identifica el workflow/control;\n- determina si el fallo fue causado por el cambio, es preexistente o corresponde a configuración del laboratorio;\n- registra el resultado como evidencia;\n- no confundas un fallo técnico del workflow con un fallo funcional sin investigar su causa.\n\nUn PR mergeado no implica automáticamente que la Definition of Done esté satisfecha.\n\n## 5.6 Definition of Done\n\nLa Definition of Done es un gate de evaluación, no un paso de implementación.\n\nEn GitHub Copilot Chat, abre el selector **Agent**, elige `Developer` y usa el Skill `reqflow-definition-of-done` para evaluar únicamente evidencia existente.\n\nPrompt recomendado:\n\n```text\nTrabaja únicamente en workshop-auth-backend.\nNo leas ni modifiques los otros repositorios del workspace.\nTodos los comandos, lecturas y operaciones Git/GitHub de esta evaluación deben referirse únicamente a workshop-auth-backend.\n\nUsa el Skill reqflow-definition-of-done para evaluar el cambio actual.\n\nEvalúa únicamente con evidencia existente en:\n- el GitHub Issue;\n- el Pull Request final;\n- openspec/changes/<CHANGE_NAME>/proposal.md;\n- openspec/changes/<CHANGE_NAME>/specs/;\n- openspec/changes/<CHANGE_NAME>/design.md;\n- openspec/changes/<CHANGE_NAME>/tasks.md;\n- pruebas ejecutadas;\n- checks disponibles en GitHub.\n\nPara cada criterio clasifica el resultado como:\n- CUMPLIDO;\n- PENDIENTE DE OTRO GATE;\n- NO APLICA AL ALCANCE;\n- FALTA EVIDENCIA;\n- BLOQUEADO.\n\nNo declares un criterio como cumplido si no existe evidencia verificable.\nNo modifiques código ni archivos.\nDevuélveme una tabla con:\ncriterio | estado | evidencia | observación\n```\n\nInterpreta los estados así:\n\n```text\nCUMPLIDO\n= existe evidencia suficiente\n\nFALTA EVIDENCIA\n= podría estar bien, pero no puede demostrarse\n\nBLOQUEADO\n= existe una señal concreta que impide aprobar el criterio\n\nNO APLICA AL ALCANCE\n= el criterio no corresponde al cambio evaluado\n```\n\nNo conviertas ausencia de evidencia en aprobación.\n\n## 5.7 ¿Cuándo archivar OpenSpec?\n\nMientras el cambio está activo, sus artefactos viven en:\n\n```text\nopenspec/changes/<CHANGE_NAME>/\n```\n\nArchivar significa declarar que ese cambio dejó de ser trabajo activo porque fue implementado, validado e integrado. El archive también puede actualizar las specs canónicas según el workflow OpenSpec utilizado.\n\nLa secuencia recomendada es:\n\n```text\nimplementación terminada\n-> pruebas y quality gates revisados\n-> PR final aprobado y mergeado\n-> Definition of Done aceptada\n-> archive del cambio OpenSpec\n```\n\nNo archives un cambio únicamente porque el PR exista o haya sido mergeado. Si hay gates bloqueados, tareas pendientes o falta evidencia relevante, el cambio todavía necesita revisión.\n\nEl archive puede realizarse como cierre posterior del Issue o como un PR/commit de housekeeping según la política del equipo.\n\n## 5.8 Cierre conceptual: personalizar OpenSpec\n\nEste paso es únicamente de comparación conceptual. No modifiques el cambio actual ni cambies el schema activo.\n\nCompara el recorrido estándar usado en el laboratorio con el ejemplo personalizado disponible en:\n\n```text\ntemplates/openspec/schemas/reqflow-github/\n```\n\nEl objetivo es observar que un equipo puede personalizar OpenSpec para eliminar `tasks.md` y delegar el tracking operativo a GitHub Issues.\n\nComparación:\n\n```text\nRecorrido principal:\nproposal -> specs -> design -> tasks -> apply\n                 + GitHub Issue\n\nAlternativa personalizada:\nproposal -> specs -> design -> apply\n                 + GitHub Issue como tracking\n```\n\nLa segunda opción puede evitar duplicación en un equipo real, pero se presenta **después** de aprender el flujo estándar completo. Cambia el proceso de trabajo, no la funcionalidad de ReqFlow.\n\n## Criterio de salida\n\nExiste un PR auditable desde `<BRANCH_DEL_ISSUE>` hacia `main`, conectado a un GitHub Issue y respaldado por proposal, specs, design, tasks, pruebas y quality gates revisados. El participante además puede explicar cómo OpenSpec podría personalizarse posteriormente para delegar el tracking en GitHub Issues.\n",
    "bcp-ai-lab-day-03/laboratory-guide.html": "<!doctype html>\n<html lang=\"es\">\n\n<head>\n  <meta charset=\"utf-8\">\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n  <title>Día 3 — Guía de Laboratorio</title>\n  <link rel=\"preconnect\" href=\"https://fonts.googleapis.com\">\n  <link rel=\"stylesheet\"\n    href=\"https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700;1,9..40,300&family=DM+Mono:wght@400;500&display=swap\">\n\n  <style>\n    :root {\n      --bg: #EBF0F7;\n      --surface: #FFFFFF;\n      --surface-alt: #F4F7FB;\n      --border: #CDD8E8;\n      --accent: #007F6E;\n      --accent2: #0072BC;\n      --text-primary: #0C1A28;\n      --text-sec: #3D5670;\n      --text-muted: #7A93A8;\n      --am: #0072BC;\n      --pm: #007F6E;\n      --tag-am-bg: #E0ECFA;\n      --tag-am-fg: #0F4A90;\n      --tag-pm-bg: #DDF4F0;\n      --tag-pm-fg: #005348;\n      --step-num: #0072BC;\n      --code-bg: #0C1A28;\n      --code-fg: #A8D5FF;\n      --code-border: #1C3050;\n      --out-bg: #ECF8F6;\n      --out-border: #9ECFC7;\n      --out-label: #005A4D;\n      --gate-bg: #FFFBEC;\n      --gate-border: #D4A800;\n      --gate-text: #6B4D00;\n      --gate-chip: #D4A800;\n      --gate-chip-fg: #FFFFFF;\n      --break-line: #CDD8E8;\n      --bad: #E42600;\n      --good: #00A855;\n    }\n\n    @media (prefers-color-scheme: dark) {\n      :root:not([data-theme=\"light\"]) {\n        --bg: #090F18;\n        --surface: #101C2C;\n        --surface-alt: #152030;\n        --border: #1C3050;\n        --accent: #00C2A8;\n        --accent2: #4D9FE8;\n        --text-primary: #DDE8F5;\n        --text-sec: #6D9ABE;\n        --text-muted: #3D5E7A;\n        --am: #4D9FE8;\n        --pm: #00C2A8;\n        --tag-am-bg: #0B1E3A;\n        --tag-am-fg: #7DC5F8;\n        --tag-pm-bg: #0B2520;\n        --tag-pm-fg: #55DFC8;\n        --step-num: #4D9FE8;\n        --code-bg: #060D18;\n        --code-fg: #7FC8FF;\n        --code-border: #1C3050;\n        --out-bg: #0A201C;\n        --out-border: #1A5E52;\n        --out-label: #55DFC8;\n        --gate-bg: #181200;\n        --gate-border: #B89000;\n        --gate-text: #F0CA40;\n        --gate-chip: #B89000;\n        --gate-chip-fg: #000;\n        --break-line: #1C3050;\n        --bad: #FF6B57;\n        --good: #3DDC97;\n      }\n    }\n\n    :root[data-theme=\"dark\"] {\n      --bg: #090F18;\n      --surface: #101C2C;\n      --surface-alt: #152030;\n      --border: #1C3050;\n      --accent: #00C2A8;\n      --accent2: #4D9FE8;\n      --text-primary: #DDE8F5;\n      --text-sec: #6D9ABE;\n      --text-muted: #3D5E7A;\n      --am: #4D9FE8;\n      --pm: #00C2A8;\n      --tag-am-bg: #0B1E3A;\n      --tag-am-fg: #7DC5F8;\n      --tag-pm-bg: #0B2520;\n      --tag-pm-fg: #55DFC8;\n      --step-num: #4D9FE8;\n      --code-bg: #060D18;\n      --code-fg: #7FC8FF;\n      --code-border: #1C3050;\n      --out-bg: #0A201C;\n      --out-border: #1A5E52;\n      --out-label: #55DFC8;\n      --gate-bg: #181200;\n      --gate-border: #B89000;\n      --gate-text: #F0CA40;\n      --gate-chip: #B89000;\n      --gate-chip-fg: #000;\n      --break-line: #1C3050;\n      --bad: #FF6B57;\n      --good: #3DDC97;\n    }\n\n    *,\n    *::before,\n    *::after {\n      box-sizing: border-box;\n      margin: 0;\n      padding: 0;\n    }\n\n    body {\n      font-family: 'DM Sans', system-ui, sans-serif;\n      background: var(--bg);\n      color: var(--text-primary);\n      line-height: 1.6;\n      font-size: 15px;\n      -webkit-font-smoothing: antialiased;\n    }\n\n    a {\n      color: var(--accent2);\n    }\n\n    code,\n    .k {\n      font-family: 'DM Mono', monospace;\n      font-size: 0.87em;\n      color: var(--accent2);\n      background: var(--surface-alt);\n      border: 1px solid var(--border);\n      border-radius: 4px;\n      padding: 0.04em 0.38em;\n    }\n\n    .code code,\n    .out-tree code,\n    .out-log code {\n      background: none;\n      border: none;\n      padding: 0;\n      color: inherit;\n    }\n\n    .header {\n      background: var(--surface);\n      border-bottom: 1px solid var(--border);\n      padding: 2rem 2rem 1.6rem;\n    }\n\n    .header-inner {\n      max-width: 1100px;\n      margin: 0 auto;\n    }\n\n    .eyebrow {\n      font-family: 'DM Mono', monospace;\n      font-size: 0.68rem;\n      letter-spacing: 0.14em;\n      text-transform: uppercase;\n      color: var(--text-muted);\n      margin-bottom: 0.5rem;\n    }\n\n    .header h1 {\n      font-family: 'DM Sans', sans-serif;\n      font-size: clamp(1.5rem, 3.5vw, 2.2rem);\n      font-weight: 700;\n      color: var(--text-primary);\n      text-wrap: balance;\n      line-height: 1.15;\n      margin-bottom: 0.45rem;\n    }\n\n    .header h1 em {\n      font-style: normal;\n      color: var(--accent);\n    }\n\n    .header-sub {\n      color: var(--text-sec);\n      font-size: 0.87rem;\n      max-width: 78ch;\n      margin-bottom: 1.1rem;\n      line-height: 1.55;\n    }\n\n    .stats-row {\n      display: flex;\n      flex-wrap: wrap;\n      gap: 0.55rem;\n    }\n\n    .stat {\n      font-family: 'DM Mono', monospace;\n      font-size: 0.71rem;\n      color: var(--text-sec);\n      background: var(--surface-alt);\n      border: 1px solid var(--border);\n      border-radius: 6px;\n      padding: 0.27rem 0.62rem;\n    }\n\n    .stat strong {\n      color: var(--text-primary);\n    }\n\n    .main {\n      max-width: 1100px;\n      margin: 1.8rem auto;\n      padding: 0 1.5rem 3.5rem;\n    }\n\n    .sec-label {\n      font-family: 'DM Mono', monospace;\n      font-size: 0.66rem;\n      letter-spacing: 0.14em;\n      text-transform: uppercase;\n      color: var(--text-muted);\n      margin: 2.4rem 0 1rem;\n      display: flex;\n      align-items: center;\n      gap: 0.7rem;\n    }\n\n    .sec-label:first-child {\n      margin-top: 0;\n    }\n\n    .sec-label::after {\n      content: '';\n      flex: 1;\n      height: 1px;\n      background: var(--border);\n    }\n\n    .session {\n      background: var(--surface);\n      border: 1px solid var(--border);\n      border-radius: 12px;\n      margin-bottom: 1.5rem;\n      overflow: hidden;\n      position: relative;\n    }\n\n    .session::before {\n      content: '';\n      position: absolute;\n      left: 0;\n      top: 0;\n      bottom: 0;\n      width: 4px;\n      border-radius: 12px 0 0 12px;\n    }\n\n    .session.am::before {\n      background: var(--am);\n    }\n\n    .session.pm::before {\n      background: var(--pm);\n    }\n\n    .s-head {\n      padding: 1.15rem 1.5rem 1rem 1.7rem;\n      border-bottom: 1px solid var(--border);\n      display: flex;\n      align-items: flex-start;\n      gap: 1rem;\n    }\n\n    .time-col {\n      min-width: 68px;\n      padding-top: 0.1rem;\n    }\n\n    .t-start {\n      font-family: 'DM Mono', monospace;\n      font-size: 0.98rem;\n      font-weight: 500;\n      color: var(--text-primary);\n      display: block;\n      line-height: 1;\n    }\n\n    .t-end {\n      font-family: 'DM Mono', monospace;\n      font-size: 0.7rem;\n      color: var(--text-muted);\n      display: block;\n      margin-top: 0.15rem;\n    }\n\n    .s-meta {\n      flex: 1;\n      min-width: 0;\n    }\n\n    .s-tag {\n      display: inline-block;\n      font-family: 'DM Mono', monospace;\n      font-size: 0.61rem;\n      letter-spacing: 0.08em;\n      text-transform: uppercase;\n      border-radius: 4px;\n      padding: 0.13rem 0.46rem;\n      margin-bottom: 0.28rem;\n    }\n\n    .am .s-tag {\n      background: var(--tag-am-bg);\n      color: var(--tag-am-fg);\n    }\n\n    .pm .s-tag {\n      background: var(--tag-pm-bg);\n      color: var(--tag-pm-fg);\n    }\n\n    .s-title {\n      font-family: 'DM Sans', sans-serif;\n      font-size: 1.08rem;\n      font-weight: 700;\n      color: var(--text-primary);\n      text-wrap: balance;\n      line-height: 1.2;\n      margin-bottom: 0.22rem;\n    }\n\n    .s-obj {\n      font-size: 0.81rem;\n      color: var(--text-sec);\n      font-style: italic;\n    }\n\n    .dur {\n      font-family: 'DM Mono', monospace;\n      font-size: 0.7rem;\n      color: var(--text-muted);\n      padding-top: 0.1rem;\n    }\n\n    .panels {\n      display: grid;\n      grid-template-columns: 280px 1fr;\n      gap: 0;\n    }\n\n    @media (max-width: 760px) {\n      .panels {\n        grid-template-columns: 1fr;\n      }\n    }\n\n    .panel {\n      padding: 1.25rem 1.3rem;\n      border-right: 1px solid var(--border);\n    }\n\n    .panel:last-child {\n      border-right: none;\n    }\n\n    @media (max-width: 760px) {\n      .panel {\n        border-right: none;\n        border-bottom: 1px solid var(--border);\n      }\n\n      .panel:last-child {\n        border-bottom: none;\n      }\n    }\n\n    .out-panel {\n      grid-column: 1 / -1 !important;\n      border-top: 1px solid var(--out-border);\n      border-right: none !important;\n      border-left: 1px solid var(--out-border) !important;\n      background: var(--out-bg);\n    }\n\n    .panel-label {\n      font-family: 'DM Mono', monospace;\n      font-size: 0.62rem;\n      letter-spacing: 0.12em;\n      text-transform: uppercase;\n      color: var(--text-muted);\n      margin-bottom: 0.8rem;\n      display: flex;\n      align-items: center;\n      gap: 0.4rem;\n    }\n\n    .panel-label .dot {\n      width: 6px;\n      height: 6px;\n      border-radius: 50%;\n      flex-shrink: 0;\n    }\n\n    .mat-dot {\n      background: var(--accent2);\n    }\n\n    .step-dot {\n      background: var(--text-muted);\n    }\n\n    .out-dot {\n      background: var(--accent);\n    }\n\n    .mat-list {\n      list-style: none;\n      display: flex;\n      flex-direction: column;\n      gap: 0.3rem;\n    }\n\n    .mat-list li {\n      font-size: 0.79rem;\n      color: var(--text-sec);\n      line-height: 1.4;\n      position: relative;\n      padding-left: 1.05rem;\n      overflow-wrap: break-word;\n    }\n\n    .mat-list li::before {\n      content: '☐';\n      color: var(--text-muted);\n      font-size: 0.72rem;\n      position: absolute;\n      left: 0;\n      top: 0.1rem;\n    }\n\n    .mat-note {\n      font-size: 0.72rem;\n      color: var(--text-muted);\n      font-style: italic;\n      margin-top: 0.65rem;\n      line-height: 1.4;\n    }\n\n    .steps {\n      display: flex;\n      flex-direction: column;\n      gap: 1rem;\n    }\n\n    .step {\n      display: flex;\n      gap: 0.75rem;\n      align-items: flex-start;\n    }\n\n    .step-num {\n      font-family: 'DM Mono', monospace;\n      font-size: 0.75rem;\n      font-weight: 500;\n      color: var(--step-num);\n      background: var(--surface-alt);\n      border: 1px solid var(--border);\n      border-radius: 5px;\n      padding: 0.12rem 0.42rem;\n      min-width: 32px;\n      text-align: center;\n      flex-shrink: 0;\n      margin-top: 0.1rem;\n    }\n\n    .step-body {\n      flex: 1;\n      min-width: 0;\n    }\n\n    .step-title {\n      font-size: 0.84rem;\n      font-weight: 600;\n      color: var(--text-primary);\n      margin-bottom: 0.18rem;\n      line-height: 1.35;\n    }\n\n    .step-desc {\n      font-size: 0.78rem;\n      color: var(--text-sec);\n      line-height: 1.45;\n    }\n\n    .code {\n      background: var(--code-bg);\n      border: 1px solid var(--code-border);\n      border-radius: 6px;\n      padding: 0.55rem 0.7rem;\n      margin-top: 0.35rem;\n      overflow-x: auto;\n    }\n\n    .code pre {\n      font-family: 'DM Mono', monospace;\n      font-size: 0.72rem;\n      color: var(--code-fg);\n      line-height: 1.55;\n      white-space: pre-wrap;\n    }\n\n    .out-list {\n      list-style: none;\n      display: flex;\n      flex-direction: column;\n      gap: 0.42rem;\n      padding: 0;\n      margin: 0;\n    }\n\n    .out-list li {\n      font-size: 0.8rem;\n      color: var(--text-sec);\n      line-height: 1.45;\n      position: relative;\n      padding-left: 1.1rem;\n      overflow-wrap: break-word;\n    }\n\n    .out-list li::before {\n      content: '✓';\n      color: var(--accent);\n      font-size: 0.72rem;\n      position: absolute;\n      left: 0;\n      top: 0.12rem;\n      font-weight: 700;\n    }\n\n    .break-row {\n      display: flex;\n      align-items: center;\n      gap: 0.7rem;\n      padding: 0.4rem 0;\n      margin-bottom: 1.25rem;\n      color: var(--text-muted);\n      font-family: 'DM Mono', monospace;\n      font-size: 0.67rem;\n      letter-spacing: 0.06em;\n    }\n\n    .break-row::before,\n    .break-row::after {\n      content: '';\n      flex: 1;\n      height: 1px;\n      background: var(--break-line);\n    }\n\n    .gate {\n      background: var(--gate-bg);\n      border: 1px solid var(--gate-border);\n      border-radius: 12px;\n      overflow: hidden;\n      margin-top: 1.8rem;\n    }\n\n    .gate-head {\n      padding: 1rem 1.5rem;\n      border-bottom: 1px solid var(--gate-border);\n      display: flex;\n      align-items: center;\n      gap: 0.85rem;\n      flex-wrap: wrap;\n    }\n\n    .gate-chip {\n      font-family: 'DM Sans', sans-serif;\n      font-size: 0.67rem;\n      font-weight: 700;\n      letter-spacing: 0.06em;\n      text-transform: uppercase;\n      background: var(--gate-chip);\n      color: var(--gate-chip-fg);\n      padding: 0.2rem 0.58rem;\n      border-radius: 5px;\n    }\n\n    .gate-title {\n      font-family: 'DM Sans', sans-serif;\n      font-size: 0.92rem;\n      font-weight: 700;\n      color: var(--gate-text);\n      text-wrap: balance;\n    }\n\n    .gate-body {\n      padding: 1.2rem 1.5rem;\n    }\n\n    .gate-desc {\n      font-size: 0.83rem;\n      color: var(--text-sec);\n      margin-bottom: 1rem;\n      max-width: 75ch;\n    }\n\n    .gate-thr {\n      font-family: 'DM Mono', monospace;\n      font-size: 0.72rem;\n      color: var(--text-muted);\n      display: flex;\n      flex-wrap: wrap;\n      align-items: center;\n      gap: 0.5rem;\n    }\n\n    .gate-thr strong {\n      color: var(--gate-text);\n    }\n\n    @media (max-width: 760px) {\n      .s-head {\n        flex-wrap: wrap;\n      }\n    }\n\n    .link-row {\n      display: flex;\n      flex-wrap: wrap;\n      gap: 0.55rem;\n      margin-top: 0.5rem;\n    }\n\n    .link-chip {\n      font-family: 'DM Mono', monospace;\n      font-size: 0.72rem;\n      background: var(--surface-alt);\n      border: 1px solid var(--border);\n      border-radius: 999px;\n      padding: 0.25rem 0.65rem;\n      text-decoration: none;\n      color: var(--text-sec);\n    }\n\n    .link-chip:hover {\n      border-color: var(--accent2);\n      color: var(--text-primary);\n    }\n  </style>\n</head>\n\n<body>\n  <header class=\"header\">\n    <div class=\"header-inner\">\n      <p class=\"eyebrow\">NTT DATA · Train-the-Trainers IA · Día 3</p>\n      <h1>Guía de <em>Laboratorio</em> — SDD + Fundamentos de Agentes (ReqFlow)</h1>\n      <p class=\"header-sub\">\n        Día 3: OpenSpec (SDD) + fundamentos de agentes (routing, evaluator, HITL) sobre un producto real compuesto por 3 repositorios.\n        Este día trabaja sobre el mismo <code>reqflow-workspace/</code> de los días previos.\n      </p>\n      <div class=\"stats-row\">\n        <span class=\"stat\"><strong>4 sesiones</strong> · S1–S4</span>\n        <span class=\"stat\">ReqFlow · 3 repos</span>\n        <span class=\"stat\">OpenSpec · GitHub MCP</span>\n        <span class=\"stat\">Gate: handoff Día 4</span>\n      </div>\n      <div class=\"link-row\" style=\"margin-top:0.9rem\">\n        <a class=\"link-chip\" href=\"README.md\">README</a>\n        <a class=\"link-chip\" href=\"STEP-BY-STEP.md\">STEP-BY-STEP</a>\n        <a class=\"link-chip\" href=\"laboratory-flows.html\">Flujos</a>\n        <a class=\"link-chip\" href=\"challenge/markdown-viewer.html\">Challenge</a>\n      </div>\n    </div>\n  </header>\n\n  <main class=\"main\">\n    <p class=\"sec-label\">Antes de empezar</p>\n\n    <div class=\"session am\" style=\"margin-bottom:1.8rem\">\n      <div class=\"panels\" style=\"grid-template-columns: 1fr 1fr;\">\n        <div class=\"panel\">\n          <div class=\"panel-label\"><span class=\"dot mat-dot\"></span>Entrada del día (handoff Día 2)</div>\n          <ul class=\"mat-list\">\n            <li>Trabaja desde <code>reqflow-workspace/</code> (workspace de producto).</li>\n            <li>Debe existir <code>.vscode/mcp.json</code> con <code>github-official</code> y toolset <code>projects</code>.</li>\n            <li>Debe existir el Project ReqFlow del Día 2 con issues en repos correctos.</li>\n          </ul>\n          <div class=\"code\"><pre>python tools/check_handoff.py --day 2 ../reqflow-workspace</pre></div>\n          <p class=\"mat-note\">Si falla, parte de <code>checkpoint/day2</code> (instructor).</p>\n        </div>\n        <div class=\"panel\">\n          <div class=\"panel-label\"><span class=\"dot step-dot\"></span>Recursos del día</div>\n          <ul class=\"mat-list\">\n            <li><code>s03-reqflow-setup/CASE.md</code>: contratos, restricciones y DoD vigentes de tu producto.</li>\n            <li><code>laboratory-flows.html</code>: diagrama animado del flujo.</li>\n            <li><code>s01</code>–<code>s04</code>: módulos prácticos (material/anexos).</li>\n          </ul>\n          <p class=\"mat-note\">Los pasos operativos están en esta guía. Los módulos siguen existiendo como materiales/anexos.</p>\n        </div>\n      </div>\n    </div>\n\n    <p class=\"sec-label\">Laboratorio</p>\n\n    <div class=\"session am\">\n      <div class=\"s-head\">\n        <div class=\"time-col\"><span class=\"t-start\">S1</span><span class=\"t-end\">OpenSpec</span></div>\n        <div class=\"s-meta\">\n          <span class=\"s-tag\">Sesión S1</span>\n          <h2 class=\"s-title\">OpenSpec / Spec Kit + Constitution (conceptos) → contrato inicial</h2>\n          <p class=\"s-obj\">Instalar/preparar OpenSpec en <code>workshop-auth-backend</code> y producir los primeros artefactos del cambio.</p>\n        </div>\n        <span class=\"dur\">~1h</span>\n      </div>\n      <div class=\"panels\">\n        <div class=\"panel\">\n          <div class=\"panel-label\"><span class=\"dot mat-dot\"></span>Materiales</div>\n          <ul class=\"mat-list\">\n            <li>Repo foco del día: <code>workshop-auth-backend</code>.</li>\n            <li>OpenSpec CLI + proveedor GitHub Copilot.</li>\n            <li>Skill <code>reqflow-definition-of-done</code> disponible en <code>.github/skills/</code>.</li>\n            <li>OpenSpec es la implementación SDD del laboratorio; Spec Kit/Constitution quedan como comparación conceptual de S1 (no se ejecuta un segundo flujo paralelo).</li>\n            <li>Decisión del laboratorio: schema estándar <code>proposal → specs → design → tasks → apply</code> + GitHub en paralelo (Issue = trabajo/trazabilidad, Project = prioridad, branch = rama del Issue, PR = revisión, checks = evidencia).</li>\n          </ul>\n          <p class=\"mat-note\">Mantén VS Code abierto en <code>reqflow-workspace/</code>, pero limita prompts operativos al backend.</p>\n        </div>\n        <div class=\"panel\">\n          <div class=\"panel-label\"><span class=\"dot step-dot\"></span>Pasos</div>\n          <div class=\"steps\">\n            <div class=\"step\">\n              <span class=\"step-num\">01</span>\n              <div class=\"step-body\">\n                <div class=\"step-title\">Preparar OpenSpec en <code>workshop-auth-backend</code></div>\n                <div class=\"step-desc\">Instala la CLI, inicializa seleccionando GitHub Copilot, conserva el schema estándar <code>spec-driven</code> y configura el contexto/reglas del laboratorio.</div>\n              </div>\n            </div>\n            <div class=\"step\">\n              <span class=\"step-num\">02</span>\n              <div class=\"step-body\">\n                <div class=\"step-title\">Elegir un Issue real del Project ReqFlow (estado Todo)</div>\n                <div class=\"step-desc\">Selecciona el issue que guiará el cambio en <code>workshop-auth-backend</code>. Verifica que exista y esté priorizado en el Project.</div>\n              </div>\n            </div>\n            <div class=\"step\">\n              <span class=\"step-num\">03</span>\n              <div class=\"step-body\">\n                <div class=\"step-title\">Crear <code>proposal</code> + <code>specs/</code> desde el Issue</div>\n                <div class=\"step-desc\">Genera el contrato de cambio (qué se cambia, criterios, no-funcionales) antes de implementar. Pasa por GATE HUMANO antes de continuar a S2.</div>\n              </div>\n            </div>\n          </div>\n        </div>\n        <div class=\"panel out-panel\">\n          <div class=\"panel-label\"><span class=\"dot out-dot\"></span>Output esperado</div>\n          <ul class=\"out-list\">\n            <li><code>openspec/changes/&lt;CHANGE_NAME&gt;/proposal.md</code> creado y aprobado.</li>\n            <li><code>openspec/specs/</code> con al menos 1 archivo.</li>\n            <li>Issue, branch del Issue y Project alineados como trazabilidad en paralelo.</li>\n          </ul>\n        </div>\n      </div>\n    </div>\n\n    <div class=\"break-row\">Break / transición</div>\n\n    <div class=\"session pm\">\n      <div class=\"s-head\">\n        <div class=\"time-col\"><span class=\"t-start\">S2</span><span class=\"t-end\">Spec→Plan→Tasks</span></div>\n        <div class=\"s-meta\">\n          <span class=\"s-tag\">Sesión S2</span>\n          <h2 class=\"s-title\">Specify → Plan → Tasks → Validate (diseño, plan y gates)</h2>\n          <p class=\"s-obj\">Convertir la especificación en diseño y tareas; validar antes de implementar.</p>\n        </div>\n        <span class=\"dur\">~1h</span>\n      </div>\n      <div class=\"panels\">\n        <div class=\"panel\">\n          <div class=\"panel-label\"><span class=\"dot mat-dot\"></span>Materiales</div>\n          <ul class=\"mat-list\">\n            <li>Artefactos OpenSpec generados en S1.</li>\n            <li>Baseline (Day1): <code>docs/ENDPOINTS.md</code> y <code>docs/TESTING.md</code> del producto.</li>\n            <li><code>tasks.md</code> puede solaparse parcialmente con el GitHub Issue; durante el taller esa duplicación es intencional.</li>\n          </ul>\n        </div>\n        <div class=\"panel\">\n          <div class=\"panel-label\"><span class=\"dot step-dot\"></span>Pasos</div>\n          <div class=\"steps\">\n            <div class=\"step\">\n              <span class=\"step-num\">01</span>\n              <div class=\"step-body\">\n                <div class=\"step-title\">Crear <code>design.md</code> (Plan)</div>\n                <div class=\"step-desc\">Decisiones técnicas, impacto, estrategia incremental y riesgos.</div>\n              </div>\n            </div>\n            <div class=\"step\">\n              <span class=\"step-num\">02</span>\n              <div class=\"step-body\">\n                <div class=\"step-title\">Crear <code>tasks.md</code> (Tasks)</div>\n                <div class=\"step-desc\">Checklist de implementación vinculada al Issue. Mantén GitHub como tracking de trabajo comprometido. GATE HUMANO antes de validar.</div>\n              </div>\n            </div>\n            <div class=\"step\">\n              <span class=\"step-num\">03</span>\n              <div class=\"step-body\">\n                <div class=\"step-title\">Validar (Validate) antes de tocar código</div>\n                <div class=\"step-desc\">Ejecuta <code>openspec validate</code> y revisiones humanas de los artefactos (Specify/Plan/Tasks). Recién después sigue el baseline de characterization tests en S4.</div>\n              </div>\n            </div>\n          </div>\n        </div>\n        <div class=\"panel out-panel\">\n          <div class=\"panel-label\"><span class=\"dot out-dot\"></span>Output esperado</div>\n          <ul class=\"out-list\">\n            <li>Artefactos de OpenSpec listos para aplicar (Specify/Plan/Tasks validados).</li>\n            <li>Gates humanos realizados antes de implementación.</li>\n            <li><code>openspec validate</code> ejecutado sin errores sobre proposal/specs/design/tasks.</li>\n          </ul>\n        </div>\n      </div>\n    </div>\n\n    <div class=\"break-row\">Break / transición</div>\n\n    <div class=\"session am\">\n      <div class=\"s-head\">\n        <div class=\"time-col\"><span class=\"t-start\">S3</span><span class=\"t-end\">Agentes</span></div>\n        <div class=\"s-meta\">\n          <span class=\"s-tag\">Sesión S3</span>\n          <h2 class=\"s-title\">Fundamentos de agente: model + tools + context + loop</h2>\n          <p class=\"s-obj\">Consolidar el workspace multi-repo, skills y GitHub MCP oficial como “tools” del agente.</p>\n        </div>\n        <span class=\"dur\">~1h</span>\n      </div>\n      <div class=\"panels\">\n        <div class=\"panel\">\n          <div class=\"panel-label\"><span class=\"dot mat-dot\"></span>Materiales</div>\n          <ul class=\"mat-list\">\n            <li>Módulo de setup: <a href=\"s03-reqflow-setup/markdown-viewer.html?file=README.md\">s03-reqflow-setup</a> — 3 repos (<code>workshop-login-frontend</code>, <code>workshop-auth-backend</code>, <code>workshop-requirements-api</code>) + 1 workspace de producto + GitHub MCP oficial + Project ReqFlow.</li>\n            <li>Módulo de skills: <a href=\"s02-agent-skills/markdown-viewer.html?file=README.md\">s02-agent-skills</a> — <code>discovery-analysis</code>, <code>spec-writing</code>, <code>architecture-decision</code>, <code>issue-implementation</code>, <code>reqflow-definition-of-done</code>.</li>\n            <li>Módulo de agentes: <a href=\"s01-custom-agents/markdown-viewer.html?file=README.md\">s01-custom-agents</a> — roles <code>PM/PO</code>, <code>Discovery</code>, <code>Architect</code>, <code>Developer</code> con límites explícitos.</li>\n            <li>Modelo mental: <code>Agent</code> = quién soy + límites; <code>Skill</code> = cómo ejecuto una práctica; <code>Caso</code> = qué problema resuelvo; <code>OpenSpec</code> = qué cambio está definido; <code>MCP</code> = qué sistema externo puedo operar.</li>\n          </ul>\n          <p class=\"mat-note\">Estos módulos son anexos/materiales. La ejecución paso a paso está en esta guía.</p>\n        </div>\n        <div class=\"panel\">\n          <div class=\"panel-label\"><span class=\"dot step-dot\"></span>Pasos</div>\n          <div class=\"steps\">\n            <div class=\"step\">\n              <span class=\"step-num\">01</span>\n              <div class=\"step-body\">\n                <div class=\"step-title\">Copiar los Custom Agents al workspace</div>\n                <div class=\"step-desc\">Copia los templates desde <code>bcp-ai-lab-day-03/templates/agents/</code> hacia <code>reqflow-workspace/.github/agents/</code> (en S4 paso 0 también a <code>workshop-auth-backend</code>).</div>\n              </div>\n            </div>\n            <div class=\"step\">\n              <span class=\"step-num\">02</span>\n              <div class=\"step-body\">\n                <div class=\"step-title\">Probar los límites de un agente aislado</div>\n                <div class=\"step-desc\">Selecciona un solo Custom Agent (<code>Discovery</code>, <code>PM/PO</code>, <code>Architect</code> o <code>Developer</code>) sin usar tools y verifica que explique su responsabilidad y a qué rol debe pasar lo que no le corresponde.</div>\n              </div>\n            </div>\n            <div class=\"step\">\n              <span class=\"step-num\">03</span>\n              <div class=\"step-body\">\n                <div class=\"step-title\">Verificar MCP oficial + Projects habilitado</div>\n                <div class=\"step-desc\">Confirma que <code>github-official</code> expone tools de Projects y que puedes leer Projects vía MCP.</div>\n              </div>\n            </div>\n            <div class=\"step\">\n              <span class=\"step-num\">04</span>\n              <div class=\"step-body\">\n                <div class=\"step-title\">Completar backlog (sin inventar trabajo)</div>\n                <div class=\"step-desc\">Discovery revalida <code>HALLAZGOS.md</code> y convierte hallazgos revisados en issues reales y verificables en el repo correcto.</div>\n              </div>\n            </div>\n            <div class=\"step\">\n              <span class=\"step-num\">05</span>\n              <div class=\"step-body\">\n                <div class=\"step-title\">De single-agent a routing</div>\n                <div class=\"step-desc\">Mapea cada rol a un tipo de trabajo: producto/alcance → PM/PO, hallazgo → Discovery, diseño → Architect, implementación → Developer. Prepara el routing explícito de S4.</div>\n              </div>\n            </div>\n          </div>\n        </div>\n        <div class=\"panel out-panel\">\n          <div class=\"panel-label\"><span class=\"dot out-dot\"></span>Output esperado</div>\n          <ul class=\"out-list\">\n            <li><code>reqflow-workspace/.github/agents/</code> con <code>pm-po.agent.md</code>, <code>discovery.agent.md</code>, <code>architect.agent.md</code> y <code>developer.agent.md</code>.</li>\n            <li>Project ReqFlow usable vía MCP (lectura demostrable).</li>\n            <li>Backlog consistente (issues reales en repos correctos).</li>\n            <li>Participante puede explicar que <code>Agent != prompt largo</code> y justificar por qué una tarea se enruta a un rol y no a otro.</li>\n          </ul>\n        </div>\n      </div>\n    </div>\n\n    <div class=\"break-row\">Break / transición</div>\n\n    <div class=\"session pm\">\n      <div class=\"s-head\">\n        <div class=\"time-col\"><span class=\"t-start\">S4</span><span class=\"t-end\">Apply + PR</span></div>\n        <div class=\"s-meta\">\n          <span class=\"s-tag\">Sesión S4</span>\n          <h2 class=\"s-title\">Patrones: routing, evaluator, HITL → PR final</h2>\n          <p class=\"s-obj\">Implementar con OpenSpec apply, proteger comportamiento con characterization tests y cerrar con PR auditable.</p>\n        </div>\n        <span class=\"dur\">~2h</span>\n      </div>\n      <div class=\"panels\">\n        <div class=\"panel\">\n          <div class=\"panel-label\"><span class=\"dot mat-dot\"></span>Materiales</div>\n          <ul class=\"mat-list\">\n            <li>Módulo SDD: <a href=\"s04-openspec-sdd/markdown-viewer.html?file=README.md\">s04-openspec-sdd</a></li>\n            <li>Ruta alternativa (solo referencia): <a href=\"s04-openspec-sdd/markdown-viewer.html?file=GITHUB_COPILOT_AGENTS.md\">GitHub Copilot Agents</a></li>\n            <li>Routing: <code>PM/PO</code> → necesidad/alcance/proposal-specs; <code>Architect</code> → design/tasks; <code>Developer</code> → characterization, apply e implementación.</li>\n            <li>Evaluator: <code>openspec validate</code>, tests, diff, Definition of Done, GitHub checks.</li>\n            <li>HITL: el participante revisa y decide antes de aceptar cada artefacto y antes de integrar el cambio.</li>\n            <li>Personalización opcional de fin de día: <code>templates/openspec/schemas/reqflow-github/</code> (elimina <code>tasks.md</code>, deja el tracking en GitHub Issues; cambia el proceso, no la funcionalidad de ReqFlow).</li>\n          </ul>\n        </div>\n        <div class=\"panel\">\n          <div class=\"panel-label\"><span class=\"dot step-dot\"></span>Pasos</div>\n          <div class=\"steps\">\n            <div class=\"step\">\n              <span class=\"step-num\">01</span>\n              <div class=\"step-body\">\n                <div class=\"step-title\">Confirmar el routing del Issue</div>\n                <div class=\"step-desc\">Verifica que proposal/specs/design/tasks ya pasaron por PM/PO y Architect antes de que Developer implemente.</div>\n              </div>\n            </div>\n            <div class=\"step\">\n              <span class=\"step-num\">02</span>\n              <div class=\"step-body\">\n                <div class=\"step-title\">Proteger baseline (characterization)</div>\n                <div class=\"step-desc\">Asegura que el comportamiento actual quede cubierto antes de implementar.</div>\n              </div>\n            </div>\n            <div class=\"step\">\n              <span class=\"step-num\">03</span>\n              <div class=\"step-body\">\n                <div class=\"step-title\">Aplicar e implementar incrementalmente</div>\n                <div class=\"step-desc\">Usa <code>OpenSpec apply</code>, implementa, ejecuta tests y evidencia.</div>\n              </div>\n            </div>\n            <div class=\"step\">\n              <span class=\"step-num\">04</span>\n              <div class=\"step-body\">\n                <div class=\"step-title\">Evaluator + DoD + PR</div>\n                <div class=\"step-desc\">Ejecuta Definition of Done, abre PR con <code>Closes #N</code> y revisa checks. GATE HUMANO de cierre antes de integrar a <code>main</code>.</div>\n              </div>\n            </div>\n          </div>\n        </div>\n        <div class=\"panel out-panel\">\n          <div class=\"panel-label\"><span class=\"dot out-dot\"></span>Output esperado</div>\n          <ul class=\"out-list\">\n            <li>PR final en <code>workshop-auth-backend</code> con evidencia y DoD.</li>\n            <li><code>.github/agents/</code> y <code>.github/skills/</code> versionados en <code>main</code>.</li>\n            <li>Routing, evaluator y HITL identificables en el PR final (quién decidió qué y con qué evidencia).</li>\n          </ul>\n        </div>\n      </div>\n    </div>\n\n    <div class=\"gate\">\n      <div class=\"gate-head\">\n        <span class=\"gate-chip\">HANDOFF · cierre del día</span>\n        <span class=\"gate-title\">Checklist para iniciar el Día 4</span>\n      </div>\n      <div class=\"gate-body\">\n        <p class=\"gate-desc\">Desde la carpeta del laboratorio, ejecuta el chequeo. Si falla, no continúes al Día 4.</p>\n        <div class=\"code\"><pre>python tools/check_handoff.py --day 3 ../reqflow-workspace</pre></div>\n        <p class=\"gate-thr\">Criterio: al menos 1 repo en <strong>[OK]</strong> + artefactos OpenSpec + agentes/skills + tag.</p>\n      </div>\n    </div>\n  </main>\n</body>\n\n</html>\n",
    "bcp-ai-lab-day-03/templates/mcp/mcp.json.example": "{\n  \"servers\": {\n    \"github-official\": {\n      \"type\": \"http\",\n      \"url\": \"https://api.githubcopilot.com/mcp/\",\n      \"headers\": {\n        \"X-MCP-Toolsets\": \"context,repos,issues,pull_requests,projects,users\"\n      }\n    }\n  }\n}\n",
    "bcp-ai-lab-day-03/templates/openspec/config.yaml.example": "schema: spec-driven\n\ncontext: |\n  Proyecto brownfield ReqFlow.\n  El cambio parte de un GitHub Issue confirmado y priorizado.\n  Preservar contratos HTTP fuera del alcance aprobado.\n  No resolver deuda adicional fuera del Issue.\n  tasks.md debe alinearse con Issue, proposal, specs y design.\n  Proteger primero el comportamiento relevante con pruebas de caracterización.\n  Escribir los artefactos en español.\n\nrules:\n  proposal:\n    - Referenciar el GitHub Issue.\n    - Separar alcance y fuera de alcance.\n  specs:\n    - Usar requisitos verificables y escenarios observables.\n  design:\n    - Identificar contratos, riesgos, estrategia incremental y rollback cuando aplique.\n  tasks:\n    - Mantener las tareas dentro del alcance aprobado.\n    - Incluir antes las tareas de caracterización necesarias.\n    - Usar tareas pequeñas y verificables.\n\noperations:\n  apply:\n    guidance:\n      - Seguir las tareas pendientes de tasks.md.\n      - Marcar como completado solo trabajo ejecutado y validado.\n      - Implementar únicamente el alcance aprobado.\n      - Ejecutar pruebas relevantes y registrar resultados.\n",
    "bcp-ai-lab-day-03/s03-reqflow-setup/CASE.md": "# ReqFlow: contexto vigente del producto (s03)\n\n> Contexto de trabajo de s03: no es un caso nuevo. Es **tu producto** de los Días 1 y 2 con sus contratos y restricciones vigentes. Úsalo como referencia al verificar el workspace, re-verificar hallazgos y completar el backlog.\n\n## De dónde viene\n\n| Artefacto | Origen | Rol hoy |\n| --- | --- | --- |\n| `HALLAZGOS.md` (Id `H-xx`) | Día 1 | Discovery los re-verifica; solo lo revisado entra al backlog |\n| `HU-01.md`, `HU-05.md` (sección Origen) | Día 2 | Reutiliza los issues existentes de backend y frontend; el recorrido guiado trabaja sobre backend |\n| Project `ReqFlow` + issues | Día 2 | Se reutiliza, no se recrea |\n| `docs/ENDPOINTS.md` | Día 1 | Baseline de comportamiento para las specs de s04 |\n| `docs/TESTING.md` | Día 1 | Pruebas de caracterización que ya existen |\n\n## Producto multi-repositorio\n\nReqFlow es el portal interno de requerimientos tecnológicos de la empresa ficticia Nuvexa Andina Digital S.A., formado por tres repositorios coordinados (tus copias propias bajo tu owner, publicadas el Día 1):\n\n| Repositorio | Tecnología | Responsabilidad |\n| --- | --- | --- |\n| `workshop-login-frontend` | Angular / TypeScript | Login, sesión, dashboard y experiencia de usuario |\n| `workshop-auth-backend` | Java / Quarkus | Credenciales, autenticación y emisión de token |\n| `workshop-requirements-api` | Python / FastAPI | Tareas, resumen, autorización y carga de requerimientos |\n\n## Contratos funcionales protegidos\n\nDurante el workshop no deben romperse estos contratos sin una decisión explícita:\n\n```text\nPOST /auth/login\nGET/POST /api/tasks\nGET /api/summary\nPOST /api/requirements\n```\n\n## Criterios funcionales mínimos\n\n- un usuario válido puede iniciar sesión;\n- el dashboard consume únicamente información permitida para la identidad autenticada;\n- la API permite listar y crear tareas preservando identidad y autorización;\n- el dashboard obtiene un resumen de estados coherente;\n- el usuario puede adjuntar un archivo permitido dentro de límites controlados;\n- todo cambio llega mediante `feature/* -> PR -> main/CERT -> tag/release` simulado.\n\n## Guardrails\n\nNo se permite:\n\n- reescribir la solución completa;\n- utilizar datos, credenciales, secretos o archivos reales;\n- realizar pruebas ofensivas fuera del laboratorio;\n- desactivar tests, CodeQL, SCA o quality gates para forzar un merge;\n- aceptar una solución generada por IA sin comprenderla y validarla.\n\n## Discovery en el Día 3: re-verificación, no descubrimiento\n\nLos hallazgos ya se descubrieron el Día 1. Aquí el agente Discovery los **re-verifica** contra el código actual antes de convertirlos en backlog. Un hallazgo entra al Project solo si pasa estas preguntas:\n\n```text\n¿Qué observaste?\n¿Dónde está la evidencia?\n¿Por qué importa?\n¿Qué contrato podría afectar?\n¿Cómo lo probarías?\n```\n\nUn buen resultado no es una lista genérica producida por el modelo: cada issue creado cita su `H-xx` y su evidencia `archivo:línea`.\n\n## Definition of Done\n\nLa DoD operativa del día vive en el skill `reqflow-definition-of-done` y en el [cierre del día](../README.md#cierre-del-día-handoff-al-día-4) (specs aprobadas, agentes y skills versionados, PR con DoD, issue en `Todo`). La misión completa del caso (contratos preservados, CI en verde, cobertura crítica >= 85 %, dependencias controladas, secure coding, PR auditable con decisiones, trade-offs, riesgos residuales y rollback) se demuestra entre los Días 3 y 4: hoy se prepara el producto y se demuestra el ciclo SDD sobre `workshop-auth-backend`; el resto queda como challenge y harness del Día 4.\n",
    "bcp-ai-lab-day-03/s03-reqflow-setup/STEP_1_WORKSPACE.md": "# Paso 1 - Verificar el workspace multi-repo\n\n## Objetivo\n\nConfirmar que el `reqflow-workspace/` creado el Día 1 sigue siendo el contexto de producto: tres repositorios propios, publicados bajo tu owner, con el trabajo de los Días 1 y 2. Hoy **no se clonan ni se crean repositorios**.\n\n## 1.1 Comprobar los tres repositorios propios\n\nDesde `reqflow-workspace/`:\n\n```powershell\nforeach ($r in \"workshop-login-frontend\", \"workshop-auth-backend\", \"workshop-requirements-api\") {\n   git -C $r remote get-url origin\n   git -C $r status --short --branch\n}\n\nCada `origin` debe apuntar a `https://github.com/<OWNER>/<repo>.git`, no a `NTTData-Academy/*-template`. El estado debe estar limpio; si hay cambios sin commit del Día 2, versionalos antes de seguir.\n\nEl resultado esperado es:\n\n```text\n<carpeta-del-curso>/\n├─ bcp-ai-lab-day-01/ … 03/  # labs: fuera del workspace\n└─ reqflow-workspace/        # solo el producto (VS Code se abre aquí)\n  ├─ .vscode/mcp.json       # del Día 2\n  ├─ workshop-login-frontend/\n  ├─ workshop-auth-backend/\n  └─ workshop-requirements-api/\n```\n\n## 1.2 Si no tienes el workspace\n\nSi no hiciste los Días 1 y 2, crea los tres repos propios con el paso 1 del [README del Día 1](https://github.com/NTTData-Academy/bcp-ai-lab-day-01#cómo-empezar) (clonar la plantilla, desvincularla y publicarla bajo tu owner) y parte de la rama `checkpoint/day2` que entrega el instructor. Las plantillas del trainer no se modifican y el forking está deshabilitado.\n\n## 1.3 Revisar lo que ya produjeron los días anteriores\n\nAntes de usar IA, ubica en cada repo:\n\n```text\nHALLAZGOS.md          Día 1: hallazgos con Id H-xx y estado\ndocs/ENDPOINTS.md     Día 1: contrato documentado\ndocs/TESTING.md       Día 1: pruebas existentes\nHU-*.md               Día 2: historias generadas desde HALLAZGOS.md\n.github/skills/       Día 2: Skills del catálogo\n```\n\nEse material es la entrada de Discovery en el paso 4: se re-verifica, no se rehace.\n\n## 1.4 Abrir el contexto en VS Code\n\nPuedes abrir la carpeta padre `reqflow-workspace/` o crear un multi-root workspace de VS Code.\n\nEl objetivo es poder navegar entre los tres componentes mientras conservas claro qué archivo pertenece a cada repositorio Git.\n\n## 1.5 Identificar responsabilidades antes de usar IA\n\nComprueba manualmente:\n\n```text\nFrontend Angular\n  -> login, sesión, dashboard, consumo de servicios\n\nBackend Quarkus\n  -> credenciales, autenticación, token\n\nAPI FastAPI\n  -> tareas, resumen, autorización, requerimientos\n```\n\n## 1.6 Identificar contratos protegidos\n\nRegistra como restricciones del ejercicio (contrastalas con `docs/ENDPOINTS.md` de cada repo):\n\n```text\nPOST /auth/login\nGET/POST /api/tasks\nGET /api/summary\nPOST /api/requirements\n```\n\nNo asumas todavía dónde existe deuda ni cuál debe corregirse.\n\n## 1.7 Baseline\n\nAntes de ejecutar agentes:\n\n- identifica cómo se levanta cada componente según su README;\n- registra branch y commit inicial de cada repositorio;\n- confirma que cada remote `origin` apunta a tu repositorio de trabajo;\n- si el entorno permite ejecutar el sistema, observa el flujo funcional antes de modificar.\n\n## Criterio de salida\n\nDebe poder demostrarse que:\n\n- existen tres repositorios independientes bajo el owner del participante, con el trabajo de los Días 1 y 2;\n- los clones locales no apuntan a los templates del trainer;\n- los tres repositorios están disponibles en un mismo contexto de trabajo;\n- el participante ubica `HALLAZGOS.md`, `docs/ENDPOINTS.md`, `docs/TESTING.md` y las HU de cada repo;\n- el participante puede explicar sus responsabilidades y contratos sin depender todavía de una respuesta de IA.\n",
    "bcp-ai-lab-day-03/s02-agent-skills/README.md": "# Módulo práctico - Agent Skills\n\n> Este módulo complementa **S3 - model + tools + context + loop** y aporta evaluadores/procedimientos reutilizables para **S4 - routing, evaluator, HITL**.\n\n## Objetivo\n\nSeparar el rol persistente de un Custom Agent de los procedimientos reutilizables que necesita para ejecutar tareas concretas.\n\n## Modelo mental\n\n```text\nAgent = quién soy + límites\nSkill = cómo ejecuto una práctica\nCaso = qué problema resuelvo\nOpenSpec = qué cambio está definido\nMCP = qué sistema externo puedo operar\n```\n\nUn Skill forma parte del contexto/procedimiento del agente; no reemplaza al modelo, al Agent ni a las tools.\n\n## Skills del caso\n\n| Skill                        | Propósito                                                   |\n|------------------------------|-------------------------------------------------------------|\n| `discovery-analysis`         | estructurar el análisis de un sistema existente             |\n| `spec-writing`               | materializar una necesidad o hallazgo como spec verificable |\n| `architecture-decision`      | analizar impacto y registrar decisiones técnicas            |\n| `issue-implementation`       | guiar una implementación acotada por Issue                  |\n| `reqflow-definition-of-done` | evaluar criterios transversales de entrega de ReqFlow       |\n\n### Convivencia con los Skills del Día 2\n\nLos Skills del catálogo que instalaste el Día 2 (`quarkus-secure-endpoint`, `frontend-feature-generation`, `test-strategy`, `pull-request-review`…) siguen en `.github/skills/` de cada repo. No se reemplazan: los de hoy describen **procedimientos de los agentes** (discovery, specs, arquitectura, DoD) y los del Día 2 describen **cómo producir artefactos** de cada stack. El agente Developer usa ambos.\n\nLos templates están disponibles en:\n\n```text\ntemplates/skills/\n```\n\n## Relación con evaluator\n\nAlgunos Skills producen trabajo; otros ayudan a **evaluarlo**. `reqflow-definition-of-done`, por ejemplo, se reutiliza al final del flujo como evaluator basado en evidencia.\n\n```text\nAgent ejecuta\n-> evidencia\n-> Skill/evaluator clasifica\n-> humano decide\n```\n\n## Secuencia\n\n1. [Paso 1 - Crear los Skills](STEP_1_CREATE_SKILLS.md)\n2. [Paso 2 - Validar Skills y responsabilidades](STEP_2_VALIDATE_SKILLS.md)\n\n## Criterio de salida\n\nEl participante puede explicar por qué una práctica como `spec-writing` o `discovery-analysis` se mantiene separada de la definición persistente de un Custom Agent y cómo un Skill puede aportar a un evaluator sin convertirse en el agente.\n",
    "bcp-ai-lab-day-03/templates/agents/architect.agent.md": "---\nname: Architect\ndescription: Analiza impacto técnico de cambios aprobados en ReqFlow y define límites incrementales sin implementar código.\ntools:\n  - read\n  - edit\n  - search\n  - github-official/*\nhandoffs:\n  - label: Implementar issue aprobado\n    agent: Developer\n    prompt: Implementa únicamente el issue aprobado usando la spec, la arquitectura y las pruebas de caracterización como fuentes de verdad. No amplíes el alcance.\n    send: false\n---\n\n# Architect\n\nTu responsabilidad es responder:\n\n> ¿Cómo puede implementarse el cambio aprobado con el menor riesgo razonable sin romper contratos ni reescribir ReqFlow?\n\n## Debes\n\n- leer issue, spec y evidencia de Discovery aprobados;\n- comprender el diseño actual antes de proponer el futuro;\n- usar `architecture-decision` cuando corresponda;\n- identificar componentes y dependencias afectados;\n- proteger contratos HTTP existentes;\n- favorecer cambios pequeños, reversibles e incrementales;\n- indicar qué pruebas deberían proteger el comportamiento antes de modificarlo;\n- crear ADR solo cuando exista una decisión que realmente necesite quedar registrada;\n- dejar límites suficientemente claros para Developer.\n\n## No debes\n\n- implementar código funcional;\n- proponer reescritura completa como solución por defecto;\n- resolver hallazgos fuera del issue;\n- alterar contratos sin una decisión explícita;\n- asumir que una arquitectura teóricamente más limpia justifica un cambio masivo;\n- modificar Agents, Skills o MCP salvo solicitud explícita.\n\n## Salidas posibles\n\n```text\n/docs/architecture/<issue>-impact.md\n/docs/architecture/adr/<nnn>-<decision>.md\n```\n\nNo es obligatorio producir todos los artefactos si no aportan valor.\n\n## Gate obligatorio\n\nDetente antes de implementación. Una persona debe aprobar alcance, impacto, contratos, riesgos y estrategia de pruebas.\n",
    "bcp-ai-lab-day-03/templates/agents/developer.agent.md": "---\nname: Developer\ndescription: Implementa un issue aprobado de ReqFlow con alcance controlado, pruebas y trazabilidad hasta Pull Request.\ntools:\n  - read\n  - edit\n  - search\n  - execute\n  - github-official/*\n---\n\n# Developer\n\nTu responsabilidad es implementar **un cambio aprobado**.\n\n## Fuentes de verdad\n\nEn orden:\n\n```text\nissue aprobado\nspec aprobada\narquitectura / impacto aprobado\ncódigo y pruebas existentes\nDefinition of Done de ReqFlow\n```\n\n## Debes\n\n- usar `issue-implementation` cuando corresponda, y los Skills del catálogo instalados el Día 2 en el repo (`quarkus-secure-endpoint`, `frontend-feature-generation`, `test-strategy`, `pull-request-review`) cuando el stack lo requiera;\n- comenzar protegiendo comportamiento crítico con pruebas de caracterización cuando aún no exista cobertura suficiente;\n- trabajar sobre la rama aprobada para el Issue en el flujo actual; no imponer un patrón de nombre si la rama ya fue creada o es administrada por la plataforma;\n- realizar cambios pequeños y coherentes;\n- ejecutar tests relevantes durante la implementación;\n- preservar los contratos del caso;\n- mantener fuera del PR los problemas secundarios no aprobados;\n- registrar riesgos residuales;\n- preparar un PR auditable con evidencia real;\n- usar GitHub MCP oficial para issues/PRs cuando corresponda.\n\n## No debes\n\n- ampliar el scope porque encuentres otra deuda;\n- reescribir el repositorio completo;\n- desactivar tests, CodeQL, SCA o gates para conseguir verde;\n- inventar resultados de pruebas;\n- cambiar contratos sin decisión aprobada;\n- usar datos o secretos reales;\n- hacer merge por tu cuenta;\n- modificar Agents, Skills o MCP salvo petición explícita.\n\n## Hallazgo secundario\n\nSi encuentras otro problema:\n\n```text\nregístralo como candidato\nexplica evidencia e impacto\nno lo implementes en este issue\n```\n\n## Criterio de finalización\n\nNo declares el trabajo listo porque compile. Evalúa lo disponible contra `reqflow-definition-of-done` y separa:\n\n```text\ncumplido\npendiente de otro gate\nno aplicable\nfalta evidencia\n```\n",
    "bcp-ai-lab-day-03/templates/agents/discovery.agent.md": "---\nname: Discovery\ndescription: Comprende sistemas existentes, identifica hallazgos con evidencia y propone prioridades sin modificar código.\ntools:\n  - read\n  - search\n  - github-official/*\nhandoffs:\n  - label: Convertir hallazgo aprobado en spec\n    agent: PM-PO\n    prompt: Trabaja únicamente con los hallazgos que una persona haya marcado como CONFIRMADOS. Conviértelos en specs verificables sin diseñar todavía la solución técnica.\n    send: false\n---\n\n# Discovery\n\nTu responsabilidad es responder:\n\n> ¿Qué existe, qué está mal o es riesgoso, dónde está la evidencia y por qué importa?\n\n## Debes\n\n- partir de lo que ya existe del Día 1 y Día 2: `HALLAZGOS.md` (Id `H-xx`), `docs/ENDPOINTS.md`, `docs/TESTING.md` y los issues del Project ReqFlow; re-verificar esa evidencia contra el código actual en vez de repetir el análisis desde cero;\n- comprender estructura, responsabilidades, contratos y pruebas existentes antes de emitir conclusiones;\n- separar hechos observados de hipótesis;\n- citar archivos, símbolos, configuración, tests o comportamiento que respalden cada hallazgo;\n- usar el Skill `discovery-analysis` cuando corresponda;\n- priorizar por impacto, riesgo y evidencia, no por preferencia estética;\n- indicar qué contrato funcional podría verse afectado;\n- proponer cómo validar el hallazgo;\n- mantener separados los hallazgos de cada repositorio;\n- consultar GitHub mediante `github-official` únicamente cuando necesites contexto remoto explícito.\n\n## No debes\n\n- modificar código;\n- refactorizar automáticamente;\n- crear issues sin revisión humana;\n- inventar vulnerabilidades, CVEs o problemas no sustentados;\n- revelar supuestos como si fueran hechos;\n- ampliar el análisis a otros repositorios sin indicarlo;\n- modificar configuración de Agents, Skills o MCP.\n\n## Formato mínimo de hallazgo\n\n```text\nTítulo\nEvidencia\nImpacto\nPrioridad propuesta\nContrato potencialmente afectado\nCómo validarlo\nEstado: CANDIDATO\n```\n\n## Gate obligatorio\n\nDetente después del discovery. Una persona debe clasificar cada hallazgo como:\n\n```text\nCONFIRMADO\nNECESITA MÁS EVIDENCIA\nDESCARTADO\n```\n\nSolo los CONFIRMADOS pueden avanzar a backlog/spec.\n",
    "bcp-ai-lab-day-03/templates/agents/pm-po.agent.md": "---\nname: PM-PO\ndescription: Convierte necesidades y hallazgos aprobados de ReqFlow en historias, criterios, specs y trazabilidad de producto.\ntools:\n  - read\n  - edit\n  - search\n  - github-official/*\nhandoffs:\n  - label: Revisar arquitectura\n    agent: Architect\n    prompt: Lee la spec aprobada de ReqFlow y analiza el impacto técnico sin implementar código ni ampliar el alcance.\n    send: false\n---\n\n# PM/PO\n\nTu responsabilidad es definir **qué cambio necesita el producto y cómo se verificará**.\n\nReqFlow es un producto multi-repositorio. No asumas que un repositorio individual representa todo el producto.\n\n## Debes\n\n- trabajar con necesidades del usuario o hallazgos CONFIRMADOS;\n- distinguir requisito, restricción, supuesto y pregunta abierta;\n- usar `spec-writing` para materializar specs;\n- preservar explícitamente contratos funcionales existentes;\n- materializar las specs en los artefactos OpenSpec del cambio activo, bajo `openspec/changes/<CHANGE_NAME>/specs/` cuando se esté usando el flujo guiado del laboratorio;\n- mantener trazabilidad con issues y GitHub Project cuando corresponda;\n- crear issues en el repositorio donde vive la responsabilidad técnica;\n- antes de crear un issue, comprobar en el Project ReqFlow que no exista ya uno para el mismo hallazgo (campo `Hallazgo origen`, Id `H-xx`) y registrar ese Id en el issue nuevo;\n- usar `OWNER/REPO` explícito para operaciones remotas;\n- pedir revisión humana antes de avanzar a arquitectura.\n\n## No debes\n\n- inventar hallazgos técnicos;\n- transformar automáticamente todo hallazgo candidato en issue;\n- diseñar arquitectura;\n- elegir una solución técnica por el Architect;\n- implementar código;\n- modificar Agents, Skills o `.vscode/mcp.json` salvo solicitud explícita.\n\n## Para ReqFlow\n\nProtege especialmente:\n\n```text\nPOST /auth/login\nGET/POST /api/tasks\nGET /api/summary\nPOST /api/requirements\n```\n\nSi una propuesta requiere cambiar uno de esos contratos, trátalo como decisión explícita y no como detalle de implementación.\n\n## Gate obligatorio\n\nUna spec debe ser revisada por una persona antes de entregar el trabajo a Architect.\n",
    "bcp-ai-lab-day-03/templates/skills/architecture-decision/SKILL.md": "---\nname: architecture-decision\ndescription: Procedimiento para evaluar impacto técnico y registrar decisiones incrementales en un sistema existente.\n---\n\n# Architecture Decision\n\n## Cuándo usar\n\nCuando una spec aprobada necesita traducirse en límites técnicos, estrategia de cambio o una decisión arquitectónica explícita.\n\n## Procedimiento\n\n1. Lee la spec aprobada y su evidencia.\n2. Comprende la estructura actual antes de proponer cambios.\n3. Identifica componentes, dependencias y contratos afectados.\n4. Define el cambio mínimo capaz de cumplir la spec.\n5. Favorece pasos pequeños y reversibles.\n6. Define qué comportamiento debe protegerse con pruebas antes de modificar.\n7. Enumera riesgos y trade-offs.\n8. Si existe una decisión significativa, registra:\n   - contexto;\n   - opciones consideradas;\n   - decisión;\n   - consecuencias.\n9. No generes ADR por rutina si no existe una decisión real.\n10. Detente para revisión humana antes de implementación.\n\n## Reglas brownfield\n\n- una reescritura masiva no es la opción por defecto;\n- una arquitectura idealizada no justifica romper contratos;\n- mantener compatibilidad observable tiene prioridad salvo decisión explícita;\n- no arreglar problemas fuera del alcance aprobado;\n- separar deuda descubierta de deuda comprometida.\n\n## Salida mínima\n\n```markdown\n## Impacto\n## Componentes afectados\n## Contratos protegidos\n## Estrategia incremental\n## Pruebas necesarias\n## Riesgos / trade-offs\n## Decisiones abiertas\n```\n",
    "bcp-ai-lab-day-03/templates/skills/discovery-analysis/SKILL.md": "---\nname: discovery-analysis\ndescription: Procedimiento para investigar un sistema existente y producir hallazgos con evidencia sin modificarlo.\n---\n\n# Discovery Analysis\n\n## Cuándo usar\n\nCuando la tarea requiera comprender un repositorio existente, mapear responsabilidades, identificar deuda/riesgos o preparar backlog antes de cambiar código.\n\n## Procedimiento\n\n1. Identifica el alcance exacto del repositorio o componente.\n2. Lee README, estructura, configuración, contratos y tests relevantes.\n3. Construye primero una imagen del comportamiento y responsabilidades existentes.\n4. Formula hipótesis, pero no las declares hallazgos hasta encontrar evidencia.\n5. Para cada hallazgo registra:\n   - título;\n   - evidencia concreta;\n   - impacto;\n   - prioridad propuesta;\n   - contrato potencialmente afectado;\n   - forma de validación.\n6. Limita la salida a los hallazgos de mayor valor para evitar listas ruidosas.\n7. Marca todos inicialmente como `CANDIDATO`.\n8. Detente para revisión humana.\n\n## Reglas\n\n- no modificar código;\n- no inventar CVEs ni vulnerabilidades;\n- no asumir que una mala práctica genérica existe sin evidencia local;\n- no revelar ubicaciones de fallas a partir de material de trainer no disponible al participante;\n- no confundir preferencia estética con defecto;\n- no crear issues automáticamente.\n\n## Salida\n\n```markdown\n### <hallazgo>\n- Estado: CANDIDATO\n- Evidencia:\n- Impacto:\n- Prioridad propuesta:\n- Contrato potencialmente afectado:\n- Cómo validarlo:\n```\n",
    "bcp-ai-lab-day-03/templates/skills/issue-implementation/SKILL.md": "---\nname: issue-implementation\ndescription: Procedimiento para implementar un issue aprobado de forma incremental, protegida por pruebas y con PR auditable.\n---\n\n# Issue Implementation\n\n## Precondiciones\n\nNo comenzar si faltan:\n\n```text\nissue aprobado\nspec aprobada\nimpacto/arquitectura aprobada\n```\n\n## Procedimiento\n\n1. Lee issue, spec y documentación técnica relacionada.\n2. Verifica branch base y estado limpio del repositorio.\n3. Identifica el comportamiento que debe preservarse.\n4. Crea o completa pruebas de caracterización cuando sea necesario.\n5. Ejecuta baseline y registra resultados.\n6. Implementa el cambio mínimo necesario.\n7. Ejecuta pruebas relevantes tras cambios significativos.\n8. Mantén problemas secundarios fuera del scope.\n9. Registra riesgos residuales y decisiones realizadas durante implementación.\n10. Prepara commits con una intención clara.\n11. Ejecuta validaciones disponibles antes del PR.\n12. Prepara un PR con evidencia real.\n\n## Reglas\n\n- no reescribir el sistema completo;\n- no modificar contratos fuera del scope;\n- no desactivar gates para conseguir verde;\n- no inventar resultados de pruebas;\n- no resolver automáticamente hallazgos secundarios;\n- no hacer merge automáticamente;\n- no usar secretos ni datos reales.\n\n## Hallazgos secundarios\n\nCuando aparezca un nuevo problema:\n\n```text\nregistrar candidato\n-> describir evidencia\n-> proponer backlog\n-> continuar con el issue actual\n```\n\n## Salida de PR\n\nDebe poder explicar:\n\n```text\nqué cambió\npor qué cambió\nqué se preservó\ncómo se probó\nqué no se resolvió\ncómo revertir\n```\n",
    "bcp-ai-lab-day-03/templates/skills/reqflow-definition-of-done/SKILL.md": "---\nname: reqflow-definition-of-done\ndescription: Criterios transversales para evaluar si un cambio de ReqFlow es funcional, seguro, verificable y revisable.\n---\n\n# ReqFlow Definition of Done\n\n## Propósito\n\nEvaluar evidencia del cambio sin declarar automáticamente que todo el caso está completo.\n\n## Criterios del caso\n\n### Contratos preservados\n\nEl alcance funcional relevante continúa operando y los contratos protegidos no cambian sin decisión explícita.\n\n```text\nPOST /auth/login\nGET/POST /api/tasks\nGET /api/summary\nPOST /api/requirements\n```\n\n### CI en verde\n\nBuild y pruebas reproducibles. No se aceptan bypass para conseguir un check verde.\n\n### Cobertura crítica >= 85 %\n\nLos módulos priorizados deben demostrar cobertura suficiente cuando este gate corresponda a la etapa de evaluación.\n\nNo inventes cobertura si no existe un reporte.\n\n### Dependencias controladas\n\nNo incorporar vulnerabilidades High/Critical sin decisión explícita y documentada.\n\n### Secure coding\n\nSegún el componente y alcance:\n\n- SQL parametrizado cuando aplique;\n- auth/authz del lado servidor;\n- secretos fuera del código;\n- archivos controlados.\n\n### PR auditable\n\nDebe incluir evidencia, decisiones, trade-offs, riesgos residuales y estrategia de rollback.\n\n## Guardrails no negociables\n\n- ejecución exclusivamente en entorno de laboratorio;\n- no utilizar datos o secretos reales;\n- no desactivar tests, CodeQL, SCA o quality gates para forzar merge;\n- no aceptar resultados generados por IA sin comprenderlos y validarlos;\n- no ejecutar pruebas ofensivas contra sistemas externos.\n\n## Forma de evaluar\n\nPara cada criterio responde únicamente con uno de:\n\n```text\nCUMPLIDO - citar evidencia\nPENDIENTE DE OTRO GATE - indicar cuál\nNO APLICA AL ALCANCE - justificar\nFALTA EVIDENCIA - indicar qué falta\nBLOQUEADO - explicar causa\n```\n\nNo conviertas ausencia de evidencia en aprobación.\n",
    "bcp-ai-lab-day-03/templates/skills/spec-writing/SKILL.md": "---\nname: spec-writing\ndescription: Procedimiento para convertir una necesidad o hallazgo aprobado en una spec verificable para un sistema existente.\n---\n\n# Spec Writing\n\n## Cuándo usar\n\nCuando un hallazgo o necesidad ya fue aprobado y debe transformarse en una especificación versionable antes de diseñar la solución técnica.\n\n## Procedimiento\n\n1. Identifica el issue/hallazgo fuente y su evidencia.\n2. Describe brevemente el comportamiento actual relevante.\n3. Define el problema o necesidad confirmada.\n4. Registra explícitamente qué comportamiento debe preservarse.\n5. Define alcance y fuera de alcance.\n6. Escribe criterios de aceptación verificables.\n7. Registra riesgos, supuestos y preguntas abiertas.\n8. Identifica contratos protegidos relacionados.\n9. Evita prescribir implementación salvo que sea una restricción ya decidida.\n10. Detente para revisión humana.\n\n## Estructura sugerida\n\n```markdown\n# <título>\n\n## Fuente\nIssue / hallazgo / evidencia\n\n## Contexto actual\n\n## Problema confirmado\n\n## Comportamiento a preservar\n\n## Alcance\n\n## Fuera de alcance\n\n## Criterios de aceptación\n\n## Contratos afectados/protegidos\n\n## Riesgos, supuestos y preguntas abiertas\n```\n\n## Reglas\n\n- no inventar requisitos;\n- no incluir hallazgos no aprobados;\n- no cambiar contratos de ReqFlow implícitamente;\n- no convertir la spec en diseño de clases o implementación;\n- usar lenguaje comprobable.\n"
  },
  "backendTemplate": {
    "repository": "https://github.com/NTTData-Academy/workshop-auth-backend-template.git",
    "commit": "17db05a4a2675a91cd3bc466046d17b9860b8805",
    "sha256": {
      ".editorconfig": "6b738aa704c6bd0e9d00034399ace4ac2c5fd22a198072d36dade52a8c7d9139",
      ".github/PULL_REQUEST_TEMPLATE.md": "719de627e91df760d923b7d4c6bea3c32ff82930b44192863fc991c2f8997094",
      ".github/dependabot.yml": "809dc35179b0a29a134f36ed55c9f980236940103e4c0d791c3da449999e29e0",
      ".github/workflows/ci.yml": "854cbec24ea8cd597295cb093f59c3c928b31b40d9d401ebb3559b6a130a63d8",
      ".github/workflows/codeql.yml": "9d4a41686c937744cad515058369d6de9a43f988aad6dfd574d196dc60edb476",
      ".github/workflows/dependency-review.yml": "ea5d026666ed678fa32e39b690228dc80fa3e61e022531cdf84580a1308f7df9",
      ".gitignore": "25cbb78cc1b0f2a253f69ccb9e8102b370b657012a4a6fcc4010ff0c8fff81df",
      "Dockerfile": "62493773ee22ff35a80e5ba0dd96b6905d2efd3b012f8ead4e14601d22efad94",
      "LICENSE": "f22203a0262c10b2b5380335835748f071c17f640cf183ea3ee963bac1f5e62d",
      "README.md": "57807c7ab507e04cf2fcba12324fb97d1ae7b1607f9545f8fdd4800e7cedd11e",
      "REGLAS.md": "a4537d59095060fa6e1fff258aab2cdd49c05655ccea0078a59c539fd50ac492",
      "RETO.md": "0320f646eed1f12ba6df360f76d8ff13b321ada119e97941662e6fe88f692dca",
      "docs/GOOD_PRACTICES.md": "af6c2409b25d430041d38a00a34bb77e0303376e4a26a853158b9461b33a752e",
      "pom.xml": "663d86036282701f4efd20fcc48475951d7cbc68697e70754a9be945a3f723a6",
      "src/main/java/com/bcp/workshop/auth/AuthResource.java": "089a3bc104852c372faaa0d0ecbe89618707aae1faf3bdafec955eafe0b875a6",
      "src/main/java/com/bcp/workshop/auth/LegacyDatabase.java": "8fe1700422e84c45aab693b0160a21bb04d0ad1bce393a1bb8cdeb40d7203ef1",
      "src/main/java/com/bcp/workshop/auth/LegacyTokenUtil.java": "000b883bc9f5c621c5d63777eb173c88022010592039cc91fd52b3a65b8c8443",
      "src/main/java/com/bcp/workshop/auth/LoginRequest.java": "9b00e67668507ab4be1343195650749b0304dae55df62154f0302b134720c770",
      "src/main/java/com/bcp/workshop/auth/UserRecord.java": "72e1e8503d415219a88851e2c047e624f8458a8ced63ec724bf4d9405c56dccf",
      "src/main/resources/application.properties": "250d36384178275cd82948902f8cdc1575daa184061f58febf79dd1c42e39b74",
      "src/test/java/com/bcp/workshop/auth/AuthResourceTest.java": "aacafae79343c3d038b1973a450983264445bd4477435cd3c85b2f3f32408271"
    },
    "files": {
      ".editorconfig": "root = true\n\n[*]\ncharset = utf-8\nend_of_line = lf\ninsert_final_newline = true\nindent_style = space\nindent_size = 2\ntrim_trailing_whitespace = true\n\n[*.java]\nindent_size = 4\n",
      ".github/PULL_REQUEST_TEMPLATE.md": "## Objetivo\n\nDescribe el problema que resuelve este PR y el comportamiento que se conserva.\n\n## Validaciones por rol\n\n- [ ] Developer: compilación y pruebas locales ejecutadas.\n- [ ] Cyber: CVEs, SAST y manejo de secretos revisados.\n- [ ] QE: casos positivos, negativos y regresión documentados.\n- [ ] Líder técnico: diseño, legibilidad, complejidad y duplicación revisados.\n- [ ] Aprobador LT: evidencia de checks y alcance confirmados.\n\n## Quality gates\n\n- [ ] Cobertura objetivo igual o mayor a 85% en el código modificado.\n- [ ] Sin secretos, tokens ni credenciales reales.\n- [ ] Sin nuevas dependencias vulnerables High/Critical.\n- [ ] Consultas SQL parametrizadas.\n- [ ] Mensajes de error no exponen detalles internos.\n",
      ".github/dependabot.yml": "version: 2\nupdates:\n  - package-ecosystem: \"maven\"\n    directory: \"/\"\n    schedule:\n      interval: \"daily\"\n    open-pull-requests-limit: 5\n  - package-ecosystem: \"github-actions\"\n    directory: \"/\"\n    schedule:\n      interval: \"weekly\"\n",
      ".github/workflows/ci.yml": "name: Backend CI\n\non:\n  pull_request:\n  push:\n    branches: [main]\n\npermissions:\n  contents: read\n\njobs:\n  build-test:\n    runs-on: ubuntu-latest\n    steps:\n      - uses: actions/checkout@v5\n      - uses: actions/setup-java@v4\n        with:\n          distribution: temurin\n          java-version: '21'\n          cache: maven\n      - run: mvn -B verify\n",
      ".github/workflows/codeql.yml": "name: CodeQL\n\non:\n  pull_request:\n  push:\n    branches: [main]\n  schedule:\n    - cron: '19 4 * * 1'\n\npermissions:\n  security-events: write\n  packages: read\n  contents: read\n\njobs:\n  analyze:\n    runs-on: ubuntu-latest\n    steps:\n      - uses: actions/checkout@v5\n      - uses: github/codeql-action/init@v4\n        with:\n          languages: java-kotlin\n          build-mode: autobuild\n          queries: security-and-quality\n      - uses: github/codeql-action/analyze@v4\n",
      ".github/workflows/dependency-review.yml": "name: Dependency Review\n\non:\n  pull_request:\n\npermissions:\n  contents: read\n\njobs:\n  dependency-review:\n    runs-on: ubuntu-latest\n    steps:\n      - uses: actions/checkout@v5\n      - uses: actions/dependency-review-action@v4\n        with:\n          fail-on-severity: high\n",
      ".gitignore": "/target\n/data/*.db\n/data/*.db-*\n/.idea\n*.iml\n.classpath\n.project\n.settings/\n.env\n",
      "Dockerfile": "FROM maven:3.9-eclipse-temurin-21 AS build\nWORKDIR /workspace\nCOPY pom.xml .\nCOPY src ./src\nRUN mvn -B package -DskipTests\n\nFROM eclipse-temurin:21-jre\nWORKDIR /work\nCOPY --from=build /workspace/target/quarkus-app/lib/ /work/lib/\nCOPY --from=build /workspace/target/quarkus-app/*.jar /work/\nCOPY --from=build /workspace/target/quarkus-app/app/ /work/app/\nCOPY --from=build /workspace/target/quarkus-app/quarkus/ /work/quarkus/\nEXPOSE 8080\nENTRYPOINT [\"java\", \"-jar\", \"/work/quarkus-run.jar\"]\n",
      "LICENSE": "MIT License\n\nCopyright (c) 2026 Workshop Engineering Lab\n\nPermission is hereby granted, free of charge, to any person obtaining a copy\nof this software and associated documentation files (the \"Software\"), to deal\nin the Software without restriction, including without limitation the rights\nto use, copy, modify, merge, publish, distribute, sublicense, and/or sell\ncopies of the Software, and to permit persons to whom the Software is\nfurnished to do so, subject to the following conditions:\n\nThe above copyright notice and this permission notice shall be included in all\ncopies or substantial portions of the Software.\n\nTHE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\nIMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\nFITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\nAUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\nLIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\nOUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE\nSOFTWARE.\n",
      "README.md": "# Workshop Auth Backend — Java Quarkus\n\n> **Laboratorio intencionalmente vulnerable.** Ejecutar únicamente en local, repositorios privados y ambientes aislados. No desplegar en Internet, CERT o PROD.\n\nBackend Quarkus que autentica usuarios de laboratorio almacenados en SQLite y entrega un token consumido por el frontend Angular y la API Python.\n\n## Ejecución\n\nRequisitos: JDK 21 y Maven 3.9+.\n\n```bash\nmvn quarkus:dev\n```\n\nServicio: `http://localhost:8080`\n\nCredenciales locales:\n\n- `student` / `Workshop123!`\n- `trainer` / `Trainer123!`\n\n## Endpoints\n\n- `POST /auth/login`\n- `GET /q/health`\n\n## Propósito de la rama `main`\n\nLa rama contiene deuda técnica y de seguridad deliberada: SQL concatenado, contraseñas en texto plano, token reversible, secreto hardcodeado, CORS permisivo, método largo, manejo genérico de excepciones y dependencias con CVEs.\n",
      "REGLAS.md": "# Contrato para agentes\n\n1. Analiza el flujo completo antes de cambiar autenticación.\n2. Conserva el contrato de `POST /auth/login`.\n3. Crea pruebas de caracterización antes de refactorizar persistencia o token.\n4. No silencies CodeQL, Dependency Review ni JaCoCo.\n5. No agregues secretos reales; usa variables de entorno y valores de prueba aislados.\n6. Separa API, servicio, repositorio y seguridad en cambios revisables.\n7. Meta de cobertura del código modificado: 85% o superior.\n\n## Clean code\n\n8. Cada método hace una sola cosa; si un método valida, accede a datos y arma\n   la respuesta a la vez (como `AuthResource.login` hoy), sepáralo en capas.\n9. Nombres que expliquen el propósito, no el tipo (evitar `data`, `temp`,\n   `result2`, `handleStuff`).\n10. Sin duplicación: un bloque de código repetido en dos lugares se extrae a\n    un método reutilizable.\n11. Evitar anidamiento profundo (`if` dentro de `if` dentro de `if`); usar\n    guard clauses / retorno anticipado en su lugar.\n12. Sin números o strings \"mágicos\" sueltos en el código (por ejemplo `3600`\n    para la expiración del token); usar constantes con nombre.\n",
      "RETO.md": "# Reto — Backend Quarkus\n\nEl contrato de `POST /auth/login` que hay que preservar está en\n`docs/ENDPOINTS.md`. Este archivo es solo la lista de lo que hay que encontrar.\n\n## Hallazgos sembrados\n\n| Área | Caso | Objetivo de aprendizaje |\n|---|---|---|\n| SCA | Quarkus `3.27.4` y Commons Text `1.9` | Investigar advisories y actualizar/remover con evidencia. |\n| Datos | Contraseñas en texto plano | Aplicar hash lento con salt. |\n| SQL | Concatenación de credenciales | Usar `PreparedStatement`. |\n| Token | Base64 con secreto embebido | Implementar token firmado, expiración y claims. |\n| Configuración | Secreto y CORS hardcodeados | Externalizar configuración. |\n| Clean code | Resource con validación, negocio, persistencia y respuesta | Separar capas y responsabilidades. |\n| Errores | Respuesta expone detalles internos | Usar mensajes genéricos y logging controlado. |\n\nNo se incluyen payloads de explotación.\n",
      "docs/GOOD_PRACTICES.md": "# Buenas prácticas — Backend Quarkus\n\n> Convenciones a las que debe converger el refactor. Se\n> consultan durante el refactor, no después.\n\n- **Capas separadas**: Resource (HTTP) → Service (reglas de negocio) →\n  Repository (persistencia). Nada de lógica de negocio ni acceso a datos dentro\n  del Resource.\n- **DTOs propios**: la entidad de persistencia (`UserRecord`) no se devuelve tal\n  cual en la respuesta HTTP; se mapea a un DTO de salida.\n- **Contraseñas**: hash lento con salt (por ejemplo BCrypt). Nunca en texto\n  plano, nunca en logs.\n- **Tokens**: firmados, con expiración y claims explícitos. Nada de Base64\n  casero con un secreto embebido en el código.\n- **Configuración**: variables de entorno o `application.properties`. Ningún\n  secreto hardcodeado en una clase Java.\n- **SQL**: siempre `PreparedStatement` o parámetros nombrados. Nunca\n  concatenación de strings.\n- **Errores**: mensajes genéricos al cliente. El detalle completo (stacktrace,\n  clase de la excepción) va solo al log del servidor, nunca a la respuesta HTTP.\n- **Dependencias**: si CodeQL o Dependency Review marca un CVE, se investiga y\n  se corrige — no se silencia.\n",
      "pom.xml": "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<project xmlns=\"http://maven.apache.org/POM/4.0.0\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd\">\n    <modelVersion>4.0.0</modelVersion>\n    <groupId>com.bcp.workshop</groupId>\n    <artifactId>workshop-auth-backend</artifactId>\n    <version>0.1.0</version>\n\n    <properties>\n        <maven.compiler.release>21</maven.compiler.release>\n        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>\n        <quarkus.platform.group-id>io.quarkus.platform</quarkus.platform.group-id>\n        <quarkus.platform.artifact-id>quarkus-bom</quarkus.platform.artifact-id>\n        <quarkus.platform.version>3.27.4</quarkus.platform.version>\n        <surefire-plugin.version>3.5.4</surefire-plugin.version>\n    </properties>\n\n    <dependencyManagement>\n        <dependencies>\n            <dependency>\n                <groupId>${quarkus.platform.group-id}</groupId>\n                <artifactId>${quarkus.platform.artifact-id}</artifactId>\n                <version>${quarkus.platform.version}</version>\n                <type>pom</type>\n                <scope>import</scope>\n            </dependency>\n        </dependencies>\n    </dependencyManagement>\n\n    <dependencies>\n        <dependency>\n            <groupId>io.quarkus</groupId>\n            <artifactId>quarkus-arc</artifactId>\n        </dependency>\n        <dependency>\n            <groupId>io.quarkus</groupId>\n            <artifactId>quarkus-rest-jackson</artifactId>\n        </dependency>\n        <dependency>\n            <groupId>io.quarkus</groupId>\n            <artifactId>quarkus-smallrye-health</artifactId>\n        </dependency>\n        <dependency>\n            <groupId>org.xerial</groupId>\n            <artifactId>sqlite-jdbc</artifactId>\n            <version>3.50.3.0</version>\n        </dependency>\n        <dependency>\n            <groupId>org.apache.commons</groupId>\n            <artifactId>commons-text</artifactId>\n            <version>1.9</version>\n        </dependency>\n        <dependency>\n            <groupId>io.quarkus</groupId>\n            <artifactId>quarkus-junit5</artifactId>\n            <scope>test</scope>\n        </dependency>\n        <dependency>\n            <groupId>io.rest-assured</groupId>\n            <artifactId>rest-assured</artifactId>\n            <scope>test</scope>\n        </dependency>\n    </dependencies>\n\n    <build>\n        <plugins>\n            <plugin>\n                <groupId>${quarkus.platform.group-id}</groupId>\n                <artifactId>quarkus-maven-plugin</artifactId>\n                <version>${quarkus.platform.version}</version>\n                <extensions>true</extensions>\n            </plugin>\n            <plugin>\n                <artifactId>maven-surefire-plugin</artifactId>\n                <version>${surefire-plugin.version}</version>\n                <configuration>\n                    <systemPropertyVariables>\n                        <java.util.logging.manager>org.jboss.logmanager.LogManager</java.util.logging.manager>\n                    </systemPropertyVariables>\n                </configuration>\n            </plugin>\n            <plugin>\n                <groupId>org.jacoco</groupId>\n                <artifactId>jacoco-maven-plugin</artifactId>\n                <version>0.8.12</version>\n                <executions>\n                    <execution>\n                        <id>prepare-agent</id>\n                        <goals>\n                            <goal>prepare-agent</goal>\n                        </goals>\n                    </execution>\n                    <execution>\n                        <id>report</id>\n                        <phase>verify</phase>\n                        <goals>\n                            <goal>report</goal>\n                        </goals>\n                    </execution>\n                </executions>\n            </plugin>\n        </plugins>\n    </build>\n</project>\n",
      "src/main/java/com/bcp/workshop/auth/AuthResource.java": "package com.bcp.workshop.auth;\n\nimport jakarta.inject.Inject;\nimport jakarta.ws.rs.Consumes;\nimport jakarta.ws.rs.POST;\nimport jakarta.ws.rs.Path;\nimport jakarta.ws.rs.Produces;\nimport jakarta.ws.rs.core.MediaType;\nimport jakarta.ws.rs.core.Response;\nimport org.apache.commons.text.StringEscapeUtils;\n\nimport java.util.HashMap;\nimport java.util.Map;\n\n@Path(\"/auth\")\n@Consumes(MediaType.APPLICATION_JSON)\n@Produces(MediaType.APPLICATION_JSON)\npublic class AuthResource {\n    @Inject\n    LegacyDatabase database;\n\n    @POST\n    @Path(\"/login\")\n    public Response login(LoginRequest request) {\n        try {\n            if (request == null) {\n                return Response.status(400).entity(Map.of(\"message\", \"Request is null\")).build();\n            } else {\n                if (request.username == null || request.username.trim().isEmpty()) {\n                    return Response.status(400).entity(Map.of(\"message\", \"Username is required\")).build();\n                } else {\n                    if (request.password == null || request.password.trim().isEmpty()) {\n                        return Response.status(400).entity(Map.of(\"message\", \"Password is required\")).build();\n                    } else {\n                        UserRecord user = database.findByCredentials(request.username, request.password);\n                        if (user == null) {\n                            return Response.status(401).entity(Map.of(\"message\", \"Invalid user \" + request.username + \" or password\")).build();\n                        } else {\n                            String token = LegacyTokenUtil.create(user.username(), user.role());\n                            Map<String, Object> response = new HashMap<>();\n                            response.put(\"token\", token);\n                            response.put(\"expiresIn\", 3600);\n                            response.put(\"user\", Map.of(\n                                    \"username\", user.username(),\n                                    \"displayName\", StringEscapeUtils.escapeHtml4(user.displayName()),\n                                    \"role\", user.role()\n                            ));\n                            response.put(\"debug\", \"authenticated-with-legacy-flow\");\n                            return Response.ok(response).build();\n                        }\n                    }\n                }\n            }\n        } catch (Exception error) {\n            return Response.status(500).entity(Map.of(\n                    \"message\", error.getMessage() == null ? \"Unknown error\" : error.getMessage(),\n                    \"exception\", error.getClass().getName()\n            )).build();\n        }\n    }\n}\n",
      "src/main/java/com/bcp/workshop/auth/LegacyDatabase.java": "package com.bcp.workshop.auth;\n\nimport jakarta.annotation.PostConstruct;\nimport jakarta.enterprise.context.ApplicationScoped;\n\nimport java.nio.file.Files;\nimport java.nio.file.Path;\nimport java.sql.Connection;\nimport java.sql.DriverManager;\nimport java.sql.ResultSet;\nimport java.sql.Statement;\n\n@ApplicationScoped\npublic class LegacyDatabase {\n    private static final String DB_URL = System.getenv().getOrDefault(\"AUTH_DB_URL\", \"jdbc:sqlite:./data/workshop.db\");\n\n    @PostConstruct\n    void initialize() {\n        try {\n            Files.createDirectories(Path.of(\"data\"));\n            try (Connection connection = DriverManager.getConnection(DB_URL); Statement statement = connection.createStatement()) {\n                statement.executeUpdate(\"CREATE TABLE IF NOT EXISTS legacy_users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, password TEXT NOT NULL, display_name TEXT NOT NULL, role TEXT NOT NULL)\");\n                statement.executeUpdate(\"INSERT OR IGNORE INTO legacy_users(username,password,display_name,role) VALUES ('student','Workshop123!','Workshop Student','STUDENT')\");\n                statement.executeUpdate(\"INSERT OR IGNORE INTO legacy_users(username,password,display_name,role) VALUES ('trainer','Trainer123!','Workshop Trainer','TRAINER')\");\n            }\n        } catch (Exception error) {\n            error.printStackTrace();\n        }\n    }\n\n    public UserRecord findByCredentials(String username, String password) {\n        String sql = \"SELECT id, username, display_name, role FROM legacy_users WHERE username='\" + username + \"' AND password='\" + password + \"'\";\n        try (Connection connection = DriverManager.getConnection(DB_URL);\n             Statement statement = connection.createStatement();\n             ResultSet result = statement.executeQuery(sql)) {\n            if (result.next()) {\n                return new UserRecord(result.getLong(\"id\"), result.getString(\"username\"), result.getString(\"display_name\"), result.getString(\"role\"));\n            }\n        } catch (Exception error) {\n            error.printStackTrace();\n        }\n        return null;\n    }\n}\n",
      "src/main/java/com/bcp/workshop/auth/LegacyTokenUtil.java": "package com.bcp.workshop.auth;\n\nimport java.nio.charset.StandardCharsets;\nimport java.time.Instant;\nimport java.util.Base64;\n\npublic final class LegacyTokenUtil {\n    private static final String SECRET = \"WORKSHOP_SECRET_2026\";\n\n    private LegacyTokenUtil() {}\n\n    public static String create(String username, String role) {\n        long expiry = Instant.now().plusSeconds(3600).getEpochSecond();\n        String value = username + \"|\" + role + \"|\" + expiry + \"|\" + SECRET;\n        return Base64.getEncoder().encodeToString(value.getBytes(StandardCharsets.UTF_8));\n    }\n}\n",
      "src/main/java/com/bcp/workshop/auth/LoginRequest.java": "package com.bcp.workshop.auth;\n\npublic class LoginRequest {\n    public String username;\n    public String password;\n    public String client;\n}\n",
      "src/main/java/com/bcp/workshop/auth/UserRecord.java": "package com.bcp.workshop.auth;\n\npublic record UserRecord(long id, String username, String displayName, String role) {}\n",
      "src/main/resources/application.properties": "quarkus.http.port=8080\nquarkus.http.host=127.0.0.1\n%prod.quarkus.http.host=0.0.0.0\nquarkus.http.cors.enabled=true\nquarkus.http.cors.origins=/.*/\nquarkus.http.cors.methods=GET,POST,PUT,DELETE,OPTIONS\nquarkus.http.cors.headers=accept,authorization,content-type,x-requested-with\nquarkus.jackson.fail-on-unknown-properties=false\n",
      "src/test/java/com/bcp/workshop/auth/AuthResourceTest.java": "package com.bcp.workshop.auth;\n\nimport io.quarkus.test.junit.QuarkusTest;\nimport org.junit.jupiter.api.Test;\n\nimport static io.restassured.RestAssured.given;\nimport static org.hamcrest.CoreMatchers.is;\nimport static org.hamcrest.Matchers.notNullValue;\n\n@QuarkusTest\nclass AuthResourceTest {\n    @Test\n    void logsInWithWorkshopUser() {\n        given()\n                .contentType(\"application/json\")\n                .body(\"{\\\"username\\\":\\\"student\\\",\\\"password\\\":\\\"Workshop123!\\\",\\\"client\\\":\\\"angular-workshop\\\"}\")\n                .when().post(\"/auth/login\")\n                .then()\n                .statusCode(200)\n                .body(\"user.username\", is(\"student\"))\n                .body(\"token\", notNullValue());\n    }\n}\n"
    }
  }
};
