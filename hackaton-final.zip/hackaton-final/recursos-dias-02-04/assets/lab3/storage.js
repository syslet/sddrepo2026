export function createStorage({key,feedback,endpoint='/api/lab3-session'}) {
  let snapshot,events=[],sending=false,dirty=false;
  const queueKey=key+'.sync';
  function persist() {
    try{localStorage.setItem(key,JSON.stringify(snapshot));localStorage.setItem(queueKey,JSON.stringify({dirty,events}));}
    catch{feedback('No se pudo guardar la copia local. Mantén esta página abierta hasta guardar en tu cuenta.');}
  }
  async function load() {
    let local;
    try{local=JSON.parse(localStorage.getItem(key)||'null');const pending=JSON.parse(localStorage.getItem(queueKey)||'{}');events=pending.events||[];dirty=pending.dirty===true;}catch{}
    const response=await fetch(endpoint,{credentials:'same-origin',cache:'no-store',signal:AbortSignal.timeout(10000)});
    if(!response.ok)throw Error('No se pudo cargar el avance de tu cuenta. Reintenta recargando la página.');
    const saved=await response.json();
    snapshot=dirty&&local ? local : saved.snapshot||local;
    if(!saved.snapshot&&local&&!dirty){dirty=true;for(const entry of local.history||[])events.push({id:crypto.randomUUID(),type:'command_execute',stepId:'',target:entry.command.slice(0,500),label:'Comando recuperado del navegador',occurredAt:entry.time,details:JSON.stringify(entry)});}
    if(snapshot)persist();
    return snapshot;
  }
  async function flush() {
    if(sending||!snapshot||(!dirty&&!events.length))return;
    sending=true;
    const current=snapshot,batch=events.slice(0,20);
    feedback('Guardando en tu cuenta…');
    try{
      const response=await fetch(endpoint,{method:'PUT',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({snapshot:current,events:batch}),signal:AbortSignal.timeout(15000)});
      if(!response.ok)throw Error('save_failed');
      const ids=new Set(batch.map(event=>event.id));events=events.filter(event=>!ids.has(event.id));dirty=snapshot!==current;persist();
      feedback(dirty||events.length?'Guardado pendiente…':'Avance y logs guardados en tu cuenta.');
    }catch{feedback('Guardado en este navegador. Pendiente de guardar en tu cuenta; se reintentará al recuperar la conexión.');return;}
    finally{sending=false;}
    if(dirty||events.length)void flush();
  }
  function save(value) {snapshot=value;dirty=true;persist();void flush();}
  function track(type,{stepId='',target='',label='',details=''}={}) {
    events.push({id:crypto.randomUUID(),type,stepId,target:target.slice(0,500),label:label.slice(0,160),details,occurredAt:new Date().toISOString()});persist();void flush();
  }
  return {load,save,track,flush};
}
