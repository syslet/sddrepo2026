export const LAB3_STEPS = [
  {
    "id": "d3-s1-paso-01",
    "section": "s1",
    "title": "Preparar OpenSpec en workshop-auth-backend"
  },
  {
    "id": "d3-s1-paso-02",
    "section": "s1",
    "title": "Elegir un Issue real del Project ReqFlow (estado Todo)"
  },
  {
    "id": "d3-s1-paso-03",
    "section": "s1",
    "title": "Crear proposal + specs/ desde el Issue"
  },
  {
    "id": "d3-s2-paso-01",
    "section": "s2",
    "title": "Crear design.md (Plan)"
  },
  {
    "id": "d3-s2-paso-02",
    "section": "s2",
    "title": "Crear tasks.md (Tasks)"
  },
  {
    "id": "d3-s2-paso-03",
    "section": "s2",
    "title": "Validar (Validate) antes de tocar código"
  },
  {
    "id": "d3-s3-paso-01",
    "section": "s3",
    "title": "Copiar los Custom Agents al workspace"
  },
  {
    "id": "d3-s3-paso-02",
    "section": "s3",
    "title": "Probar los límites de un agente aislado"
  },
  {
    "id": "d3-s3-paso-03",
    "section": "s3",
    "title": "Verificar MCP oficial + Projects habilitado"
  },
  {
    "id": "d3-s3-paso-04",
    "section": "s3",
    "title": "Completar backlog (sin inventar trabajo)"
  },
  {
    "id": "d3-s3-paso-05",
    "section": "s3",
    "title": "De single-agent a routing"
  },
  {
    "id": "d3-s4-paso-01",
    "section": "s4",
    "title": "Confirmar el routing del Issue"
  },
  {
    "id": "d3-s4-paso-02",
    "section": "s4",
    "title": "Proteger baseline (characterization)"
  },
  {
    "id": "d3-s4-paso-03",
    "section": "s4",
    "title": "Aplicar e implementar incrementalmente"
  },
  {
    "id": "d3-s4-paso-04",
    "section": "s4",
    "title": "Evaluator + DoD + PR"
  }
];
