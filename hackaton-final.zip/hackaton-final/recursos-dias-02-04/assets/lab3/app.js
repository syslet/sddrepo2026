import {browserApi,trackLab3,visitLab3} from './browser-api.js';
import {createFileManager} from './file-manager.js';
import {createTerminal} from './terminal-client.js';
const $=id=>document.getElementById(id);
const bootPhases=['account','files','session'];
const bootLabels={account:'Comprobando el acceso a tu cuenta…',files:'Cargando la guía original y los materiales del Día 3…',session:'Recuperando tus archivos, historial y avance…'};
document.addEventListener('lab3:loading',event=>{
 const current=bootPhases.indexOf(event.detail.phase);$('boot-message').textContent=bootLabels[event.detail.phase];
 document.querySelectorAll('[data-boot-step]').forEach((node,i)=>{node.dataset.state=i<current?'done':i===current?'current':'pending';const icon=node.firstElementChild;icon.className=i===current?'loading loading-spinner loading-sm':'boot-step-icon';node.querySelector('small').textContent=i<current?'Listo':i===current?'Preparando…':i===1?'OpenSpec · Agents · Skills':'Terminal, historial y avance';});
});
$('boot-retry').onclick=()=>location.reload();
const slowTimer=setTimeout(()=>{$('boot-slow').hidden=false;},8000);
function ready(){clearTimeout(slowTimer);$('lab-boot').hidden=true;$('lab-boot').setAttribute('aria-busy','false');$('work-layout').hidden=false;document.querySelectorAll('.header-actions .btn:not(#theme-toggle)').forEach(node=>node.disabled=false);}
function bootError(error){clearTimeout(slowTimer);$('lab-boot').setAttribute('aria-busy','false');$('boot-title').textContent='No se pudo abrir el laboratorio';$('boot-message').textContent=error.name==='TimeoutError'?'La conexión tardó demasiado. Puedes volver a intentarlo.':error.message;$('boot-error').hidden=false;$('boot-slow').hidden=true;document.querySelectorAll('[data-boot-step]').forEach(node=>{if(node.dataset.state==='current'){node.dataset.state='error';node.firstElementChild.className='boot-step-icon';node.querySelector('small').textContent='No completado';}});}
document.querySelectorAll('.header-actions .btn:not(#theme-toggle)').forEach(node=>node.disabled=true);
let overview=true;
let session,index=0,busy=false,terminal,fileManager,shellBusy=false;
const api=browserApi;
function color(node,text){const tokens=text.split(/("[^"]*"|'[^']*'|--?[\w-]+)/g);for(const token of tokens){const span=document.createElement('span');span.textContent=token;span.className=/^['"]/.test(token)?'literal':/^--?/.test(token)?'flag':'';node.append(span);}}
async function copyText(text){
 try{await navigator.clipboard.writeText(text);return;}catch{}
 const input=document.createElement('textarea'),focused=document.activeElement;input.value=text;input.style.cssText='position:fixed;top:0;left:0;opacity:0';
 // A modal only allows focus inside itself.
 const parent=$('help').open?$('help'):document.body;parent.append(input);input.focus();input.select();
 try{if(!document.execCommand('copy'))throw Error('copy_failed');}finally{input.remove();focused?.focus({preventScroll:true});}
}
function commandIcon(kind){
 const icon=document.createElementNS('http://www.w3.org/2000/svg','svg');
 for(const [name,value] of Object.entries({viewBox:'0 0 24 24',width:'16',height:'16',fill:'none',stroke:'currentColor','stroke-width':'1.7','aria-hidden':'true',focusable:'false'}))icon.setAttribute(name,value);
 icon.innerHTML=kind==='copy'?'<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V4a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h4"/>':kind==='check'?'<path d="M5 12.5l4.5 4.5L19 7.5"/>':'<path d="m8 5 11 7-11 7Z" stroke-linejoin="round"/>';
 return icon;
}
function lock(value){busy=value;document.querySelectorAll('#commands [data-execute],#check,#next').forEach(node=>node.disabled=value||shellBusy);$('next').disabled=value||shellBusy||(index===session.stages.length-1&&session.completed[index]);}
function render(){
 $('file-explorer').hidden=overview;
 $('work-layout').classList.toggle('show-overview',overview);
 $('overview').hidden=!overview;$('stage').hidden=overview;$('getting-started').setAttribute('aria-current',overview?'page':'false');
 $('steps').replaceChildren();for(const group of session.agenda){const section=document.createElement('li');section.className='session-group';const heading=document.createElement('h2');const label=document.createElement('span');label.textContent=group.title;const count=document.createElement('span');count.className='session-count';const members=session.stages.map((stage,i)=>({stage,i})).filter(({stage})=>stage.session===group.id);count.textContent=`${members.filter(({i})=>session.completed[i]).length}/${members.length}`;count.setAttribute('aria-label',count.textContent+' pasos completados');heading.append(label,count);const list=document.createElement('ol');session.stages.forEach((stage,i)=>{if(stage.session!==group.id)return;const li=document.createElement('li');const button=document.createElement('button');button.type='button';const n=document.createElement('span');n.className='s2-step-num';n.textContent=String(list.children.length+1).padStart(2,'0');const title=document.createElement('span');title.textContent=stage.title;button.append(n,title);if(!overview&&i===index)button.setAttribute('aria-current','step');const state=document.createElement('small');button.dataset.state=session.completed[i]?'done':'pending';state.textContent=session.completed[i]?'Completado':'Pendiente';button.append(state);button.onclick=()=>{if(!busy){overview=false;index=i;visitLab3(index);render();}};li.append(button);list.append(li);});section.append(heading,list);$('steps').append(section);}
 const completed=session.stages.filter((_,i)=>session.completed[i]).length,total=document.createElement('span');total.textContent=`de ${session.stages.length} pasos completados`;$('progress-count').replaceChildren(completed+' ',total);$('day-progress').max=session.stages.length;$('day-progress').value=completed;
 const stage=session.stages[index];$('issue-fallback').hidden=!stage.issueFallback;const siblings=session.stages.filter(x=>x.session===stage.session);$('position').textContent=`${stage.session.toUpperCase()} · Paso ${siblings.indexOf(stage)+1} de ${siblings.length}`;$('description').textContent=stage.description;$('role').textContent=stage.role;$('title').textContent=stage.title;$('commands').replaceChildren();const hasPrompts=stage.commands.some(command=>command.kind==='prompt'),hasCommands=stage.commands.some(command=>command.kind==='command');$('guide-heading').textContent=hasPrompts?(hasCommands?'Comandos y prompts de la guía':'Prompts para Copilot'):(hasCommands?'Comandos de la guía':'Instrucciones del paso');$('command-feedback').textContent=hasPrompts?'Abre el prompt para leerlo completo y copiarlo a Copilot.':hasCommands?'Este paso contiene comandos. ▶ indica los disponibles en esta terminal.':'Este paso se realiza siguiendo las instrucciones de la guía; no incluye un prompt.';stage.commands.forEach((command,i)=>{
  const li=document.createElement('li');const code=document.createElement('code');color(code,command.text);if(command.kind==='prompt'){code.className='guide-prompt';li.dataset.kind='prompt';li.dataset.agent=command.agent;}const actions=document.createElement('div');actions.className='s2-command-actions';
  const copy=document.createElement('button');copy.className='btn command-copy-action';copy.type='button';copy.title=command.kind==='prompt'?'Copiar prompt':'Copiar comando';copy.append(commandIcon('copy'));copy.setAttribute('aria-label',(command.kind==='prompt'?'Copiar prompt ':'Copiar comando ')+(i+1));copy.onclick=async()=>{try{await copyText(command.text);trackLab3('command_copy',{target:command.text,label:'Comando copiado'});copy.replaceChildren(commandIcon('check'));copy.title='Comando copiado';copy.setAttribute('aria-label','Comando copiado');$('command-feedback').textContent='Comando copiado.';setTimeout(()=>{copy.replaceChildren(commandIcon('copy'));copy.title=command.kind==='prompt'?'Copiar prompt':'Copiar comando';copy.setAttribute('aria-label',(command.kind==='prompt'?'Copiar prompt ':'Copiar comando ')+(i+1));},1500);}catch{trackLab3('copy_failed',{target:command.text,label:'Copia fallida'});$('command-feedback').textContent='No se pudo copiar. Selecciona el comando para copiarlo manualmente.';}};
  const execute=document.createElement('button');execute.className='btn command-execute-action';execute.dataset.execute='true';execute.type='button';execute.title='Ejecutar comando';execute.append(commandIcon('play'));execute.setAttribute('aria-label','Ejecutar comando '+(i+1));execute.onclick=()=>run(command.text);execute.hidden=!command.executable;
  const help=document.createElement('button');help.className='btn command-explain-action';help.type='button';help.textContent='?';help.title=command.kind==='prompt'?'Explicar prompt':'Explicar comando';help.setAttribute('aria-label',(command.kind==='prompt'?'Explicar prompt ':'Explicar comando ')+(i+1));help.setAttribute('aria-haspopup','dialog');help.onclick=()=>showItemHelp(command);
  const last=[...session.history].reverse().find(x=>x.command===command.text);if(last){const outcome=document.createElement('span');outcome.className='command-outcome';outcome.textContent=last.exitCode===0?'Ejecutado':'Terminó con error';li.append(outcome);}
  if(command.kind==='prompt'){
   const card=document.createElement('div');card.className='prompt-summary';const label=document.createElement('strong');label.textContent=command.label;const agent=document.createElement('span');agent.textContent='Copilot · '+command.agent;const preview=document.createElement('p');preview.textContent=command.text.split('\n').filter(Boolean).slice(0,2).join(' ');card.append(label,agent,preview);
   const open=document.createElement('button');open.className='btn btn-sm';open.textContent='Abrir prompt';open.onclick=()=>openPrompt(command);actions.append(open,copy,help);li.prepend(card,actions);
  }else{actions.append(copy,execute,help);li.prepend(code,actions);}$('commands').append(li);
 });
 $('edit-stage').hidden=!stage.edit;$('edit-stage').onclick=()=>{if(busy)return;fileManager.open(stage.edit);};
 $('check').hidden=index!==0;$('next').textContent=index===session.stages.length-1?(session.completed[index]?(session.completed.filter(Boolean).length===session.stages.length?'Laboratorio completado':'Paso completado'):'Completar paso'):'Completar y seguir';
 fileManager?.update(session);lock(busy);
}
function sourceLink(source){
 const folder=source.slice(0,source.lastIndexOf('/')),file=source.slice(source.lastIndexOf('/')+1);
 const link=document.createElement('a');link.href='/dia-03/'+folder+'/markdown-viewer.html?file='+encodeURIComponent(file);link.target='_blank';link.rel='noopener';link.textContent='Ver material de la guía';return link;
}
function showHelp(title,why,command,output,parts=[],options={}){
 $('help').classList.remove('prompt-dialog');$('prompt-actions').hidden=true;trackLab3('help_open',{label:title});$('help-title').textContent=title;$('help-content').replaceChildren();
 const paragraph=document.createElement('p');paragraph.textContent=why;$('help-content').append(paragraph);
 const section=(title,content)=>{const heading=document.createElement('h3');heading.textContent=title;$('help-content').append(heading);if(Array.isArray(content)){const list=document.createElement('ul');for(const text of content){const item=document.createElement('li');item.textContent=text;list.append(item);}$('help-content').append(list);}else{const text=document.createElement('p');text.textContent=content;$('help-content').append(text);}};
 if(options.where)section('Dónde se usa',options.where);
 if(command){const pre=document.createElement('pre');pre.textContent=command;$('help-content').append(pre);}
 if(parts.length)section(options.partsTitle||'Qué significa cada parte',parts);
 if(output)section(options.expectedTitle||'Qué observar al ejecutar',output);
 if(options.issues?.length)section('Qué revisar si algo no coincide',options.issues);
 if(options.source){const source=document.createElement('p');source.append(sourceLink(options.source));$('help-content').append(source);}
 $('help').showModal();
}
function itemOptions(command){return {where:command.where,issues:command.issues,source:command.source,partsTitle:command.kind==='prompt'?'Cómo usar este prompt':'Qué significa cada parte',expectedTitle:command.kind==='prompt'?'Qué debe entregar Copilot':'Qué observar al ejecutar'};}
function showItemHelp(command){showHelp(command.label,command.why,command.text,command.output,command.parts,itemOptions(command));}
let activePrompt='',activeCopyKind='prompt';
function openPrompt(command){
 showItemHelp(command);
 activePrompt=command.text;activeCopyKind='prompt';$('help').classList.add('prompt-dialog');$('prompt-actions').hidden=false;$('prompt-copy-status').textContent='';$('copy-prompt').textContent='Copiar prompt';
 $('help-content').querySelector('pre').tabIndex=0;
}
$('issue-fallback').onclick=()=>{
 const fallback=session.stages[index].issueFallback;
 const explanation=fallback.explanation;showHelp(explanation.label,explanation.why,fallback.command,explanation.output,explanation.parts,{where:explanation.where,issues:explanation.issues});
 const download=document.createElement('a');download.className='btn btn-sm';download.href=fallback.download;download.download='create_backend_issue.py';download.textContent='Descargar script';$('help-content').prepend(download);
 const source=document.createElement('p');const lab2=document.createElement('a');lab2.href='/dia-02/#s3-paso-04';lab2.target='_blank';lab2.rel='noopener';lab2.textContent='Ver requisito del Lab 2 · S3 paso 4';source.append(lab2);$('help-content').append(source);
 const details=document.createElement('details');const summary=document.createElement('summary');summary.textContent='Estructura del issue y cómo funciona';const text=document.createElement('pre');text.textContent=fallback.instructions;details.append(summary,text);$('help-content').append(details);
 const project=document.createElement('p');project.textContent='El script prepara Origen, evidencia y criterios como checklist desde tu HU, busca issues existentes y abre el formulario de GitHub para revisarlo. Después agrégalo a ReqFlow como Todo y completa Hallazgo origen. Si tienes PR de S2, añade --pr con su URL.';$('help-content').append(project);
 activePrompt=fallback.command;activeCopyKind='command';$('help').classList.add('prompt-dialog');$('prompt-actions').hidden=false;$('copy-prompt').textContent='Copiar comando';$('prompt-copy-status').textContent='';
};
$('copy-prompt').onclick=async()=>{try{await copyText(activePrompt);trackLab3('command_copy',{target:activePrompt,label:activeCopyKind==='prompt'?'Prompt copiado':'Comando copiado'});$('copy-prompt').textContent='Copiado';$('prompt-copy-status').textContent=activeCopyKind==='prompt'?'Prompt completo copiado.':'Comando copiado.';}catch{$('prompt-copy-status').textContent='Selecciona el texto para copiarlo manualmente.';}};
function openOverview(){overview=true;render();$('overview').scrollIntoView({block:'start'});$('overview').focus();}
$('getting-started').onclick=openOverview;
$('overview-link').onclick=openOverview;
$('begin-lab').onclick=()=>{overview=false;visitLab3(index);render();$('stage').focus();};
$('term-help').onclick=()=>showHelp('Terminal de práctica','Los comandos de archivos operan sobre los materiales del laboratorio. openspec init y openspec list reproducen referencias verificadas de la CLI. La inicialización representa la selección de GitHub Copilot. Los prompts pertenecen a Copilot; no se ejecutan como Bash. Esta web no llama a un modelo ni consulta GitHub. ↑/↓ recorre el historial; Ctrl+C cancela la línea; A− y A+ ajustan la letra.');
$('explain').onclick=()=>{const stage=session.stages[index],explanation=stage.explanation;showHelp(stage.title,explanation.why,null,explanation.output,explanation.actions,{where:explanation.where,issues:explanation.issues,source:stage.source,partsTitle:'Cómo realizar este paso',expectedTitle:'Cómo comprobar el paso'});};
$('workspace').onclick=()=>showHelp('Materiales y workspace','El explorador abre directamente workshop-auth-backend y contiene los archivos de la plantilla del taller: Java, Maven, configuración y pruebas. Esta web no conecta tus repositorios locales ni incluye sus cambios de los días anteriores.',session.workspace);
$('help').addEventListener('click',event=>{if(event.target===$('help')){const r=$('help').getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)$('help').close();}});
function run(command){if(terminal?.execute(command))$('feedback').textContent='Procesando el comando…';}
async function verify(route){if(busy)return;if(shellBusy){$('feedback').textContent='Espera a que termine el comando antes de comprobar la etapa.';return;}lock(true);try{const data=await api(route,{index});session=data.session;render();$('feedback').textContent=data.result.detail;}catch(error){$('feedback').textContent=error.message;}finally{lock(false);}}
$('check').onclick=()=>verify('check');$('next').onclick=async()=>{
 if(busy||shellBusy)return;
 lock(true);
 try{
  const data=await api('complete',{index});session=data.session;
  if(index<session.stages.length-1){trackLab3('step_next',{label:'Siguiente etapa'});index++;visitLab3(index);}
  render();$('feedback').textContent=data.result.detail;
 }catch(error){$('feedback').textContent=error.message;}finally{lock(false);}
};
try{session=await api('session');fileManager=createFileManager({api,onOpen:(name,content)=>{trackLab3('file_open',{target:name,label:'Archivo abierto'});showHelp(name,'Archivo del workspace · solo lectura',content);}});terminal=createTerminal({initialSession:session,onReady:async data=>{if(data){session=data;render();if($('feedback').textContent==='Procesando el comando…')$('feedback').textContent='Revisa la salida de la terminal.';}},onBusy:value=>{shellBusy=value;lock(busy);},onError:message=>$('feedback').textContent=message,onEscapeFocus:()=>$('check').focus()});index=session.stages.findIndex((_,i)=>!session.completed[i]);if(index<0)index=session.stages.length-1;trackLab3('page_view',{label:'Laboratorio Día 3'});visitLab3(index);render();ready();}catch(error){bootError(error);}
