import {createStorage} from './storage.js';
import {LAB3_STEPS} from './catalog.js';
import {stages} from './scenario.js';
import {guideData} from './guide-data.js';
let storage,activeStep='';
let worker,key,started,serial=0,pending=new Map();
function send(route,input){return new Promise((resolve,reject)=>{const id=++serial;const timer=setTimeout(()=>{worker.terminate();for(const entry of pending.values()){clearTimeout(entry.timer);entry.reject(Error('La sesión se detuvo por tiempo. Recarga para recuperar los archivos guardados.'));}pending.clear();},10000);pending.set(id,{resolve,reject,timer,route,input,stepId:activeStep});worker.postMessage({id,route,input});});}
const phase=name=>document.dispatchEvent(new CustomEvent('lab3:loading',{detail:{phase:name}}));
async function initialize(){
 phase('account');
 const response=await fetch('/auth/session',{signal:AbortSignal.timeout(15000)});const identity=await response.json();if(!response.ok||!identity.user)throw Error('Inicia sesión con GitHub para guardar tu sesión.');
 key='bcp.lab3.original-guide.v1.user.'+identity.user.id;
 const status=document.createElement('p');status.setAttribute('role','status');status.id='lab3-save-status';status.className='command-feedback';document.getElementById('feedback').after(status);
 storage=createStorage({key,feedback:message=>status.textContent=message});
 const saved=await storage.load();
 setInterval(()=>storage.flush(),10000);window.addEventListener('online',()=>storage.flush());
 phase('files');
 const referenceResponse=await fetch('/dia-03/emulator/guide-reference.json',{signal:AbortSignal.timeout(15000)});if(!referenceResponse.ok)throw Error('No se pudieron cargar las salidas verificadas.');const reference=await referenceResponse.json();if(reference.caseId!=='lab3-original-guide-v1')throw Error('Las referencias de la guía no están disponibles. Recarga la página o vuelve a intentarlo.');
 phase('session');
 worker=new Worker('/assets/lab3/worker.bundle.js',{type:'module'});
 worker.onmessage=({data})=>{const entry=pending.get(data.id);if(!entry)return;clearTimeout(entry.timer);pending.delete(data.id);if(data.error){entry.reject(Error(data.error));return;}
  if(data.snapshot&&['exec','check','approve','complete','restore'].includes(entry.route)){
   if(entry.route==='exec'){const log=data.snapshot.history.at(-1);storage.track('command_execute',{stepId:entry.stepId,target:entry.input.command,label:'Comando ejecutado',details:JSON.stringify(log)});}
   if(['check','approve'].includes(entry.route))storage.track(entry.route==='check'?'stage_check':'stage_approve',{stepId:LAB3_STEPS[entry.input.index].id,label:data.result.result.detail,details:JSON.stringify(data.result.result)});
   storage.save(data.snapshot);
  }
  entry.resolve(data.result);
 };
 worker.onerror=()=>{for(const entry of pending.values()){clearTimeout(entry.timer);entry.reject(Error('No se pudo iniciar el entorno de práctica.'));}pending.clear();};
 await new Promise((resolve,reject)=>{const id=++serial,timer=setTimeout(()=>reject(Error('No se pudo preparar el workspace.')),10000);pending.set(id,{resolve,reject,timer,route:'restore'});worker.postMessage({id,route:'restore',reference,saved:saved||{}});});
}
export async function browserApi(route,input){started ||=initialize();await started;
 if(route.startsWith('reference?')){const index=Number(new URLSearchParams(route.split('?')[1]).get('index'));if(!Number.isInteger(index)||index<0||index>=stages.length)throw Error('Referencia inválida.');const path=stages[index].source;return {path,content:guideData.files['bcp-ai-lab-day-03/'+path]};}
 return send(route,input);
}

export function trackLab3(type,details={}){storage?.track(type,{stepId:activeStep,...details});}
export function visitLab3(index){activeStep=LAB3_STEPS[index].id;trackLab3('step_view',{label:LAB3_STEPS[index].title,target:activeStep});}
