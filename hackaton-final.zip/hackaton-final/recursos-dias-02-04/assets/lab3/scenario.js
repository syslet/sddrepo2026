import {guideData} from './guide-data.js';
export const targetRepo='workshop-auth-backend';
export const workspace='/curso/reqflow-workspace/workshop-auth-backend';
export const explorerRoot=workspace;
export const {stages,agenda}=guideData;
export function migrateSession(saved={}){
 if(saved.flowVersion===3){
  const previous='/curso/reqflow-workspace/workshop-requirements-api';
  if(saved.targetRepo===targetRepo)return saved;
  const files=Object.fromEntries(Object.entries(saved.files||{}).map(([path,text])=>[path.startsWith(previous+'/')?workspace+path.slice(previous.length):path,text]));
  return {...saved,targetRepo,cwd:saved.cwd?.startsWith(previous)?workspace+saved.cwd.slice(previous.length):saved.cwd,files:Object.keys(files).length?files:undefined};
 }
 // The previous custom exercise is not evidence for the original lab.
 return {flowVersion:3,cwd:workspace,completed:stages.map(()=>false),approved:stages.map(()=>false),history:[],evidence:{},branch:'main',staged:false,committed:false,tagged:false};
}
