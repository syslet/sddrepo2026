const $=id=>document.getElementById(id);
const parentOf=name=>name.includes('/')?name.slice(0,name.lastIndexOf('/')):'';
const basename=name=>name.split('/').at(-1);
const svg=path=>`<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true">${path}</svg>`;
const folderIcon=svg('<path d="M3 7V5a2 2 0 0 1 2-2h5l2 3h7a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z"/>');
const fileIcon=svg('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6"/>');
function icon(entry){const span=document.createElement('span');span.className='fm-icon';if(entry.kind==='directory')span.innerHTML=folderIcon;else{const ext=entry.path.split('.').at(-1).toLowerCase();span.dataset.type=ext;span.textContent=({java:'J',xml:'<>',properties:'=',py:'Py',js:'JS',ts:'TS',md:'M↓',json:'{}',yaml:'Y',yml:'Y',css:'#'})[ext]||'';if(!span.textContent)span.innerHTML=fileIcon;}return span;}
export function createFileManager({api,onOpen}){
 let entries=[],selection='',filter='',signature='';
 const expanded=new Set(['src','src/main','src/test']);
 function render(){
  const focus=document.activeElement?.dataset.path;const scroll=$('fm-tree').scrollTop;$('fm-tree').replaceChildren();const query=filter.toLowerCase();
  const results=query?entries.filter(x=>x.kind==='file'&&x.path.toLowerCase().includes(query)):entries;
  function draw(parent,depth){const nodes=query?results:results.filter(x=>parentOf(x.path)===parent).sort((a,b)=>a.kind!==b.kind?(a.kind==='directory'?-1:1):a.path.localeCompare(b.path));
   for(const item of nodes){const button=document.createElement('button');button.type='button';button.className='fm-row';button.dataset.path=item.path;button.dataset.kind=item.kind;button.style.setProperty('--depth',query?0:depth);button.setAttribute('role','treeitem');button.setAttribute('aria-level',String(depth+1));button.setAttribute('aria-selected',String(item.path===selection));button.tabIndex=item.path===selection?0:-1;button.title=item.path;if(item.kind==='directory')button.setAttribute('aria-expanded',String(expanded.has(item.path)));const chevron=document.createElement('span');chevron.className='fm-chevron';chevron.textContent=item.kind==='directory'?(expanded.has(item.path)?'⌄':'›'):'';const label=document.createElement('span');label.className='fm-name';label.textContent=query?item.path:basename(item.path);button.append(chevron,icon(item),label);
    button.onclick=()=>{selection=item.path;if(item.kind==='directory'){if(expanded.has(item.path))expanded.delete(item.path);else expanded.add(item.path);render();}else open(item.path);};button.onkeydown=event=>navigate(event,item,button);$('fm-tree').append(button);if(!query&&item.kind==='directory'&&expanded.has(item.path))draw(item.path,depth+1);
   }
  }
  draw('',0);const first=$('fm-tree').querySelector('.fm-row');if(first&&!$('fm-tree').querySelector('[tabindex="0"]'))first.tabIndex=0;if(!first){const empty=document.createElement('p');empty.className='fm-tree-empty';empty.textContent='No se encontraron archivos.';$('fm-tree').append(empty);}$('fm-tree').scrollTop=scroll;if(focus)$('fm-tree').querySelector(`[data-path="${CSS.escape(focus)}"]`)?.focus();$('fm-file-count').textContent=entries.filter(x=>x.kind==='file').length+' archivos';
 }
 function navigate(event,item,button){const rows=[...$('fm-tree').querySelectorAll('.fm-row')],i=rows.indexOf(button);let target;
  if(event.key==='ArrowDown')target=rows[i+1];else if(event.key==='ArrowUp')target=rows[i-1];else if(event.key==='Home')target=rows[0];else if(event.key==='End')target=rows.at(-1);
  else if(event.key==='ArrowRight'&&item.kind==='directory'){event.preventDefault();if(!expanded.has(item.path)){expanded.add(item.path);render();}else target=rows[i+1];}
  else if(event.key==='ArrowLeft'){event.preventDefault();if(item.kind==='directory'&&expanded.has(item.path)){expanded.delete(item.path);render();}else target=rows.find(x=>x.dataset.path===parentOf(item.path));}
  if(target){event.preventDefault();selection=target.dataset.path;rows.forEach(x=>{x.tabIndex=x===target?0:-1;x.setAttribute('aria-selected',String(x===target));});target.focus();}
 }
 async function open(name){try{const file=await api('file?name='+encodeURIComponent(name));selection=name;for(let p=parentOf(name);p;p=parentOf(p))expanded.add(p);render();onOpen(name,file.content);}catch(error){onOpen(name,error.message);}}
 function update(session){const next=session.entries||[];const key=JSON.stringify(next);if(signature!==key){signature=key;entries=next;render();}}
 $('fm-search').oninput=event=>{filter=event.target.value;render();};$('fm-collapse').onclick=()=>{expanded.clear();render();};
 setInterval(async()=>{if(document.hidden)return;try{update(await api('fs'));}catch{}},3000);
 return {update,open};
}
