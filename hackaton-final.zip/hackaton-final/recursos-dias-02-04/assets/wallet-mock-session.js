(() => {
  const section = document.querySelector('[data-mock-origin]');
  if (!section) return;
  const origin = section.dataset.mockOrigin;
  const selector = document.getElementById('mock-group');
  const status = document.getElementById('mock-session-status');
  const input = document.getElementById('mock-session-url');
  const contract = document.getElementById('mock-session-contract');
  const example = document.getElementById('mock-session-example');
  const storageKey = 'hackathon-wallet-mock-group';
  function show(group) {
    if (!/^[1-8]$/.test(group)) { document.getElementById('mock-session-result').hidden = true; status.textContent = ''; return; }
    document.getElementById('mock-session-result').hidden = false;
    const base = `${origin}/groups/${group}`;
    input.value = base;
    contract.href = `${base}/openapi.json`;
    document.getElementById('mock-group-swagger').href = `/dia-04/mocks/swagger.html?group=${group}`;
    example.textContent = [
      `curl '${base}/payments'`,
      "  -H 'Content-Type: application/json'",
      "  -H 'Idempotency-Key: prueba-001'",
      `  -d '${JSON.stringify({walletId: 'wallet-demo', recipient: 'contact-demo', amountCents: 1500, scenario: 'APPROVED'}, null, 2)}'`,
    ].join(' \\\n');
    status.textContent = `Grupo ${group}: comparte esta URL con todos sus integrantes. Los otros grupos tienen datos separados.`;
  }
  try {
    sessionStorage.removeItem('hackathon-wallet-mock-session');
    const saved = localStorage.getItem(storageKey);
    if (saved && /^[1-8]$/.test(saved)) selector.value = saved;
  } catch {}
  selector.addEventListener('change', () => {
    show(selector.value);
    try { localStorage.setItem(storageKey, selector.value); } catch {}
  });
  show(selector.value);
  document.getElementById('mock-session-copy').addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(input.value); status.textContent = `URL del grupo ${selector.value} copiada.`; }
    catch { input.focus(); input.select(); status.textContent = 'URL seleccionada. Cópiala con Ctrl+C o ⌘C.'; }
  });
})();
