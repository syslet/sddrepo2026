(async () => {
  const sections = ["antes", "s1", "s2", "s3", "w1", "handoff"];
  const labels = [
    "Antes de empezar",
    "S1 · Skills",
    "S2 · Templates",
    "S3 · MCP",
    "W1 · Evaluación",
    "Handoff al Día 3",
  ];
  const steps = [...document.querySelectorAll(".step")];
  const sectionNodes = [...document.querySelectorAll("[data-section]")];
  const status = document.getElementById("status");
  const user = await (window.labSession || Promise.resolve(null));
  const storageKey = user ? `bcp-day2-completed-${user.id}` : null;
  let completed = new Set();
  let mode = "step";
  let active = "antes";
  let currentStep = null;
  let ready = false;
  let saving = false;
  const note = document.getElementById("storage-note");
  const retry = document.createElement("button");
  retry.type = "button";
  retry.className = "btn";
  retry.textContent = "Reintentar carga";
  retry.hidden = true;
  note.after(retry);
  function controls(disabled) {
    document.getElementById('reset-progress').disabled = disabled;
    document.querySelectorAll('[data-track-action="step_next"]').forEach(link => { link.setAttribute('aria-disabled', String(disabled)); });
  }
  async function requestProgress(change) {
    const response = await fetch('/api/progress', {
      method: change ? 'PUT' : 'GET',
      credentials: 'same-origin', cache: 'no-store', signal: AbortSignal.timeout(10000),
      ...(change ? {headers:{'Content-Type':'application/json'}, body:JSON.stringify(change)} : {}),
    });
    if (!response.ok) throw new Error('progress_unavailable');
    return response.json();
  }
  function applyProgress(saved) {
    completed = new Set(saved.completed);
    document.querySelectorAll('.completion').forEach(label => {
      const done = completed.has(label.closest('.step').id);
      label.dataset.completed = String(done);
      label.textContent = done ? 'Paso completado' : 'Pendiente';
    });
    updateProgress();
    note.textContent = `Guardado en tu cuenta${saved.updatedAt ? ' · ' + new Date(saved.updatedAt).toLocaleString('es-PE') : '. Pulsa Siguiente para completar y guardar el paso.'}`;
  }
  async function loadProgress() {
    controls(true);
    retry.hidden = true;
    note.textContent = 'Cargando el avance de tu cuenta…';
    try {
      let saved = await requestProgress();
      let local = [];
      try {
        const stored = JSON.parse((storageKey && localStorage.getItem(storageKey)) || '[]');
        if (Array.isArray(stored)) local = stored.filter(id => steps.some(step => step.id === id));
      } catch { /* Cloud storage works even when local storage is unavailable. */ }
      if (!saved.updatedAt) saved = await requestProgress({import:true, completed:local});
      applyProgress(saved);
      try { if (storageKey) localStorage.removeItem(storageKey); } catch { /* Local migration is already saved remotely. */ }
      ready = true;
      controls(false);
    } catch {
      ready = false;
      note.textContent = 'No se pudo cargar tu avance. Reintenta para continuar.';
      retry.hidden = false;
    }
  }
  retry.onclick = loadProgress;
  async function save(change) {
    if (!ready || saving) return false;
    saving = true;
    controls(true);
    note.textContent = 'Guardando en tu cuenta…';
    try {
      applyProgress(await requestProgress(change));
      status.textContent = 'Avance guardado en tu cuenta.';
      controls(false);
      return true;
    } catch {
      ready = false;
      note.textContent = 'No se pudo confirmar el guardado. Reintenta la carga antes de continuar.';
      retry.hidden = false;
      status.textContent = note.textContent;
      return false;
    } finally {
      saving = false;
    }
  }
  function updateProgress() {
    document.getElementById("progress-count").innerHTML =
      `${completed.size} <span>de ${steps.length} pasos completados</span>`;
    const bar = document.getElementById("day-progress");
    bar.max = steps.length;
    bar.value = completed.size;
    document.querySelectorAll("[data-count]").forEach((el) => {
      const group = steps.filter((step) =>
        step.id.startsWith(el.dataset.count + "-"),
      );
      el.textContent = `${group.filter((step) => completed.has(step.id)).length}/${group.length}`;
      el.setAttribute("aria-label", `${el.textContent} pasos completados`);
    });
    const next = steps.find((step) => !completed.has(step.id));
    const link = document.getElementById("continue");
    link.href = next ? "#" + next.id : "#handoff";
    link.textContent = completed.size
      ? next
        ? "Continuar mi laboratorio →"
        : "Revisar el handoff →"
      : "Comenzar S1 →";

  }
  steps.forEach((step, index) => {
    const title = step.querySelector(".step-title");
    title.setAttribute("role", "heading");
    title.setAttribute("aria-level", "3");
    const group = step.closest("[data-section]");
    const position = document.createElement("p");
    position.className = "step-position";
    const siblings = [...group.querySelectorAll(".step")];
    position.textContent = `Paso ${siblings.indexOf(step) + 1} de ${siblings.length} · ${group.id.toUpperCase()}`;
    step.querySelector(".step-body").prepend(position);
    const actions = document.createElement("div");
    actions.className = "step-actions";
    const completion = document.createElement("span");
    completion.className = "completion";
    completion.textContent = "Pendiente";
    actions.append(completion);
    const previous = document.createElement("a");
    previous.className = "btn";
    previous.href = "#" + (index ? steps[index - 1].id : "antes");
    previous.textContent = "← Anterior";
    previous.dataset.trackAction = "step_previous";
    previous.dataset.trackLabel = title.textContent.trim();
    const next = document.createElement("a");
    next.className = "btn";
    const nextStep = steps[index + 1];
    next.href = "#" + (nextStep ? nextStep.id : "w1");
    next.textContent = nextStep ? "Siguiente →" : "Ir a W1 →";
    next.dataset.trackAction = "step_next";
    next.dataset.trackLabel = title.textContent.trim();
    next.addEventListener("click", async event => {
      event.preventDefault();
      if (await save({stepId:step.id, completed:true})) location.hash = next.hash;
    });
    actions.append(previous, next);
    const body = step.querySelector(".step-body");
    const content = document.createElement("div");
    content.className = "step-content";
    content.tabIndex = 0;
    content.setAttribute("role", "region");
    content.setAttribute("aria-label", "Contenido del paso: " + title.textContent.trim());
    while (body.firstChild) content.append(body.firstChild);
    body.append(content, actions);
  });
  const svgIcon = (paths) => {
    const icon = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    icon.setAttribute("viewBox", "0 0 24 24");
    icon.setAttribute("width", "16");
    icon.setAttribute("height", "16");
    icon.setAttribute("fill", "none");
    icon.setAttribute("stroke", "currentColor");
    icon.setAttribute("stroke-width", "1.7");
    icon.setAttribute("aria-hidden", "true");
    icon.innerHTML = paths;
    return icon;
  };
  const copyPaths =
    '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V4a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h4"/>';
  const checkPaths = '<path d="M5 12.5l4.5 4.5L19 7.5"/>';
  document
    .querySelectorAll(".command-list")
    .forEach((list) => list.setAttribute("role", "group"));
  document.querySelectorAll(".code, .command-row").forEach((block, index) => {
    const isCommand = block.classList.contains("command-row");
    const code = block.querySelector("pre");
    const command = code.textContent;
    const summary = command.split("\n")[0].trim();
    const idleLabel = isCommand
      ? `Copiar comando: ${summary}${command.includes("\n") ? " …" : ""}`
      : `Copiar bloque de código ${index + 1}`;
    // Command rows wrap instead of scrolling, so only the copy button needs focus.
    if (!isCommand) {
      code.tabIndex = 0;
      code.setAttribute("role", "region");
      code.setAttribute("aria-label", `Código del bloque ${index + 1}`);
    }
    const button = document.createElement("button");
    button.type = "button";
    button.className = isCommand ? "code-copy command-copy" : "btn code-copy";
    const label = document.createElement("span");
    label.className = "copy-label";
    label.textContent = "Copiar";
    button.append(svgIcon(copyPaths), svgIcon(checkPaths), label);
    button.setAttribute("aria-label", idleLabel);
    if (isCommand) button.title = "Copiar comando";
    let reset;
    const setState = (state, text) => {
      clearTimeout(reset);
      button.dataset.state = state;
      label.textContent = text;
      reset = setTimeout(() => {
        delete button.dataset.state;
        label.textContent = "Copiar";
        button.setAttribute("aria-label", idleLabel);
      }, 2400);
    };
    const ownerStep = block.closest('.step');
    const blockNumber = ownerStep ? [...ownerStep.querySelectorAll('.code, .command-row')].indexOf(block)+1 : index+1;
    const resource = `${ownerStep?.id||'guide'}:block-${blockNumber}`;
    const resourceLabel = `${ownerStep?.querySelector('.step-title')?.textContent.trim()||'Guía'} · ${isCommand ? 'Comando' : 'Código'} ${blockNumber}`;
    button.addEventListener("click", async () => {
      try {
        await navigator.clipboard.writeText(command);
        window.labTrack?.(isCommand ? "command_copy" : "code_copy", {target:resource, label:resourceLabel, stepId:ownerStep?.id||""});
        setState("copied", "Copiado");
        button.setAttribute("aria-label", isCommand ? "Comando copiado" : "Código copiado");
        // Clear first so repeating the same copy is announced again.
        status.textContent = "";
        requestAnimationFrame(() => {
          status.textContent = isCommand
            ? `Comando copiado: ${summary}`
            : "Código copiado al portapapeles.";
        });
      } catch {
        window.labTrack?.("copy_failed", {target:resource, label:resourceLabel, stepId:ownerStep?.id||""});
        setState("manual", isCommand ? "Selecciona" : "Seleccionar código");
        const selection = getSelection();
        const range = document.createRange();
        range.selectNodeContents(code);
        selection.removeAllRanges();
        selection.addRange(range);
        status.textContent =
          "No se pudo copiar. El código está seleccionado; usa Ctrl+C o ⌘C.";
      }
    });
    if (isCommand) {
      block.append(button);
    } else {
      const toolbar = document.createElement("div");
      toolbar.className = "code-tools";
      toolbar.append(button);
      block.prepend(toolbar);
    }
  });
  document
    .querySelectorAll(
      "#s1 > .panels > .panel:first-child, #s2 > .panels > .panel:first-child, #s3 > .panels > .panel:first-child",
    )
    .forEach((panel) => {
      const details = document.createElement("details");
      details.className = "materials";
      const summary = document.createElement("summary");
      summary.textContent = "Materiales y referencias de la sesión";
      const heading = panel.querySelector(".panel-label");
      heading.remove();
      details.append(summary);
      while (panel.firstChild) details.append(panel.firstChild);
      panel.append(details);
    });
  function readLocation() {
    const id = location.hash.slice(1);
    const step = steps.find((step) => step.id === id);
    if (step) {
      active = step.closest("[data-section]").id;
      currentStep = step.id;
    } else if (sections.includes(id)) {
      active = id;
      currentStep =
        steps.find(
          (step) => step.id.startsWith(id + "-") && !completed.has(step.id),
        )?.id ||
        steps.find((step) => step.id.startsWith(id + "-"))?.id ||
        null;
    } else if (id === "handoff-check") {
      active = "handoff";
      currentStep = null;
    } else if (!id) {
      active = "antes";
      currentStep = null;
    }
  }
  let lastViewed = null;
  function render(focus = false) {
    const viewed = currentStep || active;
    if (viewed !== lastViewed) {
      window.labTrack?.('step_view', {stepId:viewed,target:'#'+viewed,label:steps.find(step=>step.id===viewed)?.querySelector('.step-title')?.textContent.trim()||labels[sections.indexOf(active)]});
      lastViewed = viewed;
    }
    const all = mode === "all";
    document.documentElement.dataset.session = all ? "all" : active;
    document.querySelectorAll(".materials").forEach((details) => {
      details.open = all;
    });
    document.body.classList.toggle("all-view", all);
    document.body.classList.toggle("step-workspace", !all && Boolean(currentStep));
    document.getElementById("intro").hidden = !all && active !== "antes";
    sectionNodes.forEach((node) => {
      node.hidden =
        !all &&
        node.id !== active &&
        !(active === "handoff" && node.id === "handoff-check");
    });
    document.querySelectorAll(".section-label,.break").forEach((node) => {
      node.hidden = !all;
    });
    steps.forEach((step) => {
      step.hidden = !all && step.id !== currentStep;
    });
    document.querySelectorAll(".out-panel").forEach((panel) => {
      const group = [
        ...panel.closest("[data-section]").querySelectorAll(".step"),
      ];
      panel.hidden = !all && currentStep !== group.at(-1)?.id;
    });
    document.getElementById("current-section").textContent = all
      ? "Guía completa del Día 2"
      : labels[sections.indexOf(active)];
    document
      .getElementById("step-view")
      .setAttribute("aria-pressed", String(!all));
    document
      .getElementById("all-view")
      .setAttribute("aria-pressed", String(all));
    document.querySelectorAll(".agenda a").forEach((link) => {
      if (link.hash === "#" + active)
        link.setAttribute("aria-current", "location");
      else link.removeAttribute("aria-current");
    });
    const index = sections.indexOf(active);
    const prev = document.getElementById("section-prev");
    const next = document.getElementById("section-next");
    prev.hidden = index === 0;
    next.hidden = index === sections.length - 1;
    prev.href = "#" + sections[Math.max(0, index - 1)];
    next.href = "#" + sections[Math.min(sections.length - 1, index + 1)];
    next.textContent = `Ir a ${labels[Math.min(sections.length - 1, index + 1)]} →`;
    if (focus) {
      const target = document.getElementById(currentStep || active);
      target.setAttribute("tabindex", "-1");
      target.focus({ preventScroll: true });
      if (all || !currentStep) target.scrollIntoView({ block: "start" });
    }
    if (!all && currentStep) {
      document.getElementById(currentStep).scrollIntoView({ block: "start" });
    }
  }
  document.getElementById("step-view").onclick = () => {
    mode = "step";
    window.labTrack?.("view_mode", {target:"step",label:"Paso a paso"});
    readLocation();
    render();
  };
  document.getElementById("all-view").onclick = () => {
    mode = "all";
    window.labTrack?.("view_mode", {target:"all",label:"Todo el día"});
    render();
  };
  document.getElementById("reset-progress").onclick = () => {
    if (!confirm("¿Borrar el avance del Día 2 de tu cuenta en todos tus dispositivos?")) return;
    save({reset:true});
  };
  const mobile = matchMedia("(max-width: 800px)");
  const agenda = document.querySelector(".agenda");
  function adaptAgenda() {
    agenda.open = !mobile.matches;
  }
  adaptAgenda();
  mobile.addEventListener("change", adaptAgenda);
  document.querySelector(".agenda").addEventListener("click", (event) => {
    if (event.target.closest("a") && mobile.matches) agenda.open = false;
  });
  window.addEventListener("hashchange", () => {
    readLocation();
    render(location.hash !== "#contenido");
    if (location.hash === "#contenido") {
      const main = document.getElementById("contenido");
      main.focus({ preventScroll: true });
      main.scrollIntoView({ block: "start" });
    }
  });
  updateProgress();
  await loadProgress();
  readLocation();
  render();
})();
