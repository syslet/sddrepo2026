(() => {
  const origin = 'https://bcp-wallet-mock.yefri.workers.dev';
  const selector = document.getElementById('swagger-group');
  const status = document.getElementById('swagger-status');
  const container = document.getElementById('swagger-ui');
  const contract = document.getElementById('swagger-contract');
  const retry = document.getElementById('swagger-retry');
  const storageKey = 'hackathon-wallet-mock-group';
  let controller;

  async function load() {
    controller?.abort();
    container.replaceChildren();
    container.hidden = true;
    contract.hidden = true;
    retry.hidden = true;
    const group = selector.value;
    if (!/^[1-8]$/.test(group)) { status.textContent = 'Elige tu grupo para cargar las APIs.'; return; }
    const url = `${origin}/groups/${group}/openapi.json`;
    const request = new AbortController();
    controller = request;
    const timer = setTimeout(() => request.abort('timeout'), 20000);
    status.textContent = `Cargando APIs del grupo ${group}…`;
    const pageUrl = new URL(location.href); pageUrl.searchParams.set('group', group);
    pageUrl.hash = ''; history.replaceState(null, '', pageUrl);
    try { localStorage.setItem(storageKey, group); } catch {}
    try {
      const response = await fetch(url, {signal: request.signal});
      if (!response.ok) throw new Error(`El servicio respondió HTTP ${response.status}.`);
      const spec = await response.json();
      if (request.signal.aborted) return;
      if (typeof SwaggerUIBundle !== 'function') throw new Error('No se pudo cargar Swagger UI. Recarga la página.');
      container.hidden = false;
      window.ui = SwaggerUIBundle({
        spec, dom_id: '#swagger-ui',
        layout: 'BaseLayout', docExpansion: 'none', filter: true,
        deepLinking: false, defaultModelsExpandDepth: -1,
        supportedSubmitMethods: ['get', 'post'],
        tryItOutEnabled: false, displayRequestDuration: true,
        validatorUrl: null, queryConfigEnabled: false,
        withCredentials: false,
      });
      contract.href = url;
      contract.hidden = false;
      status.textContent = `Grupo ${group} · Contrato cargado. Despliega una sección y un endpoint para probarlo.`;
    } catch (error) {
      if (controller !== request) return;
      status.textContent = request.signal.aborted ? 'La carga tardó demasiado. Vuelve a intentarlo.' : `No se pudo cargar el contrato. ${error.message}`;
      retry.hidden = false;
    } finally { clearTimeout(timer); }
  }
  const requested = new URL(location.href).searchParams.get('group');
  if (requested && /^[1-8]$/.test(requested)) selector.value = requested;
  else if (!requested) {
    try { const saved = localStorage.getItem(storageKey); if (saved && /^[1-8]$/.test(saved)) selector.value = saved; } catch {}
  }
  selector.addEventListener('change', () => {
    const url = new URL(location.href);
    url.searchParams.set('group', selector.value);
    url.hash = '';
    location.assign(url);
  });
  retry.addEventListener('click', load);
  load();
})();
