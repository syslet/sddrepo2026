import {COMMANDS,CWD} from './sandbox-contract.js';
const get=id=>document.getElementById('sandbox-'+id);
let worker, seq=0, pending=new Map(), snapshot, key, busy=false, entries=[], historyIndex=null, historyDraft='', selectedFile=null;
function startWorker(){worker?.terminate();worker=new Worker('/assets/sandbox-worker.bundle.js',{type:'module'});worker.onmessage=({data})=>{const p=pending.get(data.id);if(!p)return;pending.delete(data.id);clearTimeout(p.timer);data.error?p.reject(Error(data.error)):p.resolve(data);};worker.onerror=()=>{for(const p of pending.values()){clearTimeout(p.timer);p.reject(Error('El motor de terminal no pudo iniciar.'));}pending.clear();};}
function send(data){return new Promise((resolve,reject)=>{const id=++seq;const timer=setTimeout(()=>{pending.delete(id);worker.terminate();reject(Error('La ejecución excedió el tiempo permitido.'));},5000);pending.set(id,{resolve,reject,timer});worker.postMessage({...data,id});});}
function renderLog(){
  const terminal=get('log');terminal.replaceChildren();
  const token=(text,className,parent)=>{const span=document.createElement('span');span.className=className;span.textContent=text;parent.append(span);};
  for(const entry of entries){
    const line=document.createElement('span');line.className='terminal-line terminal-'+entry.type;
    if(entry.type==='command'){
      token((entry.cwd || CWD).replace('/workspace/','')+' ','terminal-path',line);token('$ ','terminal-prompt',line);let first=true;
      for(const part of entry.text.match(/"(?:\\.|[^"\\])*"|'[^']*'|\s+|[^\s]+/g) || []){
        if(/^\s+$/.test(part)){line.append(document.createTextNode(part));continue;}
        const cls=first ? 'terminal-command' : /^-/.test(part) ? 'terminal-option' : /^["']/.test(part) ? 'terminal-string' : /[/]|\.md$/.test(part) ? 'terminal-path' : 'terminal-argument';
        token(part,cls,line);first=false;
      }
    }else line.textContent=entry.text;
    terminal.append(line,document.createTextNode('\n'));
  }
  terminal.scrollTop=terminal.scrollHeight;
}
function log(text,type='output'){
  entries.push({text,type,...(type==='command' ? {cwd:snapshot?.cwd || CWD} : {})});historyIndex=null;
  while(entries.length>1 && entries.reduce((sum,entry)=>sum+entry.text.length,0)>30000)entries.shift();
  renderLog();
}
function renderFiles(data) {
  const previous=new Set([...(snapshot?.state.files || []),...(snapshot?.directories || []).map(path=>path.replace(CWD+'/',''))]);
  const root=new Map();
  const insert=(path,isFile)=>{const parts=path.split('/').filter(Boolean);let level=root;for(const [index,name] of parts.entries()){if(!level.has(name))level.set(name,{name,children:new Map(),file:false});const item=level.get(name);item.fullPath=parts.slice(0,index+1).join('/');if(index===parts.length-1 && isFile){item.file=true;item.path=path;}level=item.children;}};
  for(const path of data.directories || [])insert(path.replace(CWD+'/',''),false);
  for(const path of data.state.files)insert(path,true);
  get('files').replaceChildren();
  const draw=(level,parent)=>{const list=document.createElement('ul');parent.append(list);for(const item of [...level.values()].sort((a,b)=>Number(a.file)-Number(b.file)||a.name.localeCompare(b.name))){const li=document.createElement('li');list.append(li);if(item.file){const button=document.createElement('button');button.className='sandbox-file';button.textContent=item.name;button.setAttribute('aria-label','Abrir '+item.path);button.onclick=()=>{selectedFile=item.path;showFile(data);};li.append(button);if(snapshot && !previous.has(item.path)){li.className='sandbox-file-new';const tag=document.createElement('small');tag.textContent='Creado';li.append(tag);}}else{const label=document.createElement('span');label.className='sandbox-folder';label.textContent=item.name+'/';li.append(label);if(snapshot){const exists=[...previous].some(path=>path===item.fullPath);if(!exists)label.classList.add('sandbox-folder-new');}if(item.children.size)draw(item.children,li);}}};
  if(root.size)draw(root,get('files'));else get('files').textContent='Aún no hay carpetas ni archivos del Skill. Ejecuta mkdir para empezar.';
  get('file-count').textContent=`${data.state.checks.filter(check=>check.ok).length} de ${data.state.checks.length} archivos esperados`;
}
function showFile(data){
  const path=selectedFile && CWD+'/'+selectedFile;
  if(!path || !Object.hasOwn(data.files,path)){get('file-detail').hidden=true;return;}
  get('file-detail').hidden=false;get('file-name').textContent=selectedFile;
  get('file-content').textContent=data.files[path] || 'Archivo vacío. touch lo creó sin contenido.';
}
function update(data){
  renderFiles(data);showFile(data);snapshot=data;
  get('cwd').textContent=CWD;get('prompt').textContent=data.cwd.replace('/workspace/','')+' $';
  try{localStorage.setItem(key,JSON.stringify({files:data.files,directories:data.directories,cwd:data.cwd,entries}));}catch {}
}
function lock(value){
  busy=value;get('command').readOnly=value;
  document.querySelectorAll('#sandbox-run,#sandbox-check,#sandbox-reset,#sandbox-commands button').forEach(button=>button.disabled=value);
}
function changes(before,after){
  const all=data=>new Set([...(data?.state.files || []),...(data?.directories || []).map(path=>path.replace(CWD+'/','')+'/')]);
  const old=all(before),now=all(after),created=[...now].filter(path=>!old.has(path)),removed=[...old].filter(path=>!now.has(path));
  if(created.length)return 'Creado: '+created.join(', ')+'.';
  if(removed.length)return 'Eliminado: '+removed.join(', ')+'.';
  if(Object.keys(after.files).some(path=>before?.files[path]!==after.files[path]))return 'Contenido de archivos actualizado.';
  return 'Sin cambios en archivos.';
}
async function recover(){
  const last=snapshot;startWorker();
  update(await send(last ? {type:'restore',files:last.files,directories:last.directories,cwd:last.cwd} : {type:'reset'}));
}
async function execute(command,focusInput=false){
  if(busy || !command.trim())return;
  if(command.trim()==='clear'){entries=[];renderLog();update(snapshot);get('feedback').textContent='Terminal limpia. Tus archivos se conservan.';return;}
  const before=snapshot;lock(true);log(command,'command');get('exit').textContent='Ejecutando…';get('criteria').replaceChildren();
  try{
    const data=await send({type:'exec',command});
    if(data.result.stdout)log(data.result.stdout.trimEnd());
    if(data.result.stderr)log(data.result.stderr.trimEnd(),'error');
    const silent=!data.result.stdout && !data.result.stderr;
    get('exit').textContent=data.result.exitCode===0 ? (silent?'Comando terminado sin salida.':'Comando terminado.') : data.result.stderr?'El comando falló. Revisa el error en la terminal.':`Terminó con código ${data.result.exitCode}, sin mensaje.`;
    const summary=changes(before,data);update(data);
    get('feedback').textContent=get('exit').textContent+' '+summary;
  }catch(error){
    try{await recover();get('feedback').textContent='El comando se detuvo. Se restauró tu último workspace; puedes continuar.';}
    catch{get('feedback').textContent='No se pudo recuperar la terminal. Pulsa Reintentar.';get('retry').hidden=false;}
    get('exit').textContent=error.message;
  }finally{lock(false);if(focusInput)get('command').focus({preventScroll:true});}
}
get('terminal-form').onsubmit=event=>{event.preventDefault();if(busy)return;const command=get('command').value;get('command').value='';execute(command,true);};
get('reset').onclick=async()=>{if(busy)return;lock(true);try{startWorker();entries=[];renderLog();update(await send({type:'reset'}));get('criteria').replaceChildren();get('file-detail').hidden=true;get('feedback').textContent='Terminal vacía. Vuelve a ejecutar los comandos.';get('exit').textContent='';}catch(e){get('feedback').textContent=e.message;}finally{lock(false);}};
get('check').onclick=async()=>{if(busy)return;lock(true);get('criteria').replaceChildren();try{const data=await send({type:'inspect'});update(data);for(const check of data.state.checks){const li=document.createElement('li');li.dataset.ok=check.ok;li.textContent=(check.ok?'Existe · ':'Falta · ')+check.path;get('criteria').append(li);}get('feedback').textContent=data.state.passed?'Los tres archivos existen. Has ejecutado el resultado esperado de este paso.':'Todavía faltan archivos. Revisa qué comando crea cada uno.';const response=await fetch('/api/sandbox',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({files:data.state.checks.filter(c=>c.ok).map(c=>c.path)}),signal:AbortSignal.timeout(5000)});if(!response.ok)throw Error('No se pudo guardar el resultado.');const saved=await response.json();get('status').textContent=`${saved.passed?'Archivos comprobados':'Con archivos pendientes'} · ${saved.state.attempts} intento(s)`;}catch(e){get('feedback').textContent=e.message;}finally{lock(false);}};
async function load(){get('retry').hidden=true;try{const user=await window.labSession;if(!user)throw Error('Inicia sesión para abrir la terminal.');key='bcp-terminal-'+user.id;startWorker();const res=await fetch('/api/sandbox',{credentials:'same-origin',signal:AbortSignal.timeout(5000)});if(!res.ok)throw Error('No se pudo cargar tu estado.');const saved=await res.json();get('status').textContent=`${saved.state.passed?'Última comprobación correcta':'Práctica de terminal'} · ${saved.state.attempts} intento(s)`;get('commands').replaceChildren();for(const command of [...COMMANDS,'find .github/skills -type f']){const li=document.createElement('li');const code=document.createElement('code');code.textContent=command;const button=document.createElement('button');button.className='btn';button.textContent='Ejecutar';button.setAttribute('aria-label','Ejecutar '+command);button.onclick=()=>execute(command);li.append(code,button);get('commands').append(li);}let savedFiles;try{savedFiles=JSON.parse(localStorage.getItem(key));}catch {}if(savedFiles?.files){entries=Array.isArray(savedFiles.entries) ? savedFiles.entries.filter(entry=>entry && typeof entry.text==='string' && ['command','output','error'].includes(entry.type)) : (savedFiles.log || '').replace(/^\[código de salida \d+\]\n?/gm,'').split('\n').filter(Boolean).map(text=>({text:text.startsWith('$ ') ? text.slice(2) : text,type:text.startsWith('$ ') ? 'command' : /^(touch|mkdir|find|cat|rm|ls):/.test(text) ? 'error' : 'output'}));renderLog();update(await send({type:'restore',files:savedFiles.files,directories:savedFiles.directories,cwd:savedFiles.cwd}));}else{entries=[];renderLog();update(await send({type:'inspect'}));}get('work').hidden=false;}catch(e){get('status').textContent=e.message;get('retry').hidden=false;}}
get('command').addEventListener('keydown',event=>{
  if(busy)return;
  if(event.ctrlKey && event.key.toLowerCase()==='l'){event.preventDefault();entries=[];renderLog();update(snapshot);return;}
  if(!['ArrowUp','ArrowDown'].includes(event.key))return;
  const commands=entries.filter(entry=>entry.type==='command').map(entry=>entry.text);
  if(!commands.length)return;event.preventDefault();
  if(historyIndex===null){historyIndex=commands.length;historyDraft=get('command').value;}
  historyIndex=Math.max(0,Math.min(commands.length,historyIndex+(event.key==='ArrowUp'?-1:1)));
  get('command').value=historyIndex===commands.length?historyDraft:commands[historyIndex];
});
get('log').addEventListener('click',()=>{if(!window.getSelection()?.toString())get('command').focus({preventScroll:true});});
get('retry').onclick=load;
await load();
