(() => {
const menu=document.getElementById('labs-menu');
const labsToggle=document.getElementById('labs-toggle'),labsList=document.getElementById('labs-list'),labLinks=[...labsList.querySelectorAll('a')];
for(const link of labLinks){
 if(location.pathname.startsWith(new URL(link.href).pathname)&&link.getAttribute('href')!=='/')link.setAttribute('aria-current','true');
 link.addEventListener('click',()=>setLabsMenu(false));
}
function setLabsMenu(open,{focus}={}){
 labsToggle.setAttribute('aria-expanded',String(open));labsList.hidden=!open;
 if(open&&focus!==undefined)labLinks.at(focus)?.focus();
 if(!open&&focus==='toggle')labsToggle.focus();
}
labsToggle.addEventListener('click',()=>setLabsMenu(labsList.hidden));
menu.addEventListener('keydown',event=>{
 if(event.key==='Escape'&&!labsList.hidden){event.preventDefault();setLabsMenu(false,{focus:'toggle'});return;}
 if(event.target===labsToggle&&(event.key==='ArrowDown'||event.key==='ArrowUp')){event.preventDefault();setLabsMenu(true,{focus:event.key==='ArrowDown'?0:-1});return;}
 const at=labLinks.indexOf(document.activeElement);if(at<0)return;
 const move={ArrowDown:at+1,ArrowUp:at-1,Home:0,End:labLinks.length-1}[event.key];
 if(move!==undefined){event.preventDefault();labLinks[(move+labLinks.length)%labLinks.length].focus();}
});
menu.addEventListener('focusout',event=>{if(!menu.contains(event.relatedTarget))setLabsMenu(false);});
document.addEventListener('click',event=>{if(!labsList.hidden&&!menu.contains(event.target))setLabsMenu(false);});

})();
