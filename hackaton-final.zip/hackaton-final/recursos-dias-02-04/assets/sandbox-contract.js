export const EXERCISE_ID='skill-files-v1';
export const ROOT='/workspace';
export const CWD=ROOT+'/workshop-auth-backend';
export const SKILL='.github/skills/feature-intake-spec-checklist';
export const REQUIRED=[`${SKILL}/SKILL.md`,`${SKILL}/examples/input.sample.md`,`${SKILL}/examples/output.sample.md`];
export const COMMANDS=[`mkdir -p ${SKILL}/examples`,`touch ${REQUIRED[0]}`,`touch ${REQUIRED[1]}`,`touch ${REQUIRED[2]}`];
