(() => {
  const media = matchMedia("(prefers-color-scheme: dark)");
  let preference;
  try {
    preference = localStorage.getItem("bcp-lab-theme");
  } catch {}
  function apply(theme) {
    document.documentElement.dataset.theme = theme;
    const button = document.getElementById("theme-toggle");
    if (button) {
      const label = theme === "dark" ? "Tema claro" : "Tema oscuro";
      button.textContent = label;
      button.setAttribute("aria-label", "Cambiar a " + label.toLowerCase());
    }
  }
  apply(
    preference === "light" || preference === "dark"
      ? preference
      : media.matches
        ? "dark"
        : "light",
  );
  media.addEventListener("change", () => {
    if (!preference) apply(media.matches ? "dark" : "light");
  });
  document.addEventListener("DOMContentLoaded", () => {
    apply(document.documentElement.dataset.theme);
    document.getElementById("theme-toggle")?.addEventListener("click", () => {
      preference =
        document.documentElement.dataset.theme === "dark" ? "light" : "dark";
      apply(preference);
      try {
        localStorage.setItem("bcp-lab-theme", preference);
      } catch {}
    });
  });
})();
