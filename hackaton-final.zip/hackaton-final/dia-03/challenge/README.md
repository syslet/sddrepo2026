# Challenge - Completar ReqFlow por equipo

## Objetivo

Aplicar el patrón demostrado sobre `workshop-requirements-api` a los otros componentes sin recibir una solución prescrita.

Repositorios:

```text
workshop-auth-backend
workshop-login-frontend
```

## Qué sí reutilizar

Reutiliza:

- Custom Agents;
- Skills;
- OpenSpec con su flujo estándar `spec-driven`;
- GitHub MCP oficial;
- Project ReqFlow;
- estructura de evidencia;
- human gates;
- evaluators y Definition of Done.

## Qué NO reutilizar mecánicamente

No copies hallazgos, artefactos OpenSpec, decisiones arquitectónicas, tests ni patrones de implementación sin validar contexto.

## Patrón del temario

```text
Specify -> Plan -> Tasks -> Validate
```

y durante la ejecución:

```text
routing -> evaluator -> HITL
```

## Regla OpenSpec + GitHub

```text
OpenSpec
  -> proposal
  -> specs
  -> design
  -> tasks
  -> apply

GitHub
  -> Issue
  -> Project
  -> branch
  -> PR
  -> checks
```

Usa ambos. `tasks.md` descompone el cambio OpenSpec; el GitHub Issue mantiene el trabajo comprometido y su trazabilidad dentro del producto.

## Challenge sobre `workshop-auth-backend`

Comprender y mejorar autenticación sin romper:

```text
POST /auth/login
```

La ubicación y solución concreta deben descubrirse en el código real.

## Challenge sobre `workshop-login-frontend`

Mantener login y dashboard mientras se investiga mantenibilidad, tipado, responsabilidades, sesión/renderizado, seguridad del cliente y pruebas.

No trasladar al cliente decisiones de autorización que pertenecen al servidor.

## Proceso obligatorio

```text
Discovery
 -> evidencia
 -> HITL
 -> GitHub Issue en repo correcto
 -> Project ReqFlow
 -> rama del Issue
 -> proposal + specs
 -> HITL
 -> design
 -> HITL
 -> tasks
 -> HITL
 -> characterization
 -> apply + implementación
 -> tests / evaluator
 -> PR final
 -> checks
 -> Definition of Done / HITL
```

No utilices PRs internos `copilot/*` como requisito del challenge. Si se usa una ruta alternativa desde GitHub Copilot Agents, aplica las reglas específicas de esa ruta y conserva la trazabilidad hacia el Issue/PR final.

## Integración final

Como ejercicio posterior, el equipo debería demostrar que los tres componentes continúan interoperando:

```text
login -> dashboard -> tareas -> requerimiento
```

## Personalización opcional

Después de completar el recorrido estándar, el equipo puede revisar `templates/openspec/schemas/reqflow-github/` como ejemplo de un schema donde GitHub Issues reemplazan el tracking de `tasks.md`.

## Evaluación

Se observa:

- evidencia del Discovery;
- calidad de proposal/specs/design/tasks;
- preservación funcional;
- calidad del razonamiento;
- cambios incrementales;
- testing;
- trazabilidad GitHub;
- capacidad de aceptar o rechazar sugerencias de IA con criterio.
