#!/usr/bin/env python3
"""Prepare the backend issue required by Lab 2, S3 step 4, from a student's HU."""
import argparse
import json
import re
import subprocess
import sys
import unicodedata
from pathlib import Path


def normalize(value):
    return ''.join(char for char in unicodedata.normalize('NFD', value) if not unicodedata.combining(char)).casefold()


def build_issue(text, pr=None):
    title = re.search(r'^#\s+(HU-\d+\s*[-–:].+)$', text, re.MULTILINE)
    if not title:
        raise ValueError('La HU debe empezar con # HU-01 - Título de la historia.')
    sections = {}
    current = None
    for line in text.splitlines():
        heading = re.match(r'^##\s+(.+)$', line)
        if heading:
            current = normalize(heading[1].strip())
            sections[current] = []
        elif current:
            sections[current].append(line)
    origin = '\n'.join(sections.get('origen', [])).strip()
    ids = sorted(set(re.findall(r'\bH-\d+\b', origin)))
    if not ids or re.search(r'\bH-xx\b|<[^>]+>', origin, re.IGNORECASE):
        raise ValueError('Completa Origen con el Id real de HALLAZGOS.md, por ejemplo H-01. No uses H-xx.')
    if not re.search(r'[\w./\\-]+\.[\w]+:\d+', origin):
        raise ValueError('Origen debe incluir evidencia real archivo:línea, por ejemplo src/main/java/Clase.java:42.')
    criteria = []
    for line in sections.get('criterios de aceptacion', []):
        item = re.match(r'^\s*[-*]\s+(?:\[[ xX]\]\s*)?(.+)$', line)
        if item:
            criteria.append('- [ ] ' + item[1])
    if not criteria:
        raise ValueError('La HU debe incluir ## Criterios de aceptación con una lista de criterios verificables.')
    body = '## Origen\n\n' + origin + '\n'
    context = '\n'.join(sections.get('contexto', [])).strip()
    if context:
        body += '\n## Contexto\n\n' + context + '\n'
    body += '\n## Criterios de aceptación\n\n' + '\n'.join(criteria) + '\n'
    if pr:
        body += '\n## PR de S2\n\n' + pr + '\n'
    return title[1].strip(), body, ids


def gh(*args):
    output = subprocess.run(['gh', *args], check=True, text=True, capture_output=True)
    return output.stdout.strip()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--hu', default='HU-01.md', type=Path)
    parser.add_argument('--repo', required=True, help='OWNER/workshop-auth-backend')
    parser.add_argument('--pr', help='URL del PR de S2, si existe')
    parser.add_argument('--web', action='store_true', help='Revisar duplicados y abrir el formulario de GitHub para crear el issue')
    args = parser.parse_args()
    if not re.fullmatch(r'[\w.-]+/workshop-auth-backend', args.repo) or args.repo.startswith(('TU_OWNER/', 'OWNER/')):
        parser.error('Usa tu repositorio real: TU_USUARIO/workshop-auth-backend.')
    if args.pr and not re.fullmatch(r'https://github\.com/' + re.escape(args.repo) + r'/pull/\d+', args.pr):
        parser.error('--pr debe ser un PR de GitHub del mismo backend.')
    try:
        title, body, ids = build_issue(args.hu.read_text(encoding='utf-8-sig'), args.pr)
        draft = args.hu.parent / 'ISSUE-DRAFT.md'
        if draft.exists() and draft.read_text(encoding='utf-8') != body:
            raise ValueError(f'{draft} ya existe con otro contenido. Revísalo o renómbralo antes de generar otro.')
        if not draft.exists():
            with draft.open('x', encoding='utf-8') as output:
                output.write(body)
        print(f'Título: {title}\nRepositorio: {args.repo}\nBorrador: {draft}\n\n{body}')
        if not args.web:
            print('Borrador preparado. No se creó ningún issue. Usa --web para revisar duplicados y abrir GitHub.')
            return 0
        gh('auth', 'status')
        queries = [f'"{title}" in:title', *[f'"{identifier}" in:body' for identifier in ids]]
        duplicates = {}
        for query in queries:
            matches = json.loads(gh('issue', 'list', '--repo', args.repo, '--state', 'all', '--limit', '100', '--search', query, '--json', 'number,title,url,body'))
            if len(matches) >= 100:
                raise ValueError('La búsqueda tiene demasiadas coincidencias. Revisa los issues en GitHub antes de crear otro.')
            for issue in matches:
                issue_ids = set(re.findall(r'\bH-\d+\b', issue.get('body') or ''))
                if normalize(issue['title']) == normalize(title) or issue_ids.intersection(ids):
                    duplicates[issue['number']] = issue
        if duplicates:
            print('\nYa hay issues con ese título o hallazgo. Reutiliza el que corresponda:')
            for issue in duplicates.values():
                print(issue['url'] + ' ' + issue['title'])
            return 0
        gh('issue', 'create', '--repo', args.repo, '--title', title, '--body-file', str(draft), '--web')
        print('\nGitHub abrió el formulario. Revisa el contenido y pulsa Submit new issue cuando esté correcto.')
        print('Después agrégalo al Project ReqFlow como Todo y completa Hallazgo origen con: ' + ', '.join(ids))
        return 0
    except (OSError, ValueError, subprocess.CalledProcessError) as error:
        print(f'No se creó ningún issue: {error}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
