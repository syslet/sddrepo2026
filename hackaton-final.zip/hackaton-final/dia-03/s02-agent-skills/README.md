# Módulo práctico - Agent Skills

> Este módulo complementa **S3 - model + tools + context + loop** y aporta evaluadores/procedimientos reutilizables para **S4 - routing, evaluator, HITL**.

## Objetivo

Separar el rol persistente de un Custom Agent de los procedimientos reutilizables que necesita para ejecutar tareas concretas.

## Modelo mental

```text
Agent = quién soy + límites
Skill = cómo ejecuto una práctica
Caso = qué problema resuelvo
OpenSpec = qué cambio está definido
MCP = qué sistema externo puedo operar
```

Un Skill forma parte del contexto/procedimiento del agente; no reemplaza al modelo, al Agent ni a las tools.

## Skills del caso

| Skill                        | Propósito                                                   |
|------------------------------|-------------------------------------------------------------|
| `discovery-analysis`         | estructurar el análisis de un sistema existente             |
| `spec-writing`               | materializar una necesidad o hallazgo como spec verificable |
| `architecture-decision`      | analizar impacto y registrar decisiones técnicas            |
| `issue-implementation`       | guiar una implementación acotada por Issue                  |
| `reqflow-definition-of-done` | evaluar criterios transversales de entrega de ReqFlow       |

### Convivencia con los Skills del Día 2

Los Skills del catálogo que instalaste el Día 2 (`quarkus-secure-endpoint`, `frontend-feature-generation`, `test-strategy`, `pull-request-review`…) siguen en `.github/skills/` de cada repo. No se reemplazan: los de hoy describen **procedimientos de los agentes** (discovery, specs, arquitectura, DoD) y los del Día 2 describen **cómo producir artefactos** de cada stack. El agente Developer usa ambos.

Los templates están disponibles en:

```text
templates/skills/
```

## Relación con evaluator

Algunos Skills producen trabajo; otros ayudan a **evaluarlo**. `reqflow-definition-of-done`, por ejemplo, se reutiliza al final del flujo como evaluator basado en evidencia.

```text
Agent ejecuta
-> evidencia
-> Skill/evaluator clasifica
-> humano decide
```

## Secuencia

1. [Paso 1 - Crear los Skills](STEP_1_CREATE_SKILLS.md)
2. [Paso 2 - Validar Skills y responsabilidades](STEP_2_VALIDATE_SKILLS.md)

## Criterio de salida

El participante puede explicar por qué una práctica como `spec-writing` o `discovery-analysis` se mantiene separada de la definición persistente de un Custom Agent y cómo un Skill puede aportar a un evaluator sin convertirse en el agente.
