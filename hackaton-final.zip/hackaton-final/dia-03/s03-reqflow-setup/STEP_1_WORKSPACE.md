# Paso 1 - Verificar el workspace multi-repo

## Objetivo

Confirmar que el `reqflow-workspace/` creado el Día 1 sigue siendo el contexto de producto: tres repositorios propios, publicados bajo tu owner, con el trabajo de los Días 1 y 2. Hoy **no se clonan ni se crean repositorios**.

## 1.1 Comprobar los tres repositorios propios

Desde `reqflow-workspace/`:

```powershell
foreach ($r in "workshop-login-frontend", "workshop-auth-backend", "workshop-requirements-api") {
   git -C $r remote get-url origin
   git -C $r status --short --branch
}

Cada `origin` debe apuntar a `https://github.com/<OWNER>/<repo>.git`, no a `NTTData-Academy/*-template`. El estado debe estar limpio; si hay cambios sin commit del Día 2, versionalos antes de seguir.

El resultado esperado es:

```text
<carpeta-del-curso>/
├─ bcp-ai-lab-day-01/ … 03/  # labs: fuera del workspace
└─ reqflow-workspace/        # solo el producto (VS Code se abre aquí)
  ├─ .vscode/mcp.json       # del Día 2
  ├─ workshop-login-frontend/
  ├─ workshop-auth-backend/
  └─ workshop-requirements-api/
```

## 1.2 Si no tienes el workspace

Si no hiciste los Días 1 y 2, crea los tres repos propios con el paso 1 del [README del Día 1](https://github.com/NTTData-Academy/bcp-ai-lab-day-01#cómo-empezar) (clonar la plantilla, desvincularla y publicarla bajo tu owner) y parte de la rama `checkpoint/day2` que entrega el instructor. Las plantillas del trainer no se modifican y el forking está deshabilitado.

## 1.3 Revisar lo que ya produjeron los días anteriores

Antes de usar IA, ubica en cada repo:

```text
HALLAZGOS.md          Día 1: hallazgos con Id H-xx y estado
docs/ENDPOINTS.md     Día 1: contrato documentado
docs/TESTING.md       Día 1: pruebas existentes
HU-*.md               Día 2: historias generadas desde HALLAZGOS.md
.github/skills/       Día 2: Skills del catálogo
```

Ese material es la entrada de Discovery en el paso 4: se re-verifica, no se rehace.

## 1.4 Abrir el contexto en VS Code

Puedes abrir la carpeta padre `reqflow-workspace/` o crear un multi-root workspace de VS Code.

El objetivo es poder navegar entre los tres componentes mientras conservas claro qué archivo pertenece a cada repositorio Git.

## 1.5 Identificar responsabilidades antes de usar IA

Comprueba manualmente:

```text
Frontend Angular
  -> login, sesión, dashboard, consumo de servicios

Backend Quarkus
  -> credenciales, autenticación, token

API FastAPI
  -> tareas, resumen, autorización, requerimientos
```

## 1.6 Identificar contratos protegidos

Registra como restricciones del ejercicio (contrastalas con `docs/ENDPOINTS.md` de cada repo):

```text
POST /auth/login
GET/POST /api/tasks
GET /api/summary
POST /api/requirements
```

No asumas todavía dónde existe deuda ni cuál debe corregirse.

## 1.7 Baseline

Antes de ejecutar agentes:

- identifica cómo se levanta cada componente según su README;
- registra branch y commit inicial de cada repositorio;
- confirma que cada remote `origin` apunta a tu repositorio de trabajo;
- si el entorno permite ejecutar el sistema, observa el flujo funcional antes de modificar.

## Criterio de salida

Debe poder demostrarse que:

- existen tres repositorios independientes bajo el owner del participante, con el trabajo de los Días 1 y 2;
- los clones locales no apuntan a los templates del trainer;
- los tres repositorios están disponibles en un mismo contexto de trabajo;
- el participante ubica `HALLAZGOS.md`, `docs/ENDPOINTS.md`, `docs/TESTING.md` y las HU de cada repo;
- el participante puede explicar sus responsabilidades y contratos sin depender todavía de una respuesta de IA.
