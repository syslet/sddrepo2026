# Paso 2 - Configurar GitHub MCP oficial

## Objetivo

Conectar el workspace de ReqFlow al GitHub MCP oficial con capacidades de repositorios, issues, pull requests y Projects.

## 2.1 Configuración

### Inconsistencia típica desde el Día 2

Si vienes del Día 2, tu `./reqflow-workspace/.vscode/mcp.json` puede contener servidores MCP locales (`github-local`) o una configuración sin el toolset `projects`.
En el Día 3 debes usar **solo** el servidor `github-official` y habilitar `projects`.

### Configuración requerida

Crea o actualiza `./reqflow-workspace/.vscode/mcp.json`:

```json
{
  "servers": {
    "github-official": {
      "type": "http",
      "url": "https://api.githubcopilot.com/mcp/",
      "headers": {
        "X-MCP-Toolsets": "context,repos,issues,pull_requests,projects,users"
      }
    }
  }
}
```

No incrustes tokens en el archivo.

## 2.2 Conectar

En VS Code:

1. abre Copilot Chat;
2. utiliza modo Agent;
3. comprueba que `github-official` esté conectado;
4. abre **Configure Tools**;
5. localiza las tools del GitHub MCP oficial.

## 2.3 Verificar Projects

Antes de intentar crear el Project de ReqFlow, comprueba que el toolset `projects` quedó realmente disponible.

### Verificación visual

En **Configure Tools**:

1. expande `github-official`;
2. busca tools relacionadas con GitHub Projects;
3. confirma que existen operaciones de lectura y escritura de Projects.

Según la versión de VS Code, los nombres pueden mostrarse de forma amigable o con el nombre técnico de la tool. La implementación oficial actual consolida estas capacidades en tools como:

```text
projects_list
projects_write
```

### Prueba real de lectura

Usa el **modo Agent estándar de VS Code** y ejecuta:

```text
Usando exclusivamente github-official, lista los GitHub Projects accesibles para mi usuario.

No uses terminal, GitHub CLI, web ni otras herramientas.
Indica qué tool MCP utilizaste.
```

Resultado esperado:

```text
VS Code Agent mode
  -> github-official
  -> Projects
  -> GitHub
```

No es necesario que exista todavía un Project llamado `ReqFlow`. En este punto solo estamos verificando que la capacidad de Projects está expuesta y puede consultarse mediante MCP.

Si no aparecen tools de Projects o la lectura falla por autorización, no continúes todavía con la creación del Project. Conserva el error como evidencia y revisa configuración/permisos antes de seguir.

## 2.4 Prueba de lectura de repositorio

Para esta prueba usa el **modo Agent estándar de VS Code**. No selecciones todavía ninguno de los Custom Agents (`PM/PO`, `Discovery`, `Architect` o `Developer`).

Aquí solo queremos validar que VS Code puede invocar correctamente el servidor `github-official` para consultar un repositorio real. Los roles especializados se utilizarán en los pasos posteriores, cuando ya exista una tarea propia de cada responsabilidad.

Usa repositorio explícito:

```text
Usando exclusivamente github-official, consulta información de <OWNER>/workshop-auth-backend y dime qué tool MCP utilizaste.
No uses terminal ni GitHub CLI para obtener la información de GitHub.
```

Resultado esperado:

```text
VS Code Agent mode
  -> github-official
  -> GitHub
```

La respuesta debe provenir de una tool del MCP oficial y debe indicar cuál fue utilizada.

## 2.5 Principio de seguridad

Recuerda el Día 2:

```text
Agent limita comportamiento
MCP limita tools expuestas
OAuth/scopes limitan identidad
GitHub permissions limitan recursos
Policies/rulesets gobiernan integración
```

La presencia de una tool con capacidad de escritura sobre Projects no garantiza que la identidad tenga permisos efectivos para crear o modificar Projects.

## Criterio de salida

- `github-official` aparece conectado;
- las capacidades de Projects están visibles y una lectura real funciona mediante MCP;
- una operación de lectura de repositorio se ejecuta mediante GitHub MCP usando el modo Agent estándar;
- no se utilizaron herramientas alternativas para ocultar un fallo de MCP.
