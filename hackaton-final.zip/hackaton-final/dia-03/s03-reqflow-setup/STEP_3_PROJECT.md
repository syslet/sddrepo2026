# Paso 3 - Crear el GitHub Project de ReqFlow (desde cero)

## Objetivo

Crear desde cero un GitHub Project `ReqFlow` bajo el owner del participante para coordinar trabajo ubicado en tres repositorios distintos.

## 3.1 Reutilizar el Project del Día 2

El Project `ReqFlow` ya existe: lo creaste el Día 2 (S3) con los issues de HU-01 y HU-05. **No crees otro.** Selecciona el Agent `PM/PO`:

```text
Usando exclusivamente el GitHub MCP oficial, consulta el GitHub Project "ReqFlow"
del owner <OWNER> y lista sus items: repositorio, título, estado y campo
"Hallazgo origen".

No crees ni modifiques nada todavía.
No uses terminal ni GitHub CLI.
```

Solo si no existe (no hiciste el Día 2 o partes de `checkpoint/day2`), pide su creación con la misma restricción de usar solo `github-official`, revisa la propuesta antes de autorizar la escritura y crea el campo `Hallazgo origen`. Si falla por scopes o permisos, conserva el error como evidencia y corrige la autorización antes de continuar.

## 3.2 Verificar el Project

Después de crearlo:

```text
Usando exclusivamente github-official, lista los GitHub Projects de <OWNER> y confirma el número o identificador del Project ReqFlow.
```

## 3.3 No existe "un repo principal" para el Project

El Project pertenece al producto/owner y puede coordinar items de varios repositorios.

No intentes mover el código de los tres componentes a un solo repositorio para simplificar el laboratorio.

## 3.4 Preparar la trazabilidad

Todavía no crees una lista masiva de issues.

El siguiente paso será:

```text
Discovery de los 3 repos
 -> hallazgos candidatos
 -> revisión humana
 -> selección de algunos
 -> issues en el repo correcto
 -> agregar esos issues a ReqFlow
```

## Nota sobre Projects

El GitHub MCP oficial implementa actualmente operaciones consolidadas de Projects. La tool de escritura puede incluir operaciones como crear Project, agregar items y actualizar items.

No memorices nombres internos de campos o IDs si la tool puede resolverlos. Observa siempre el esquema que VS Code muestra en el momento de la ejecución.

## Criterio de salida

Existe un GitHub Project `ReqFlow`, creado o consultado mediante GitHub MCP oficial, y todavía no se ha confundido el Project de producto con ninguno de los tres repositorios de implementación.
