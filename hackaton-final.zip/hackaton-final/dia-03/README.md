# BCP AI Lab - Día 3

## SDD + Fundamentos de Agentes sobre ReqFlow

Este repositorio contiene el Día 3 del workshop. Está pensado para una persona que entra por primera vez y necesita saber qué abrir, qué preparar y qué ejecutar.

Stack de IA del programa (los 4 días): **VS Code + GitHub Copilot en modo Agent**. Los Custom Agents (`.agent.md`), Skills (`.github/skills/`) y `mcp.json` del Día 2 solo los descubre Copilot.

## Objetivo del día

Gobernar un cambio real sobre tu backlog del Día 2 con Spec Driven Development: partir de `HALLAZGOS.md` y los issues existentes del Project ReqFlow (sin duplicar), definir specs con `docs/ENDPOINTS.md` como baseline, caracterizar reutilizando `docs/TESTING.md`, y operar con Custom Agents y Skills versionados. Cierras con el tag `day3-done` y `check_handoff.py --day 3` en verde: eso es la entrada del Día 4.

## Empieza aquí

1. Abre [laboratory-guide.html](laboratory-guide.html) si quieres una ruta visual.
2. Lee [STEP-BY-STEP.md](STEP-BY-STEP.md) para preparar el entorno y seguir el recorrido.
3. Consulta [el contexto vigente del producto](s03-reqflow-setup/CASE.md) para contratos, restricciones y DoD de tu ReqFlow.
4. Sigue las sesiones en orden: **S1 -> S2 -> S3 -> S4** (ver tabla de sesiones y módulos abajo).

No necesitas leer todos los documentos antes de comenzar.

ReqFlow no es un caso nuevo: es **tu producto** de los Días 1 y 2 (tres repos propios + Project ReqFlow). El sistema ya funciona; el objetivo no es reconstruirlo desde cero, sino comprenderlo, gobernar cambios asistidos por IA y demostrar un ciclo de Spec Driven Development sobre un cambio real de tu backlog.

## Sesiones y módulos

Los nombres de las sesiones se mantienen alineados con el temario oficial. Las carpetas `s01` a `s04` son **módulos prácticos**: no reemplazan los nombres S1-S4 y algunos aportan a más de una sesión. El detalle de cada módulo vive en su README.

| Sesión (temario) | Módulo | Aporte + guía |
| --- | --- | --- |
| S1 - OpenSpec / Spec Kit + Constitution | [`s04-openspec-sdd/`](s04-openspec-sdd/README.md) | Definición técnica + contrato |
| S2 - Specify -> Plan -> Tasks -> Validate | [`s04-openspec-sdd/`](s04-openspec-sdd/README.md) | Spec-to-tasks: proposal, design, tasks, apply |
| S3 - Fundamentos: model + tools + context + loop | [`s01-custom-agents/`](s01-custom-agents/README.md), [`s02-agent-skills/`](s02-agent-skills/README.md), [`s03-reqflow-setup/`](s03-reqflow-setup/README.md) | Roles, procedimientos y setup sobre tu producto |
| S4 - Patrones: routing, evaluator, HITL | [`s01-custom-agents/`](s01-custom-agents/README.md), [`s02-agent-skills/`](s02-agent-skills/README.md), [`s04-openspec-sdd/`](s04-openspec-sdd/README.md) | Routing, review gates y decisión humana |
| Challenge | [`challenge/`](challenge/README.md) | Mismo patrón en `workshop-auth-backend` y `workshop-login-frontend` |

## Continuidad con Día 2

### Entrada del día

El Día 3 **no parte de cero**: trabaja sobre el mismo `reqflow-workspace/` y el mismo Project de los días anteriores. Antes de S1, verifica desde la carpeta del laboratorio:

```powershell
python tools/check_handoff.py --day 2 ../reqflow-workspace
```

| Viene de | Artefacto | Se usa en |
| --- | --- | --- |
| Día 1 | `<OWNER>/workshop-*` (3 repos propios) | `s03` paso 1: se verifican, no se crean |
| Día 1 | `HALLAZGOS.md` (Id `H-xx`) | `s03` paso 4: Discovery re-verifica en vez de empezar de cero |
| Día 1 | `docs/ENDPOINTS.md` | `s04` paso 1: baseline de comportamiento a preservar en las specs |
| Día 1 | `docs/TESTING.md` | `s04` paso 3: pruebas de caracterización que ya existen |
| Día 2 | Project `ReqFlow` + issues de HU-01/HU-05 | `s03` pasos 3 y 4: se reutilizan y se completa el backlog |
| Día 2 | Skills del catálogo en `.github/skills/` de cada repo | `s01`/`s02`: los usa el agente Developer |
| Día 2 | `.vscode/mcp.json` con `github-official` | `s01`: se agrega el toolset `projects` |

Si el chequeo falla, parte de la rama `checkpoint/day2` que entrega el instructor.

El Día 2 cerró con:

```text
Modelo -> MCP -> GitHub
```

El Día 3 agrega especialización, contexto y un proceso explícito para trabajar con especificaciones:

```text
Modelo
  -> Custom Agent
  -> Agent Skill / OpenSpec workflow
  -> GitHub MCP oficial
  -> GitHub
  -> evidencia
  -> decisión humana
```

## Referencias

- [Contexto vigente del producto](s03-reqflow-setup/CASE.md): contratos, restricciones y DoD de tu ReqFlow.
- [Guía de inicio y recorrido](STEP-BY-STEP.md): entorno y orden de ejecución.

## Cierre del día: handoff al Día 4

El Día 4 automatiza este mismo ciclo con agentes programáticos sobre **tu** backlog. Antes de salir, deja en `workshop-auth-backend`:

- `openspec/specs/` y `openspec/changes/<CHANGE_NAME>/` aprobados (el Día 4 los usa como contrato);
- `.github/agents/` y `.github/skills/` versionados en `main`;
- el PR del Issue guiado con su tabla de Definition of Done;
- en el Project ReqFlow, al menos un issue más en estado `Todo` para que lo tome el agente del Día 4;
- el tag `day3-done` (`git tag day3-done && git push --follow-tags`).

Verifica desde la carpeta del laboratorio:

```powershell
python tools/check_handoff.py --day 3 ../reqflow-workspace
```

Rúbrica: [EVALUACION-D3.md](EVALUACION-D3.md).

## Principio del día

```text
Primero comprender.
Después especificar.
Luego planificar, proteger e implementar.
Siempre demostrar con evidencia.
```

La IA propone y acelera; OpenSpec estructura el cambio; GitHub organiza el trabajo del producto; los evaluadores y gates humanos deciden qué avanza.
