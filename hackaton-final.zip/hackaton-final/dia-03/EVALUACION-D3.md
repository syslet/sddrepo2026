# Evaluación D3 — Agents + SDD

Puerta de entrada: `check_handoff.py --day 2` en verde (apto / no apto, no puntúa). Umbral de salida: **promedio ponderado ≥ 8.0** + tag `day3-done`.

| # | Criterio | Peso | Aprueba (≥ 8) si… | Evidencia |
|---|---|---|---|---|
| 1 | Output | 30% | `openspec/specs/` + `changes/<CHANGE>/` aprobados, `.github/agents/` y `.github/skills/` versionados en `main`, PR del issue guiado con DoD, ≥1 issue en `Todo`; commit + tag `day3-done` | `check_handoff.py --day 3` en verde, PR |
| 2 | Contenido | 30% | Specs con `ENDPOINTS.md` como baseline; caracterización que reutiliza `TESTING.md`; sin issues duplicados (deduplicación por `Hallazgo origen`) | Specs, tests de caracterización |
| 3 | Trazabilidad | 20% | Hallazgo → issue → spec → PR encadenados con `H-xx` y `Closes`; sin backlog creado de cero existiendo el del D2 | Issues, specs, rama del issue |
| 4 | Criterio humano | 20% | Revisiones humanas registradas antes de aceptar specs, diseño, tareas e integración (HITL); Custom Agent correcto para cada fase | Gates humanos en el flujo |

Escala por criterio: 0 ausente · 1–3 parcial · 4–5 básico · 6–7 sólido · 8–10 ejemplar y verificable.
