#!/usr/bin/env bash
# ============================================================================
# Automatizacion COMPLETA del MCP del Dia 2 (BCP AI Lab - s3_mcp).
#
# A diferencia del resto del toolkit (que es generico y lo corre el admin UNA
# vez por laptop, antes de que llegue el alumno), este script SI necesita
# datos propios del alumno: su owner/repo de GitHub y su sesion de
# 'gh auth login'. Por eso es un script aparte, pensado para correrse por
# cada alumno (o por el instructor, una vez por alumno) cuando llega al Paso
# 1 de s3_mcp — reemplaza tener que seguir a mano STEP_1.md y STEP_2.md.
#
# Hace, en orden:
#   1. Construye las imagenes del MCP local (reusa 04-prebuild-mcp-images.sh).
#   2. Pide (o recibe por flag) GITHUB_OWNER/GITHUB_REPO y asegura 'gh auth'
#      (incluye el scope 'project').
#   3. Levanta el servicio con Podman/Docker Compose en segundo plano y lo
#      deja CORRIENDO en http://localhost:8081/mcp.
#   4. Configura Visual Studio Code automaticamente:
#        - settings de usuario: chat.agent.enabled, chat.mcp.access,
#          chat.mcp.discovery.enabled
#        - servidores MCP del perfil de usuario, via 'code --add-mcp'
#        - reqflow-workspace/.vscode/mcp.json (servers: github-local y
#          github-official), igual a lo que pide STEP_2.md del lab
#   5. Instala y configura MCP Inspector (reusa 05-setup-mcp-inspector.sh),
#      con su catalogo ya apuntando al servidor que acaba de quedar corriendo.
#      Abre una terminal para logs del MCP y otra para ejecutar el Inspector.
#
# Uso:
#   ./bootstrap.sh day02-mcp --owner <OWNER> --repo <REPO>
#   ./bootstrap.sh day02-mcp                      (pregunta owner/repo por teclado)
#
# Flags: --owner, --repo, --engine podman|docker, --skip-vscode, --skip-inspector, --no-terminals
# Variables de entorno: COURSE_DIR, WORKSPACE_DIR, GITHUB_OWNER, GITHUB_REPO.
# Idempotente: si el contenedor ya esta corriendo con el mismo owner/repo, no
# lo reconstruye; si cambias owner/repo, lo reinicia con los datos nuevos.
# ============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../lib/common.sh"
refresh_path

OWNER="${GITHUB_OWNER:-}"
REPO="${GITHUB_REPO:-}"
ENGINE_OVERRIDE=""
SKIP_VSCODE=""
SKIP_INSPECTOR=""
NO_TERMINALS=""

while [ $# -gt 0 ]; do
  case "$1" in
    --owner) OWNER="$2"; shift 2 ;;
    --repo) REPO="$2"; shift 2 ;;
    --engine) ENGINE_OVERRIDE="$2"; shift 2 ;;
    --skip-vscode) SKIP_VSCODE=1; shift ;;
    --skip-inspector) SKIP_INSPECTOR=1; shift ;;
    --no-terminals) NO_TERMINALS=1; shift ;;
    *) shift ;;
  esac
done

if ! has_cmd gh; then
  err "GitHub CLI (gh) no esta en PATH. Corre primero: ./bootstrap.sh tools"
  return 1
fi

ENGINE="${ENGINE_OVERRIDE:-$(container_engine)}"
if [ -z "$ENGINE" ]; then
  err "No se encontro podman ni docker. Corre primero: ./bootstrap.sh tools && ./bootstrap.sh podman"
  return 1
fi
info "Motor de contenedores: $ENGINE"

# El login debe preceder al clonado de un laboratorio privado.
info "Verificando acceso a GitHub..."

if gh_logged_in; then
  ok "Sesion de GitHub CLI activa ($(gh api user --jq .login 2>/dev/null))"
else
  warn "No hay sesion activa funcional de GitHub CLI."
  info "Iniciando 'gh auth login' (sigue las instrucciones que aparezcan en pantalla)..."
  gh auth login || { err "No se pudo autenticar con GitHub CLI."; return 1; }
fi

ensure_lab_repo "02" || return 1
info "=== Paso 1/5: imagenes del MCP local (Dia 2) ==="
source "$SCRIPT_DIR/04-prebuild-mcp-images.sh" --day 02 --engine "$ENGINE" \
  || { err "No se pudieron preparar las imagenes del MCP."; return 1; }
MCP_LOCAL_DIR="$COURSE_DIR/bcp-ai-lab-day-02/s3_mcp/tools/mcp-local"
if [ ! -f "$MCP_LOCAL_DIR/compose.yaml" ]; then
  err "No se encontro $MCP_LOCAL_DIR/compose.yaml. Verifica COURSE_DIR."
  return 1
fi

info "=== Paso 2/5: datos de GitHub del alumno ==="
if gh_has_scope project; then
  ok "El token activo ya tiene el scope 'project'."
else
  info "Asegurando el scope 'project' en el token (requerido por GitHub Projects)..."
  gh auth refresh -s project || warn "No se pudo refrescar el scope 'project' automaticamente. Si falla mas adelante: gh auth refresh -s project"
fi

if [ -z "$OWNER" ]; then
  OWNER="$(gh_current_login)"
  if [ -n "$OWNER" ]; then
    ok "GitHub owner detectado automaticamente: $OWNER (cuenta activa de gh auth)"
  else
    warn "No se pudo detectar el owner automaticamente."
    read -r -p "GitHub owner: " OWNER
  fi
fi

if [ -z "$REPO" ]; then
  info "Buscando repos propios del workshop bajo $OWNER (viven en tu cuenta personal, no en un org)..."
  CANDIDATES=()
  for name in workshop-auth-backend workshop-login-frontend workshop-requirements-api; do
    if gh_repo_exists "$OWNER/$name"; then
      CANDIDATES+=("$name")
      ok "  encontrado: $OWNER/$name"
    fi
  done

  if [ "${#CANDIDATES[@]}" -eq 1 ]; then
    REPO="${CANDIDATES[0]}"
    ok "Usando automaticamente: $REPO (el unico repo propio del workshop detectado bajo $OWNER)"
  elif [ "${#CANDIDATES[@]}" -gt 1 ]; then
    log "Se encontraron varios repos propios del workshop bajo $OWNER:"
    idx=1
    for c in "${CANDIDATES[@]}"; do log "  $idx) $c"; idx=$((idx+1)); done
    read -r -p "Elige un numero, o escribe otro nombre de repo [1]: " SEL
    SEL="${SEL:-1}"
    case "$SEL" in
      ''|*[!0-9]*) REPO="$SEL" ;;
      *)
        if [ "$SEL" -ge 1 ] 2>/dev/null && [ "$SEL" -le "${#CANDIDATES[@]}" ] 2>/dev/null; then
          REPO="${CANDIDATES[$((SEL-1))]}"
        else
          REPO="$SEL"
        fi
        ;;
    esac
  else
    warn "No se encontro ninguno de tus 3 repos del workshop (workshop-auth-backend, workshop-login-frontend, workshop-requirements-api) bajo $OWNER."
    warn "¿Ya completaste el Dia 1 (clonar y publicar tus 3 repos propios)? Si tu owner es otro, pasa --owner <OWNER>."
    read -r -p "Nombre del repositorio a usar para probar el MCP: " REPO
  fi
fi

if [ -z "$OWNER" ] || [ -z "$REPO" ]; then
  err "Owner y Repo son obligatorios para levantar el MCP."
  return 1
fi

TOKEN="$(gh auth token)"
if [ -z "$TOKEN" ]; then
  err "No se pudo obtener el token con 'gh auth token'. Ejecuta: gh auth login"
  return 1
fi
ok "Usando GITHUB_OWNER=$OWNER GITHUB_REPO=$REPO"

# ---------- Paso 3/5: levantar el servicio ----------
info "=== Paso 3/5: servicio MCP (puerto 8081) ==="
export GITHUB_TOKEN="$TOKEN" GITHUB_OWNER="$OWNER" GITHUB_REPO="$REPO"

check_endpoint() {
  local url="$1" status client
  if has_cmd curl.exe; then client=curl.exe; elif has_cmd curl; then client=curl; else client=""; fi
  if [ -n "$client" ]; then
    # Un GET SSE puede agotar el tiempo despues de recibir HTTP 200.
    status="$("$client" --connect-timeout 2 --max-time 3 -s -o /dev/null -w '%{http_code}' "$url" 2>/dev/null)" || true
  elif has_cmd powershell; then
    status="$(powershell -NoProfile -NonInteractive -Command "try { (Invoke-WebRequest -Uri '$url' -UseBasicParsing -TimeoutSec 3).StatusCode } catch { if (\$_.Exception.Response) { \$_.Exception.Response.StatusCode.value__ } else { '' } }" 2>/dev/null | tr -d '\r')" || return 1
  else
    return 1
  fi
  # GET sin sesion/Accept puede devolver 400, 405 o 406 en un endpoint MCP sano.
  case "$status" in 200|400|405|406) printf '%s' "$status" ;; *) return 1 ;; esac
}

# Estado de la ultima ejecucion exitosa (owner/repo usados), para decidir si
# el contenedor que ya esta corriendo sirve tal cual o hay que reconfigurarlo.
STATE_FILE="$MCP_LOCAL_DIR/.workshop-bootstrap-last-run"
PREV_OWNER=""; PREV_REPO=""
if [ -f "$STATE_FILE" ]; then
  PREV_OWNER="$(grep -o 'OWNER=.*' "$STATE_FILE" 2>/dev/null | cut -d= -f2-)"
  PREV_REPO="$(grep -o 'REPO=.*' "$STATE_FILE" 2>/dev/null | cut -d= -f2-)"
fi

CURRENT_STATUS="$(check_endpoint "http://localhost:8081/mcp")" || CURRENT_STATUS=""
if [ -n "$CURRENT_STATUS" ] && [ "$PREV_OWNER" = "$OWNER" ] && [ "$PREV_REPO" = "$REPO" ]; then
  ok "El servicio MCP ya esta corriendo y respondiendo con el mismo owner/repo ($OWNER/$REPO). Se omite relanzarlo."
else
  if [ -n "$CURRENT_STATUS" ]; then
    warn "El servicio ya esta corriendo pero con datos distintos (antes: ${PREV_OWNER:-?}/${PREV_REPO:-?}, ahora: $OWNER/$REPO). Reconfigurando con los datos correctos..."
  else
    info "El servicio no esta corriendo todavia. Levantandolo..."
  fi
  if (cd "$MCP_LOCAL_DIR" && $ENGINE compose --in-pod false up -d --build 2>/dev/null) \
     || (cd "$MCP_LOCAL_DIR" && $ENGINE compose up -d --build); then
    ok "Servicio MCP levantado (segundo plano)."
  else
    err "No se pudo levantar el servicio MCP con '$ENGINE compose'. Revisa los logs."
    return 1
  fi

  info "Esperando a que http://localhost:8081/mcp responda..."
  READY=""
  for i in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15; do
    READY="$(check_endpoint "http://localhost:8081/mcp")" || READY=""
    [ -n "$READY" ] && break
    sleep 2
  done
  if [ -n "$READY" ]; then
    ok "Servicio MCP respondiendo en http://localhost:8081/mcp (HTTP $READY)"
    printf 'OWNER=%s\nREPO=%s\n' "$OWNER" "$REPO" > "$STATE_FILE"
  else
    err "El endpoint MCP no respondio correctamente. Revisa logs con: $ENGINE compose -f \"$MCP_LOCAL_DIR/compose.yaml\" logs"
    return 1
  fi
fi

# ---------- Paso 4/5: configurar VS Code ----------
if [ -n "$SKIP_VSCODE" ]; then
  warn "Configuracion de VS Code omitida (--skip-vscode)."
else
  info "=== Paso 4/5: configurando Visual Studio Code ==="
  if has_cmd code; then
    info "Agregando servidores MCP al perfil de usuario de VS Code (code --add-mcp)..."
    code --add-mcp "{\"name\":\"github-local\",\"type\":\"http\",\"url\":\"http://localhost:8081/mcp\"}" >/dev/null 2>&1 \
      && ok "github-local agregado al perfil de usuario." \
      || warn "No se pudo agregar github-local via 'code --add-mcp' (puede que ya exista)."
    code --add-mcp "{\"name\":\"github-official\",\"type\":\"http\",\"url\":\"https://api.githubcopilot.com/mcp/\"}" >/dev/null 2>&1 \
      && ok "github-official agregado al perfil de usuario." \
      || warn "No se pudo agregar github-official via 'code --add-mcp' (puede que ya exista)."

    VSCODE_SETTINGS="$(vscode_user_settings_path)"
    if [ -n "$VSCODE_SETTINGS" ]; then
      info "Asegurando settings de Copilot/MCP en $VSCODE_SETTINGS ..."
      ensure_json_keys "$VSCODE_SETTINGS" '{"chat.agent.enabled": true, "chat.mcp.access": true, "chat.mcp.discovery.enabled": true}' \
        && ok "Settings de usuario de VS Code listos." \
        || warn "No se pudieron escribir los settings de usuario de VS Code."
    fi
  else
    warn "'code' no esta en PATH; no se pudo configurar VS Code automaticamente via CLI. Instala VS Code y agrega 'code' al PATH (Shell Command: Install 'code' command in PATH)."
  fi

  if [ -d "$WORKSPACE_DIR" ]; then
    info "Escribiendo $WORKSPACE_DIR/.vscode/mcp.json (servers: github-local, github-official)..."
    mkdir -p "$WORKSPACE_DIR/.vscode"
    force_json_servers "$WORKSPACE_DIR/.vscode/mcp.json" "servers" \
      '{"github-local": {"type": "http", "url": "http://localhost:8081/mcp"}, "github-official": {"type": "http", "url": "https://api.githubcopilot.com/mcp/", "headers": {"X-MCP-Toolsets": "context,repos,issues,pull_requests,projects,users"}}}' \
      && ok ".vscode/mcp.json listo en el workspace (y corregido si tenia valores distintos)." \
      || warn "No se pudo escribir .vscode/mcp.json en el workspace."
  else
    warn "No existe $WORKSPACE_DIR todavia (se crea en el Dia 1, Paso 1). Cuando exista, vuelve a correr este script y se configurara ahi tambien."
  fi
fi

# ---------- Paso 5/5: MCP Inspector ----------
if [ -n "$SKIP_INSPECTOR" ]; then
  warn "MCP Inspector omitido (--skip-inspector)."
else
  info "=== Paso 5/5: MCP Inspector ==="
  source "$SCRIPT_DIR/05-setup-mcp-inspector.sh" || return 1
fi

if [ -z "$NO_TERMINALS" ]; then
  source "$SCRIPT_DIR/../lib/mcp-terminals.sh"
  open_mcp_terminals || return 1
else
  info "Apertura de terminales omitida (--no-terminals)."
fi

ok "Dia 2 - MCP disponible en http://localhost:8081/mcp."
log ""
log "Verificaciones utiles:"
log "  $ENGINE ps --filter publish=8081"
log "  npx @modelcontextprotocol/inspector --cli --server-url http://localhost:8081/mcp --transport http --method tools/list"
log "En VS Code: recarga la ventana (Developer: Reload Window), abre Copilot Chat -> modo Agent -> Configure Tools,"
log "y confirma que aparece el grupo de 'github-local' (y 'github-official')."
