#!/usr/bin/env python3
"""Prueba curl | bash con HTTP local y pasos sustitutos, sin instalar herramientas."""
import functools
import hashlib
import http.server
import os
from pathlib import Path
import select
import shutil
import subprocess
import tarfile
import tempfile
import threading
import time


ROOT = Path(__file__).resolve().parent.parent


class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *_args):
        pass


def build(project, output):
    subprocess.run(
        ["bash", str(project / "scripts/build-release.sh"), str(output)],
        check=True, capture_output=True, text=True,
    )


def verify_terminal(url, env):
    # Una terminal real comprueba que read no recibe el EOF del pipe de curl.
    import pty

    pid, terminal = pty.fork()
    if pid == 0:
        os.execvpe("bash", ["bash", "-c",
                   'set -o pipefail; curl -fsSL "$1/install.sh" | bash -s -- day02-mcp',
                   "verify", url], dict(env, VERIFY_PROMPT="yes"))
    output = b""
    answered = False
    try:
        deadline = time.monotonic() + 15
        while time.monotonic() < deadline:
            if not select.select([terminal], [], [], 0.2)[0]:
                continue
            try:
                chunk = os.read(terminal, 4096)
            except OSError:
                break
            if not chunk:
                break
            output += chunk
            if b"VERIFY_PROMPT>" in output and not answered:
                os.write(terminal, b"respuesta desde terminal\n")
                answered = True
        else:
            os.kill(pid, 9)
            raise AssertionError("Timeout de entrada interactiva")
    finally:
        os.close(terminal)
        _, status = os.waitpid(pid, 0)
    assert answered and status == 0, output.decode(errors="replace")


def main():
    subprocess.run(["python3", str(ROOT / "scripts/verify-terminal.py")], check=True)
    subprocess.run(["python3", str(ROOT / "scripts/verify-mcp-terminals.py")], check=True)
    subprocess.run(["python3", str(ROOT / "scripts/verify-workshop.py")], check=True)
    with tempfile.TemporaryDirectory(prefix="verify-workshop-") as temporary:
        work = Path(temporary)
        # Comprueba el paquete real y sus scripts sin ejecutarlos.
        build(ROOT, work / "real-release")
        with tarfile.open(work / "real-release/workshop-bootstrap.tar.gz") as archive:
            for member in archive.getmembers():
                if member.name.endswith(".sh"):
                    content = archive.extractfile(member).read()
                    assert b"\r\n" not in content, member.name
                    assert member.mode & 0o100, member.name

        fixture = work / "fixture"
        (fixture / "scripts").mkdir(parents=True)
        (fixture / "lib").mkdir()
        (fixture / "config").mkdir()
        shutil.copy(ROOT / "bootstrap.sh", fixture / "bootstrap.sh")
        shutil.copy(ROOT / "install.sh", fixture / "install.sh")
        shutil.copy(ROOT / "scripts/build-release.sh", fixture / "scripts/build-release.sh")
        (fixture / "README.md").write_text("Fixture de verificacion\n")
        (fixture / "lib/common.sh").write_text(
            'info() { :; }; ok() { :; }; err() { echo "$*" >&2; }\n'
            'gh_logged_in() { [ "${VERIFY_LOGGED_IN:-yes}" = yes ]; }\n'
        )
        shutil.copy(ROOT / "lib/windows_terminal.py", fixture / "lib/windows_terminal.py")
        shutil.copy(ROOT / "lib/mcp-terminals.sh", fixture / "lib/mcp-terminals.sh")
        shutil.copy(ROOT / "lib/open-terminal.ps1", fixture / "lib/open-terminal.ps1")
        shutil.copy(ROOT / "lib/workshop.sh", fixture / "lib/workshop.sh")
        (fixture / "bin").mkdir()
        cygpath = fixture / "bin/cygpath"
        cygpath.write_text(
            '#!/usr/bin/env bash\n'
            'if [ "${@: -1}" = \'C:\\Users\\Usuario\\Documents\\bcp-ai-labs\' ]; then\n'
            '  printf "%s\\n" "$VERIFY_DEFAULT_DOCUMENTS"\n'
            'else printf "%s\\n" "${@: -1}"; fi\n'
        )
        cygpath.chmod(0o755)
        gh = fixture / "bin/gh"
        gh.write_text('#!/usr/bin/env bash\nprintf "%s\\n" "gh $*" >> "$VERIFY_LOG"\nexit "${VERIFY_LOGIN_EXIT:-0}"\n')
        gh.chmod(0o755)
        (fixture / "config/inspector-catalog.json.template").write_text("{}\n")
        steps = sorted(path.name for path in (ROOT / "scripts").glob("[0-9]*.sh"))
        for step in steps:
            (fixture / "scripts" / step).write_text(
                ('# WORKSHOP_PYTHON313_V1\n' if step == '01-install-tools.sh' else '') +
                f'printf "%s\\n" "{step} $*" >> "$VERIFY_LOG"\n'
                f'[ "${{VERIFY_FAIL_STEP:-}}" != "{step}" ] || return 7\n'
                'if [ "${VERIFY_PROMPT:-}" = yes ]; then\n'
                '  printf "VERIFY_PROMPT>"\n'
                '  read -r answer || return 1\n'
                '  printf "%s\\n" "$answer" >> "$VERIFY_LOG"\n'
                'fi\n'
                'return 0\n'
            )
        web = work / "web"
        build(fixture, web)
        server = http.server.ThreadingHTTPServer(
            ("127.0.0.1", 0), functools.partial(QuietHandler, directory=str(web))
        )
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            url = f"http://127.0.0.1:{server.server_port}"
            destination = work / "toolkit con espacios"
            log = work / "steps.log"
            env = dict(os.environ, OSTYPE="msys", VERIFY_LOG=str(log),
                       VERIFY_DEFAULT_DOCUMENTS=str(work / "Users/Usuario/Documents/bcp-ai-labs"),
                       PATH=str(fixture / "bin") + os.pathsep + os.environ["PATH"],
                       COURSE_DIR=str(work / "curso con espacios"),
                       WORKSHOP_INSTALL_DIR=str(destination), WORKSHOP_DOWNLOAD_BASE_URL=url)

            def run(*args, changes=None, expected=0):
                result = subprocess.run(
                    ["bash", "-c", 'set -o pipefail; curl -fsSL "$1/install.sh" | bash -s -- "${@:2}"',
                     "verify", url, *args],
                    env=dict(env, **(changes or {})), capture_output=True, text=True,
                    start_new_session=True, timeout=30,
                )
                assert result.returncode == expected, (result.returncode, result.stdout, result.stderr)
                return result

            help_result = run("--help", changes={"OSTYPE": "darwin"})
            assert "Sin argumentos muestra esta ayuda" in help_result.stdout
            for command in ("check", "tools", "terminal", "day01", "day02", "podman", "labs", "python-envs", "mcp-images", "inspector", "warm-cache", "day02-mcp", "all"):
                assert any(line.strip().startswith(command + " ") for line in help_result.stdout.splitlines())
            assert help_result.stdout.count("curl -fsSL") == 3
            for command in ("OPCION", "check", "tools"):
                assert f"curl -fsSL {url}/install.sh | bash -s -- {command}\n" in help_result.stdout
            default_result = run(changes={"OSTYPE": "darwin"})
            assert default_result.stdout == help_result.stdout
            assert not destination.exists() and not log.exists()
            run()
            assert not destination.exists() and not log.exists()
            run("check", changes={"OSTYPE": "darwin"}, expected=1)
            assert not destination.exists()
            run("all")
            recorded = log.read_text().splitlines()
            all_steps = [f"{steps[index]} " for index in (0, 1, 9, 2, 8, 3)] + [
                f"{steps[10]} 01", f"{steps[10]} 02", f"{steps[4]} --day 04",
                f"{steps[6]} ", f"{steps[0]} ",
            ]
            assert recorded == all_steps, recorded
            assert (work / "curso con espacios").is_dir()
            # Usuario es literal; no depende del perfil activo, HOME o cwd.
            profile = work / "Users/Otra cuenta con espacios"
            documents = work / "Users/Usuario/Documents/bcp-ai-labs"
            default_course = run("check", changes={"COURSE_DIR": "", "USERPROFILE": str(profile)})
            assert documents.is_dir()
            assert f"[INFO] Curso: {documents}\n" in default_course.stdout
            local_defaults = subprocess.run(
                ["bash", "-c", 'source "$1"; printf "%s\\n%s\\n" "$COURSE_DIR" "$WORKSPACE_DIR"',
                 "verify", str(ROOT / "lib/common.sh")],
                env=dict(env, COURSE_DIR="", WORKSPACE_DIR="", USERPROFILE=str(profile)),
                capture_output=True, text=True, check=True,
            )
            assert local_defaults.stdout.splitlines() == [str(documents), str(documents / "reqflow-workspace")]
            explicit = run("check", changes={"USERPROFILE": str(profile)})
            assert f"[INFO] Curso: {work / 'curso con espacios'}\n" in explicit.stdout
            for command, step in (("check", steps[0]), ("tools", steps[1]), ("terminal", steps[9]), ("podman", steps[2]), ("python-envs", steps[3]), ("mcp-images", steps[4]), ("inspector", steps[5]), ("warm-cache", steps[6]), ("labs", steps[8])):
                before = len(log.read_text().splitlines())
                run(command)
                assert log.read_text().splitlines()[before:] == [f"{step} "]
            for command, day in (("day01", "01"), ("day02", "02")):
                run(command, "--directory", "C:\\curso con espacios")
                assert log.read_text().splitlines()[-1] == f"{steps[10]} {day} --directory C:\\curso con espacios"
            before = len(log.read_text().splitlines())
            run()
            assert len(log.read_text().splitlines()) == before
            marker = destination / "conservar.txt"
            marker.write_text("conservar")
            run("terminal", "--directory", "C:\\curso con espacios")
            assert log.read_text().splitlines()[-1] == f"{steps[9]} --directory C:\\curso con espacios"
            # La copia anterior se conserva; la opcion nueva usa otra carpeta.
            (destination / "scripts/09-setup-terminal.sh").unlink()
            before = len(log.read_text().splitlines())
            run("terminal")
            upgraded = Path(str(destination) + "-terminal-v1")
            assert (upgraded / "scripts/09-setup-terminal.sh").is_file()
            assert marker.read_text() == "conservar"
            assert not (destination / "scripts/09-setup-terminal.sh").exists()
            assert log.read_text().splitlines()[before:] == [f"{steps[9]} "]
            run("terminal")
            assert log.read_text().splitlines()[-1] == f"{steps[9]} "
            (destination / "scripts/10-prepare-workshop.sh").unlink()
            run("day01")
            days_upgrade = Path(str(destination) + "-days-v1")
            assert (days_upgrade / "scripts/10-prepare-workshop.sh").is_file()
            assert marker.read_text() == "conservar"
            old_tools = destination / "scripts/01-install-tools.sh"
            old_tools.write_text(old_tools.read_text().replace('# WORKSHOP_PYTHON313_V1\n', ''))
            run("tools")
            assert "WORKSHOP_PYTHON313_V1" in (days_upgrade / "scripts/01-install-tools.sh").read_text()
            assert "WORKSHOP_PYTHON313_V1" not in old_tools.read_text()
            run("day02-mcp", "--owner", "alumno", "--repo", "demo")
            assert log.read_text().splitlines()[-1] == f"{steps[7]} --owner alumno --repo demo"
            assert marker.read_text() == "conservar"
            # Una copia que aun abre PowerShell se mantiene intacta.
            (destination / "lib/open-terminal.ps1").write_text("Start-Process powershell\n")
            run("day02-mcp", "--no-terminals")
            mcp_upgrade = Path(str(destination) + "-mcp-terminal-v1")
            assert "WORKSHOP_WINDOWS_TERMINAL_V1" in (mcp_upgrade / "lib/open-terminal.ps1").read_text()
            assert (destination / "lib/open-terminal.ps1").read_text() == "Start-Process powershell\n"
            assert marker.read_text() == "conservar"
            if os.name == "posix":
                verify_terminal(url, env)
                assert log.read_text().splitlines()[-1] == "respuesta desde terminal"
            old_bootstrap = destination / "bootstrap.sh"
            old_bootstrap.write_text(old_bootstrap.read_text().replace('WORKSHOP_ALL_WORKSPACES_V1', 'OLD_ALL'))
            before = len(log.read_text().splitlines())
            run("all")
            all_upgrade = Path(str(destination) + "-all-v1")
            assert "WORKSHOP_ALL_WORKSPACES_V1" in (all_upgrade / "bootstrap.sh").read_text()
            assert "WORKSHOP_ALL_WORKSPACES_V1" not in old_bootstrap.read_text()
            assert marker.read_text() == "conservar"
            assert log.read_text().splitlines()[before:] == all_steps
            before = len(log.read_text().splitlines())
            run("all")
            assert log.read_text().splitlines()[before:] == all_steps
            for failed_step, completed in ((steps[9], 3), (steps[10], 7)):
                before = len(log.read_text().splitlines())
                run("all", changes={"VERIFY_FAIL_STEP": failed_step}, expected=1)
                assert log.read_text().splitlines()[before:] == all_steps[:completed]
            before = len(log.read_text().splitlines())
            run("all", changes={"VERIFY_FAIL_STEP": steps[1]}, expected=1)
            assert len(log.read_text().splitlines()) == before + 2
            before = len(log.read_text().splitlines())
            run("all", changes={"VERIFY_LOGGED_IN": "no"})
            login_steps = log.read_text().splitlines()[before:]
            assert login_steps[4] == "gh auth login", login_steps
            assert login_steps[:4] + login_steps[5:] == all_steps, login_steps
            before = len(log.read_text().splitlines())
            run("all", changes={"VERIFY_LOGGED_IN": "no", "VERIFY_LOGIN_EXIT": "1"}, expected=1)
            assert len(log.read_text().splitlines()) == before + 5
            run("desconocido", expected=1)

            occupied = work / "ocupado"
            occupied.mkdir()
            (occupied / "personal.txt").write_text("conservar")
            run("check", changes={"WORKSHOP_INSTALL_DIR": str(occupied)}, expected=1)
            assert (occupied / "personal.txt").read_text() == "conservar"

            fresh = work / "fresh"
            checksum = web / "workshop-bootstrap.tar.gz.sha256"
            checksum.write_text("0" * 64 + "  workshop-bootstrap.tar.gz\n")
            run("check", changes={"WORKSHOP_INSTALL_DIR": str(fresh)}, expected=1)
            assert not fresh.exists()
            assert not list(work.glob(".workshop-download.*"))

            package = web / "workshop-bootstrap.tar.gz"
            package.unlink()
            run("check", changes={"WORKSHOP_INSTALL_DIR": str(fresh)}, expected=22)
            assert not fresh.exists()
            # Un paquete valido de tar, pero sin los scripts, tambien se rechaza.
            with tarfile.open(package, "w:gz"):
                pass
            checksum.write_text(hashlib.sha256(package.read_bytes()).hexdigest() + "  workshop-bootstrap.tar.gz\n")
            run("check", changes={"WORKSHOP_INSTALL_DIR": str(fresh)}, expected=1)
            assert not fresh.exists()
            assert not list(work.glob(".workshop-download.*"))
        finally:
            server.shutdown()
            server.server_close()
            thread.join()
    print("OK: paquete real, curl | bash, ayuda por defecto sin instalacion, opciones individuales, all explicito, login, argumentos, terminal, reutilizacion, errores y limpieza.")


if __name__ == "__main__":
    main()
