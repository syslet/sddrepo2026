#!/usr/bin/env python3
"""Ejecuta la preparacion real con Git local y sustitutos de GitHub/runtimes."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile
import tempfile


ROOT = Path(__file__).resolve().parent.parent
NAMES = ("workshop-auth-backend", "workshop-requirements-api", "workshop-login-frontend")
STUB = r'''#!/usr/bin/env python3
import json, os, shutil, subprocess, sys
from pathlib import Path
name, args = Path(sys.argv[0]).name, sys.argv[1:]
root = Path(os.environ['VERIFY_WORKSHOP_ROOT'])
with (root / 'commands.jsonl').open('a') as log:
    log.write(json.dumps([name, str(Path.cwd()), *args]) + '\n')
if os.environ.get('VERIFY_FAIL_TOOL') == name:
    sys.exit(9)
if name == 'gh':
    if args[:2] == ['api', 'user']:
        print('alumno')
    elif args[:2] == ['api', '--include']:
        if os.environ.get('VERIFY_API_FAILURE'):
            print('HTTP/2.0 503 Service Unavailable'); sys.exit(1)
        repo = args[2].removeprefix('repos/')
        exists = (root / 'remotes' / (repo + '.git')).exists()
        print('HTTP/2.0 200 OK\n\ntrue' if exists else 'HTTP/2.0 404 Not Found\n')
        sys.exit(0 if exists else 1)
    elif args[:2] == ['repo', 'create']:
        assert '--private' in args
        target = root / 'remotes' / (args[2] + '.git')
        target.parent.mkdir(parents=True, exist_ok=True)
        subprocess.run(['git', 'init', '--bare', '--initial-branch=main', str(target)], check=True, capture_output=True)
    elif args[:2] == ['repo', 'clone']:
        target = Path(args[3]); target.mkdir(parents=True)
        if args[2].endswith('bcp-ai-skill-catalog'):
            (target / 'SKILLS-MANIFEST.json').write_text('{}')
        else:
            (target / 'requirements.txt').write_text('httpx\n')
            mcp = target / 's3_mcp/tools/mcp-local'; mcp.mkdir(parents=True)
            (mcp / 'Dockerfile').write_text('FROM scratch\n')
            (mcp / 'compose.yaml').write_text('services: {}\n')
            tools = target / 'tools'; tools.mkdir()
            (tools / 'check_handoff.py').write_text('raise SystemExit(1)\n')
elif name == 'cygpath':
    print(args[-1])
elif name == 'powershell':
    pass
elif name == 'node':
    print('v22.13.0')
elif name == 'java':
    print('openjdk 21.0.5')
elif name == 'mvn' and args == ['--version']:
    print('Apache Maven 3.9.9')
elif name in ('podman', 'docker') and args == ['compose', 'version']:
    print('Docker Compose version 2.0')
elif name in ('py', 'python.exe'):
    if name == 'py' and args and args[0] in ('-3.12', '-3.11'):
        sys.exit(1)
    if '--version' in args:
        print('Python 3.13.1')
    elif args == ['-3.13', '-m', 'venv', '.venv']:
        target = Path('.venv/Scripts/python.exe')
        target.parent.mkdir(parents=True)
        shutil.copyfile(__file__, target); target.chmod(0o755)
    elif args[:3] == ['-3.13', '-c', 'import sys']:
        pass
    elif args[:2] == ['-3.13', '-']:
        subprocess.run([sys.executable, '-', *args[2:]], input=sys.stdin.read(), text=True, check=True)
    elif args[:2] == ['-m', 'pip']:
        pass
    elif len(args) > 1 and args[0] == '-3.13' and args[1].endswith('check_handoff.py'):
        sys.exit(1)
    else:
        raise AssertionError(args)
'''


def main():
    with tempfile.TemporaryDirectory(prefix="verify-workshop-") as temporary:
        root = Path(temporary)
        release = root / "release"
        subprocess.run(["bash", str(ROOT / "scripts/build-release.sh"), str(release)],
                       check=True, capture_output=True)
        with tarfile.open(release / "workshop-bootstrap.tar.gz") as archive:
            archive.extractall(root / "package")
        project = root / "package/workshop-bootstrap"
        commands = root / "bin"; commands.mkdir()
        for name in ("gh", "cygpath", "powershell", "node", "npm", "java", "mvn", "py", "podman", "docker"):
            path = commands / name; path.write_text(STUB); path.chmod(0o755)
        env = dict(os.environ, OS="Windows_NT", HOME=str(root / "home"),
                   PATH=str(commands) + os.pathsep + os.environ["PATH"], VERIFY_WORKSHOP_ROOT=str(root),
                   GIT_AUTHOR_NAME="Fixture", GIT_AUTHOR_EMAIL="fixture@example.com",
                   GIT_COMMITTER_NAME="Fixture", GIT_COMMITTER_EMAIL="fixture@example.com",
                   GIT_CONFIG_COUNT="1", GIT_CONFIG_KEY_0="url." + (root / "remotes").as_uri() + "/.insteadOf",
                   GIT_CONFIG_VALUE_0="https://github.com/")
        (root / "commands.jsonl").touch()

        def git(*args):
            return subprocess.check_output(["git", *args], env=env, text=True, stderr=subprocess.DEVNULL).strip()

        for name in NAMES:
            template = root / "remotes/NTTData-Academy" / (name + "-template.git")
            template.mkdir(parents=True)
            git("init", "--initial-branch=main", str(template))
            for filename in ("pom.xml", "requirements.txt", "requirements-dev.txt", "package.json", "package-lock.json", ".env.example"):
                (template / filename).write_text("fixture\n")
            git("-C", str(template), "add", ".")
            git("-C", str(template), "commit", "-m", "first")
            (template / "history.txt").write_text("complete history")
            git("-C", str(template), "add", ".")
            git("-C", str(template), "commit", "-m", "second")

        def run(day, course, *options, expected=0, changes=None):
            result = subprocess.run(["bash", str(project / "bootstrap.sh"), day, "--directory", str(course), *options],
                                    env=dict(env, **(changes or {})), capture_output=True, text=True, timeout=35)
            assert result.returncode == expected, (result.returncode, result.stdout, result.stderr)
            return result

        course = root / "curso con espacios y 'comilla'"
        result = run("day01", course)
        workspace = course / "reqflow-workspace"
        assert not (course / "bcp-ai-lab-day-02").exists()
        for name in NAMES:
            repo = workspace / name
            assert git("-C", str(repo), "rev-list", "--count", "HEAD") == "2"
            assert git("-C", str(repo), "config", "--get", "remote.origin.url") == "https://github.com/alumno/" + name + ".git"
            (repo / "HALLAZGOS.md").write_text("mi trabajo")
            (repo / ".env").write_text("mi configuracion")
        log = root / "commands.jsonl"
        first = [json.loads(line) for line in log.read_text().splitlines()]
        assert len([call for call in first if call[0] == "gh" and call[2:4] == ["repo", "create"]]) == 3
        log.write_text("")
        run("day01", course)
        assert not any(json.loads(line)[2:4] == ["repo", "create"] for line in log.read_text().splitlines())
        result = run("day02", course)
        assert "Faltan entregables del Dia 1" in result.stdout
        assert (workspace / "bcp-ai-skill-catalog/SKILLS-MANIFEST.json").is_file()
        assert (course / "bcp-ai-lab-day-02/.venv/Scripts/python.exe").is_file()
        assert not (course / "bcp-ai-lab-day-04").exists()
        calls = [json.loads(line) for line in log.read_text().splitlines()]
        assert not any("day02-mcp" in call or "--follow" in call for call in calls)
        for name in NAMES:
            assert (workspace / name / "HALLAZGOS.md").read_text() == "mi trabajo"
            assert (workspace / name / ".env").read_text() == "mi configuracion"
        # Recupera un repo remoto con commits propios, sin sembrarlo otra vez.
        repo = workspace / NAMES[0]
        git("-C", str(repo), "add", "HALLAZGOS.md")
        git("-C", str(repo), "commit", "-m", "participant")
        git("-C", str(repo), "push")
        shutil.rmtree(repo)
        run("day02", course)
        assert (repo / "HALLAZGOS.md").read_text() == "mi trabajo"
        assert git("-C", str(repo), "rev-list", "--count", "HEAD") == "3"
        # all usa la preparacion real del workspace; solo sustituye instalaciones de maquina.
        for step in ("00-check-prereqs.sh", "01-install-tools.sh", "02-setup-podman.sh",
                     "03-setup-python-envs.sh", "06-warm-dependency-caches.sh", "09-setup-terminal.sh"):
            (project / "scripts" / step).write_text('return 0\n')
        all_course = root / "all con espacios"

        def run_all():
            result = subprocess.run(["bash", str(project / "bootstrap.sh"), "all"],
                                    env=dict(env, COURSE_DIR=str(all_course), WORKSPACE_DIR=""),
                                    capture_output=True, text=True, timeout=35)
            assert result.returncode == 0, (result.stdout, result.stderr)

        run_all()
        all_workspace = all_course / "reqflow-workspace"
        for day in ("01", "02", "03", "04"):
            assert (all_course / f"bcp-ai-lab-day-{day}").is_dir()
        for name in NAMES:
            assert git("-C", str(all_workspace / name), "config", "--get", "remote.origin.url") == "https://github.com/alumno/" + name + ".git"
        assert (all_workspace / "bcp-ai-skill-catalog/SKILLS-MANIFEST.json").is_file()
        assert (all_workspace / NAMES[1] / ".venv/Scripts/python.exe").is_file()
        all_local_work = all_workspace / NAMES[0] / "HALLAZGOS.md"
        all_local_work.write_text("conservar al repetir all")
        log.write_text("")
        run_all()
        assert all_local_work.read_text() == "conservar al repetir all"
        calls = [json.loads(line) for line in log.read_text().splitlines()]
        assert not any(call[2:4] == ["repo", "create"] or "--follow" in call for call in calls)
        # Carpeta ocupada, origin incorrecto, API caida y fallo npm no se silencian.
        occupied = root / "ocupado/reqflow-workspace" / NAMES[0]; occupied.mkdir(parents=True)
        (occupied / "personal.txt").write_text("conservar")
        run("day01", root / "ocupado", expected=1)
        assert (occupied / "personal.txt").read_text() == "conservar"
        run("day01", course, changes={"VERIFY_API_FAILURE": "yes"}, expected=1)
        run("day01", course, changes={"VERIFY_FAIL_TOOL": "npm"}, expected=1)
        git("-C", str(repo), "remote", "set-url", "origin", "https://github.com/otro/repo.git")
        run("day01", course, expected=1)
        run("day01", course, "--unknown", expected=1)
        run("day02", root / "no-dia1", "--owner", "otro", expected=1)
        assert not (root / "remotes/otro").exists()
    print("OK: day01/day02/all, Git e historial reales, repos privados, recuperacion, cambios locales, rutas, dependencias, handoff y errores.")


if __name__ == "__main__":
    main()
