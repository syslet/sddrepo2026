#!/usr/bin/env bash
# Preparacion del producto del participante. No completa ejercicios ni handoffs.
source "$BOOTSTRAP_DIR/lib/workshop.sh"
prepare_workshop "$@"
