#!/usr/bin/env bash
# Genera los tres archivos estaticos que se publican en Cloudflare Pages.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUTPUT="${1:-$ROOT/dist}"
mkdir -p "$OUTPUT"
OUTPUT="$(cd "$OUTPUT" && pwd)"
BUILD_STAGE="$(mktemp -d)"
trap 'rm -rf -- "$BUILD_STAGE"' EXIT

mkdir -p "$BUILD_STAGE/workshop-bootstrap/scripts" "$BUILD_STAGE/workshop-bootstrap/lib"
cp "$ROOT/bootstrap.sh" "$ROOT/README.md" "$BUILD_STAGE/workshop-bootstrap/"
cp "$ROOT/lib/"*.sh "$ROOT/lib/"*.py "$ROOT/lib/"*.ps1 "$BUILD_STAGE/workshop-bootstrap/lib/"
cp -R "$ROOT/config" "$BUILD_STAGE/workshop-bootstrap/"
cp "$ROOT/scripts/"[0-9]*.sh "$BUILD_STAGE/workshop-bootstrap/scripts/"
chmod -R u+rwX "$BUILD_STAGE/workshop-bootstrap"
# Un zip extraido en Windows puede contener CRLF y perder permisos ejecutables.
for script in "$BUILD_STAGE/workshop-bootstrap/bootstrap.sh" \
  "$BUILD_STAGE/workshop-bootstrap/lib/"*.sh "$BUILD_STAGE/workshop-bootstrap/scripts/"*.sh; do
  sed 's/\r$//' "$script" > "$BUILD_STAGE/normalized.sh"
  cat "$BUILD_STAGE/normalized.sh" > "$script"
  chmod u+x "$script"
  bash -n "$script"
done
COPYFILE_DISABLE=1 tar -czf "$OUTPUT/workshop-bootstrap.tar.gz" -C "$BUILD_STAGE" workshop-bootstrap
if command -v sha256sum >/dev/null 2>&1; then
  HASH="$(sha256sum "$OUTPUT/workshop-bootstrap.tar.gz")"
else
  HASH="$(shasum -a 256 "$OUTPUT/workshop-bootstrap.tar.gz")"
fi
printf '%s  workshop-bootstrap.tar.gz\n' "${HASH%% *}" > "$OUTPUT/workshop-bootstrap.tar.gz.sha256"
cp "$ROOT/install.sh" "$OUTPUT/install.sh"
bash -n "$OUTPUT/install.sh"
printf 'Archivos listos en %s\nPublica install.sh, workshop-bootstrap.tar.gz y workshop-bootstrap.tar.gz.sha256 en la raiz de Pages.\n' "$OUTPUT"
