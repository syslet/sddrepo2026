#!/usr/bin/env bash
# Prepara el motor de contenedores Podman a nivel de MAQUINA:
# WSL2, podman machine init/start, podman-compose, y pre-descarga de las
# imagenes base genericas que usan los compose.yaml de los labs (ahorra
# varios minutos de descarga durante la clase). No arranca ningun servicio
# del workshop ni usa credenciales de GitHub del alumno.
# Uso: ./bootstrap.sh podman

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../lib/common.sh"

refresh_path

if ! has_cmd podman; then
  err "podman no esta en PATH. Corre primero: ./bootstrap.sh tools"
  return 1
fi

if is_windows; then
  info "Verificando WSL2 (requerido por Podman en Windows)..."
  if has_cmd wsl.exe; then
    if wsl.exe --status >/dev/null 2>&1; then
      ok "WSL2 disponible."
    else
      if is_admin; then
        warn "WSL2 no parece estar instalado/configurado. Ejecutando 'wsl --install --no-distribution' (automatico)..."
        wsl.exe --install --no-distribution
        warn "Puede requerir REINICIAR la maquina una sola vez. Reinicia y vuelve a correr: ./bootstrap.sh podman"
        return 0
      else
        err "WSL2 no esta configurado y esta terminal no es Administrador: no se puede habilitar automaticamente. Reejecuta como Administrador."
        return 1
      fi
    fi
  else
    warn "No se encontro wsl.exe. Si Podman usa Hyper-V en vez de WSL2 puedes ignorar esto."
  fi

  info "Verificando maquina de Podman..."
  if podman machine list --format '{{.Name}}' 2>/dev/null | grep -q .; then
    ok "Ya existe una maquina de Podman."
  else
    info "Creando maquina de Podman (podman machine init)..."
    podman machine init || { err "Fallo 'podman machine init'. Revisa que WSL2/Hyper-V este habilitado y vuelve a intentar."; return 1; }
  fi

  if podman machine list --format '{{.Running}}' 2>/dev/null | grep -qi true; then
    ok "La maquina de Podman ya esta corriendo."
  else
    info "Iniciando maquina de Podman (podman machine start)..."
    podman machine start || warn "No se pudo iniciar la maquina. Prueba manualmente: podman machine start"
  fi
fi

info "Verificando podman compose..."
if podman compose version >/dev/null 2>&1; then
  ok "podman compose disponible."
else
  info "Instalando podman-compose (py -m pip install --user podman-compose)..."
  PY="$(py_launcher)"
  $PY -m pip install --user --quiet podman-compose
  PYVER=$($PY -c "import sys;print(f'Python{sys.version_info[0]}{sys.version_info[1]}')" 2>/dev/null || echo "Python312")
  SCRIPTS_PATH_WIN="${APPDATA:-$HOME/AppData/Roaming}\\Python\\$PYVER\\Scripts"
  SCRIPTS_PATH_UNIX="$(cygpath -u "$SCRIPTS_PATH_WIN" 2>/dev/null)"
  export PATH="$PATH:$SCRIPTS_PATH_UNIX"
  if is_admin; then
    win_prepend_machine_path "$SCRIPTS_PATH_WIN"
    ok "Carpeta de scripts de Python agregada al PATH de maquina (permanente): $SCRIPTS_PATH_WIN"
  fi
  if podman compose version >/dev/null 2>&1; then
    ok "podman compose disponible en esta sesion."
  else
    warn "podman compose sigue sin detectarse en esta sesion. Vuelve a correr ./bootstrap.sh check en una terminal nueva."
  fi
fi

info "Pre-descargando imagenes base genericas usadas por los labs (ahorra tiempo en clase)..."
IMAGES=(
  "docker.io/library/maven:3.9-eclipse-temurin-21"
  "docker.io/library/python:3.13-slim"
  "docker.io/library/node:24-slim"
)
for img in "${IMAGES[@]}"; do
  if podman image exists "$img" 2>/dev/null; then
    ok "Imagen ya en cache: $img"
    continue
  fi
  info "Descargando $img ..."
  if podman pull "$img" >/dev/null 2>&1; then
    ok "Descargada: $img"
  else
    warn "Fallo normal de pull para $img, probablemente certificado roto en la VM de Podman. Reintentando con --tls-verify=false..."
    if podman pull --tls-verify=false "$img" >/dev/null 2>&1; then
      ok "Descargada (sin TLS verify): $img"
      warn "Causa raiz: certificados incompletos en la maquina de Podman. Solucion permanente: podman machine ssh -- sudo update-ca-trust"
    else
      warn "No se pudo descargar $img. Revisa tu conexion o hazlo manualmente mas tarde."
    fi
  fi
done

ok "Podman listo a nivel de maquina."
