#!/usr/bin/env bash
# Diagnostico de prerrequisitos para los 4 dias del workshop BCP AI Lab.
# Uso: ./bootstrap.sh check
# Genera un reporte en <COURSE_DIR>/diagnostico-<hostname>.md (no instala nada).

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../lib/common.sh"

refresh_path
REPORT="$COURSE_DIR/diagnostico-$(hostname 2>/dev/null || echo equipo).md"
PASS=0; FAIL=0; ROWS=()

row() {
  # row "Herramienta" "estado" "detalle"
  ROWS+=("| $1 | $2 | $3 |")
  [ "$2" = "OK" ] && PASS=$((PASS+1)) || FAIL=$((FAIL+1))
}

info "Revisando herramientas base..."

if is_windows; then
  if is_admin; then
    row "terminal elevada (Admin)" "OK" "si"
  else
    row "terminal elevada (Admin)" "INFO" "no (algunas instalaciones de maquina requieren Admin)"
  fi
fi

if has_cmd git; then
  v=$(git --version | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -1)
  version_ge "$v" "2.40.0" && row "git" "OK" "$v" || row "git" "WARN" "$v (se recomienda >= 2.40)"
else
  row "git" "FALTA" "no esta en PATH"
fi

if has_cmd gh; then
  v=$(gh --version | head -1 | grep -oE '[0-9]+\.[0-9]+\.[0-9]+')
  row "gh (GitHub CLI)" "OK" "$v"
  if gh_logged_in; then
    row "gh auth" "OK" "autenticado ($(gh api user --jq .login 2>/dev/null))"
  else
    row "gh auth" "FALTA" "ejecuta: gh auth login"
  fi
else
  row "gh (GitHub CLI)" "FALTA" "no esta en PATH"
fi

if has_cmd node; then
  v=$(node --version | tr -d 'v')
  version_ge "$v" "22.12.0" && row "node" "OK" "$v" || row "node" "WARN" "$v (labs piden >= 22.12)"
else
  row "node" "FALTA" "no esta en PATH"
fi

if has_cmd npm; then
  row "npm" "OK" "$(npm --version)"
else
  row "npm" "FALTA" "no esta en PATH"
fi

PYV="$(py_valid_launcher)"
if [ -n "$PYV" ]; then
  v=$($PYV --version 2>&1 | grep -oE '[0-9]+\.[0-9]+\.[0-9]+')
  row "python (3.11-3.13)" "OK" "$v ($PYV)"
else
  row "python (3.11-3.13)" "FALTA" "instala con: ./bootstrap.sh tools"
fi

if has_cmd java; then
  v=$(java --version 2>&1 | head -1)
  case "$v" in *" 21"*|*"21."*) row "java" "OK" "$v" ;; *) row "java" "WARN" "$v (auth-backend requiere Java 21; corre ./bootstrap.sh tools para fijar Java 21 en PATH/JAVA_HOME)" ;; esac
  if [ -n "${JAVA_HOME:-}" ]; then
    row "JAVA_HOME" "OK" "$JAVA_HOME"
  else
    row "JAVA_HOME" "INFO" "no fijado (opcional si 'mvn' ya resuelve Java 21 via PATH)"
  fi
else
  row "java" "FALTA" "no esta en PATH (requerido Java 21 para workshop-auth-backend)"
fi

if has_cmd mvn; then
  v=$(mvn --version 2>&1 | head -1 | grep -oE '[0-9]+\.[0-9]+\.[0-9]+')
  version_ge "$v" "3.9.0" && row "maven" "OK" "$v" || row "maven" "WARN" "$v (labs piden >= 3.9; corre ./bootstrap.sh tools para actualizar)"
else
  row "maven" "FALTA" "instala con: ./bootstrap.sh tools"
fi

if has_cmd podman; then
  v=$(podman --version | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -1)
  row "podman" "OK" "$v"
  if is_windows; then
    if podman machine list --format '{{.Name}}' 2>/dev/null | grep -q .; then
      row "podman machine" "OK" "inicializada"
    else
      row "podman machine" "FALTA" "ejecuta: ./bootstrap.sh podman"
    fi
  fi
  if podman compose version >/dev/null 2>&1; then
    row "podman compose" "OK" "disponible"
  else
    row "podman compose" "FALTA" "ejecuta: ./bootstrap.sh podman"
  fi
else
  row "podman" "FALTA" "no esta en PATH"
fi

if has_cmd docker; then
  row "docker (alternativa)" "OK" "$(docker --version)"
fi

if is_windows; then
  has_cmd winget && row "winget" "OK" "$(winget --version)" || row "winget" "FALTA" "necesario para instalar herramientas"
  has_cmd choco && row "choco" "OK" "disponible" || row "choco" "INFO" "opcional, algunos labs lo mencionan"
fi

if has_cmd code; then
  row "VS Code CLI" "OK" "disponible"
  if code --list-extensions 2>/dev/null | grep -qi 'GitHub.copilot$'; then
    row "Extension GitHub Copilot" "OK" "instalada"
  else
    row "Extension GitHub Copilot" "FALTA" "instalar desde VS Code Marketplace"
  fi
else
  row "VS Code CLI" "INFO" "'code' no esta en PATH (no bloqueante)"
fi

info "Revisando estructura de carpetas del workshop en: $COURSE_DIR"
for d in bcp-ai-lab-day-01 bcp-ai-lab-day-02 bcp-ai-lab-day-03 bcp-ai-lab-day-04 reqflow-workspace; do
  if [ -d "$COURSE_DIR/$d" ]; then row "carpeta $d" "OK" "existe"; else row "carpeta $d" "INFO" "no existe todavia"; fi
done

if [ -d "$WORKSPACE_DIR" ]; then
  for r in workshop-auth-backend workshop-login-frontend workshop-requirements-api; do
    if [ -d "$WORKSPACE_DIR/$r/.git" ]; then
      origin=$(git -C "$WORKSPACE_DIR/$r" remote get-url origin 2>/dev/null || echo "sin-origin")
      row "repo $r" "OK" "$origin"
    else
      row "repo $r" "FALTA" "no clonado en reqflow-workspace/"
    fi
  done
  if [ -f "$WORKSPACE_DIR/.vscode/mcp.json" ]; then
    row ".vscode/mcp.json" "OK" "existe"
  else
    row ".vscode/mcp.json" "FALTA" "ejecuta: ./bootstrap.sh mcp"
  fi
fi

{
  echo "# Diagnostico workshop - $(date)"
  echo
  echo "| Item | Estado | Detalle |"
  echo "|---|---|---|"
  for r in "${ROWS[@]}"; do echo "$r"; done
  echo
  echo "Resumen: $PASS OK / $FAIL con problema."
} > "$REPORT"

log ""
log "| Item | Estado | Detalle |"
log "|---|---|---|"
for r in "${ROWS[@]}"; do log "$r"; done
log ""
if [ "$FAIL" -eq 0 ]; then ok "Todo listo ($PASS checks OK). Reporte: $REPORT"; else warn "$FAIL items requieren accion. Reporte: $REPORT"; fi
