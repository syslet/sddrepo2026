#!/usr/bin/env bash
# Pre-calienta las cachés GLOBALES de npm / Maven (.m2) / pip usando las
# plantillas publicas de referencia (workshop-*-template), en una carpeta
# TEMPORAL que se borra al terminar. Así, cuando el alumno clone SU PROPIO
# repo (Dia 1, paso 1) y corra npm install / mvn quarkus:dev / pip install,
# las dependencias ya estan en la cache local y no se re-descargan por red.
# No crea reqflow-workspace, no usa 'gh repo create', no toca repos del alumno.
# Uso: ./bootstrap.sh warm-cache [--org NTTData-Academy]

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../lib/common.sh"

refresh_path

ORG="$LAB_ORG"
while [ $# -gt 0 ]; do
  case "$1" in
    --org) ORG="$2"; shift 2 ;;
    *) shift ;;
  esac
done

TMP_DIR="$(mktemp -d 2>/dev/null || echo "$COURSE_DIR/.warm-cache-tmp")"
mkdir -p "$TMP_DIR"
trap 'rm -rf "$TMP_DIR"' EXIT

clone_template() {
  local name="$1" dest="$2"
  if has_cmd gh; then
    gh repo clone "$ORG/$name" "$dest" -- --depth 1 >/dev/null 2>&1 && return 0
  fi
  git clone --depth 1 "https://github.com/$ORG/$name.git" "$dest" >/dev/null 2>&1
}

info "Pre-calentando cache de Maven (~/.m2) con workshop-auth-backend-template..."
if clone_template "workshop-auth-backend-template" "$TMP_DIR/auth"; then
  if has_cmd mvn && [ -f "$TMP_DIR/auth/pom.xml" ]; then
    (cd "$TMP_DIR/auth" && mvn -q -B dependency:go-offline) \
      && ok "Dependencias Maven precargadas en ~/.m2" \
      || warn "mvn dependency:go-offline fallo (no bloqueante)."
  else
    warn "No se encontro pom.xml o mvn no esta instalado, se omite."
  fi
else
  warn "No se pudo clonar workshop-auth-backend-template (red o permisos). Se omite el precalentado de Maven."
fi

info "Pre-calentando cache de npm con workshop-login-frontend-template..."
if clone_template "workshop-login-frontend-template" "$TMP_DIR/frontend"; then
  if has_cmd npm && [ -f "$TMP_DIR/frontend/package.json" ]; then
    (cd "$TMP_DIR/frontend" && npm install --no-audit --no-fund >/dev/null 2>&1) \
      && ok "Dependencias npm precargadas en la cache global de npm" \
      || warn "npm install fallo (no bloqueante)."
  else
    warn "No se encontro package.json o npm no esta instalado, se omite."
  fi
else
  warn "No se pudo clonar workshop-login-frontend-template (red o permisos). Se omite el precalentado de npm."
fi

info "Pre-calentando cache de pip con workshop-requirements-api-template..."
if clone_template "workshop-requirements-api-template" "$TMP_DIR/api"; then
  PY="$(py_launcher)"
  if [ -f "$TMP_DIR/api/requirements.txt" ]; then
    local_req_args=(-r "$TMP_DIR/api/requirements.txt")
    [ -f "$TMP_DIR/api/requirements-dev.txt" ] && local_req_args+=(-r "$TMP_DIR/api/requirements-dev.txt")
    $PY -m pip download --quiet --dest "$TMP_DIR/pip-cache" "${local_req_args[@]}" >/dev/null 2>&1 \
      && ok "Paquetes pip precargados en la cache de pip" \
      || warn "pip download fallo (no bloqueante)."
  else
    warn "No se encontro requirements.txt, se omite."
  fi
else
  warn "No se pudo clonar workshop-requirements-api-template (red o permisos). Se omite el precalentado de pip."
fi

ok "Pre-calentado de dependencias terminado (carpeta temporal eliminada, nada quedo en el workspace)."
