#!/usr/bin/env bash
# Configura Windows Terminal para el usuario que ejecuta este comando.

setup_workshop_terminal() {
  local directory="$COURSE_DIR" PY bash_exe settings_path local_app_data arg
  while [ "$#" -gt 0 ]; do
    arg="$1"; shift
    case "$arg" in
      --directory)
        [ "$#" -gt 0 ] && [ -n "$1" ] || { err "Falta la ruta de --directory."; return 1; }
        directory="$1"; shift ;;
      *) err "Parametro desconocido: $arg. Usa terminal [--directory <ruta>]."; return 1 ;;
    esac
  done
  is_windows && has_cmd cygpath && has_cmd powershell || {
    err "Ejecuta terminal desde Git Bash en Windows, con Windows PowerShell disponible."; return 1;
  }
  PY="$(py_launcher)"
  $PY -c 'import sys; assert sys.version_info >= (3, 8)' >/dev/null 2>&1 || {
    err "Falta Python 3. Ejecuta primero la opcion tools y vuelve a ejecutar terminal."; return 1;
  }
  bash_exe="$(cygpath -aw /bin/bash.exe)" || return 1
  [ -f /bin/bash.exe ] || { err "No se encontro bash.exe de Git for Windows."; return 1; }
  directory="$(cygpath -au "$directory")" || return 1
  mkdir -p -- "$directory" || return 1
  directory="$(cygpath -aw "$directory")" || return 1

  # Detecta Terminal estable de Store/winget o la instalacion sin MSIX.
  local detect_settings='
    $ErrorActionPreference = "Stop"
    [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding
    $package = Get-AppxPackage -Name Microsoft.WindowsTerminal | Select-Object -First 1
    if ($package) { Join-Path $env:LOCALAPPDATA ("Packages\" + $package.PackageFamilyName + "\LocalState\settings.json") }
    elseif (Test-Path (Join-Path $env:LOCALAPPDATA "Microsoft\Windows Terminal\settings.json")) {
      Join-Path $env:LOCALAPPDATA "Microsoft\Windows Terminal\settings.json"
    }
  '
  settings_path="$(powershell -NoProfile -NonInteractive -Command "$detect_settings" | tr -d '\r')" || return 1
  if [ -z "$settings_path" ]; then
    has_cmd winget || { err "Falta Windows Terminal y winget. Instala App Installer y repite terminal."; return 1; }
    info "Instalando Windows Terminal para este usuario..."
    winget install --id Microsoft.WindowsTerminal -e --source winget \
      --accept-package-agreements --accept-source-agreements --disable-interactivity || {
        err "No se pudo instalar Windows Terminal."; return 1;
      }
    settings_path="$(powershell -NoProfile -NonInteractive -Command "$detect_settings" | tr -d '\r')" || return 1
  fi
  [ -n "$settings_path" ] || {
    err "No se encontro la configuracion de Terminal estable. Abre Windows Terminal una vez y repite terminal."; return 1;
  }
  local_app_data="$(powershell -NoProfile -NonInteractive -Command '[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding; [Environment]::GetFolderPath("LocalApplicationData")' | tr -d '\r')" || return 1
  [ -n "$local_app_data" ] || { err "No se encontro LOCALAPPDATA de este usuario."; return 1; }
  PYTHONUTF8=1 $PY "$(cygpath -aw "$BOOTSTRAP_DIR/lib/windows_terminal.py")" \
    --settings "$settings_path" --local-app-data "$local_app_data" \
    --bash "$bash_exe" --directory "$directory" || return 1
  ok "Workshop - Bash es el perfil predeterminado. Carpeta inicial: $directory"
  info "Cierra Windows Terminal y abrelo de nuevo. Ctrl+Shift+T: pestana. Alt+Shift+D: panel."
  info "Se configuro solo este usuario. No se modificaron PATH ni variables de Windows."
}

setup_workshop_terminal "$@"
