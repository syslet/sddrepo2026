#!/usr/bin/env bash
# Clona (o reutiliza si ya existen) los 4 repos de laboratorio del workshop
# directamente desde GitHub (org NTTData-Academy), para que nadie tenga que
# copiar zips o clonar a mano antes de correr el resto del toolkit. Todos
# los alumnos tienen acceso de lectura a estos 4 repos, asi que basta con
# tener 'gh auth login' hecho (en cualquier cuenta con acceso) para que esto
# funcione sin pedir nada mas.
#
# Solo clona el CONTENIDO DE LABORATORIO (guias, Dockerfiles, scripts de
# referencia) — nunca toca reqflow-workspace ni los repos propios del
# alumno (workshop-auth-backend, etc.), que se crean aparte en el Dia 1.
#
# Uso:
#   ./bootstrap.sh labs                      Clona los 4 (01,02,03,04) si faltan
#   ./bootstrap.sh labs --days 02,04         Solo esos dias
#   ./bootstrap.sh labs --org OtraOrg        Si el curso usa otro org/fork

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../lib/common.sh"
refresh_path

ORG="$LAB_ORG"
DAYS="01,02,03,04"
while [ $# -gt 0 ]; do
  case "$1" in
    --org) ORG="$2"; shift 2 ;;
    --days) DAYS="$2"; shift 2 ;;
    *) shift ;;
  esac
done

if ! has_cmd gh; then
  err "GitHub CLI (gh) no esta en PATH. Corre primero: ./bootstrap.sh tools"
  return 1
fi
if ! gh_logged_in; then
  err "No hay sesion de GitHub CLI activa. Ejecuta: gh auth login (cualquier cuenta con acceso al org $ORG) y vuelve a correr este paso."
  return 1
fi

FAILED=0
IFS=',' read -ra DAY_LIST <<< "$DAYS"
for d in "${DAY_LIST[@]}"; do
  d="$(echo "$d" | tr -d '[:space:]')"
  [ -n "$d" ] || continue
  ensure_lab_repo "$d" "$ORG" || FAILED=1
done

if [ "$FAILED" -eq 0 ]; then
  ok "Repos de laboratorio listos en $COURSE_DIR."
else
  warn "Al menos un repo no se pudo clonar. Revisa los mensajes anteriores (acceso al org, red, 'gh auth login')."
fi
return "$FAILED"
