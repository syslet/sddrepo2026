#!/usr/bin/env bash
# Instala y pre-configura el MCP Inspector (https://modelcontextprotocol.io/docs/2026-07-28/tools/inspector)
# a nivel de MAQUINA (perfil del usuario), con el catalogo por defecto sembrado
# con los dos servidores MCP genericos del curso (local del lab y GitHub oficial).
# No depende de owner/repo/token del alumno: el servidor local siempre vive en
# http://localhost:8081/mcp cuando el alumno lo levanta con start-mcp.ps1.
# Uso: ./bootstrap.sh inspector

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../lib/common.sh"

refresh_path

if ! has_cmd node || ! has_cmd npm; then
  err "node/npm no estan en PATH. Corre primero: ./bootstrap.sh tools"
  return 1
fi

NODE_VER=$(node --version | tr -d 'v')
version_ge "$NODE_VER" "22.19.0" || warn "MCP Inspector recomienda Node >= 22.19.0 (tienes $NODE_VER). Puede funcionar igual."

info "Verificando @modelcontextprotocol/inspector (instalacion global)..."
if [ -z "${FORCE_REINSTALL:-}" ] && npm list -g --depth=0 @modelcontextprotocol/inspector >/dev/null 2>&1; then
  ok "MCP Inspector ya instalado globalmente (se omite reinstalacion). Usa FORCE_REINSTALL=1 para forzar actualizar."
else
  info "Instalando/actualizando @modelcontextprotocol/inspector globalmente (para que 'npx' no tenga que descargarlo en clase)..."
  if npm install -g @modelcontextprotocol/inspector; then
    ok "MCP Inspector instalado globalmente."
  else
    warn "No se pudo instalar globalmente. 'npx @modelcontextprotocol/inspector' lo descargara la primera vez que se use."
  fi
fi

CATALOG_DIR="$HOME/.mcp-inspector"
CATALOG_FILE="$CATALOG_DIR/mcp.json"
mkdir -p "$CATALOG_DIR"

info "Asegurando catalogo de $CATALOG_FILE con los servidores estandar del curso..."
if force_json_servers "$CATALOG_FILE" "mcpServers" \
  '{"github-local": {"type": "streamable-http", "url": "http://localhost:8081/mcp"}, "github-official": {"type": "streamable-http", "url": "https://api.githubcopilot.com/mcp/", "headers": {"X-MCP-Toolsets": "context,repos,issues,pull_requests,projects,users"}}}'; then
  ok "Catalogo listo (y corregido si tenia valores distintos): $CATALOG_FILE"
else
  warn "No se pudo escribir el catalogo. Puedes crearlo manualmente, revisa config/inspector-catalog.json.template"
fi

ok "MCP Inspector listo a nivel de maquina."
log "Para abrirlo (una vez el alumno tenga su MCP local corriendo en el puerto 8081):"
log "  npx @modelcontextprotocol/inspector"
log "Prueba rapida sin UI (lista las tools del servidor local):"
log "  npx @modelcontextprotocol/inspector --cli --server-url http://localhost:8081/mcp --transport http --method tools/list"
