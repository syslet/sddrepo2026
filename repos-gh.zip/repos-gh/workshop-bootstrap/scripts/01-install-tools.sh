#!/usr/bin/env bash
# WORKSHOP_PYTHON313_V1
# Instala/actualiza TODO lo que falte a nivel de MAQUINA (CLI + extensiones
# VS Code), de forma 100% desatendida. No clona ni toca nada del contenido
# del workshop (reqflow-workspace). Requiere permisos de administrador en
# Windows para los pasos de maquina (winget --scope machine, Chocolatey,
# JAVA_HOME). Si la terminal no esta elevada, avisa y continua en modo
# "mejor esfuerzo".
# Uso: ./bootstrap.sh tools

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../lib/common.sh"

if ! is_windows; then
  warn "Este script esta pensado para las maquinas Windows del taller. En otros OS instala manualmente: git, gh, node 22+, python 3.11-3.13, java 21, maven 3.9+, podman."
  return 0
fi

if ! is_admin; then
  warn "Esta terminal NO esta elevada (Administrador)."
  warn "Algunas instalaciones de maquina (winget --scope machine, Chocolatey, JAVA_HOME) pueden fallar o quedar incompletas."
  warn "Recomendado: cierra esta ventana y abre 'Git Bash' con 'Ejecutar como administrador', luego vuelve a correr: ./bootstrap.sh tools"
fi

if ! has_cmd winget; then
  err "winget no esta disponible. Instala 'App Installer' desde Microsoft Store (o actualiza Windows) y vuelve a correr este script."
  return 1
fi

winget_install() {
  local id="$1" label="$2"
  info "Verificando $label ($id)..."
  if winget list --id "$id" -e >/dev/null 2>&1; then
    ok "$label ya instalado."
    return 0
  fi
  info "Instalando $label (automatico, sin intervencion)..."
  if winget install --id "$id" -e --source winget --scope machine \
      --accept-package-agreements --accept-source-agreements --silent --disable-interactivity >/dev/null 2>&1 \
     || winget install --id "$id" -e --source winget \
          --accept-package-agreements --accept-source-agreements --silent --disable-interactivity >/dev/null 2>&1; then
    ok "$label instalado."
    refresh_path
    return 0
  else
    warn "No se pudo instalar $label automaticamente con winget. Revisa conexion/permisos."
    return 1
  fi
}

# Si el paquete fue instalado via winget (aparece en 'winget list --id'),
# intenta actualizarlo a la ultima version con 'winget upgrade'. Si no fue
# instalado via winget (binario manual/portable), no lo toca: solo avisa,
# para no romper una instalacion que el admin gestiona por otro medio.
winget_upgrade_if_managed() {
  local id="$1" label="$2"
  if winget list --id "$id" -e >/dev/null 2>&1; then
    info "Actualizando $label a la ultima version (winget upgrade)..."
    winget upgrade --id "$id" -e --source winget --scope machine \
      --accept-package-agreements --accept-source-agreements --silent --disable-interactivity >/dev/null 2>&1 \
    || winget upgrade --id "$id" -e --source winget \
         --accept-package-agreements --accept-source-agreements --silent --disable-interactivity >/dev/null 2>&1
    refresh_path
    ok "$label actualizado (o ya estaba en la ultima version)."
  else
    warn "$label esta instalado con una version por debajo de la minima, pero no via winget: no se actualiza automaticamente (podria romper una instalacion gestionada a mano). Actualizalo manualmente."
  fi
}

# --- Git: version minima 2.40 (igual que valida ./bootstrap.sh check) ---
if [ -n "${SKIP_GIT:-}" ]; then
  :
elif ! has_cmd git; then
  winget_install "Git.Git" "Git (incluye Git Bash)"
else
  GITV="$(git --version | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -1)"
  if version_ge "$GITV" "2.40.0"; then
    ok "Git ya instalado ($GITV)."
  else
    warn "Git $GITV es menor al minimo recomendado (2.40). Actualizando..."
    winget_upgrade_if_managed "Git.Git" "Git"
  fi
fi

# --- GitHub CLI: solo se valida presencia, no hay minimo documentado ---
[ -n "${SKIP_GH:-}" ] || { has_cmd gh || winget_install "GitHub.cli" "GitHub CLI (gh)"; }

# --- Node.js: version minima 22.12 (requerida por los labs) ---
if [ -n "${SKIP_NODE:-}" ]; then
  :
elif ! has_cmd node; then
  winget_install "OpenJS.NodeJS.LTS" "Node.js LTS (>=22.12 requerido por los labs)"
else
  NODEV="$(node --version | tr -d 'v')"
  if version_ge "$NODEV" "22.12.0"; then
    ok "Node.js ya instalado ($NODEV)."
  else
    warn "Node.js $NODEV es menor al minimo requerido por los labs (22.12). Actualizando..."
    winget_upgrade_if_managed "OpenJS.NodeJS.LTS" "Node.js LTS"
  fi
fi

# --- Python: los labs piden 3.11-3.13. Un 'python'/'py' generico presente ---
# --- puede ser una version distinta (p.ej. 3.9 o 3.14); por eso se valida  ---
# --- con py_valid_launcher(), no solo con has_cmd.                        ---
if [ -n "${SKIP_PYTHON:-}" ]; then
  :
elif { has_cmd py && py -3.13 --version >/dev/null 2>&1; } || has_cmd python3.13; then
  ok "Python 3.13 ya instalado."
else
  winget_install "Python.Python.3.13" "Python 3.13"
fi

[ -n "${SKIP_CODE:-}" ]   || { has_cmd code || winget_install "Microsoft.VisualStudioCode" "Visual Studio Code"; }
[ -n "${SKIP_PODMAN:-}" ] || { has_cmd podman || winget_install "RedHat.Podman"          "Podman CLI"; }

# --- Java 21: se instala y se fija como predeterminado a nivel de maquina ---
# --- (JAVA_HOME + PATH), aunque ya exista otra version de Java, porque    ---
# --- workshop-auth-backend (Quarkus) requiere Java 21 exactamente.       ---
find_jdk21_home() {
  local base="/c/Program Files/Eclipse Adoptium"
  [ -d "$base" ] || return 1
  local d
  for d in "$base"/jdk-21*; do
    [ -d "$d" ] && { echo "$d"; return 0; }
  done
  return 1
}

if [ -n "${SKIP_JAVA:-}" ]; then
  :
else
  JDK21_DIR="$(find_jdk21_home)"
  if [ -n "$JDK21_DIR" ]; then
    ok "Java 21 (Temurin) ya instalado en $JDK21_DIR"
  else
    winget_install "EclipseAdoptium.Temurin.21.JDK" "Java 21 (Temurin JDK, requerido por workshop-auth-backend)"
    JDK21_DIR="$(find_jdk21_home)"
  fi

  if [ -n "$JDK21_DIR" ] && is_admin; then
    WIN_JDK21_DIR=$(cygpath -w "$JDK21_DIR" 2>/dev/null || echo "$JDK21_DIR")
    info "Fijando JAVA_HOME=$WIN_JDK21_DIR y priorizandolo en PATH de maquina (asi 'mvn'/'java' usan Java 21 aunque haya otra version instalada)..."
    win_set_machine_env "JAVA_HOME" "$WIN_JDK21_DIR"
    win_prepend_machine_path "${WIN_JDK21_DIR}\\bin"
    refresh_path
    export JAVA_HOME="$WIN_JDK21_DIR"
    export PATH="$JDK21_DIR/bin:$PATH"
    ok "JAVA_HOME configurado a nivel de maquina (y priorizado en esta misma sesion)."
  elif [ -n "$JDK21_DIR" ]; then
    warn "Java 21 esta en $JDK21_DIR pero no se pudo fijar JAVA_HOME a nivel de maquina (sin permisos admin). Reejecuta como Administrador para automatizarlo."
  fi
fi

# --- Maven: no existe paquete oficial en winget. Los labs documentan ---
# --- expresamente 'choco install maven -y' asumiendo Chocolatey presente;---
# --- si Chocolatey no esta, se instala primero de forma automatica    ---
# --- usando el comando oficial publicado en chocolatey.org/install.    ---
# --- Si ya hay un mvn instalado pero por debajo de 3.9, se actualiza    ---
# --- con 'choco upgrade maven -y' para quedar en el estandar del curso. ---
MVN_OK=0
if has_cmd mvn; then
  MVNV="$(mvn --version 2>&1 | head -1 | grep -oE '[0-9]+\.[0-9]+\.[0-9]+')"
  if version_ge "$MVNV" "3.9.0"; then
    ok "Maven ya instalado ($MVNV)."
    MVN_OK=1
  else
    warn "Maven $MVNV es menor al minimo requerido por los labs (3.9). Se actualizara."
  fi
fi

if [ "$MVN_OK" -eq 0 ]; then
  if ! has_cmd choco; then
    if is_admin; then
      info "Chocolatey no esta instalado. Instalando Chocolatey (comando oficial de chocolatey.org/install)..."
      powershell -NoProfile -NonInteractive -Command "Set-ExecutionPolicy Bypass -Scope Process -Force; [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072; iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))" >/dev/null 2>&1 \
        && ok "Chocolatey instalado." \
        || warn "No se pudo instalar Chocolatey automaticamente."
      refresh_path
    else
      warn "Chocolatey no esta instalado y esta terminal no es Administrador: no se puede instalar automaticamente. Reejecuta como Administrador."
    fi
  fi
  if has_cmd choco; then
    if has_cmd mvn; then
      info "Actualizando Maven con Chocolatey (choco upgrade maven -y)..."
      choco upgrade maven -y >/dev/null 2>&1 && ok "Maven actualizado." || warn "Fallo 'choco upgrade maven -y'. Revisa el log de Chocolatey."
    else
      info "Instalando Maven con Chocolatey (choco install maven -y)..."
      choco install maven -y >/dev/null 2>&1 && ok "Maven instalado." || warn "Fallo 'choco install maven -y'. Revisa el log de Chocolatey."
    fi
    refresh_path
  fi
fi

if has_cmd mvn; then
  ok "mvn disponible."
else
  warn "mvn sigue sin detectarse en esta sesion. Vuelve a correr ./bootstrap.sh check en una terminal NUEVA para confirmar."
fi

if has_cmd code; then
  if code --list-extensions 2>/dev/null | grep -qi '^GitHub\.copilot$'; then
    ok "Extension GitHub.copilot ya instalada."
  else
    info "Instalando extension GitHub.copilot..."
    code --install-extension GitHub.copilot --force >/dev/null 2>&1 && ok "GitHub.copilot instalada." || warn "No se pudo instalar GitHub.copilot (hazlo desde el Marketplace)."
  fi
  if code --list-extensions 2>/dev/null | grep -qi '^GitHub\.copilot-chat$'; then
    ok "Extension GitHub.copilot-chat ya instalada."
  else
    info "Instalando extension GitHub.copilot-chat..."
    code --install-extension GitHub.copilot-chat --force >/dev/null 2>&1 && ok "GitHub.copilot-chat instalada." || warn "No se pudo instalar GitHub.copilot-chat (hazlo desde el Marketplace)."
  fi
else
  warn "'code' no esta en PATH; abre VS Code una vez para registrarlo, o instala las extensiones GitHub Copilot / GitHub Copilot Chat manualmente."
fi

refresh_path
ok "Paso de instalacion de herramientas terminado."
