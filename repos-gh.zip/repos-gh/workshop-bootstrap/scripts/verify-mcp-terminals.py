#!/usr/bin/env python3
"""Ejecuta day02-mcp real con procesos sustitutos para Windows, MCP e Inspector."""
import json
import os
from pathlib import Path
import signal
import subprocess
import tempfile
import time


ROOT = Path(__file__).resolve().parent.parent


STUB = r'''#!/usr/bin/env python3
import json, os, subprocess, sys, time
from pathlib import Path
name = Path(sys.argv[0]).name
args = sys.argv[1:]
with open(os.environ['VERIFY_COMMANDS'], 'a') as log:
    log.write(json.dumps([name, *args]) + '\n')
if name == 'gh':
    if args[:2] == ['auth', 'token']:
        print('fixture-secret-not-for-files')
    elif args[:2] == ['api', 'user']:
        print('alumno')
    elif args[:3] == ['api', '-i', 'user']:
        print('X-OAuth-Scopes: repo, project')
elif name == 'curl.exe':
    status_file = Path(os.environ['VERIFY_HTTP_STATUS'])
    values = status_file.read_text().splitlines()
    print(values[0], end='')
    if len(values) > 1:
        status_file.write_text('\n'.join(values[1:]) + '\n')
    sys.exit(7 if values[0] == '000' else 0)
elif name == 'cygpath':
    print(args[-1])
elif name == 'powershell':
    if '-File' in args:
        if os.environ.get('VERIFY_LAUNCH_FAIL'):
            sys.exit(1)
        runner = args[args.index('-RunnerPath') + 1]
        shell = args[args.index('-BashPath') + 1]
        child = subprocess.Popen([shell, runner], stdin=subprocess.DEVNULL,
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                 start_new_session=True)
        with open(os.environ['VERIFY_CHILDREN'], 'a') as children:
            children.write(str(child.pid) + '\n')
elif name == 'node':
    print('v22.19.0')
elif name == 'docker' and args[:2] == ['compose', 'logs']:
    assert Path.cwd() == Path(os.environ['VERIFY_MCP_DIRECTORY']).resolve()
    time.sleep(120)
elif name == 'npx':
    assert Path.cwd() == Path(os.environ['COURSE_DIR']).resolve()
    assert os.environ.get('GITHUB_TOKEN') == 'fixture-secret-not-for-files'
    assert args == ['--yes', '@modelcontextprotocol/inspector', '--config',
                    os.environ['HOME'] + '/.mcp-inspector/mcp.json', '--server', 'github-local'], args
    time.sleep(120)
elif name == 'sleep':
    time.sleep(0.01)
'''


def main():
    with tempfile.TemporaryDirectory(prefix="verify-mcp-") as temporary:
        work = Path(temporary)
        project = work / "toolkit"
        commands = work / "bin"
        commands.mkdir()
        for relative in ["bootstrap.sh", "lib/common.sh", "lib/mcp-terminals.sh",
                         "lib/open-terminal.ps1", "scripts/04-prebuild-mcp-images.sh",
                         "scripts/05-setup-mcp-inspector.sh", "scripts/07-day02-mcp-setup.sh"]:
            destination = project / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_text((ROOT / relative).read_text())
        for name in ["gh", "curl.exe", "cygpath", "powershell", "node", "npm", "docker", "npx", "sleep"]:
            path = commands / name
            path.write_text(STUB)
            path.chmod(0o755)
        course = work / "curso con espacios y 'comilla'"
        local = course / "bcp-ai-lab-day-02/s3_mcp/tools/mcp-local"
        local.mkdir(parents=True)
        (local / "compose.yaml").write_text("services: {}\n")
        (local / "Dockerfile").write_text("FROM scratch\n")
        state = local / ".workshop-bootstrap-last-run"
        state.write_text("OWNER=alumno\nREPO=demo\n")
        status = work / "http-status"
        log = work / "commands.jsonl"
        log.touch()
        children = work / "children"
        children.touch()
        env = dict(os.environ, HOME=str(work / "home con espacios"), COURSE_DIR=str(course),
                   PATH=str(commands) + os.pathsep + os.environ["PATH"], OS="Windows_NT",
                   VERIFY_MCP_DIRECTORY=str(local),
                   VERIFY_HTTP_STATUS=str(status), VERIFY_COMMANDS=str(log), VERIFY_CHILDREN=str(children))

        def events():
            return [json.loads(line) for line in log.read_text().splitlines()]

        def run(*options, statuses="406\n", expected=0, changes=None):
            status.write_text(statuses)
            result = subprocess.run(
                ["bash", str(project / "bootstrap.sh"), "day02-mcp", "--engine", "docker",
                 "--owner", "alumno", "--repo", "demo", "--skip-vscode", *options],
                env=dict(env, **(changes or {})), capture_output=True, text=True, timeout=20,
            )
            assert result.returncode == expected, (result.returncode, result.stdout, result.stderr)
            return result

        def stop_children():
            for line in children.read_text().splitlines():
                try:
                    os.killpg(int(line), signal.SIGTERM)
                except ProcessLookupError:
                    pass
            for _ in range(100):
                if not list(course.glob(".workshop-bootstrap-cache/terminals/*.pid")):
                    break
                time.sleep(0.01)

        try:
            # Reproduce el fallo: 000 + estado previo debe relanzar el MCP.
            run(statuses="000\n406\n")
            deadline = time.monotonic() + 3
            while not any(call[0] == "npx" for call in events()) and time.monotonic() < deadline:
                time.sleep(0.02)
            calls = events()
            assert any(call[:2] == ["docker", "compose"] and "up" in call for call in calls)
            assert any(call[:3] == ["docker", "compose", "logs"] for call in calls)
            assert any(call[0] == "npx" for call in calls)
            launches = [call for call in calls if call[0] == "powershell" and "-File" in call]
            assert len(launches) == 2, launches
            assert [call[-1] for call in launches] == ["Workshop MCP", "Workshop MCP Inspector"]
            assert [call[call.index('-WorkingDirectory') + 1] for call in launches] == [str(local), str(course)]
            runners = course / ".workshop-bootstrap-cache/terminals"
            for runner in runners.glob("*.sh"):
                subprocess.run(["bash", "-n", str(runner)], check=True)
                assert "fixture-secret-not-for-files" not in runner.read_text()
            run()
            assert len([call for call in events() if call[0] == "powershell" and "-File" in call]) == 2
            stop_children()
            log.write_text("")
            run("--skip-inspector")
            launches = [call for call in events() if call[0] == "powershell" and "-File" in call]
            assert len(launches) == 1 and launches[0][-1] == "Workshop MCP"
            stop_children()
            log.write_text("")
            run("--no-terminals")
            assert not any(call[0] == "npx" or (call[0] == "powershell" and "-File" in call) for call in events())
            log.write_text("")
            run(statuses="000\n", expected=1)
            assert not any(call[0] == "powershell" and "-File" in call for call in events())
            run(statuses="503\n", expected=1)
            run(expected=1, changes={"VERIFY_LAUNCH_FAIL": "yes"})
        finally:
            stop_children()
    print("OK: dos sesiones, comandos reales de arranque, rutas con espacios/comillas, reutilizacion, flags, HTTP 000/503 y fallos de apertura.")


if __name__ == "__main__":
    main()
