#!/usr/bin/env bash
# Pre-construye las imagenes de contenedor del servidor MCP local
# (misma imagen para TODOS los alumnos: no depende de owner/repo/token).
# NO levanta el servicio (eso lo hace el alumno con start-mcp.ps1 usando SU
# owner/repo/token, parte del laboratorio). Solo deja las imagenes en cache
# para que ese paso tarde segundos en vez de minutos durante la clase.
# Uso: ./bootstrap.sh mcp-images [--day 02|04]

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../lib/common.sh"

refresh_path

DAY="02"
ENGINE_OVERRIDE=""
while [ $# -gt 0 ]; do
  case "$1" in
    --day) DAY="$2"; shift 2 ;;
    --engine) ENGINE_OVERRIDE="$2"; shift 2 ;;
    *) shift ;;
  esac
done

ENGINE="${ENGINE_OVERRIDE:-$(container_engine)}"
if [ -z "$ENGINE" ]; then
  err "No se encontro podman ni docker. Corre primero: ./bootstrap.sh tools && ./bootstrap.sh podman"
  return 1
fi
info "Motor de contenedores: $ENGINE"

ensure_lab_repo "$DAY"

if [ "$DAY" = "04" ]; then
  MCP_LOCAL_DIR="$COURSE_DIR/bcp-ai-lab-day-04/00_support/mcp-local"
else
  MCP_LOCAL_DIR="$COURSE_DIR/bcp-ai-lab-day-02/s3_mcp/tools/mcp-local"
fi

if [ ! -f "$MCP_LOCAL_DIR/Dockerfile" ]; then
  warn "No se encontro $MCP_LOCAL_DIR/Dockerfile. Verifica que bcp-ai-lab-day-$DAY este presente en $COURSE_DIR, o pasa --day 02|04."
  return 0
fi

CACHE_DIR="$COURSE_DIR/.workshop-bootstrap-cache"
BASE_REPO_DIR="$CACHE_DIR/mcp-github-project-manager"
mkdir -p "$CACHE_DIR"

info "Preparando imagen base mcp-github-project-manager:latest..."
if $ENGINE image exists localhost/mcp-github-project-manager:latest 2>/dev/null; then
  ok "Imagen base ya en cache."
else
  if [ -d "$BASE_REPO_DIR/.git" ]; then
    info "Actualizando clon existente..."
    git -C "$BASE_REPO_DIR" pull --ff-only || warn "No se pudo actualizar el clon, se usara el existente."
  else
    info "Clonando kunwarVivek/mcp-github-project-manager (imagen base generica, no es un repo del workshop)..."
    git clone --depth 1 https://github.com/kunwarVivek/mcp-github-project-manager.git "$BASE_REPO_DIR" \
      || { err "No se pudo clonar la imagen base. Revisa tu conexion a internet."; return 1; }
  fi
  info "Construyendo imagen base (puede tardar unos minutos, se hace una sola vez por maquina)..."
  (cd "$BASE_REPO_DIR" && $ENGINE build -t localhost/mcp-github-project-manager:latest .) \
    && ok "Imagen base construida." \
    || { err "Fallo el build de la imagen base."; return 1; }
fi

if [ "$DAY" = "04" ]; then
  WRAPPER_TAGS=("mcp-project-http" "mcp-task-http")
else
  WRAPPER_TAGS=("mcp-http")
fi

for tag in "${WRAPPER_TAGS[@]}"; do
  if [ -z "${FORCE_REBUILD:-}" ] && $ENGINE image exists "$tag" 2>/dev/null; then
    ok "Imagen $tag ya en cache (se omite rebuild). Usa FORCE_REBUILD=1 para forzar."
    continue
  fi
  info "Construyendo wrapper HTTP ($tag) del laboratorio..."
  if (cd "$MCP_LOCAL_DIR" && $ENGINE build -f Dockerfile -t "$tag" .); then
    ok "Imagen $tag lista en cache local."
  else
    err "Fallo el build de $tag. Revisa $MCP_LOCAL_DIR/Dockerfile"
    return 1
  fi
done

ok "Imagenes MCP pre-construidas. El alumno solo necesita correr:"
log "  cd bcp-ai-lab-day-$DAY/.../mcp-local"
log "  ./start-mcp.ps1 -Owner \"<SU_OWNER>\" -Repo \"<SU_REPO>\""
log "(usara su propio token de 'gh auth token' y las imagenes que ya quedaron en cache)."
