#!/usr/bin/env bash
# Crea los virtualenvs e instala las librerias Python de las carpetas de LAB
# (bcp-ai-lab-day-02 raiz, bcp-ai-lab-day-04/s1_crewai..s4_guardrails).
# Solo opera sobre el material del curso (identico para todos los alumnos),
# NUNCA sobre reqflow-workspace ni sobre repos propios del alumno.
# Uso: ./bootstrap.sh python-envs   (usa COURSE_DIR=. por defecto)

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../lib/common.sh"

refresh_path
ensure_lab_repo "02"
ensure_lab_repo "04"

PY="$(py_valid_launcher)"
if [ -z "$PY" ]; then
  err "No se encontro un Python valido (3.11-3.13) en PATH. Corre primero: ./bootstrap.sh tools"
  return 1
fi
info "Usando interprete: $PY"

setup_env() {
  local dir="$1"
  shift
  local reqs=("$@")
  [ -d "$dir" ] || { warn "No existe $dir, se omite."; return; }

  local existing_reqs=()
  for r in "${reqs[@]}"; do [ -f "$dir/$r" ] && existing_reqs+=("$r"); done
  if [ "${#existing_reqs[@]}" -eq 0 ]; then
    warn "Sin requirements.txt en $dir, se omite."
    return
  fi

  info "Preparando entorno en: $dir"
  local venv_rel
  if is_windows; then venv_rel=".venv/Scripts/python.exe"; else venv_rel=".venv/bin/python"; fi

  local venv_ok=0
  if [ -d "$dir/.venv" ]; then
    if ( cd "$dir" && "$venv_rel" --version >/dev/null 2>&1 ); then
      venv_ok=1
      ok "  .venv ya existe y funciona (reutilizando)."
    else
      warn "  .venv existe pero esta roto (no ejecuta). Se recreara."
      rm -rf "$dir/.venv"
    fi
  fi

  if [ "$venv_ok" -eq 0 ]; then
    (cd "$dir" && $PY -m venv .venv) || { warn "  No se pudo crear .venv en $dir"; return; }
    ok "  .venv creado."
  fi

  local req_args=()
  for r in "${existing_reqs[@]}"; do req_args+=("-r" "$r"); done

  info "  Instalando dependencias (${existing_reqs[*]})..."
  if ( cd "$dir" && "$venv_rel" -m pip install --upgrade pip --quiet 2>/dev/null; "$venv_rel" -m pip install --quiet "${req_args[@]}" ); then
    ok "  Dependencias instaladas en $dir/.venv"
  else
    warn "  Fallo instalando dependencias en $dir. Revisa manualmente con: cd '$dir' && .venv\\Scripts\\activate && pip install -r requirements.txt"
  fi

  if [ -f "$dir/.env.example" ] && [ ! -f "$dir/.env" ]; then
    cp "$dir/.env.example" "$dir/.env"
    ok "  .env creado desde .env.example"
  fi
}

setup_env "$COURSE_DIR/bcp-ai-lab-day-02" "requirements.txt"
setup_env "$COURSE_DIR/bcp-ai-lab-day-04/s1_crewai" "requirements.txt"
setup_env "$COURSE_DIR/bcp-ai-lab-day-04/s2_langgraph" "requirements.txt"
setup_env "$COURSE_DIR/bcp-ai-lab-day-04/s3_harness" "requirements.txt"
setup_env "$COURSE_DIR/bcp-ai-lab-day-04/s4_guardrails" "requirements.txt"

ok "Entornos Python de las carpetas de lab preparados."
warn "Nota: workshop-requirements-api (dentro de reqflow-workspace) crea su propio .venv el Dia 1, siguiendo el README del lab - eso lo hace el alumno."
