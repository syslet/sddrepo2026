#!/usr/bin/env python3
"""Comprueba la configuracion real de Terminal sobre carpetas temporales."""
import contextlib
import importlib.util
import io
import json
import os
from pathlib import Path
import tempfile
import unittest
import sys
import subprocess


sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location(
    "windows_terminal", Path(__file__).resolve().parent.parent / "lib/windows_terminal.py")
terminal = importlib.util.module_from_spec(spec)
spec.loader.exec_module(terminal)


class TerminalConfigurationTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="verify-terminal-")
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.settings = self.root / "LocalState/settings.json"
        self.settings.parent.mkdir()
        self.bash = self.root / "Git personalizado/bin/bash.exe"
        self.bash.parent.mkdir(parents=True)
        self.bash.touch()
        self.directory = self.root / "curso con espacios y ñ"
        self.directory.mkdir()
        self.fragment = self.root / "Microsoft/Windows Terminal/Fragments/BCPWorkshop/workshop.json"

    def configure(self):
        with contextlib.redirect_stdout(io.StringIO()):
            terminal.configure(self.settings, self.root, self.bash, self.directory)

    def test_preserves_jsonc_profiles_strings_bom_and_crlf(self):
        raw = ('{\r\n // No borrar mis ajustes\r\n'
               ' "defaultProfile": /* comentario */ "{otro}",\r\n'
               ' "help": "https://example.com/a,}/*texto*/",\r\n'
               ' "profiles": {"defaults": {"font": {"size": 14}}, "list": [\r\n'
               ' {"guid": "{personal}", "name": "Mi perfil", "defaultProfile": "anidado"},\r\n'
               ' ]},\r\n "actions": ["copy", "paste"],\r\n}\r\n')
        before = b"\xef\xbb\xbf" + raw.encode("utf-8")
        self.settings.write_bytes(before)
        self.configure()
        expected = before.replace(b'"{otro}"', json.dumps(terminal.PROFILE_ID).encode())
        self.assertEqual(self.settings.read_bytes(), expected)
        backups = list(self.settings.parent.glob("settings.json.workshop-*.bak"))
        self.assertEqual(len(backups), 1)
        self.assertEqual(backups[0].read_bytes(), before)
        self.assertEqual(terminal.parse_jsonc(self.settings.read_text(encoding="utf-8-sig"))[0]["actions"], ["copy", "paste"])
        profile = json.loads(self.fragment.read_text(encoding="utf-8"))["profiles"][0]
        launcher = self.fragment.with_name("workshop-bash.cmd")
        self.assertEqual(profile["commandline"], f'cmd.exe /d /s /c ""{launcher}""')
        self.assertEqual(profile["startingDirectory"], str(self.directory))
        self.assertIn(b'set "CHERE_INVOKING=1"', launcher.read_bytes())
        self.assertIn(f'"{self.bash}" --login -i'.encode(), launcher.read_bytes())
        self.assertFalse(profile["elevate"])

    def test_repeat_and_change_directory(self):
        self.configure()
        before = self.settings.read_bytes(), self.fragment.read_bytes()
        self.configure()
        self.assertEqual((self.settings.read_bytes(), self.fragment.read_bytes()), before)
        self.assertFalse(list(self.root.rglob("*.bak")))
        self.directory = self.root / "otra carpeta"
        self.directory.mkdir()
        self.configure()
        self.assertEqual(self.settings.read_bytes(), before[0])
        profiles = json.loads(self.fragment.read_text(encoding="utf-8"))["profiles"]
        self.assertEqual(len(profiles), 1)
        self.assertEqual(profiles[0]["startingDirectory"], str(self.directory))
        self.assertEqual(len(list(self.fragment.parent.glob("*.bak"))), 1)

    def test_missing_default_preserves_existing_settings(self):
        for raw in ('{}\n', '{/* comentario */}', '{"profiles": [], "theme": "dark",}'):
            updated = terminal.set_default_profile(raw)
            before = terminal.parse_jsonc(raw)[0]
            after = terminal.parse_jsonc(updated)[0]
            self.assertEqual(after.pop("defaultProfile"), terminal.PROFILE_ID)
            self.assertEqual(before, after)
            self.assertEqual(terminal.set_default_profile(updated), updated)

    def test_terminal_generated_profile_reference_can_be_reused(self):
        raw = json.dumps({"defaultProfile": terminal.PROFILE_ID,
                          "profiles": {"list": [{"guid": terminal.PROFILE_ID,
                                                  "source": terminal.SOURCE,
                                                  "name": "Workshop - Bash"}]}})
        self.settings.write_text(raw, encoding="utf-8")
        self.configure()
        self.configure()
        self.assertEqual(self.settings.read_text(encoding="utf-8"), raw)
        self.assertFalse(list(self.root.rglob("*.bak")))

    def test_invalid_or_conflicting_settings_leave_everything_untouched(self):
        for raw in ('{"profiles": [}', '{/* sin cierre', '{"defaultProfile":"a", "defaultProfile":"b"}',
                    '{"disabledProfileSources": ["BCPWorkshop"]}',
                    json.dumps({"profiles": {"list": [{"guid": terminal.PROFILE_ID, "startingDirectory": "personal"}]}})):
            with self.subTest(raw=raw):
                self.settings.write_text(raw, encoding="utf-8")
                with self.assertRaises(ValueError):
                    self.configure()
                self.assertEqual(self.settings.read_text(encoding="utf-8"), raw)
                self.assertFalse(self.fragment.exists())
                self.assertFalse(list(self.root.rglob("*.bak")))

    @unittest.skipUnless(os.name == "nt", "La apertura real de Git Bash requiere Windows")
    def test_real_windows_launcher_preserves_starting_directory(self):
        self.bash = Path(os.environ["ProgramFiles"]) / "Git/bin/bash.exe"
        self.configure()
        profile = json.loads(self.fragment.read_text(encoding="utf-8"))["profiles"][0]
        result = subprocess.run(
            profile["commandline"], cwd=self.directory,
            input='printf "WORKSHOP_DIRECTORY=%s\\n" "$(pwd -W)"\nprintf "WORKSHOP_CHERE=%s\\n" "$CHERE_INVOKING"\nexit\n',
            capture_output=True, text=True, encoding="utf-8", timeout=30)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("WORKSHOP_DIRECTORY=" + str(self.directory).replace("\\", "/"), result.stdout)
        self.assertIn("WORKSHOP_CHERE=1", result.stdout)

    @unittest.skipUnless(os.name == "nt", "El lanzador PowerShell requiere Windows")
    def test_powershell_sends_two_tabs_to_windows_terminal(self):
        self.configure()
        commands = self.root / "bin"
        commands.mkdir()
        capture = self.root / "wt-arguments.txt"
        env = dict(os.environ, LOCALAPPDATA=str(self.root), VERIFY_WT_CAPTURE=str(capture),
                   VERIFY_WT_EXE=str(commands / "wt.exe"))
        path_key = next(key for key in env if key.lower() == "path")
        env[path_key] = str(commands) + os.pathsep + env[path_key]
        # Un ejecutable real captura los argumentos nativos recibidos de
        # Windows PowerShell 5, sin abrir la GUI en el runner de CI.
        source = ('public class Capture { public static void Main(string[] args) {'
                  'System.IO.File.WriteAllLines(System.Environment.GetEnvironmentVariable("VERIFY_WT_CAPTURE"),'
                  'args, new System.Text.UTF8Encoding(false)); }}')
        env["VERIFY_WT_SOURCE"] = source
        subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive", "-Command",
                        "Add-Type -TypeDefinition $env:VERIFY_WT_SOURCE -OutputAssembly $env:VERIFY_WT_EXE -OutputType ConsoleApplication"],
                       env=env, check=True, capture_output=True, timeout=30)
        launcher = Path(__file__).resolve().parent.parent / "lib/open-terminal.ps1"
        for title in ("Workshop MCP", "Workshop MCP Inspector"):
            runner = "/c/curso con espacios y 'comilla'/" + title + ".sh"
            subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                            "-File", str(launcher), "-BashPath", str(self.bash), "-RunnerPath", runner,
                            "-WorkingDirectory", str(self.directory), "-Title", title],
                           env=env, check=True, capture_output=True, timeout=30)
            self.assertEqual(capture.read_text(encoding="utf-8").splitlines(), [
                "-w", "BCPWorkshopMCP", "new-tab", "--profile", terminal.PROFILE_ID,
                "--title", title, "--suppressApplicationTitle", "--startingDirectory",
                str(self.directory), str(self.bash), "--login", runner])


if __name__ == "__main__":
    unittest.main()
