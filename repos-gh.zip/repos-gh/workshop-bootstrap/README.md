# workshop-bootstrap

Automatizacion de **prerrequisitos de maquina** y preparacion del workspace
para el BCP AI Lab (Dias 01-04). `tools` instala las herramientas que faltan.
`all` prepara la maquina, Windows Terminal y los workspaces de los Dias 1 y 2.
Ejecuta `all` con la cuenta de GitHub del participante: crea o clona sus repos
privados. Si falta la sesion, inicia el login.

## Ejecutar desde un enlace

Abre **Git Bash como Administrador** en Windows. Ejecuta cada opcion por separado.
Primero, consulta el diagnostico:

```bash
curl -fsSL https://bcp-ai-labs.pages.dev/install.sh | bash -s -- check
```

Para instalar las herramientas que falten:

```bash
curl -fsSL https://bcp-ai-labs.pages.dev/install.sh | bash -s -- tools
```

Descarga el toolkit completo, comprueba su SHA-256, lo guarda en
`C:\workshop-bootstrap` y ejecuta solamente la opcion seleccionada de `bootstrap.sh`.
El diagnostico queda por defecto en `C:\Users\Usuario\Documents\bcp-ai-labs`. No necesitas
clonar este proyecto ni tener `gh` instalado para descargar el toolkit.
Si la carpeta del toolkit ya existe, la reutiliza sin reemplazar archivos.
Para usar una version nueva, elige otra `WORKSHOP_INSTALL_DIR`.

Sin argumentos, el instalador muestra la ayuda sin descargar ni ejecutar el toolkit.
La ayuda muestra las opciones y sus descripciones en columnas alineadas, con el formato del comando y ejemplos al final:

```bash
curl -fsSL https://bcp-ai-labs.pages.dev/install.sh | bash
```

Conserva las opciones `check`, `tools`, `day01`, `day02`, `podman`, `labs`, `python-envs`,
`terminal`, `mcp-images`, `inspector`, `warm-cache`, `day02-mcp` y `all`.
`all` ejecuta el flujo completo solo si se indica expresamente:

```bash
curl -fsSL https://bcp-ai-labs.pages.dev/install.sh | bash -s -- all
```

Incluye herramientas, Windows Terminal, los cuatro laboratorios, `day01` y
`day02`, sus dependencias, el catalogo de Skills, imagenes MCP e Inspector.
Los tres repos privados se crean si faltan o se clonan desde la cuenta activa.
Conserva los repos locales y el trabajo existente. Puede pedir login de GitHub
con la cuenta del participante y reinicio de Windows para WSL2.
`day02-mcp` se ejecuta aparte para levantar el MCP personal.
Si el toolkit anterior tiene un `all` que solo prepara la maquina, descarga
una copia hermana `-all-v1` y conserva la anterior.
`tools` requiere Git Bash instalado y permisos para instalar herramientas.

Para ejecutar el diagnostico o la configuracion personal del Dia 2:

```bash
curl -fsSL https://bcp-ai-labs.pages.dev/install.sh | bash -s -- check
curl -fsSL https://bcp-ai-labs.pages.dev/install.sh | bash -s -- day02-mcp
```

Si tus labs ya estan en otra carpeta, indica su ruta. Las variables deben
ir despues del pipe, junto al proceso `bash`:

```bash
curl -fsSL https://bcp-ai-labs.pages.dev/install.sh | COURSE_DIR=/c/Users/Usuario/Documents/bcp-ai-labs bash -s -- check
curl -fsSL https://bcp-ai-labs.pages.dev/install.sh | WORKSHOP_INSTALL_DIR=/c/workshop-bootstrap-v2 bash -s -- tools
```

## Preparar tus workshops por dia: `day01` y `day02`

Ejecuta cada dia por separado con tu cuenta de GitHub, desde Git Bash o el
perfil `Workshop - Bash` de Windows Terminal. Si faltan herramientas,
ejecuta `tools` antes. Se requieren Java 21, Maven 3.9+, Node 22.12+,
Python 3.13, Git y GitHub CLI. `tools` instala Python 3.13 cuando falta.

Para crear el workspace y preparar el Dia 1:

```bash
curl -fsSL https://bcp-ai-labs.pages.dev/install.sh | bash -s -- day01
```

Descarga solo el laboratorio 01 y crea `reqflow-workspace/` al lado.
Detecta tu owner con `gh auth`; pide login si falta. Crea estos tres repos
privados desde las plantillas, conservando el historial completo:

- `workshop-auth-backend`: descarga las dependencias de Maven.
- `workshop-requirements-api`: crea `.venv` con Python 3.13 e instala los requirements normales y de desarrollo.
- `workshop-login-frontend`: instala dependencias con `npm ci` si hay lock, o `npm install` si no.

Si los repos ya existen en GitHub, clona tus repos personales. Si ya estan
en tu computadora, reutiliza las copias con su rama, commits y cambios.
Copia `.env.example` a `.env` solo si falta `.env`. No cambia un origin ajeno
ni reemplaza una carpeta ocupada o un entorno Python roto.

Para preparar el Dia 2 con esos mismos repos:

```bash
curl -fsSL https://bcp-ai-labs.pages.dev/install.sh | bash -s -- day02
```

Descarga solo el laboratorio 02, prepara su `.venv`, las dependencias del
producto, el catalogo `bcp-ai-skill-catalog`, las imagenes MCP del Dia 2 y
MCP Inspector. Requiere Podman/Docker Compose disponible; usa `podman` si
necesitas prepararlo. Recupera tus repos personales si faltan localmente.
Si no existen en GitHub, indica que debes ejecutar `day01`: no crea un
producto nuevo para sustituir el trabajo del Dia 1.

Comprueba el handoff del Dia 1 e informa los entregables pendientes.
No genera HALLAZGOS, Skills de ejercicios, issues, respuestas ni tags.
El catalogo queda listo para que selecciones los Skills siguiendo la guia.
El MCP con tus credenciales se ejecuta aparte con `day02-mcp`.

Para elegir la carpeta del curso sin variables temporales:

```bash
curl -fsSL https://bcp-ai-labs.pages.dev/install.sh | bash -s -- day01 --directory 'C:\Users\Usuario\Documents\bcp-ai-labs'
curl -fsSL https://bcp-ai-labs.pages.dev/install.sh | bash -s -- day02 --directory 'C:\Users\Usuario\Documents\bcp-ai-labs'
```

Tambien aceptan `--owner <usuario>` si necesitas otro owner. Usa el mismo
owner y carpeta ambos dias. Sin `--directory`, todos usan la ruta fija
`C:\Users\Usuario\Documents\bcp-ai-labs`. `Usuario` es el nombre literal de la cuenta del taller.
Repetirlos no fuerza pushes ni cambia archivos del participante.
No arrancan los servicios: sigue la guia para ejecutarlos en sus terminales.
Si tu toolkit es anterior, descargan una copia hermana `-days-v1`.
`all` incluye `day01` y luego `day02`, ademas de la preparacion de maquina.

## Windows Terminal con pestanas: `terminal`

Ejecuta esta opcion desde Git Bash con tu usuario del taller. Requiere Python 3,
incluido en `tools`. No necesita ejecutar `all` ni configurar WSL:

```bash
curl -fsSL https://bcp-ai-labs.pages.dev/install.sh | bash -s -- terminal
```

Instala Windows Terminal estable si falta, usando winget. Crea el perfil
`Workshop - Bash` y lo selecciona como predeterminado. La carpeta inicial
es la carpeta del curso, por defecto `C:\Users\Usuario\Documents\bcp-ai-labs`.
Para elegir otra carpeta, puedes indicarla como argumento, sin exportar variables:

```bash
curl -fsSL https://bcp-ai-labs.pages.dev/install.sh | bash -s -- terminal --directory 'C:\Users\Usuario\Documents\bcp-ai-labs'
```

Crea la carpeta si falta. El perfil usa el `bash.exe` de Git for Windows y
`CHERE_INVOKING=1` solo dentro de esa terminal, para respetar la carpeta inicial.
No cambia el PATH ni las variables persistentes de Windows.

Cierra Windows Terminal y abrelo de nuevo. `Ctrl+Shift+T` abre otra pestana.
`Alt+Shift+D` divide el panel usando el perfil actual.
Para instalar herramientas con permisos elevados, abre Terminal como Administrador.
El perfil no pide elevacion automaticamente.

La configuracion se aplica al usuario que ejecuta el comando. Conserva los
otros perfiles, comentarios y ajustes. Guarda respaldos `*.workshop-*.bak`
junto a los archivos que modifica. Repetirlo no duplica el perfil.
Si los ajustes no son JSONC valido o hay una personalizacion de la ruta del mismo perfil
en `settings.json`, informa el problema antes de modificar la configuracion.

Si tienes un toolkit anterior sin esta opcion, el instalador usa una carpeta
hermana con sufijo `-terminal-v1`, sin modificar la copia anterior.
`terminal` tambien forma parte de `all`, despues de instalar las herramientas.

## Publicar el instalador en Cloudflare Pages

Desde la raiz del proyecto, genera los archivos:

```bash
bash scripts/build-release.sh
```

Publica estos tres archivos de `dist/` en la raiz del proyecto Pages
`bcp-ai-labs`, junto al sitio existente:

- `install.sh`
- `workshop-bootstrap.tar.gz`
- `workshop-bootstrap.tar.gz.sha256`

Si Pages despliega desde Git, usa `bash scripts/build-release.sh` como comando
de build y `dist` como directorio de salida para un proyecto dedicado al
instalador. Si el proyecto tambien contiene una web, copia los tres archivos
a la salida de esa web antes de desplegarla.

Las tres URLs deben responder sin autenticacion. Excluyelas de cualquier
regla de acceso que devuelva `401` y de las redirecciones a `index.html`.
Comprueba la descarga publicada sin ejecutar instalaciones:

```bash
curl -fsSL https://bcp-ai-labs.pages.dev/install.sh | bash -s -- --help
```

La comprobacion SHA-256 detecta descargas incompletas o archivos que no
corresponden al paquete publicado. Publica siempre el paquete y su checksum
en el mismo despliegue.

Para probar la descarga, los errores y la reutilizacion en un servidor local,
sin instalar herramientas de Windows:

```bash
python3 scripts/verify-installer.py
```

## Donde debe vivir esta carpeta

**Fuera de la carpeta del curso, en una ruta fija e identica en todas las
laptops**, por ejemplo:

```
C:\workshop-bootstrap\
```

Por que ahi y no dentro de `reqflow-workspace/` ni dentro de
`bcp-ai-lab-day-0X/`:

- `reqflow-workspace/` es el **producto del alumno** (sus 3 repos propios);
  nunca debe mezclarse con herramientas de infraestructura, y VS Code se
  abre justo ahi — no quieres que el alumno vea ni toque este toolkit.
- `bcp-ai-lab-day-0X/` es contenido de curso que se distribuye por laboratorio
  (zip/clon); el bootstrap es independiente de eso: la mayoria de sus pasos
  (`tools`, `podman`, `inspector`) no necesitan ningun contenido de curso
  presente todavia.
- Una ruta fija (`C:\workshop-bootstrap`) permite copiarla igual a todas las
  laptops (USB, carpeta compartida, `robocopy`, Intune, etc.) y volver a
  correrla sin pedir rutas.

Estructura recomendada en cada laptop, una vez todo esta listo:

```text
C:\
├── workshop-bootstrap\         ← este toolkit (se puede borrar despues del taller)
└── Users\Usuario\Documents\bcp-ai-labs\
    ├── bcp-ai-lab-day-01\
    ├── bcp-ai-lab-day-02\
    ├── bcp-ai-lab-day-03\
    ├── bcp-ai-lab-day-04\
    └── reqflow-workspace\   ← producto del alumno, preparado con day01
```

Los pasos `python-envs`, `mcp-images`, `warm-cache` y `day02-mcp` SI leen
contenido de curso (`bcp-ai-lab-day-02`, `bcp-ai-lab-day-04`) via
`COURSE_DIR`. Ya no es necesario copiarlo a mano: todos los alumnos tienen
acceso de lectura a los 4 repos de laboratorio en GitHub
(`NTTData-Academy/bcp-ai-lab-day-01..04`), asi que cada uno de esos pasos
clona automaticamente el repo que necesite si todavia no esta en
`COURSE_DIR` (usando la sesion de `gh` de quien corre el script). Tambien
puedes clonarlos todos de una vez: `./bootstrap.sh labs`. Si prefieres
usar otro org/fork, pasa `--org <Org>` o la variable `LAB_ORG`.

## Ejecutar desde una copia local

1. Copia la carpeta `workshop-bootstrap\` a la laptop (ej. `C:\workshop-bootstrap`).
2. Abre **Git Bash como Administrador** (clic derecho → "Ejecutar como
   administrador"). Es necesario para instalar en modo maquina (winget
   `--scope machine`, Chocolatey, variables de entorno de sistema como
   `JAVA_HOME`). Si no corres elevado, el script lo detecta, avisa, e instala
   lo que pueda a nivel de usuario — pero para quedar 100% listo, usa Admin.
3. Ejecuta:

   ```bash
   cd /c/workshop-bootstrap
   ./bootstrap.sh all
   ```

   Esto corre en orden: diagnostico → herramientas faltantes → Windows Terminal →
   Podman y WSL2 → login de GitHub con la cuenta del participante si falta →
   clonar los cuatro laboratorios → entornos Python → `day01`, con los tres
   repos privados y dependencias → `day02`, con los mismos repos, Skills,
   imagenes MCP e Inspector → imagenes MCP del Dia 4 → caches → diagnostico final.

4. Si el paso de Podman instala/habilita WSL2 por primera vez, puede pedir
   **reiniciar la laptop una sola vez**. Reinicia y vuelve a correr
   `./bootstrap.sh all` (todo lo anterior ya quedo hecho, es idempotente:
   solo retoma lo que falte).
5. Al terminar, corre `./bootstrap.sh check` y confirma que no queden filas
   `FALTA`. El login de GitHub debe corresponder al participante.

Para apuntar a una carpeta de curso especifica en vez de la actual:

```bash
COURSE_DIR=/c/Users/Usuario/Documents/bcp-ai-labs ./bootstrap.sh labs
COURSE_DIR=/c/Users/Usuario/Documents/bcp-ai-labs ./bootstrap.sh python-envs
COURSE_DIR=/c/Users/Usuario/Documents/bcp-ai-labs ./bootstrap.sh mcp-images --day 02
COURSE_DIR=/c/Users/Usuario/Documents/bcp-ai-labs ./bootstrap.sh mcp-images --day 04
COURSE_DIR=/c/Users/Usuario/Documents/bcp-ai-labs ./bootstrap.sh warm-cache
```

## Que valida/instala automaticamente (sin preguntar nada)

| Herramienta | Si falta... |
|---|---|
| Git (y Git Bash) | se instala via `winget` (`Git.Git`) |
| GitHub CLI (`gh`) | se instala via `winget` (`GitHub.cli`) |
| Node.js LTS (>=22.12) | se instala via `winget` (`OpenJS.NodeJS.LTS`) |
| Python 3.13 | se instala via `winget` (`Python.Python.3.13`) |
| Java 21 (Temurin) | se instala via `winget`; ademas se fija `JAVA_HOME` y se prioriza en el `PATH` de maquina **aunque ya exista otra version de Java**, para que `mvn`/`java` usen siempre 21 |
| Maven 3.9+ | se instala **Chocolatey primero si no esta** (comando oficial de chocolatey.org), y luego `choco install maven -y`, igual que documentan los labs |
| Podman CLI | se instala via `winget` (`RedHat.Podman`); luego se habilita WSL2, se crea/arranca la maquina de Podman, se instala `podman-compose`, y se **pre-descargan** las 3 imagenes base (Maven/Python/Node) que usan los `compose.yaml` del Dia 1 |
| Visual Studio Code | se instala via `winget`; se instalan ademas las extensiones `GitHub.copilot` y `GitHub.copilot-chat` |
| Repos de laboratorio (`bcp-ai-lab-day-01..04`) | se **clonan automaticamente desde GitHub** (`NTTData-Academy`, acceso de lectura para todos los alumnos) con `gh repo clone` si no estan ya en `COURSE_DIR` |
| MCP Inspector | se instala global con `npm install -g @modelcontextprotocol/inspector`, y se siembra su catalogo (`~/.mcp-inspector/mcp.json`) con los servidores `github-local` (puerto 8081) y `github-official` del curso |
| Entornos Python de los labs | se crea `.venv` y se instalan las dependencias de `bcp-ai-lab-day-02/requirements.txt` y `bcp-ai-lab-day-04/s1_crewai..s4_guardrails/requirements.txt` |
| Imagenes del MCP local | se clonan/compilan `mcp-github-project-manager` + el wrapper HTTP del lab, sin necesitar owner/repo/token |
| Caches npm/Maven/pip | se precalientan clonando temporalmente las plantillas publicas `workshop-*-template` (se borra la copia al terminar) |

Todo es **idempotente**: correrlo de nuevo detecta lo que ya esta hecho y lo
salta — no rompe nada, no reinstala de mas.

## Alcance de `all`

`all` crea `reqflow-workspace/`, crea o clona los tres repos privados del
participante y prepara los Dias 1 y 2. Los repos pertenecen a la cuenta activa
de GitHub, no a `NTTData-Academy`. Las plantillas conservan su historial completo.

No crea respuestas de ejercicios, entregables, issues, Projects ni tags de
evaluacion. Tampoco levanta el MCP personal ni configura VS Code con sus
credenciales. Ejecuta `day02-mcp` aparte cuando llegues a esa seccion del Dia 2.

## Dia 2 — MCP + VS Code + Podman, automatizado por alumno: `day02-mcp`

`all` prepara el workspace y las herramientas. `day02-mcp` levanta el servicio
con el owner/repo y la sesion de GitHub del participante. Ejecutalo cuando llegues al
Paso 1 de `s3_mcp` — reemplaza seguir a mano `STEP_1.md` y `STEP_2.md`.

```bash
cd /c/workshop-bootstrap
./bootstrap.sh day02-mcp
```

Pide la MENOR cantidad de datos posible, apoyandose en `gh auth` para
deducir lo que el alumno quizas no sepa de memoria:

- **OWNER**: se detecta solo con `gh api user` (la cuenta con la que el
  alumno hizo `gh auth login`) — nunca se pregunta, salvo que la deteccion
  falle. **Importante**: `workshop-auth-backend`, `workshop-login-frontend`
  y `workshop-requirements-api` viven en la **cuenta personal** de cada
  alumno (no en un org de GitHub), que es exactamente lo que `gh api user`
  devuelve — por eso nunca se usa `LAB_ORG` para esto.
- **REPO**: el script busca, bajo ese OWNER, cuales de esos 3 repos
  propios ya existen (`gh repo view <owner>/<nombre>`, de solo lectura) y:
  - si encuentra **exactamente uno**, lo usa automaticamente, sin preguntar;
  - si encuentra **varios**, muestra un menu numerado (Enter = el primero);
  - si no encuentra **ninguno** (el alumno no ha hecho el Dia 1 todavia, o
    su OWNER es otro), pide el nombre a mano como ultimo recurso.

  También puedes evitar toda interaccion pasando los flags directamente:
  `./bootstrap.sh day02-mcp --owner <OWNER> --repo <REPO>`.

Hace, en orden:

1. **Imagenes**: construye `mcp-github-project-manager` + el wrapper HTTP del
   lab (reusa `mcp-images`, no repite el build si ya esta en cache).
2. **GitHub**: si no hay sesion de `gh auth login`, la dispara (el alumno
   completa el login); asegura el scope `project`; obtiene el token con
   `gh auth token`.
3. **Podman**: levanta el servicio con `podman compose up -d --build` (o
   `docker compose` si no hay Podman) y lo **deja corriendo** en
   `http://localhost:8081/mcp`; espera y confirma que el endpoint responda.
4. **VS Code, automatico**:
   - agrega `github-local` y `github-official` al perfil de usuario con
     `code --add-mcp` (comando oficial documentado por Microsoft);
   - asegura en el `settings.json` de usuario las claves
     `chat.agent.enabled`, `chat.mcp.access` y `chat.mcp.discovery.enabled`
     (sin pisar valores que el alumno ya haya puesto, ni tocar sus
     comentarios/formato existentes);
   - si `reqflow-workspace/` ya existe (se crea en el Dia 1), escribe
     `.vscode/mcp.json` con los `servers` `github-local` y
     `github-official` — exactamente el archivo que pide `STEP_2.md`.
5. **MCP Inspector**: lo instala/actualiza y confirma que su catalogo apunta
   al servidor que acaba de quedar corriendo (reusa `inspector`). Abre dos
   pestanas en una ventana de Windows Terminal, con el perfil `Workshop - Bash`:
   **Workshop MCP** muestra los logs del contenedor y **Workshop MCP Inspector**
   ejecuta el Inspector con `github-local` seleccionado. Cada pestana inicia
   en su carpeta: el MCP local y la carpeta del curso, respectivamente.
   El Inspector muestra su enlace de acceso y abre su interfaz en el navegador.

Configura antes Windows Terminal para el mismo usuario:

```bash
curl -fsSL https://bcp-ai-labs.pages.dev/install.sh | bash -s -- terminal
curl -fsSL https://bcp-ai-labs.pages.dev/install.sh | bash -s -- day02-mcp
```

Flags utiles: `--engine podman|docker`, `--skip-vscode`, `--skip-inspector`,
`--no-terminals`. `--skip-inspector` tambien omite su pestana.
`--no-terminals` prepara el servicio y la configuracion sin abrir pestanas.
`all` configura Terminal y prepara los workspaces. Las pestanas se abren con `day02-mcp`,
que usa los datos del alumno. No ejecuta las otras opciones del instalador.

Repetir `day02-mcp` reutiliza las sesiones que siguen ejecutando sus comandos.
Si cierras la del MCP, el contenedor sigue corriendo. Si cierras la del
Inspector, repite `day02-mcp` para abrirla de nuevo. Los archivos de arranque
se guardan en `COURSE_DIR/.workshop-bootstrap-cache/terminals`. El token se
obtiene con `gh auth token` dentro de cada sesion y no se escribe en esos archivos.
Si la copia del toolkit es anterior, el instalador usa una carpeta hermana
con sufijo `-mcp-terminal-v1`, sin modificar la copia anterior.

Para verificar este flujo con procesos sustitutos, sin instalar ni abrir aplicaciones:

```bash
python3 scripts/verify-mcp-terminals.py
```
Es idempotente: si lo vuelves a correr con el mismo owner/repo no reconstruye
nada; si cambias owner/repo, reinicia el contenedor con los datos nuevos; si
`reqflow-workspace/` todavia no existia la primera vez, solo avisa y, al
volver a correrlo despues de que exista, completa el `.vscode/mcp.json`.

## Que necesita tener el alumno ANTES de sentarse (nada tecnico)

- Una cuenta de **GitHub** (personal o la que indique el trainer) — la va a
  usar el Dia 1 para `gh auth login` y crear sus 3 repos. No necesita
  configurar nada de antemano en la laptop: Git, GitHub CLI, Node, Python,
  Java, Maven, Podman, VS Code, Copilot y MCP Inspector ya estan instalados
  por este bootstrap.
- Nada mas. Se sienta, abre Git Bash, y sigue la guia del Dia 1 desde el
  primer paso (`gh auth login`, clonar sus repos, etc.). Cuando llegue al
  Paso 1 de MCP del Dia 2, el instructor (o el propio alumno) corre
  `./bootstrap.sh day02-mcp` y en unos minutos tiene el MCP corriendo, VS
  Code configurado y el Inspector listo, sin seguir la guia paso a paso.

## Estructura

```
workshop-bootstrap/
├── bootstrap.sh                       # orquestador (punto de entrada)
├── lib/common.sh                      # helpers compartidos (incluye refresh_path, is_admin)
├── lib/windows_terminal.py            # fragmento de Terminal y actualizacion segura de JSONC
├── lib/mcp-terminals.sh               # sesiones de logs MCP e Inspector
├── lib/open-terminal.ps1              # abre pestanas en Windows Terminal
├── lib/workshop.sh                    # repos personales y dependencias de day01/day02
└── scripts/
    ├── 00-check-prereqs.sh            # diagnostico (solo lectura)
    ├── 01-install-tools.sh            # git/gh/node/python/java21/maven/podman/VS Code — instala si falta
    ├── 02-setup-podman.sh             # WSL2 + podman machine + imagenes base
    ├── 03-setup-python-envs.sh        # venvs de las carpetas de lab
    ├── 04-prebuild-mcp-images.sh      # imagenes del MCP local (sin levantarlo)
    ├── 05-setup-mcp-inspector.sh      # instala/siembra catalogo de Inspector
    ├── 06-warm-dependency-caches.sh   # cache npm/maven/pip (best-effort)
    ├── 07-day02-mcp-setup.sh          # POR ALUMNO: MCP corriendo + VS Code + Inspector (Dia 2)
    ├── 08-clone-labs.sh               # clona los 4 repos de laboratorio si faltan
    ├── 09-setup-terminal.sh           # Windows Terminal, perfil Bash y carpeta inicial
    └── 10-prepare-workshop.sh         # workspace del participante, por dia
```

## Nota tecnica: por que usar `./bootstrap.sh`, no `bash bootstrap.sh`

En Windows hay varios binarios llamados `bash.exe` (el de Git for Windows y
el stub de WSL en `System32`). Para evitar ambiguedad, estos scripts estan
pensados para correrse **desde dentro de una terminal Git Bash ya abierta**
(`./bootstrap.sh ...`), tal como va a trabajar el alumno despues. Todos los
scripts usan `source` internamente entre si para compartir el `PATH`
refrescado dentro de la misma ejecucion, sin reordenar `/usr/bin` ni
`/mingw64/bin` (que deben seguir resolviendose primero para que
`grep`/`dirname`/`npm` sigan funcionando).

## Checklist antes de distribuir a produccion

Validado end-to-end en una laptop real (Windows + Git Bash) antes de cerrar
esta version:

- [x] Sintaxis de los 11 archivos (`bootstrap.sh`, `lib/common.sh`, los 9
      scripts de `scripts/`) verificada con `bash -n` usando el Git Bash real
      del sistema (no el stub de `System32`).
- [x] `./bootstrap.sh check` corrido de punta a punta: detecta correctamente
      herramientas presentes/ausentes, versiones por debajo del minimo,
      sesion de `gh auth` real (incluso con una segunda cuenta rota en el
      keyring — caso real encontrado y corregido).
- [x] `./bootstrap.sh python-envs`: crea un venv real, detecta uno roto y lo
      recrea, detecta uno sano y lo reutiliza sin tocarlo.
- [x] `./bootstrap.sh labs`: clona un repo de laboratorio real desde GitHub,
      es idempotente (segunda corrida no reclona), y los demas pasos
      (`mcp-images`, `python-envs`, `day02-mcp`) auto-clonan el repo que
      necesiten si falta.
- [x] Helpers de JSON (`ensure_json_keys`, `merge_json_servers`,
      `force_json_servers`) probados con comentarios reales de VS Code,
      valores ya correctos, valores incorrectos a corregir, y entradas
      ajenas que deben preservarse intactas.
- [x] Autodeteccion de `OWNER`/`REPO` del Dia 2 probada contra GitHub real:
      detecta el owner sin preguntar, encuentra los 3 repos personales
      existentes, resuelve el menu por numero/Enter/nombre libre, y cae en
      el flujo manual cuando el owner no tiene ninguno de los 3 repos.
- [x] `code --add-mcp` y la ruta de `settings.json`/`mcp.json` de usuario de
      VS Code confirmadas contra una instalacion real (`%APPDATA%\Code\User`).
- [x] Dockerfile/`compose.yaml`/`start-mcp.ps1` de `s3_mcp/tools/mcp-local`
      (Dia 2) y `00_support/mcp-local` (Dia 4) verificados byte a byte contra
      los 4 repos reales de `NTTData-Academy` via `gh api`.

Pendiente de validar **en una laptop limpia real** (no se pudo probar desde
la maquina de desarrollo porque ya tiene casi todo instalado y no tiene
Podman). **Decision del equipo: se distribuye a produccion sin ese piloto
previo.** Mitigaciones ya incorporadas para ese riesgo:

- [ ] `./bootstrap.sh all` completo en un equipo recien liberado, sin ninguna
      herramienta instalada, con el usuario Administrador real del taller.
      → Mitigado por: cada paso es idempotente y reporta en texto claro
      (`[FAIL]`/`[WARN]`) que hacer si algo no se instala; `./bootstrap.sh all`
      se puede re-ejecutar las veces que sea necesario sin romper nada.
- [ ] El flujo de reinicio de WSL2 (`wsl --install`) en una maquina que
      nunca tuvo WSL, confirmando que `./bootstrap.sh all` retoma correctamente
      despues del reinicio.
      → Mitigado por: el script detecta WSL2 ausente, lo instala, avisa
      explicitamente "reinicia y vuelve a correr `./bootstrap.sh all`", y
      termina ahi (no deja la maquina en un estado intermedio raro).
- [ ] `./bootstrap.sh day02-mcp` de punta a punta con Podman real: build de
      imagenes, contenedor corriendo, y verificacion visual en VS Code
      (Copilot Chat → modo Agent → Configure Tools) de que `github-local`
      aparece con sus tools.
      → Mitigado por: si el build o el `compose up` fallan, el script se
      detiene con `[FAIL]` y el comando exacto para diagnosticar
      (`<engine> compose -f <ruta> logs`); no deja el servicio en estado
      ambiguo (o quedo arriba y responde, o el script ya reporto el error).

**Plan de contingencia en el primer dia real de uso:**
1. El primer alumno/instructor que corra `./bootstrap.sh all` en una laptop
   del taller es, de facto, el piloto. Pide que te comparta la salida
   completa (o el archivo `diagnostico-<hostname>.md` que genera) ante
   cualquier fila `FALTA`.
2. Si `day02-mcp` falla en el build de Podman, el fallback manual documentado
   en el propio `s3_mcp/STEP_1.md` del lab (clonar y `podman build` a mano)
   sigue funcionando igual — este toolkit no reemplaza esos pasos, solo los
   automatiza.
3. Cualquier ajuste que surja de ese primer uso real, se corrige en
   `workshop-bootstrap/` y se redistribuye (`robocopy`/USB/carpeta
   compartida) al resto de laptops antes de que lleguen mas alumnos.
