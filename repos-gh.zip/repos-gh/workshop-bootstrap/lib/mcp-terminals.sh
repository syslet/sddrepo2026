#!/usr/bin/env bash

MCP_TERMINALS_LIB="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

terminal_is_running() {
  local pid_file="$1" pid
  [ -f "$pid_file" ] || return 1
  read -r pid < "$pid_file" || return 1
  [[ "$pid" =~ ^[0-9]+$ ]] && kill -0 "$pid" 2>/dev/null
}

write_terminal_runner() {
  local runner="$1" pid_file="$2"
  {
    printf '#!/usr/bin/env bash\nset -uo pipefail\n'
    printf 'PID_FILE=%q\n' "$pid_file"
    printf '%s\n' 'trap '\''rm -f -- "$PID_FILE"'\'' EXIT' 'printf "%s\n" "$$" > "$PID_FILE"'
    printf 'export COURSE_DIR=%q\n' "$COURSE_DIR"
    printf 'source %q\nrefresh_path || true\n' "$MCP_TERMINALS_LIB/common.sh"
    # Las credenciales se obtienen en la terminal, nunca se escriben al disco.
    printf '%s\n' 'unset GITHUB_TOKEN' 'export GITHUB_TOKEN="$(gh auth token)"'
    printf '%s\n' '[ -n "$GITHUB_TOKEN" ] || { echo "No se pudo obtener el token de GitHub." >&2; exit 1; }'
    printf 'export GITHUB_OWNER=%q GITHUB_REPO=%q\n' "$OWNER" "$REPO"
  } > "$runner"
}

open_windows_terminal() {
  local title="$1" runner="$2" pid_file="$3" directory="$4" shell_path launcher i
  if terminal_is_running "$pid_file"; then
    ok "Terminal $title ya abierta."
    return 0
  fi
  shell_path="$(command -v bash.exe || command -v bash)" || return 1
  shell_path="$(cygpath -w "$shell_path")" || return 1
  launcher="$(cygpath -w "$MCP_TERMINALS_LIB/open-terminal.ps1")" || return 1
  directory="$(cygpath -aw "$directory")" || return 1
  MSYS2_ARG_CONV_EXCL='*' powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "$launcher" \
    -BashPath "$shell_path" -RunnerPath "$runner" -WorkingDirectory "$directory" -Title "$title" || return 1
  for i in {1..40}; do
    if terminal_is_running "$pid_file"; then
      ok "Terminal $title abierta."
      return 0
    fi
    sleep 0.25
  done
  err "La terminal $title no inicio su comando. Revisa el error en la ventana abierta."
  return 1
}

open_mcp_terminals() {
  local directory="$COURSE_DIR/.workshop-bootstrap-cache/terminals" engine_path
  if ! is_windows || ! has_cmd powershell || ! has_cmd cygpath; then
    err "Abrir pestanas requiere Windows, Git Bash y Windows Terminal configurado con la opcion terminal. Usa --no-terminals para omitirlas."
    return 1
  fi
  mkdir -p "$directory" || return 1
  engine_path="$(command -v "$ENGINE")" || return 1
  if ! terminal_is_running "$directory/mcp.pid"; then
    write_terminal_runner "$directory/mcp.sh" "$directory/mcp.pid" || return 1
    {
      printf 'cd %q || exit 1\n' "$MCP_LOCAL_DIR"
      printf 'printf "Logs del MCP. Cerrar esta terminal no detiene el contenedor.\\n"\n'
      printf '%q compose logs --follow --tail 100\n' "$engine_path"
    } >> "$directory/mcp.sh"
  fi
  open_windows_terminal 'Workshop MCP' "$directory/mcp.sh" "$directory/mcp.pid" "$MCP_LOCAL_DIR" || return 1

  [ -z "$SKIP_INSPECTOR" ] || return 0
  if ! terminal_is_running "$directory/inspector.pid"; then
    write_terminal_runner "$directory/inspector.sh" "$directory/inspector.pid" || return 1
    printf 'cd %q || exit 1\n' "$COURSE_DIR" >> "$directory/inspector.sh"
    printf 'npx --yes @modelcontextprotocol/inspector --config %q --server github-local\n' \
      "$HOME/.mcp-inspector/mcp.json" >> "$directory/inspector.sh"
  fi
  open_windows_terminal 'Workshop MCP Inspector' "$directory/inspector.sh" "$directory/inspector.pid" "$COURSE_DIR"
}
