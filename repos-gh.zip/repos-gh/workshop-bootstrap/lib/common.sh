#!/usr/bin/env bash
# Funciones compartidas por todos los scripts de workshop-bootstrap.
# Se cargan con: source "$(dirname "$0")/../lib/common.sh"

set -uo pipefail

C_RESET=$'\033[0m'; C_RED=$'\033[31m'; C_GREEN=$'\033[32m'; C_YELLOW=$'\033[33m'; C_CYAN=$'\033[36m'

log()  { printf '%s\n' "$*"; }
info() { printf '%s[INFO]%s %s\n' "$C_CYAN" "$C_RESET" "$*"; }
ok()   { printf '%s[ OK ]%s %s\n' "$C_GREEN" "$C_RESET" "$*"; }
warn() { printf '%s[WARN]%s %s\n' "$C_YELLOW" "$C_RESET" "$*"; }
err()  { printf '%s[FAIL]%s %s\n' "$C_RED" "$C_RESET" "$*" >&2; }

has_cmd() { command -v "$1" >/dev/null 2>&1; }

is_windows() {
  case "${OS:-}${OSTYPE:-}" in *Windows*|*windows*|*msys*|*cygwin*|*win32*) return 0 ;; esac
  [ -n "${WINDIR:-}" ] && return 0
  return 1
}

# Compara dos versiones "a.b.c" vs "x.y.z" -> 0 si $1 >= $2
version_ge() {
  [ "$1" = "$2" ] && return 0
  local a b IFS=.
  read -ra a <<<"$1"; read -ra b <<<"$2"
  for i in 0 1 2; do
    local ai="${a[i]:-0}" bi="${b[i]:-0}"
    if [ "$ai" -gt "$bi" ] 2>/dev/null; then return 0; fi
    if [ "$ai" -lt "$bi" ] 2>/dev/null; then return 1; fi
  done
  return 0
}

# COURSE_DIR = carpeta del curso (padre de bcp-ai-lab-day-XX y reqflow-workspace).
# Carpeta fija del taller para todas las computadoras Windows.
if [ -z "${COURSE_DIR:-}" ]; then
  if is_windows && has_cmd cygpath; then
    COURSE_DIR="$(cygpath -au 'C:\Users\Usuario\Documents\bcp-ai-labs')" || return 1
  else
    COURSE_DIR="$HOME/Documents"
  fi
fi
WORKSPACE_DIR="${WORKSPACE_DIR:-$COURSE_DIR/reqflow-workspace}"

py_launcher() {
  # Devuelve el mejor comando de Python disponible, preferido 3.12.
  if is_windows && has_cmd py; then
    if py -3.12 --version >/dev/null 2>&1; then echo "py -3.12"; return; fi
    if py -3.11 --version >/dev/null 2>&1; then echo "py -3.11"; return; fi
    if py -3.13 --version >/dev/null 2>&1; then echo "py -3.13"; return; fi
    echo "py"; return
  fi
  if has_cmd python3.12; then echo "python3.12"; return; fi
  if has_cmd python3; then echo "python3"; return; fi
  echo "python"
}

container_engine() {
  if has_cmd podman; then echo "podman"; return; fi
  if has_cmd docker; then echo "docker"; return; fi
  echo ""
}

# Devuelve el mejor comando/version de Python 3.11-3.13 disponible via el
# launcher 'py' (el que piden los labs), vacio si ninguno esta instalado.
# A diferencia de py_launcher() (que siempre devuelve ALGO, incluso un
# 'python' generico), esta funcion es para VALIDAR si ya existe una version
# valida, de modo que un Python viejo/distinto instalado no oculte la falta
# de 3.11-3.13 real.
py_valid_launcher() {
  if is_windows && has_cmd py; then
    for v in 3.12 3.13 3.11; do
      py -$v --version >/dev/null 2>&1 && { echo "py -$v"; return 0; }
    done
    return 1
  fi
  local c
  for c in python3.12 python3.13 python3.11; do
    has_cmd "$c" && { echo "$c"; return 0; }
  done
  if has_cmd python3; then
    local v; v=$(python3 --version 2>&1 | grep -oE '[0-9]+\.[0-9]+' | head -1)
    case "$v" in 3.11|3.12|3.13) echo "python3"; return 0 ;; esac
  fi
  return 1
}

# 0 si hay una sesion de GitHub CLI realmente funcional (no solo "alguna
# cuenta en el keyring"). 'gh auth status' puede devolver exit code 1 aunque
# la cuenta ACTIVA funcione perfectamente, si hay otra cuenta rota en el
# keyring (caso real observado) — por eso no se usa su exit code como senal.
gh_logged_in() {
  has_cmd gh || return 1
  gh api user --jq .login >/dev/null 2>&1
}

# Devuelve los OAuth scopes del token ACTIVO de GitHub CLI, en minuscula,
# separados por espacio (ej. "gist read:org repo workflow"). Usa la cabecera
# X-OAuth-Scopes de la API, que identifica sin ambiguedad el token realmente
# en uso — a diferencia de parsear el texto de 'gh auth status', que mezcla
# todas las cuentas del keyring (incluidas las rotas/inactivas) y puede dar
# falsos positivos/negativos.
gh_token_scopes() {
  has_cmd gh || { echo ""; return 1; }
  gh api -i user 2>/dev/null | grep -i '^x-oauth-scopes:' | cut -d: -f2- | tr -d '\r' | tr ',' ' ' | tr 'A-Z' 'a-z'
}

# 0 si el scope dado esta presente en el token activo de GitHub CLI.
gh_has_scope() {
  local scope="$1" scopes
  scopes="$(gh_token_scopes)"
  printf ' %s ' "$scopes" | grep -q " $scope "
}

# Login (username) de la cuenta ACTIVA de GitHub CLI, vacio si no hay sesion.
# Es la fuente de verdad para "OWNER": los repos propios del alumno
# (workshop-auth-backend, workshop-login-frontend, workshop-requirements-api)
# viven bajo SU cuenta personal, no bajo LAB_ORG — por eso nunca se asume
# un org aqui, solo se lee la cuenta con la que el alumno hizo 'gh auth login'.
gh_current_login() {
  has_cmd gh || { echo ""; return 1; }
  gh api user --jq .login 2>/dev/null
}

# 0 si "<owner>/<repo>" existe y el token activo tiene al menos acceso de
# lectura. Util para autodescubrir, sin preguntarle nada al alumno, cuales
# de sus repos personales del workshop ya existen.
gh_repo_exists() {
  has_cmd gh || return 1
  gh repo view "$1" >/dev/null 2>&1
}

# Organizacion de GitHub donde viven los 4 repos de laboratorio (todos los
# alumnos tienen acceso de lectura). Puede sobreescribirse con LAB_ORG.
LAB_ORG="${LAB_ORG:-NTTData-Academy}"

# Asegura que bcp-ai-lab-day-<day> exista en COURSE_DIR: si ya esta ahi (ya
# sea porque alguien lo clono/copio a mano o porque ya se clono antes), no
# hace nada. Si falta, lo clona directo desde GitHub con 'gh repo clone'
# (usa la sesion de gh de quien corre el script; los 4 repos son de lectura
# para todos los alumnos). Nunca sobreescribe un folder que ya exista.
# Uso: ensure_lab_repo "02" ["OrgOpcional"]
ensure_lab_repo() {
  local day="$1" org="${2:-$LAB_ORG}"
  local name="bcp-ai-lab-day-$day"
  local dest="$COURSE_DIR/$name"

  if [ -d "$dest" ]; then
    ok "$name ya presente en $dest (se omite clonado)."
    return 0
  fi

  if ! has_cmd gh; then
    warn "gh no esta en PATH; no se puede clonar $org/$name automaticamente. Corre primero: ./bootstrap.sh tools"
    return 1
  fi
  if ! gh_logged_in; then
    warn "No hay sesion de GitHub CLI activa; no se puede clonar $org/$name automaticamente. Ejecuta: gh auth login"
    return 1
  fi

  info "Clonando $org/$name en $dest ..."
  if gh repo clone "$org/$name" "$dest" -- --depth 1 >/dev/null 2>&1; then
    ok "$name clonado en $dest"
    return 0
  else
    warn "No se pudo clonar $org/$name (revisa acceso al repo o tu conexion)."
    return 1
  fi
}

# 0 si la terminal actual corre elevada (Administrador) en Windows.
is_admin() {
  is_windows || return 1
  net session >/dev/null 2>&1
}

# Relee las variables PATH/JAVA_HOME de Machine+User desde el registro de
# Windows y AGREGA al FINAL del PATH actual las rutas nuevas que todavia no
# esten presentes (p.ej. una herramienta recien instalada por winget/choco).
# Nunca reordena ni antepone nada: hacerlo rompe /usr/bin y /mingw64/bin de
# Git Bash (que deben seguir resolviendose primero) y por lo tanto rompe
# utilidades como grep/dirname/npm. Asi, un paso que instala una herramienta
# y el siguiente que la usa funcionan en la MISMA ejecucion de bootstrap.sh,
# sin pedirle al operador que abra una terminal nueva.
refresh_path() {
  is_windows || return 0
  has_cmd powershell || return 0
  local win_machine win_user combined unix_path entry
  win_machine=$(powershell -NoProfile -NonInteractive -Command "[Environment]::GetEnvironmentVariable('Path','Machine')" 2>/dev/null | tr -d '\r')
  win_user=$(powershell -NoProfile -NonInteractive -Command "[Environment]::GetEnvironmentVariable('Path','User')" 2>/dev/null | tr -d '\r')
  combined="${win_machine};${win_user}"
  if has_cmd cygpath; then
    unix_path=$(cygpath -u -p "$combined" 2>/dev/null)
    if [ -n "$unix_path" ]; then
      local IFS=:
      for entry in $unix_path; do
        [ -n "$entry" ] || continue
        case ":$PATH:" in
          *":$entry:"*) : ;;
          *) PATH="$PATH:$entry" ;;
        esac
      done
      export PATH
    fi
  fi
  local jh
  jh=$(powershell -NoProfile -NonInteractive -Command "[Environment]::GetEnvironmentVariable('JAVA_HOME','Machine')" 2>/dev/null | tr -d '\r')
  [ -n "$jh" ] && export JAVA_HOME="$jh"
}

# Fija una variable de entorno a nivel de MAQUINA (persiste para toda sesion
# nueva, incluida la del alumno). Requiere permisos de administrador.
win_set_machine_env() {
  local name="$1" value="$2"
  is_windows || return 0
  powershell -NoProfile -NonInteractive -Command "[Environment]::SetEnvironmentVariable('$name', '$value', 'Machine')" >/dev/null 2>&1
}

# Antepone una ruta al PATH de MAQUINA si todavia no esta presente (evita
# duplicados en reinvocaciones). Requiere permisos de administrador.
win_prepend_machine_path() {
  local newpath="$1"
  is_windows || return 0
  powershell -NoProfile -NonInteractive -Command "
    \$p = [Environment]::GetEnvironmentVariable('Path','Machine')
    if (-not (\$p -split ';' | Where-Object { \$_ -eq '$newpath' })) {
      [Environment]::SetEnvironmentVariable('Path', '$newpath;' + \$p, 'Machine')
    }
  " >/dev/null 2>&1
}

# Rutas (unix-style, dentro de Git Bash) a los settings.json de usuario de
# VS Code segun el OS. Vacio si no se detecta.
vscode_user_settings_path() {
  if is_windows; then
    [ -n "${APPDATA:-}" ] && cygpath -u "${APPDATA}/Code/User/settings.json" 2>/dev/null
  elif [ "$(uname -s 2>/dev/null)" = "Darwin" ]; then
    echo "$HOME/Library/Application Support/Code/User/settings.json"
  else
    echo "${XDG_CONFIG_HOME:-$HOME/.config}/Code/User/settings.json"
  fi
}

# Asegura que ciertas claves top-level existan en un settings.json de VS Code
# (que puede tener comentarios // y /* */). Si una clave ya existe (con
# cualquier valor), no la toca. Si falta, la inserta justo despues del primer
# '{' sin reescribir ni reformatear el resto del archivo, para no romper
# comentarios o configuraciones propias del alumno/instructor.
# Uso: ensure_json_keys "<archivo>" '{"clave1": true, "clave2": "valor"}'
ensure_json_keys() {
  local file="$1" updates_json="$2"
  local PY; PY="$(py_launcher)"
  $PY - "$file" "$updates_json" <<'PYEOF'
import json, re, sys, os

path, updates_json = sys.argv[1], sys.argv[2]
updates = json.loads(updates_json)

def strip_comments(s):
    s = re.sub(r'//[^\n]*', '', s)
    s = re.sub(r'/\*.*?\*/', '', s, flags=re.S)
    return s

if not os.path.exists(path):
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(updates, f, indent=2)
    print("CREATED")
    sys.exit(0)

with open(path, "r", encoding="utf-8") as f:
    raw = f.read()

try:
    parsed = json.loads(strip_comments(raw)) if raw.strip() else {}
except Exception:
    parsed = None

if parsed is not None:
    missing = {k: v for k, v in updates.items() if k not in parsed}
else:
    missing = {k: v for k, v in updates.items() if ('"%s"' % k) not in raw}

if not missing:
    print("ALREADY_OK")
    sys.exit(0)

insertion = "".join('  "%s": %s,\n' % (k, json.dumps(v)) for k, v in missing.items())
idx = raw.find("{")
if idx == -1:
    new_raw = "{\n" + insertion + "}\n"
else:
    new_raw = raw[:idx + 1] + "\n" + insertion + raw[idx + 1:]

with open(path, "w", encoding="utf-8") as f:
    f.write(new_raw)
print("UPDATED:" + ",".join(missing.keys()))
PYEOF
}

# Fusiona entradas dentro de una clave anidada top-level de un archivo JSON
# "puro" (sin comentarios), p.ej. {"servers": {...}} (.vscode/mcp.json de VS
# Code) o {"mcpServers": {...}} (catalogo de MCP Inspector). Nunca pisa una
# entrada que ya exista con el mismo nombre; crea el archivo si no existe.
# Uso: merge_json_servers "<archivo>" "servers" '{"nombre": {...}}'
merge_json_servers() {
  local file="$1" top_key="$2" entries_json="$3"
  local PY; PY="$(py_launcher)"
  $PY - "$file" "$top_key" "$entries_json" <<'PYEOF'
import json, sys, os

path, top_key, entries_json = sys.argv[1], sys.argv[2], sys.argv[3]
entries = json.loads(entries_json)

data = {}
if os.path.exists(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        data = {}

data.setdefault(top_key, {})
changed = False
for name, cfg in entries.items():
    if name not in data[top_key]:
        data[top_key][name] = cfg
        changed = True

d = os.path.dirname(path)
if d:
    os.makedirs(d, exist_ok=True)
with open(path, "w", encoding="utf-8") as f:
    json.dump(data, f, indent=2, ensure_ascii=False)

print("CHANGED" if changed else "ALREADY_OK")
PYEOF
}

# Como merge_json_servers, pero para las entradas "canonicas" del curso: las
# SOBRESCRIBE siempre al valor correcto (si estaban mal configuradas, mal
# apuntadas a otro puerto, etc., quedan corregidas), sin tocar ninguna otra
# entrada que el alumno/instructor haya agregado con otro nombre. Esto es lo
# que mantiene a todas las laptops en el mismo estandar del workshop.
# Uso: force_json_servers "<archivo>" "servers" '{"nombre": {...}}'
force_json_servers() {
  local file="$1" top_key="$2" entries_json="$3"
  local PY; PY="$(py_launcher)"
  $PY - "$file" "$top_key" "$entries_json" <<'PYEOF'
import json, sys, os

path, top_key, entries_json = sys.argv[1], sys.argv[2], sys.argv[3]
entries = json.loads(entries_json)

data = {}
if os.path.exists(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        data = {}

data.setdefault(top_key, {})
changed = False
for name, cfg in entries.items():
    if data[top_key].get(name) != cfg:
        data[top_key][name] = cfg
        changed = True

d = os.path.dirname(path)
if d:
    os.makedirs(d, exist_ok=True)
with open(path, "w", encoding="utf-8") as f:
    json.dump(data, f, indent=2, ensure_ascii=False)

print("CHANGED" if changed else "ALREADY_OK")
PYEOF
}
