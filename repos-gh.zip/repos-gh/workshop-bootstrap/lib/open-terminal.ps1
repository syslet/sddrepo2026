# WORKSHOP_WINDOWS_TERMINAL_V1
param(
    [Parameter(Mandatory = $true)][string]$BashPath,
    [Parameter(Mandatory = $true)][string]$RunnerPath,
    [Parameter(Mandatory = $true)][string]$Title,
    [Parameter(Mandatory = $true)][string]$WorkingDirectory
)

$ErrorActionPreference = 'Stop'

$terminal = Get-Command wt.exe -ErrorAction SilentlyContinue
if (-not $terminal) {
    throw 'No se encontro Windows Terminal. Ejecuta primero la opcion terminal del instalador.'
}

$fragmentPath = Join-Path $env:LOCALAPPDATA 'Microsoft\Windows Terminal\Fragments\BCPWorkshop\workshop.json'
if (-not (Test-Path -LiteralPath $fragmentPath)) {
    throw 'Falta el perfil Workshop - Bash. Ejecuta primero la opcion terminal del instalador.'
}
$fragment = Get-Content -LiteralPath $fragmentPath -Raw -Encoding UTF8 | ConvertFrom-Json
$profile = $fragment.profiles | Where-Object { $_.guid -eq '{dd5acfd4-3c64-5bad-bcac-0ec8f735131a}' } | Select-Object -First 1
if (-not $profile) { throw 'El fragmento no incluye Workshop - Bash. Repite la opcion terminal.' }

# El nombre de ventana agrupa MCP e Inspector en dos pestanas. La orden
# explicita ejecuta el runner, con el aspecto del perfil ya configurado.
$arguments = @('-w', 'BCPWorkshopMCP', 'new-tab', '--profile', $profile.guid,
    '--title', $Title, '--suppressApplicationTitle', '--startingDirectory', $WorkingDirectory,
    $BashPath, '--login', $RunnerPath)
& $terminal.Source @arguments
if ($LASTEXITCODE -ne 0) { throw "Windows Terminal no pudo abrir $Title, codigo $LASTEXITCODE." }
