#!/usr/bin/env bash

WORKSHOP_REPOS=(workshop-auth-backend workshop-requirements-api workshop-login-frontend)

workshop_python() {
  if has_cmd py && py -3.13 --version >/dev/null 2>&1; then printf 'py -3.13'; return 0; fi
  if has_cmd python3.13; then printf 'python3.13'; return 0; fi
  local executable
  for executable in python3 python; do
    if has_cmd "$executable" && "$executable" --version 2>&1 | grep -q '^Python 3\.13\.'; then
      printf '%s' "$executable"; return 0
    fi
  done
  return 1
}

workshop_remote_state() {
  local remote="$1" response status
  response="$(gh api --include "repos/$remote" --jq '.private' 2>&1)" || true
  status="$(printf '%s\n' "$response" | awk '/^HTTP\/[0-9.]+ / {print $2; exit}')"
  case "$status" in
    404) printf 'missing' ;;
    200)
      if [ "$(printf '%s\n' "$response" | tail -1 | tr -d '\r')" != true ]; then
        err "$remote debe ser privado. Revisa su visibilidad antes de continuar."; return 1
      fi
      printf 'exists' ;;
    *) err "No se pudo consultar $remote (HTTP ${status:-desconocido}). Revisa acceso o conexion."; return 1 ;;
  esac
}

workshop_check_local() {
  local path="$1" remote="$2" origin top expected normalized_remote
  [ -e "$path" ] || [ -L "$path" ] || return 0
  top="$(git -C "$path" rev-parse --show-toplevel 2>/dev/null)" || {
    err "$path existe y no es un repositorio Git. No se reemplazara."; return 1;
  }
  expected="$(cd "$path" && pwd -P)" || return 1
  [ "$(cd "$top" && pwd -P)" = "$expected" ] || { err "$path no es la raiz de su propio repositorio."; return 1; }
  origin="$(git -C "$path" config --get remote.origin.url 2>/dev/null)" || return 1
  normalized_remote="$(printf '%s' "$remote" | tr 'A-Z' 'a-z')"
  case "$(printf '%s' "$origin" | tr 'A-Z' 'a-z')" in
    "https://github.com/$normalized_remote"|"https://github.com/$normalized_remote.git"|"git@github.com:$normalized_remote"|"git@github.com:$normalized_remote.git") ;;
    *) err "$path apunta a $origin, no a $remote. No se modificara su origin."; return 1 ;;
  esac
  git -C "$path" rev-parse --verify HEAD >/dev/null 2>&1 || { err "$path no tiene commits. Revisa esa copia antes de continuar."; return 1; }
}

workshop_ensure_repo() (
  local name="$1" owner="$2" day="$3" destination="$WORKSPACE_DIR/$1" state heads stage
  workshop_check_local "$destination" "$owner/$name" || return 1
  state="$(workshop_remote_state "$owner/$name")" || return 1
  if [ -d "$destination" ]; then
    [ "$state" = exists ] || { err "No existe $owner/$name en GitHub. Revisa el origin de tu copia local."; return 1; }
    ok "$name reutilizado. Se conservan sus archivos, commits y rama."
    return 0
  fi
  if [ "$state" = missing ] && [ "$day" != 01 ]; then
    err "Falta $owner/$name. Ejecuta day01 o recupera tu repo del Dia 1."; return 1
  fi
  heads=""
  if [ "$state" = exists ]; then
    heads="$(git ls-remote --heads "https://github.com/$owner/$name.git")" || return 1
    if [ -z "$heads" ] && [ "$day" != 01 ]; then
      err "$owner/$name esta vacio. El Dia 2 necesita el trabajo del Dia 1."; return 1
    fi
  fi
  stage="$(mktemp -d "$WORKSPACE_DIR/.prepare-$name.XXXXXX")" || return 1
  trap 'rm -rf -- "$stage"' EXIT
  if [ -n "$heads" ]; then
    git clone "https://github.com/$owner/$name.git" "$stage/repo" || return 1
  else
    # Historial completo, como pide la guia. No usa fork ni clones shallow.
    git clone --branch main --single-branch "https://github.com/$LAB_ORG/$name-template.git" "$stage/repo" || return 1
    git -C "$stage/repo" remote set-url origin "https://github.com/$owner/$name.git" || return 1
    if [ "$state" = missing ]; then
      gh repo create "$owner/$name" --private || return 1
    fi
    # Solo publica la semilla nueva, nunca una copia local del participante.
    git -C "$stage/repo" push -u origin HEAD || return 1
  fi
  [ ! -e "$destination" ] && [ ! -L "$destination" ] || { err "$destination aparecio durante la preparacion. Repite el comando."; return 1; }
  mv "$stage/repo" "$destination" || return 1
  ok "$owner/$name listo en $destination"
)

workshop_python_env() {
  local directory="$1" python="$2" venv requirements=() name
  venv="$directory/.venv/Scripts/python.exe"
  if ! is_windows; then venv="$directory/.venv/bin/python"; fi
  if [ -e "$directory/.venv" ] || [ -L "$directory/.venv" ]; then
    "$venv" --version 2>&1 | grep -q '^Python 3\.13\.' || { err "$directory/.venv no usa Python 3.13 o no funciona. No se eliminara automaticamente."; return 1; }
  else
    (cd "$directory" && $python -m venv .venv) || return 1
  fi
  for name in requirements.txt requirements-dev.txt; do
    [ ! -f "$directory/$name" ] || requirements+=(-r "$name")
  done
  [ "${#requirements[@]}" -gt 0 ] || { err "Falta requirements.txt en $directory."; return 1; }
  (cd "$directory" && "$venv" -m pip install "${requirements[@]}") || return 1
}

prepare_workshop() (
  local day="$1" owner="" directory="$COURSE_DIR" arg python name version catalog
  shift
  while [ "$#" -gt 0 ]; do
    arg="$1"; shift
    case "$arg" in
      --directory|--owner)
        [ "$#" -gt 0 ] && [ -n "$1" ] || { err "Falta el valor de $arg."; return 1; }
        if [ "$arg" = --directory ]; then directory="$1"; else owner="$1"; fi
        shift ;;
      *) err "Parametro desconocido: $arg. Usa day$day [--directory <carpeta>] [--owner <usuario>]."; return 1 ;;
    esac
  done
  is_windows || { err "Prepara este workshop desde Git Bash en Windows."; return 1; }
  refresh_path || true
  for name in git gh node npm java mvn; do
    has_cmd "$name" || { err "Falta $name. Ejecuta tools antes de day$day."; return 1; }
  done
  python="$(workshop_python)" || { err "Falta Python 3.13. Ejecuta tools antes de day$day."; return 1; }
  version="$(node --version | tr -d 'v')"
  version_ge "$version" 22.12.0 || { err "Se requiere Node 22.12 o superior. Ejecuta tools."; return 1; }
  version="$(java --version 2>&1)" || { err "No se pudo ejecutar Java. Ejecuta tools."; return 1; }
  printf '%s\n' "$version" | head -1 | grep -Eq '(^|[[:space:]])21([.[:space:]]|$)' || { err "Se requiere Java 21. Ejecuta tools."; return 1; }
  version="$(mvn --version 2>&1)" || { err "No se pudo ejecutar Maven. Ejecuta tools."; return 1; }
  version="$(printf '%s\n' "$version" | head -1 | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -1)"
  version_ge "$version" 3.9.0 || { err "Se requiere Maven 3.9 o superior. Ejecuta tools."; return 1; }
  if ! gh_logged_in; then gh auth login || return 1; fi
  owner="${owner:-$(gh_current_login)}"
  [[ "$owner" =~ ^[a-zA-Z0-9][a-zA-Z0-9-]*$ ]] || { err "Owner de GitHub invalido."; return 1; }
  if [ "$day" = 02 ]; then
    name="$(container_engine)"
    [ -n "$name" ] && "$name" compose version >/dev/null 2>&1 || {
      err "El Dia 2 requiere Podman/Docker Compose disponible. Ejecuta podman antes de day02."; return 1;
    }
  fi
  directory="$(cygpath -au "$directory")" || return 1
  mkdir -p -- "$directory" || return 1
  COURSE_DIR="$(cd "$directory" && pwd -P)"
  WORKSPACE_DIR="$COURSE_DIR/reqflow-workspace"
  export COURSE_DIR WORKSPACE_DIR
  # Revisa los destinos antes de clonar o crear repos remotos.
  for name in "${WORKSHOP_REPOS[@]}"; do
    workshop_check_local "$WORKSPACE_DIR/$name" "$owner/$name" || return 1
  done
  gh auth setup-git --hostname github.com || return 1
  ensure_lab_repo "$day" || return 1
  mkdir -p "$WORKSPACE_DIR" || return 1
  for name in "${WORKSHOP_REPOS[@]}"; do
    workshop_ensure_repo "$name" "$owner" "$day" || return 1
    if [ -f "$WORKSPACE_DIR/$name/.env.example" ] && [ ! -e "$WORKSPACE_DIR/$name/.env" ] && [ ! -L "$WORKSPACE_DIR/$name/.env" ]; then
      cp "$WORKSPACE_DIR/$name/.env.example" "$WORKSPACE_DIR/$name/.env" || return 1
    fi
  done
  workshop_python_env "$WORKSPACE_DIR/workshop-requirements-api" "$python" || return 1
  (cd "$WORKSPACE_DIR/workshop-auth-backend" && mvn -B dependency:go-offline) || return 1
  if [ -f "$WORKSPACE_DIR/workshop-login-frontend/package-lock.json" ]; then name=ci; else name=install; fi
  (cd "$WORKSPACE_DIR/workshop-login-frontend" && npm "$name" --no-audit --no-fund) || return 1
  if [ "$day" = 02 ]; then
    workshop_python_env "$COURSE_DIR/bcp-ai-lab-day-02" "$python" || return 1
    catalog="$WORKSPACE_DIR/bcp-ai-skill-catalog"
    if [ ! -e "$catalog" ] && [ ! -L "$catalog" ]; then
      gh repo clone "$LAB_ORG/bcp-ai-skill-catalog" "$catalog" || return 1
    fi
    [ -f "$catalog/SKILLS-MANIFEST.json" ] || { err "Falta el manifest del catalogo de Skills. Revisa $catalog."; return 1; }
    bash "$BOOTSTRAP_DIR/bootstrap.sh" mcp-images --day 02 || return 1
    bash "$BOOTSTRAP_DIR/bootstrap.sh" inspector || return 1
    if [ -f "$COURSE_DIR/bcp-ai-lab-day-02/tools/check_handoff.py" ]; then
      $python "$COURSE_DIR/bcp-ai-lab-day-02/tools/check_handoff.py" --day 1 "$WORKSPACE_DIR" || \
        warn "Faltan entregables del Dia 1. Completa el handoff antes de los ejercicios del Dia 2."
    fi
    info "MCP personal: ejecuta day02-mcp cuando necesites levantarlo con tu cuenta."
  fi
  ok "Preparacion day$day completa. Abre en VS Code: $WORKSPACE_DIR"
  info "Los servicios y ejercicios se ejecutan siguiendo la guia. No se crearon entregables ni tags de evaluacion."
)
