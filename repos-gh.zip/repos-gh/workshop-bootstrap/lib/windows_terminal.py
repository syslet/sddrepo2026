"""Agrega un fragmento de Terminal y cambia el perfil inicial conservando JSONC."""
import argparse
import json
import os
from pathlib import Path
import re
import tempfile
import uuid


PROFILE_ID = "{dd5acfd4-3c64-5bad-bcac-0ec8f735131a}"
SOURCE = "BCPWorkshop"


def unique_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Clave JSON duplicada: {key}")
        result[key] = value
    return result


def parse_jsonc(raw):
    # Mantiene los offsets para editar solo defaultProfile, sin reformatear.
    clean, structure = list(raw), list(raw)
    decoder = json.JSONDecoder()
    i = 0
    while i < len(raw):
        if raw[i] == '"':
            _, size = decoder.raw_decode(raw[i:])
            structure[i:i + size] = "x" * size
            i += size
        elif raw.startswith("//", i) or raw.startswith("/*", i):
            if raw.startswith("//", i):
                end = raw.find("\n", i)
                end = len(raw) if end < 0 else end
            else:
                end = raw.find("*/", i + 2)
                if end < 0:
                    raise ValueError("Comentario JSONC sin cerrar")
                end += 2
            for j in range(i, end):
                clean[j] = structure[j] = "\n" if raw[j] == "\n" else " "
            i = end
        else:
            i += 1
    layout = "".join(structure)
    for match in re.finditer(r",(?=\s*[}\]])", layout):
        clean[match.start()] = " "
    cleaned = "".join(clean)
    data = json.loads(cleaned, object_pairs_hook=unique_pairs)
    if not isinstance(data, dict):
        raise ValueError("settings.json debe contener un objeto JSON")
    return data, cleaned, layout


def set_default_profile(raw):
    data, clean, layout = parse_jsonc(raw)
    if SOURCE in data.get("disabledProfileSources", []):
        raise ValueError("BCPWorkshop esta deshabilitado en disabledProfileSources")
    profiles = data.get("profiles", {})
    profiles = profiles.get("list", []) if isinstance(profiles, dict) else profiles
    for profile in profiles:
        if (profile.get("guid", "").lower() == PROFILE_ID and
                (any(key in profile for key in ("commandline", "startingDirectory", "environment"))
                 or profile.get("hidden") is True or profile.get("elevate") is True)):
            raise ValueError("Hay una personalizacion del perfil Workshop en settings.json. "
                             "Revisala antes de configurar el fragmento.")
    if data.get("defaultProfile") == PROFILE_ID:
        return raw
    if "defaultProfile" not in data:
        opening = layout.index("{")
        newline = "\r\n" if "\r\n" in raw else "\n"
        field = newline + '    "defaultProfile": ' + json.dumps(PROFILE_ID)
        return raw[:opening + 1] + field + ("," if data else "") + raw[opening + 1:]
    # Localiza la clave a profundidad 1; ignora claves iguales en perfiles.
    depth = 0
    decoder = json.JSONDecoder()
    i = 0
    while i < len(clean):
        if clean[i] == '"':
            value, size = decoder.raw_decode(clean[i:])
            end = i + size
            if depth == 1 and value == "defaultProfile":
                colon = end
                while clean[colon].isspace():
                    colon += 1
                if clean[colon] == ":":
                    start = colon + 1
                    while clean[start].isspace():
                        start += 1
                    _, length = decoder.raw_decode(clean[start:])
                    return raw[:start] + json.dumps(PROFILE_ID) + raw[start + length:]
            i = end
        else:
            if clean[i] in "{[":
                depth += 1
            elif clean[i] in "}]":
                depth -= 1
            i += 1
    raise ValueError("No se pudo localizar defaultProfile")


def atomic_write(path, content):
    original = path.read_bytes() if path.exists() else None
    if original == content:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    if original is not None:
        backup = path.with_name(path.name + ".workshop-" + uuid.uuid4().hex + ".bak")
        with backup.open("xb") as file:
            file.write(original)
        print(f"Respaldo: {backup}")
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as file:
            temporary = Path(file.name)
            file.write(content)
        os.replace(temporary, path)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()


def configure(settings, local_app_data, bash, directory):
    if not bash.is_file():
        raise ValueError(f"No existe bash.exe: {bash}")
    if not directory.is_dir():
        raise ValueError(f"No existe la carpeta inicial: {directory}")
    before = settings.read_bytes() if settings.exists() else b"{}\n"
    bom = b"\xef\xbb\xbf" if before.startswith(b"\xef\xbb\xbf") else b""
    updated = set_default_profile(before.decode("utf-8-sig"))
    parse_jsonc(updated)
    fragment = local_app_data / "Microsoft/Windows Terminal/Fragments" / SOURCE / "workshop.json"
    launcher = fragment.with_name("workshop-bash.cmd")
    # Funciona tambien en Terminal sin variables por perfil. El cambio de
    # pagina de codigos permite rutas Unicode en el archivo batch UTF-8.
    launcher_content = ('@echo off\r\nchcp 65001 >nul\r\nsetlocal\r\n'
                        'set "CHERE_INVOKING=1"\r\n'
                        f'"{str(bash).replace("%", "%%")}" --login -i\r\n'
                        'exit /b %ERRORLEVEL%\r\n')
    profile = {"guid": PROFILE_ID, "name": "Workshop - Bash",
               "commandline": f'cmd.exe /d /s /c ""{launcher}""',
               "startingDirectory": str(directory), "hidden": False, "elevate": False}
    # El fragmento solo contiene nuestro perfil, los demas quedan intactos.
    atomic_write(launcher, launcher_content.encode("utf-8"))
    atomic_write(fragment, (json.dumps({"profiles": [profile]}, indent=4, ensure_ascii=False) + "\n").encode("utf-8"))
    atomic_write(settings, bom + updated.encode("utf-8"))
    print(f"Perfil: {fragment}")
    print(f"Configuracion: {settings}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("settings", "local-app-data", "bash", "directory"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    try:
        configure(args.settings, args.local_app_data, args.bash, args.directory)
    except (OSError, ValueError, TypeError, AttributeError) as error:
        parser.exit(1, f"[FAIL] No se pudo configurar Terminal: {error}\n")


if __name__ == "__main__":
    main()
