#!/usr/bin/env bash
# ============================================================================
# workshop-bootstrap - Herramientas y workspaces para BCP AI Lab (Dias 01-04).
# Ejecutar desde Git Bash como Administrador, con la cuenta del participante
# en GitHub para crear o clonar sus repos privados con day01/day02/all.
#
# check/tools preparan la maquina. all incluye terminal y day01/day02.
# day01/day02 preparan el workspace
# personal y sus dependencias. day02-mcp configura el MCP personal aparte.
# Ninguna opcion genera las respuestas del laboratorio, issues o Projects.
#
# Uso:
#   ./bootstrap.sh check                 Diagnostico de la maquina (no instala nada)
#   ./bootstrap.sh tools                 Instala git/gh/node/python/java/maven/podman/VS Code
#   ./bootstrap.sh terminal [--directory <ruta>]  Windows Terminal + perfil Workshop - Bash
#   ./bootstrap.sh day01 [--directory <ruta>] [--owner <usuario>]  Crea/prepara el workspace del Dia 1
#   ./bootstrap.sh day02 [--directory <ruta>] [--owner <usuario>]  Prepara Dia 2 conservando Dia 1
#   ./bootstrap.sh podman                WSL2 + podman machine + podman-compose + pull de imagenes
#   ./bootstrap.sh labs [--days 01,02,03,04] [--org <Org>]
#       Clona (si faltan) los 4 repos de laboratorio directo desde GitHub
#       (NTTData-Academy). No toca reqflow-workspace ni repos del alumno.
#   ./bootstrap.sh python-envs           venvs de bcp-ai-lab-day-02 y day-04 (s1..s4)
#   ./bootstrap.sh mcp-images [--day 02|04]   Pre-construye las imagenes del MCP local
#   ./bootstrap.sh inspector             Instala y pre-configura MCP Inspector
#   ./bootstrap.sh warm-cache            Pre-calienta cache npm/maven/pip (best-effort)
#   ./bootstrap.sh all                   Maquina, terminal y workspaces Dia 1/2; sin day02-mcp
#
#   ./bootstrap.sh day02-mcp [--owner <O> --repo <R>]
#       Script APARTE pensado para correrse POR ALUMNO (no en 'all'): levanta
#       el servicio MCP del Dia 2 con el owner/repo/token reales del alumno,
#       configura VS Code (settings + servidores MCP + .vscode/mcp.json) e
#       instala/apunta MCP Inspector al servidor que queda corriendo.
#       Abre dos pestanas de Windows Terminal (--no-terminals las omite).
#
# Variable opcional: COURSE_DIR (por defecto: C:\Users\Usuario\Documents\bcp-ai-labs).
# Debe ser la carpeta que contiene bcp-ai-lab-day-01..04 (y luego reqflow-workspace).
# Variable opcional LAB_ORG (por defecto: NTTData-Academy) para el org de los 4 labs.
# ============================================================================
set -uo pipefail

BOOTSTRAP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$BOOTSTRAP_DIR/lib/common.sh"

usage() { sed -n '2,/^set -uo pipefail/{ /^set -uo pipefail/d; p; }' "${BASH_SOURCE[0]}"; }

cmd="${1:-}"; shift || true

case "$cmd" in
  check)       source "$BOOTSTRAP_DIR/scripts/00-check-prereqs.sh" ;;
  tools)       source "$BOOTSTRAP_DIR/scripts/01-install-tools.sh" ;;
  terminal)    source "$BOOTSTRAP_DIR/scripts/09-setup-terminal.sh" "$@" ;;
  day01)       source "$BOOTSTRAP_DIR/scripts/10-prepare-workshop.sh" 01 "$@" ;;
  day02)       source "$BOOTSTRAP_DIR/scripts/10-prepare-workshop.sh" 02 "$@" ;;
  podman)      source "$BOOTSTRAP_DIR/scripts/02-setup-podman.sh" ;;
  labs)        source "$BOOTSTRAP_DIR/scripts/08-clone-labs.sh" "$@" ;;
  python-envs) source "$BOOTSTRAP_DIR/scripts/03-setup-python-envs.sh" ;;
  mcp-images)  source "$BOOTSTRAP_DIR/scripts/04-prebuild-mcp-images.sh" "$@" ;;
  inspector)   source "$BOOTSTRAP_DIR/scripts/05-setup-mcp-inspector.sh" ;;
  warm-cache)  source "$BOOTSTRAP_DIR/scripts/06-warm-dependency-caches.sh" "$@" ;;
  day02-mcp)   source "$BOOTSTRAP_DIR/scripts/07-day02-mcp-setup.sh" "$@" ;;
  all)
    # WORKSHOP_ALL_WORKSPACES_V1
    info "=== 1/11 Diagnostico inicial ==="
    source "$BOOTSTRAP_DIR/scripts/00-check-prereqs.sh" || exit 1
    info "=== 2/11 Instalando herramientas de maquina ==="
    source "$BOOTSTRAP_DIR/scripts/01-install-tools.sh" || exit 1
    info "=== 3/11 Configurando Windows Terminal ==="
    source "$BOOTSTRAP_DIR/scripts/09-setup-terminal.sh" || exit 1
    info "=== 4/11 Configurando Podman ==="
    source "$BOOTSTRAP_DIR/scripts/02-setup-podman.sh" || exit 1
    info "=== 5/11 Clonando los 4 repos de laboratorio (si faltan) ==="
    if ! gh_logged_in; then
      info "Inicia sesion con la cuenta del participante: se usara para sus repos privados y los laboratorios."
      gh auth login || { err "No se pudo iniciar sesion en GitHub. Vuelve a ejecutar all."; exit 1; }
    fi
    source "$BOOTSTRAP_DIR/scripts/08-clone-labs.sh" || exit 1
    info "=== 6/11 Entornos Python de los labs ==="
    source "$BOOTSTRAP_DIR/scripts/03-setup-python-envs.sh" || exit 1
    info "=== 7/11 Workspace Dia 1: crear o clonar los 3 repos privados y sus dependencias ==="
    source "$BOOTSTRAP_DIR/scripts/10-prepare-workshop.sh" 01 || exit 1
    info "=== 8/11 Workspace Dia 2: mismos repos, Python, Skills, imagenes MCP e Inspector ==="
    source "$BOOTSTRAP_DIR/scripts/10-prepare-workshop.sh" 02 || exit 1
    info "=== 9/11 Pre-construyendo imagenes MCP del Dia 4 ==="
    source "$BOOTSTRAP_DIR/scripts/04-prebuild-mcp-images.sh" --day 04 || exit 1
    info "=== 10/11 Pre-calentando cache de dependencias (npm/maven/pip) ==="
    source "$BOOTSTRAP_DIR/scripts/06-warm-dependency-caches.sh" || exit 1
    info "=== 11/11 Diagnostico final ==="
    source "$BOOTSTRAP_DIR/scripts/00-check-prereqs.sh" || exit 1
    info "Flujo terminado. Revisa los items pendientes en el diagnostico final."
    info "El MCP personal se levanta aparte con day02-mcp."
    ;;
  ""|-h|--help|help) usage ;;
  *) err "Comando desconocido: $cmd"; usage; exit 1 ;;
esac
