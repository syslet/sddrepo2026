#!/usr/bin/env bash
# Punto de entrada remoto. Publicar junto al paquete generado por build-release.sh.
set -euo pipefail

install_workshop() {
  local install_dir="${WORKSHOP_INSTALL_DIR:-/c/workshop-bootstrap}"
  local base_url="${WORKSHOP_DOWNLOAD_BASE_URL:-https://bcp-ai-labs.pages.dev}"
  local stage expected actual entry description

  if [ "$#" -eq 0 ] || [ "${1:-}" = --help ] || [ "${1:-}" = -h ]; then
    printf '\n%s\n\n' 'WORKSHOP · Comandos disponibles'
    for entry in check tools terminal day01 day02 podman labs python-envs mcp-images inspector warm-cache day02-mcp all; do
      case "$entry" in
        check) description='Revisar herramientas, sin instalar' ;;
        tools) description='Instalar herramientas faltantes' ;;
        terminal) description='Configurar Windows Terminal, pestanas y carpeta inicial' ;;
        day01) description='Crear tus 3 repos privados y preparar dependencias del Dia 1' ;;
        day02) description='Preparar Dia 2 con tus mismos repos, Python y catalogo de Skills' ;;
        podman) description='Configurar Podman y WSL2' ;;
        labs) description='Descargar laboratorios' ;;
        python-envs) description='Preparar entornos Python' ;;
        mcp-images) description='Construir imagenes MCP' ;;
        inspector) description='Configurar MCP Inspector' ;;
        warm-cache) description='Preparar caches de npm, Maven y pip' ;;
        day02-mcp) description='Configurar tu MCP personal' ;;
        all) description='Preparar maquina, Windows Terminal y workspaces Dia 1/2' ;;
      esac
      printf '  %-13s %s\n' "$entry" "$description"
    done
    printf '\n%s\n' 'Ejecuta una opcion por vez en Git Bash como Administrador.'
    printf '\nComo ejecutar (reemplaza OPCION por un comando de la lista):\n  curl -fsSL %s/install.sh | bash -s -- OPCION\n' "${base_url%/}"
    printf '\nEjemplos:\n  curl -fsSL %s/install.sh | bash -s -- check\n  curl -fsSL %s/install.sh | bash -s -- tools\n' "${base_url%/}" "${base_url%/}"
    printf '%s\n' '' 'Parametros opcionales:' \
      '  terminal     --directory <carpeta inicial> (por defecto: carpeta del curso)' \
      '  day01/day02  --directory <carpeta del curso> --owner <usuario>' \
      '  labs         --days 01,02,03,04 --org <Org>' \
      '  mcp-images   --day 02 (o --day 04)' \
      '  day02-mcp    --owner <cuenta> --repo <repositorio> [--no-terminals] [--skip-inspector]'
    printf '%s\n' '' 'Sin argumentos muestra esta ayuda. No inicia la preparacion.' \
      'all: incluye terminal, day01 y day02; crea/clona tus repos privados. day02-mcp va aparte.' \
      'Carpeta predeterminada para todos: C:\Users\Usuario\Documents\bcp-ai-labs.' \
      'Variables: WORKSHOP_INSTALL_DIR, WORKSHOP_DOWNLOAD_BASE_URL, COURSE_DIR.'
    return 0
  fi
  case "$1" in
    all|check|tools|terminal|day01|day02|podman|labs|python-envs|mcp-images|inspector|warm-cache|day02-mcp) ;;
    *) printf '[FAIL] Comando desconocido: %s\n' "$1" >&2; return 1 ;;
  esac
  case "${OSTYPE:-}" in
    msys*|cygwin*) ;;
    *) printf '%s\n' '[FAIL] Abre Git Bash en Windows como Administrador para ejecutar este instalador.' >&2; return 1 ;;
  esac

  if [ "$1" = all ] && [ -f "$install_dir/bootstrap.sh" ] && \
     { ! grep -q 'WORKSHOP_ALL_WORKSPACES_V1' "$install_dir/bootstrap.sh" || \
       [ ! -f "$install_dir/scripts/09-setup-terminal.sh" ] || \
       [ ! -f "$install_dir/scripts/10-prepare-workshop.sh" ] || \
       ! grep -q 'WORKSHOP_PYTHON313_V1' "$install_dir/scripts/01-install-tools.sh" 2>/dev/null; }; then
    install_dir="${install_dir}-all-v1"
    printf '[INFO] Usando %s con terminal y workspaces, sin modificar la copia anterior.\n' "$install_dir"
  fi

  if [ "$1" = terminal ] && [ -f "$install_dir/bootstrap.sh" ] && \
     { [ ! -f "$install_dir/scripts/09-setup-terminal.sh" ] || [ ! -f "$install_dir/lib/windows_terminal.py" ]; }; then
    install_dir="${install_dir}-terminal-v1"
    printf '[INFO] El toolkit anterior no incluye terminal. Usando %s sin modificar la copia anterior.\n' "$install_dir"
  fi
  if [ "$1" = day02-mcp ] && [ -f "$install_dir/bootstrap.sh" ] && \
     { [ ! -f "$install_dir/lib/mcp-terminals.sh" ] || \
       ! grep -q 'WORKSHOP_WINDOWS_TERMINAL_V1' "$install_dir/lib/open-terminal.ps1" 2>/dev/null; }; then
    install_dir="${install_dir}-mcp-terminal-v1"
    printf '[INFO] La copia anterior no abre pestanas MCP. Usando %s sin modificarla.\n' "$install_dir"
  fi
  if { [ "$1" = day01 ] || [ "$1" = day02 ]; } && [ -f "$install_dir/bootstrap.sh" ] && \
     { [ ! -f "$install_dir/scripts/10-prepare-workshop.sh" ] || [ ! -f "$install_dir/lib/workshop.sh" ]; }; then
    install_dir="${install_dir}-days-v1"
    printf '[INFO] Usando %s para preparar el dia, sin modificar la copia anterior.\n' "$install_dir"
  fi
  if [ "$1" = tools ] && [ -f "$install_dir/bootstrap.sh" ] && \
     ! grep -q 'WORKSHOP_PYTHON313_V1' "$install_dir/scripts/01-install-tools.sh" 2>/dev/null; then
    install_dir="${install_dir}-days-v1"
    printf '[INFO] Usando %s con Python 3.13, sin modificar la copia anterior.\n' "$install_dir"
  fi
  if [ -e "$install_dir" ] || [ -L "$install_dir" ]; then
    if [ ! -f "$install_dir/bootstrap.sh" ] || [ ! -f "$install_dir/lib/common.sh" ]; then
      printf '[FAIL] %s ya existe y no contiene el toolkit. Usa otra WORKSHOP_INSTALL_DIR.\n' "$install_dir" >&2
      return 1
    fi
    printf '[INFO] Reutilizando toolkit en %s.\n' "$install_dir"
  else
    for entry in curl tar mktemp sha256sum; do
      command -v "$entry" >/dev/null 2>&1 || {
        printf '[FAIL] Falta %s. Usa una instalacion completa de Git Bash.\n' "$entry" >&2
        return 1
      }
    done
    mkdir -p "$(dirname "$install_dir")"
    stage="$(mktemp -d "$(dirname "$install_dir")/.workshop-download.XXXXXX")"
    WORKSHOP_DOWNLOAD_STAGE="$stage"
    trap 'rm -rf -- "$WORKSHOP_DOWNLOAD_STAGE"' EXIT
    printf '[INFO] Descargando toolkit desde %s ...\n' "$base_url"
    curl -fSL --retry 3 --connect-timeout 20 "${base_url%/}/workshop-bootstrap.tar.gz" -o "$stage/toolkit.tar.gz"
    curl -fsSL --retry 3 --connect-timeout 20 "${base_url%/}/workshop-bootstrap.tar.gz.sha256" -o "$stage/checksum"
    read -r expected _ < "$stage/checksum"
    if [[ ! "$expected" =~ ^[[:xdigit:]]{64}$ ]]; then
      printf '%s\n' '[FAIL] El checksum publicado no es valido.' >&2
      return 1
    fi
    actual="$(sha256sum "$stage/toolkit.tar.gz")"
    if [ "${actual%% *}" != "$expected" ]; then
      printf '%s\n' '[FAIL] La descarga no coincide con su SHA-256. No se ejecutara.' >&2
      return 1
    fi
    tar -xzf "$stage/toolkit.tar.gz" -C "$stage"
    for entry in bootstrap.sh lib/common.sh config/inspector-catalog.json.template \
      lib/windows_terminal.py scripts/09-setup-terminal.sh \
      lib/mcp-terminals.sh lib/open-terminal.ps1 \
      lib/workshop.sh scripts/10-prepare-workshop.sh \
      scripts/00-check-prereqs.sh scripts/01-install-tools.sh scripts/02-setup-podman.sh \
      scripts/03-setup-python-envs.sh scripts/04-prebuild-mcp-images.sh \
      scripts/05-setup-mcp-inspector.sh scripts/06-warm-dependency-caches.sh \
      scripts/07-day02-mcp-setup.sh scripts/08-clone-labs.sh; do
      [ -f "$stage/workshop-bootstrap/$entry" ] || {
        printf '[FAIL] Paquete incompleto: falta %s.\n' "$entry" >&2
        return 1
      }
    done
    mv "$stage/workshop-bootstrap" "$install_dir"
    rm -rf -- "$stage"
    trap - EXIT
  fi

  if [ -z "${COURSE_DIR:-}" ]; then
    COURSE_DIR="$(cygpath -au 'C:\Users\Usuario\Documents\bcp-ai-labs')" || return 1
  fi
  export COURSE_DIR
  mkdir -p "$COURSE_DIR"
  printf '[INFO] Toolkit: %s\n[INFO] Curso: %s\n' "$install_dir" "$COURSE_DIR"
  printf '[INFO] Opcion seleccionada: %s\n' "$1"
  if [ "$1" = all ]; then
    printf '%s\n' '[INFO] all prepara los repos privados de la cuenta de GitHub activa. Iniciara login si falta la sesion. WSL2 puede requerir reinicio.'
  fi
  if [ ! -t 0 ] && ( : < /dev/tty ) 2>/dev/null; then
    bash "$install_dir/bootstrap.sh" "$@" < /dev/tty
  else
    bash "$install_dir/bootstrap.sh" "$@"
  fi
}

# Esta llamada debe quedar al final para no ejecutar una descarga truncada.
install_workshop "$@"
