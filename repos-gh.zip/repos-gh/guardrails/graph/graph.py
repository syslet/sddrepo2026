"""Seis nodos, pausa humana por nodo y ciclo de correcciones."""

import os
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver
from graph.state import WorkflowState
from graph.nodes import (
    architect_node,
    backend_node,
    frontend_node,
    testing_node,
    security_node,
    chapter_node,
)

MAX_REVIEW_ROUNDS = int(os.getenv("MAX_REVIEW_ROUNDS", "3"))
NODE_FUNCTIONS = {
    "architect": architect_node,
    "backend": backend_node,
    "frontend": frontend_node,
    "testing": testing_node,
    "security": security_node,
    "chapter": chapter_node,
}
NODES = list(NODE_FUNCTIONS)


def should_retry(state: WorkflowState) -> str:
    if (
        state.get("last_verdict", "observaciones") != "aprobado"
        and state.get("review_round", 0) < MAX_REVIEW_ROUNDS
    ):
        return "backend"
    return END


def build_graph():
    builder = StateGraph(WorkflowState)
    for name, node in NODE_FUNCTIONS.items():
        builder.add_node(name, node)
    builder.set_entry_point("architect")
    for current, following in zip(NODES, NODES[1:]):
        builder.add_edge(current, following)
    builder.add_conditional_edges(
        "chapter", should_retry, {"backend": "backend", END: END}
    )
    return builder.compile(checkpointer=MemorySaver(), interrupt_before=NODES)


graph = build_graph()
