[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
Get-Command gh -ErrorAction Stop | Out-Null
Get-Command git -ErrorAction Stop | Out-Null

$manifestPath = Join-Path $PSScriptRoot 'repositories.json'
if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) {
    throw 'Missing repositories.json. Run Scan-Repositories.ps1 first.'
}
$repositories = @(Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json)
if ($repositories.Count -eq 0) {
    throw 'The repository inventory is empty.'
}

foreach ($repository in $repositories) {
    if ($repository.name -notmatch '^[A-Za-z0-9_.-]+$' -or
        $repository.name -in @('.', '..') -or
        $repository.clone_url -cne "https://github.com/NTTData-Academy/$($repository.name).git") {
        throw "Invalid repository inventory entry: $($repository.name)"
    }
}

$cloned = 0
$skipped = 0
$failures = @()
foreach ($repository in $repositories) {
    $destination = Join-Path $PSScriptRoot $repository.name
    if (Test-Path -LiteralPath $destination) {
        if (Test-Path -LiteralPath (Join-Path $destination '.git')) {
            $origin = & git -C $destination remote get-url origin
            if ($LASTEXITCODE -eq 0 -and $origin -ceq $repository.clone_url) {
                Write-Host "Already cloned: $($repository.name)"
                $skipped++
                continue
            }
        }
        Write-Warning "Destination exists but is not the expected clone: $destination"
        $failures += $repository.name
        continue
    }

    & gh repo clone $repository.clone_url $destination
    if ($LASTEXITCODE -ne 0) {
        Write-Warning "Clone failed: $($repository.name)"
        $failures += $repository.name
        continue
    }
    $cloned++
}

Write-Host "Cloned: $cloned; already present: $skipped; failed: $($failures.Count)"
if ($failures.Count -gt 0) {
    throw "Repositories requiring attention: $($failures -join ', ')"
}
