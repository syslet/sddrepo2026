# Paso 4 - Discovery y backlog multi-repo

## Objetivo

Utilizar el Agent `Discovery` para comprender los tres componentes y convertir únicamente hallazgos revisados en backlog trazable.

## 4.1 Regla de oro

Discovery no corrige código.

```text
observar -> explicar -> evidenciar -> priorizar
```

No:

```text
observar -> arreglar automáticamente
```

## 4.2 Analizar cada repositorio por separado

Ejecuta una conversación de Discovery por componente para evitar mezclar evidencias.

Ejemplo para FastAPI:

```text
Analiza workshop-requirements-api sin modificar archivos.

Parte de lo que ya existe: workshop-requirements-api/HALLAZGOS.md (Dia 1) y
los issues del Project ReqFlow (Dia 2). Re-verifica cada hallazgo "Pendiente"
contra el codigo actual e indica si ya tiene issue (campo Hallazgo origen).
Despues comprende estructura, contratos (docs/ENDPOINTS.md) y pruebas
existentes (docs/TESTING.md).
Después presenta como máximo 5 hallazgos candidatos.

Para cada hallazgo incluye:
- evidencia concreta;
- por qué importa;
- prioridad propuesta;
- contrato funcional que podría verse afectado;
- cómo lo validarías antes de cambiarlo.

No inventes problemas si no encuentras evidencia.
No implementes soluciones.
```

Repite el patrón para:

```text
workshop-auth-backend
workshop-login-frontend
```

## 4.3 Revisión humana

Antes de crear issues, revisa cada hallazgo.

Clasifica:

```text
CONFIRMADO
NECESITA MÁS EVIDENCIA
DESCARTADO
```

Un hallazgo generado por IA no se convierte en backlog por existir en una respuesta.

## 4.4 Seleccionar backlog inicial

Para mantener la sesión manejable, selecciona pocos hallazgos confirmados.

Sugerencia:

```text
1 a 3 por repositorio
```

No se busca resolver toda la deuda del caso.

Los issues de HU-01 (backend) y HU-05 (frontend) del Día 2 ya cubren parte del backlog. Normalmente solo falta crear los de `workshop-requirements-api`, que es el repo guiado de S4.

## 4.5 Crear issues en el repositorio correcto

Selecciona `PM/PO` y proporciona únicamente los hallazgos aprobados.

Ejemplo:

```text
Usando exclusivamente github-official, convierte estos hallazgos CONFIRMADOS en issues.

Reglas:
- cada issue debe vivir en el repositorio al que pertenece la evidencia;
- no dupliques: si el hallazgo ya tiene issue en ReqFlow, reutilízalo;
- incluye el Id H-xx del hallazgo de origen y completa el campo Hallazgo origen;
- no inventes nuevos hallazgos;
- incluye problema, evidencia, impacto y criterio verificable;
- antes de crear, muéstrame el repositorio destino y el título propuesto.
```

## 4.6 Agregar los issues al Project ReqFlow

Después de crear los issues aprobados:

```text
Usando exclusivamente las tools de Projects de github-official, agrega al Project ReqFlow los issues que acabamos de aprobar.
No cambies su repositorio de origen.
```

Resultado conceptual:

```text
ReqFlow Project
  + Frontend issue -> workshop-login-frontend
  + Backend issue  -> workshop-auth-backend
  + API issue      -> workshop-requirements-api
```

## 4.7 Elegir el issue guiado

De los issues de `workshop-requirements-api`, selecciona uno para demostrar el ciclo SDD completo.

Criterios recomendados:

- hallazgo confirmado;
- alcance pequeño o mediano;
- contrato identificable;
- comportamiento susceptible de proteger con pruebas;
- no requiere resolver previamente media aplicación.

No fijamos un issue específico en la guía porque el discovery forma parte de la evaluación.

## 4.8 Relación con `tasks.md` de OpenSpec

El GitHub Issue creado en este laboratorio no reemplaza a `tasks.md`.

En S4 ambos coexistirán deliberadamente:

```text
GitHub Issue
= trabajo comprometido, responsable, prioridad y trazabilidad del producto

OpenSpec tasks.md
= checklist de implementación del cambio seleccionado
```

Es normal que exista cierto solapamiento. El objetivo del Día 3 es que el participante conozca el flujo completo estándar de OpenSpec y, al mismo tiempo, conserve GitHub como plataforma operativa del producto.

## Criterio de salida

- existe evidencia de Discovery en los tres repos;
- los hallazgos fueron revisados humanamente;
- hay issues distribuidos entre los repositorios;
- esos issues aparecen coordinados en ReqFlow Project;
- hay exactamente un issue de FastAPI seleccionado para S4;
- el participante puede explicar que ese Issue convivirá en S4 con `tasks.md` de OpenSpec.
