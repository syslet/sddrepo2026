# 📚 Guía de Provisión Automática de Repositorios

## 🎯 Objetivo de la Automatización

Este sistema automatiza completamente el proceso de creación de repositorios en la organización **CIX-SOFTWARE-LABS**, eliminando tareas manuales y garantizando que todos los repositorios se configuren de manera estandarizada y segura.

### ¿Qué resuelve esta automatización?

- ✅ **Elimina procesos manuales** tediosos y propensos a errores
- ✅ **Estandariza la configuración** de todos los repositorios del equipo
- ✅ **Asegura la asignación correcta** de permisos y equipos desde el inicio
- ✅ **Reduce tiempo de setup** de horas a segundos (30-60 seg aprox.)
- ✅ **Garantiza el uso de templates** aprobados y actualizados

---

## ⚠️ Prerrequisitos

Antes de solicitar un nuevo repositorio, asegúrate de:

1. **✅ Equipos Enterprise IdP creados:**
   - Tu código de proyecto debe tener equipos ya configurados en la organización:
     - `<TU-CÓDIGO>-ADMIN`
     - `<TU-CÓDIGO>-DEVELOPERS`
   - Si no existen, contacta al equipo de Platform Engineering

2. **✅ Permisos de acceso:**
   - Debes tener acceso al repositorio [devo-self-service-portal](https://github.com/CIX-SOFTWARE-LABS/devo-self-service-portal)
   - Debes poder crear issues en la organización

3. **✅ Decisión de template:**
   - Define claramente si necesitas Azure Functions o una Library
   - Revisa la documentación de cada template antes de elegir

---

## 🚀 Cómo Usar la Herramienta

### Paso 1: Acceder al Portal de Self-Service

1. Navega al repositorio: **[devo-self-service-portal](https://github.com/CIX-SOFTWARE-LABS/devo-self-service-portal)**
2. Ve a la pestaña **"Issues"**
3. Haz clic en **"New Issue"**
4. Selecciona la plantilla: **"Nuevo repositorio (CIX-SOFTWARE-LABS)"**

### Paso 2: Completar el Formulario

El formulario te solicitará la siguiente información:

#### 📦 **Código de Proyecto** (Requerido)
Selecciona el código de tu proyecto desde el menú desplegable:

- `TESR` - Codigo de laboratorio.
- `CFZD` - Codigo de laboratorio.
- `PREC` - Codigo de laboratorio.
- `CWAP` - Codigo de laboratorio.
- `IREC` - Codigo de laboratorio.
- `CIXT` - Codigo de laboratorio.
- `XPAY` - Codigo de laboratorio.
- `CROS` - Codigo de laboratorio.
- `CRYP` - Codigo de laboratorio.

**Nota:** Este código se usará para:
- Formar el nombre del repositorio
- Asignar equipos de manera automática (`<CÓDIGO>-ADMIN` y `<CÓDIGO>-DEVELOPERS`)

#### 📝 **Nombre del Repositorio** (Requerido)
Escribe **solo el nombre descriptivo** del repositorio, sin incluir el código del proyecto.

**Formato:** minúsculas con guiones (`-`) para separar palabras

**Ejemplos correctos:**
- ✅ `payment-gateway-api` (para Azure Functions de API de pagos)
- ✅ `user-authentication-service` (para servicio de autenticación)
- ✅ `order-processor-function` (para función de procesamiento)
- ✅ `http-client-library` (para librería compartida)
- ✅ `logging-utils-package` (para paquete de utilidades)

**Errores comunes:**
- ❌ `TESR-payment-api` (no incluir el código del proyecto)
- ❌ `payment_api` (usar guiones `-`, no underscores `_`)
- ❌ `PaymentAPI` (no usar mayúsculas o CamelCase)
- ❌ `payment api` (no usar espacios)

**Resultado final:** El sistema combinará automáticamente el código y nombre:
```
<código>-<nombre>
Ejemplo: tesr-payment-gateway-api
```

#### 🎨 **Template del Repositorio** (Requerido)
Selecciona el template según el tipo de proyecto:

| Template | Descripción | Uso Específico |
|----------|-------------|----------------|
| **template-repo-functions** | Template para Azure Functions | Desarrollo de funciones serverless en Azure. Incluye workflows de CI/CD para despliegue automático a Azure Function Apps. |
| **template-repo-library** | Template para librerías y paquetes | Desarrollo de librerías compartidas con despliegue automático a GitHub Packages (npm, Maven, NuGet, etc.). Ideal para SDKs y módulos reutilizables. |

**¿Cuál debo elegir?**
- 🔵 **Azure Functions**: Si tu proyecto es un backend serverless, APIs REST, procesamiento de eventos, o cualquier función que se ejecute en Azure.
- 📦 **Library/Package**: Si estás creando código que será consumido por otros proyectos (librerías, utilidades, SDKs, wrappers).

#### 📄 **Descripción del Repositorio** (Opcional)
Una breve descripción del propósito del repositorio. Esta descripción aparecerá en GitHub.

**Ejemplo:** 
> API serverless para gestión de órdenes del sistema de pagos centralizado

### Paso 3: Enviar la Solicitud

1. Revisa que toda la información sea correcta
2. Haz clic en **"Submit new issue"**
3. **¡Listo!** El proceso se ejecutará automáticamente

### Paso 4: Seguimiento del Proceso

Una vez enviado el issue:

1. **Recibirás actualizaciones en tiempo real** en los comentarios del issue
2. Verás el progreso con checkboxes:
   - ✅ Parseo de solicitud
   - ✅ Autenticación del App
   - ✅ Creación del repositorio
   - ✅ Creación/asignación de equipos
   - ✅ Resultado final

3. Al finalizar exitosamente:
   - Recibirás un comentario con el **enlace al repositorio creado**
   - El issue se **cerrará automáticamente**
   - El repositorio estará **listo para usar**

---

## 📋 Información que Debes Proporcionar

### Resumen de Campos

| Campo | Obligatorio | Descripción | Ejemplo |
|-------|-------------|-------------|---------|
| **Código de Proyecto** | ✅ Sí | Código del equipo/proyecto | `TESR` |
| **Nombre del Repositorio** | ✅ Sí | Nombre descriptivo (sin código) | `payment-gateway-api` |
| **Template** | ✅ Sí | Tipo de proyecto | `template-repo-functions` |
| **Descripción** | ⚪ No | Descripción del propósito | "API serverless para pagos" |

### Ejemplos Completos

#### Ejemplo 1: Azure Function
```yaml
Código de Proyecto: XPAY
Nombre del Repositorio: transaction-processor-function
Template: template-repo-functions
Descripción: Azure Function para procesamiento de transacciones en tiempo real
```

**Resultado:**
- 📦 Repositorio creado: `xpay-transaction-processor-function`
- 👥 Equipos asignados:
  - `XPAY-ADMIN` (permiso: admin)
  - `XPAY-DEVELOPERS` (permiso: push)
- 🔒 Visibilidad: Private
- 🎨 Template aplicado: template-repo-functions
- 🚀 Preparado para: Despliegue a Azure Functions

#### Ejemplo 2: Librería/Package
```yaml
Código de Proyecto: CIXT
Nombre del Repositorio: http-client-library
Template: template-repo-library
Descripción: Librería compartida para cliente HTTP con retry y circuit breaker
```

**Resultado:**
- 📦 Repositorio creado: `cixt-http-client-library`
- 👥 Equipos asignados:
  - `CIXT-ADMIN` (permiso: admin)
  - `CIXT-DEVELOPERS` (permiso: push)
- 🔒 Visibilidad: Private
- 🎨 Template aplicado: template-repo-library
- 📦 Preparado para: Publicación en GitHub Packages

---

## 🎯 Alcance de la Automatización

### ✅ Lo que la Automatización HACE

1. **Creación del Repositorio**
   - Crea el repositorio en la organización `CIX-SOFTWARE-LABS`
   - Aplica el template seleccionado (estructura, archivos base, workflows)
   - Establece visibilidad como **private** automáticamente
   - Normaliza el nombre a minúsculas con formato estándar

2. **Configuración de Equipos**
   - Identifica equipos Enterprise IdP existentes:
     - `<CÓDIGO>-ADMIN` → Permiso: **admin**
     - `<CÓDIGO>-DEVELOPERS` → Permiso: **push** (write)
   - Asigna permisos automáticamente
   - Prueba múltiples formatos de slug para máxima compatibilidad

3. **Configuración Inicial**
   - Inicializa el repositorio con el contenido del template
   - Configura issues habilitados
   - Prepara README.md y archivos de configuración del template
   - **template-repo-functions**: Incluye workflows para despliegue a Azure Functions
   - **template-repo-library**: Incluye workflows para publicación en GitHub Packages

4. **Notificaciones y Seguimiento**
   - Comentarios en tiempo real del progreso
   - Enlace directo al repositorio creado
   - Cierre automático del issue al completar
   - Logs detallados para troubleshooting

### ⚠️ Lo que la Automatización NO HACE

1. **No crea equipos nuevos**
   - Los equipos deben existir previamente en tu Enterprise IdP
   - Formato esperado: `<CÓDIGO>-ADMIN` y `<CÓDIGO>-DEVELOPERS`
   - Si no existen, recibirás una advertencia pero el repo se creará

2. **No configura protecciones de rama**
   - Las branch protection rules deben configurarse manualmente
   - Se recomienda proteger `main` después de la creación

3. **No clona el código localmente**
   - Debes clonar el repositorio manualmente después de crearlo:
     ```bash
     git clone https://github.com/CIX-SOFTWARE-LABS/<nombre-repo>.git
     ```

4. **No configura secretos ni variables**
   - Los secrets y variables de CI/CD deben agregarse manualmente
   - Accede a Settings → Secrets and variables → Actions

5. **No personaliza el contenido del template**
   - El template se aplica tal cual está definido
   - Las personalizaciones deben hacerse después de clonar el repo

---

## 🔧 Próximos Pasos Después de la Creación

Una vez que tu repositorio esté creado:

### 1. Clonar el Repositorio
```bash
git clone https://github.com/CIX-SOFTWARE-LABS/<tu-repo>.git
cd <tu-repo>
```

### 2. Revisar el Template y Configurar según el Tipo

#### Si elegiste **template-repo-functions** (Azure Functions):
- 📖 Lee el `README.md` para entender la estructura del proyecto
- 🔧 Revisa los workflows en `.github/workflows/` (CI/CD para Azure)
- ⚙️ Configura las variables necesarias para Azure:
  - `AZURE_FUNCTIONAPP_NAME`
  - `AZURE_FUNCTIONAPP_PUBLISH_PROFILE` (secret)
- 🧪 Prueba la función localmente con Azure Functions Core Tools
- 📝 Actualiza el `host.json` y `local.settings.json` según tus necesidades

#### Si elegiste **template-repo-library** (GitHub Packages):
- 📖 Lee el `README.md` para entender cómo publicar tu librería
- 📦 Revisa el workflow de publicación en `.github/workflows/`
- 🏷️ Configura el `package.json` (npm) o archivo equivalente según tu lenguaje
- 🔐 Verifica que el token `GITHUB_TOKEN` tenga permisos para packages
- 📚 Documenta la API de tu librería en el README
- 🧪 Configura tests antes de publicar

### 3. Configurar Protecciones (Recomendado)
- Ve a Settings → Branches
- Agrega reglas de protección para `main`:
  - ✅ Require pull request reviews
  - ✅ Require status checks to pass
  - ✅ Require branches to be up to date

### 4. Agregar Secretos y Variables

#### Para Azure Functions (template-repo-functions):
- Settings → Secrets and variables → Actions
- **Secrets requeridos:**
  - `AZURE_FUNCTIONAPP_PUBLISH_PROFILE`: Perfil de publicación de Azure
  - Otros secrets específicos de tu función (connection strings, API keys, etc.)
- **Variables recomendadas:**
  - `AZURE_FUNCTIONAPP_NAME`: Nombre de tu Function App en Azure
  - `AZURE_REGION`: Región de Azure (ej: eastus, westeurope)

#### Para Libraries (template-repo-library):
- Settings → Secrets and variables → Actions
- **Token automático:** `GITHUB_TOKEN` (ya configurado por defecto)
- **Secrets opcionales:**
  - Tokens para otros registros de paquetes (npm, PyPI, Maven Central)
- **Variables recomendadas:**
  - `PACKAGE_NAME`: Nombre del paquete
  - `REGISTRY_URL`: URL del registro si usas uno personalizado

### 5. Comenzar a Desarrollar 🚀
```bash
git checkout -b feature/mi-primera-feature
# ... hacer cambios ...
git add .
git commit -m "feat: implementar funcionalidad inicial"
git push origin feature/mi-primera-feature
```

---

## 🆘 Soporte y Troubleshooting

### Problemas Comunes

#### ❌ "Equipos no encontrados"
**Causa:** Los equipos `<CÓDIGO>-ADMIN` o `<CÓDIGO>-DEVELOPERS` no existen en Enterprise IdP

**Solución:** 
1. Verifica que los equipos existan en la organización
2. Asigna permisos manualmente desde Settings → Collaborators and teams

#### ❌ "Template no se aplicó"
**Causa:** El GitHub App puede no tener permisos para usar templates

**Solución:** 
- El sistema creará un issue en el nuevo repo con instrucciones para aplicar el template manualmente
- Sigue las instrucciones del issue automático

#### ❌ "Nombre de repositorio inválido"
**Causa:** El nombre contiene caracteres no permitidos

**Solución:**
- Usa solo letras minúsculas, números y guiones
- No uses espacios, underscores ni caracteres especiales

### ¿Necesitas Ayuda?

- 📖 **Documentación de templates:**
  - [template-repo-functions](https://github.com/CIX-SOFTWARE-LABS/template-repo-functions) - Para Azure Functions
  - [template-repo-library](https://github.com/CIX-SOFTWARE-LABS/template-repo-library) - Para GitHub Packages

- 🐛 **Reportar problemas:**
  - Abre un issue en [devo-self-service-portal](https://github.com/CIX-SOFTWARE-LABS/devo-self-service-portal/issues)
  - Incluye el número del issue de provisión original
  - Describe el problema con el mayor detalle posible

- 📚 **Recursos adicionales:**
  - [Documentación oficial de Azure Functions](https://docs.microsoft.com/azure/azure-functions/)
  - [Guía de GitHub Packages](https://docs.github.com/packages)
  - [Workflows de GitHub Actions](https://docs.github.com/actions)

- 💬 **Contacto:**
  - Equipo de DevOps/Platform Engineering
  - Canal de Slack: #cix-platform-support (si aplica)
  - Email: platform-engineering@cix.com (ajustar según tu org)

---

## 📊 Tiempos Estimados

| Proceso | Tiempo |
|---------|--------|
| Completar formulario | 1-2 minutos |
| Ejecución automática | 30-60 segundos |
| **Total** | **~2-3 minutos** |

Comparado con el proceso manual (1-2 horas), esta automatización te ahorra **95% del tiempo** ⚡

---

## ✨ Mejores Prácticas

### General
1. **Nomenclatura consistente:** Usa nombres descriptivos y claros que reflejen el propósito
2. **Template adecuado:** 
   - ¿Es código que SE EJECUTA? → `template-repo-functions` (Azure Functions)
   - ¿Es código que SE CONSUME? → `template-repo-library` (GitHub Packages)
3. **Descripción clara:** Aunque es opcional, ayuda mucho a otros desarrolladores
4. **Verifica equipos:** Confirma que tus equipos IdP existan ANTES de crear el issue
5. **Revisa el template:** Estudia el README del template antes de empezar a desarrollar

### Para Azure Functions
- 🔐 Nunca commitees credenciales en `local.settings.json` (está en .gitignore)
- 🧪 Prueba localmente antes de hacer push
- 📊 Implementa logging adecuado desde el inicio
- ⚡ Optimiza el cold start (tamaño del código, dependencias)
- 🏷️ Usa tags semánticos para deployments (`v1.0.0`, `v1.1.0`)

### Para Libraries/Packages
- 📝 Documenta bien tu API pública desde el principio
- 🔢 Sigue versionado semántico estrictamente (SemVer)
- 🧪 Mantén alta cobertura de tests (mínimo 80%)
- 📋 Incluye ejemplos de uso en el README
- 🔄 Documenta cambios en CHANGELOG.md
- ⚠️ Marca breaking changes claramente en las release notes

---

---

## ❓ FAQ - Preguntas Frecuentes

### ¿Puedo cambiar el template después de crear el repositorio?
No automáticamente. Tendrías que aplicar los cambios manualmente o crear un nuevo repositorio. Es importante elegir bien desde el inicio.

### ¿Qué pasa si mis equipos IdP no existen?
El repositorio se creará de todas formas, pero recibirás una advertencia. Deberás asignar permisos manualmente o solicitar la creación de los equipos.

### ¿Puedo crear repositorios públicos?
No, todos los repositorios se crean como **private** por políticas de seguridad de la organización.

### ¿Cuántos repositorios puedo crear?
No hay límite técnico, pero se recomienda crear repositorios con propósitos claros y bien definidos.

### ¿Puedo eliminar un repositorio creado por error?
Sí, pero debes tener permisos de admin. Es mejor contactar al equipo de Platform Engineering para repositorios críticos.

### ¿El template incluye todo lo necesario para CI/CD?
Sí, ambos templates incluyen workflows básicos de CI/CD. Deberás configurar los secrets y variables específicos de tu proyecto.

### ¿Puedo modificar los workflows del template?
¡Por supuesto! Los workflows son un punto de partida. Personalízalos según tus necesidades específicas.

### ¿Cómo actualizo mi repo si el template cambia?
Los cambios al template no se aplican automáticamente. Deberás hacer merge manual de los cambios que desees adoptar.

---

**Versión:** 2.0  
**Última actualización:** Diciembre 2025  
**Mantenido por:** Equipo de Platform Engineering - CIX
