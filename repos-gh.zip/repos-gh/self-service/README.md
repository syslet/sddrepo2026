# self-service

Self-service para crear los 3 repositorios del workshop en la **cuenta personal** de cada usuario, vía issue.

## Flujo

1. El usuario abre un issue con la plantilla "Crear mis repositorios del workshop".
2. El workflow [new-repo.yml](.github/workflows/new-repo.yml) inicia un OAuth Device Flow y comenta un código en el issue.
3. El usuario autoriza en `https://github.com/login/device`.
4. El workflow valida que la cuenta autorizada sea el autor del issue y genera los repos desde los templates, con `owner` = usuario.
5. Comenta los enlaces y cierra el issue.

## Configuración (una sola vez)

1. **OAuth App** (Settings > Developer settings > OAuth Apps > New): marcar **Enable Device Flow**. Callback URL cualquiera (ej. la URL de este repo).
2. Guardar el **Client ID** como variable del repo: `WORKSHOP_OAUTH_CLIENT_ID` (Settings > Secrets and variables > Actions > Variables). No requiere client secret.
3. Crear el label `new-repo` en este repositorio.
4. Los 3 repos `NTTData-Academy/workshop-*-template` deben ser **públicos** y tener activado **Template repository** (Settings > General). Si son privados, solo podrán usarlos miembros de la organización.