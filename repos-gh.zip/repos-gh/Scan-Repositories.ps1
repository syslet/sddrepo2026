[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
Get-Command gh -ErrorAction Stop | Out-Null

$response = & gh api --paginate --slurp 'orgs/NTTData-Academy/repos?type=all&per_page=100'
if ($LASTEXITCODE -ne 0) {
    throw 'Unable to list repositories. Check gh auth status and organization access.'
}

$pages = ($response -join "`n") | ConvertFrom-Json
$repositories = @(
    foreach ($page in $pages) {
        foreach ($repository in $page) {
            [PSCustomObject]@{
                name           = $repository.name
                clone_url      = $repository.clone_url
                visibility     = $repository.visibility
                default_branch = $repository.default_branch
                archived       = $repository.archived
            }
        }
    }
) | Sort-Object name

if (@($repositories).Count -eq 0) {
    throw 'No accessible repositories found. The existing inventory was not changed.'
}

$manifestPath = Join-Path $PSScriptRoot 'repositories.json'
ConvertTo-Json -InputObject @($repositories) -Depth 4 |
    Set-Content -LiteralPath $manifestPath -Encoding UTF8
$repositories | Format-Table name, visibility, default_branch, archived -AutoSize
Write-Host "Saved $(@($repositories).Count) repositories to $manifestPath"
